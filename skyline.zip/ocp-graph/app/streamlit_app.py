"""Streamlit UI: pick a channel, see how far behind the cluster is and the
upgrade path (optionally restricted to releases mirrored in Nexus).

Reads parquet directly via DuckDB — Postgres is a downstream sink for other
consumers, not a dependency of this UI.
"""

import os
from pathlib import Path

import duckdb
import streamlit as st

DATA_DIR = Path(os.environ.get("DATA_DIR", "/data"))
P = lambda t: str(DATA_DIR / "parquet" / t / "*" / "*.parquet")  # noqa: E731

st.set_page_config(page_title="OCP Upgrade Graph", layout="wide")
st.title("OpenShift upgrade graph")


@st.cache_resource
def db():
    con = duckdb.connect()
    for t in ["channels", "graph_nodes", "graph_edges", "cluster_state",
              "nexus_releases"]:
        if list((DATA_DIR / "parquet" / t).glob("*/*.parquet")):
            con.execute(f"""CREATE VIEW {t} AS
                SELECT * FROM read_parquet('{P(t)}', hive_partitioning=true)""")
    return con


con = db()
tables = {r[0] for r in con.execute("SHOW TABLES").fetchall()}
if "graph_edges" not in tables:
    st.warning("No snapshots yet — wait for the first ingest run.")
    st.stop()

# ---- sidebar --------------------------------------------------------------
chans = [r[0] for r in con.execute(
    "SELECT DISTINCT channel FROM graph_edges ORDER BY channel").fetchall()]

cluster_ver, cluster_chan = None, None
if "cluster_state" in tables:
    row = con.execute(
        "SELECT version, channel FROM cluster_state "
        "ORDER BY snapshot_ts DESC LIMIT 1").fetchone()
    if row:
        cluster_ver, cluster_chan = row

channel = st.sidebar.selectbox(
    "Channel", chans,
    index=chans.index(cluster_chan) if cluster_chan in chans else 0)
from_ver = st.sidebar.text_input("From version", value=cluster_ver or "")
only_nexus = st.sidebar.checkbox("Only releases mirrored in Nexus",
                                 disabled="nexus_releases" not in tables)

# ---- headline metrics -----------------------------------------------------
latest_in_chan = con.execute("""
    SELECT max(version) FROM (
      SELECT version FROM graph_nodes
      WHERE channel = ? AND snapshot_ts = (
        SELECT max(snapshot_ts) FROM graph_nodes WHERE channel = ?))
""", [channel, channel]).fetchone()[0]

c1, c2, c3 = st.columns(3)
c1.metric("Cluster version", cluster_ver or "n/a")
c2.metric(f"Latest in {channel}", latest_in_chan or "n/a")
if "nexus_releases" in tables:
    n = con.execute("""SELECT count(DISTINCT tag) FROM nexus_releases
        WHERE snapshot_ts = (SELECT max(snapshot_ts) FROM nexus_releases)"""
                    ).fetchone()[0]
    c3.metric("Releases in Nexus", n)

# ---- upgrade paths --------------------------------------------------------
if from_ver:
    nexus_filter = """
      AND to_version IN (SELECT tag FROM nexus_releases
        WHERE snapshot_ts = (SELECT max(snapshot_ts) FROM nexus_releases))
    """ if only_nexus else ""

    paths = con.execute(f"""
      WITH RECURSIVE latest AS (
        SELECT max(snapshot_ts) ts FROM graph_edges WHERE channel = ?),
      edges AS (
        SELECT from_version, to_version FROM graph_edges, latest
        WHERE channel = ? AND snapshot_ts = latest.ts {nexus_filter}),
      walk(version, path, hops) AS (
        SELECT ?, [?], 0
        UNION ALL
        SELECT e.to_version, list_append(w.path, e.to_version), w.hops + 1
        FROM walk w JOIN edges e ON e.from_version = w.version
        WHERE NOT list_contains(w.path, e.to_version) AND w.hops < 12)
      SELECT version AS reachable, hops,
             array_to_string(path, ' \u2192 ') AS shortest_path
      FROM walk WHERE hops > 0
      QUALIFY row_number() OVER (PARTITION BY version ORDER BY hops) = 1
      ORDER BY string_split(version, '.')[1]::INT,
               string_split(version, '.')[2]::INT,
               string_split(version, '.')[3]::INT DESC
    """, [channel, channel, from_ver, from_ver]).df()

    st.subheader(f"Reachable from {from_ver} on {channel}")
    if paths.empty:
        st.info("No outgoing edges — version not in this channel, a dead-end, "
                "or (with the Nexus filter) targets aren't mirrored yet.")
    else:
        st.dataframe(paths, use_container_width=True, hide_index=True)

# ---- raw channel membership ----------------------------------------------
with st.expander("Channel membership (latest snapshot)"):
    st.dataframe(con.execute("""
        SELECT version FROM channels
        WHERE channel = ? AND snapshot_ts = (
          SELECT max(snapshot_ts) FROM channels)
        ORDER BY string_split(version, '.')[1]::INT,
                 string_split(version, '.')[2]::INT,
                 string_split(version, '.')[3]::INT DESC
    """, [channel]).df(), hide_index=True)
