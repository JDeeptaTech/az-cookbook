"""Push parquet snapshots to PostgreSQL, incrementally by snapshot_ts.

Uses DuckDB's postgres extension: no pandas roundtrip, single COPY-speed
INSERT ... SELECT read_parquet(). Idempotent: only snapshots newer than
max(snapshot_ts) already in Postgres are pushed.

Env: PG_DSN  e.g. "host=pg.corp port=5432 dbname=ocp user=loader password=..."
     DATA_DIR (default /data)
"""

import os
from pathlib import Path

import duckdb

DATA_DIR = Path(os.environ.get("DATA_DIR", "/data"))
TABLES = ["channels", "graph_nodes", "graph_edges", "cluster_state", "nexus_releases"]


def run_push():
    dsn = os.environ.get("PG_DSN")
    if not dsn:
        print("push: PG_DSN not set, skipping")
        return

    con = duckdb.connect()
    con.execute("LOAD postgres;")  # pre-installed in the image
    con.execute("ATTACH ? AS pg (TYPE postgres);", [dsn])

    for table in TABLES:
        glob = str(DATA_DIR / "parquet" / table / "*" / "*.parquet")
        if not list((DATA_DIR / "parquet" / table).glob("*/*.parquet")):
            continue

        con.execute(f"""
            CREATE TABLE IF NOT EXISTS pg.{table} AS
            SELECT * EXCLUDE (snapshot_date)
            FROM read_parquet('{glob}', hive_partitioning=true) LIMIT 0;
        """)
        pushed = con.execute(f"""
            INSERT INTO pg.{table}
            SELECT * EXCLUDE (snapshot_date)
            FROM read_parquet('{glob}', hive_partitioning=true)
            WHERE snapshot_ts > coalesce(
                (SELECT max(snapshot_ts) FROM pg.{table}),
                TIMESTAMPTZ '1970-01-01');
        """).fetchall()
        print(f"push: {table}: {pushed[0][0] if pushed else 0} rows")

    con.close()


if __name__ == "__main__":
    run_push()
