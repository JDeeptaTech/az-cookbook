"""Scheduler process: run ingest then postgres push on a cron schedule.

Env: INGEST_CRON  (default "0 */6 * * *" = every 6h)
     RUN_ON_START (default "true")
"""

import os

from apscheduler.schedulers.blocking import BlockingScheduler
from apscheduler.triggers.cron import CronTrigger

from ingest import run_ingest
from push_postgres import run_push


def job():
    try:
        run_ingest()
        run_push()
    except Exception as exc:  # keep the scheduler alive on transient failures
        print(f"scheduler: job failed: {exc!r}")


def main():
    cron = os.environ.get("INGEST_CRON", "0 */6 * * *")
    if os.environ.get("RUN_ON_START", "true").lower() == "true":
        job()
    sched = BlockingScheduler(timezone="UTC")
    sched.add_job(job, CronTrigger.from_crontab(cron),
                  max_instances=1, coalesce=True, misfire_grace_time=3600)
    print(f"scheduler: running with cron '{cron}' (UTC)")
    sched.start()


if __name__ == "__main__":
    main()
