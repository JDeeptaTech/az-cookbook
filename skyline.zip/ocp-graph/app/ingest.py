"""Fetch Cincinnati graph / cluster version / Nexus tags -> hive-partitioned parquet.

Layout:  {DATA_DIR}/parquet/{table}/snapshot_date=YYYY-MM-DD/part-{epoch}.parquet
Tables:  channels, graph_nodes, graph_edges, cluster_state, nexus_releases
"""

import io
import os
import tarfile
import time
from datetime import datetime, timezone
from pathlib import Path

import pyarrow as pa
import pyarrow.parquet as pq
import requests
import yaml

OSUS = "https://api.openshift.com/api/upgrades_info"
TIMEOUT = 60
DATA_DIR = Path(os.environ.get("DATA_DIR", "/data"))


def fetch_channel_index() -> dict[str, list[str]]:
    r = requests.get(f"{OSUS}/graph-data", timeout=TIMEOUT)
    r.raise_for_status()
    channels: dict[str, list[str]] = {}
    with tarfile.open(fileobj=io.BytesIO(r.content), mode="r:*") as tar:
        for m in tar.getmembers():
            if m.name.startswith("channels/") and m.name.endswith(".yaml"):
                doc = yaml.safe_load(tar.extractfile(m).read())
                channels[doc["name"]] = doc.get("versions", [])
    return channels


def fetch_graph(channel: str, arch: str):
    r = requests.get(f"{OSUS}/v1/graph", params={"channel": channel, "arch": arch},
                     headers={"Accept": "application/json"}, timeout=TIMEOUT)
    r.raise_for_status()
    g = r.json()
    nodes = g.get("nodes", [])
    edges = [(nodes[a]["version"], nodes[b]["version"]) for a, b in g.get("edges", [])]
    return nodes, edges


def fetch_cluster_version():
    api, token = os.environ.get("OC_API"), os.environ.get("OC_TOKEN")
    if not (api and token):
        return None
    r = requests.get(
        f"{api.rstrip('/')}/apis/config.openshift.io/v1/clusterversions/version",
        headers={"Authorization": f"Bearer {token}"},
        verify=os.environ.get("OC_CA_CERT", True), timeout=TIMEOUT)
    r.raise_for_status()
    cv = r.json()
    return cv["status"]["desired"]["version"], cv["spec"].get("channel", "")


def fetch_nexus_tags() -> list[str]:
    base, image = os.environ.get("NEXUS_URL"), os.environ.get("NEXUS_IMAGE")
    if not (base and image):
        return []
    auth = ((os.environ["NEXUS_USER"], os.environ.get("NEXUS_PASS", ""))
            if os.environ.get("NEXUS_USER") else None)
    tags, last = [], None
    while True:
        params = {"n": 500, **({"last": last} if last else {})}
        r = requests.get(f"{base.rstrip('/')}/v2/{image}/tags/list",
                         params=params, auth=auth, timeout=TIMEOUT)
        r.raise_for_status()
        batch = r.json().get("tags") or []
        tags.extend(batch)
        if len(batch) < 500:
            return tags
        last = batch[-1]


def _write(table: str, rows: list[dict], ts: datetime):
    if not rows:
        return
    part = DATA_DIR / "parquet" / table / f"snapshot_date={ts:%Y-%m-%d}"
    part.mkdir(parents=True, exist_ok=True)
    pq.write_table(pa.Table.from_pylist(rows),
                   part / f"part-{int(time.time())}.parquet",
                   compression="zstd")


def run_ingest():
    ts = datetime.now(timezone.utc)
    arch = os.environ.get("ARCH", "amd64")
    wanted = [c.strip() for c in os.environ.get("CHANNELS", "").split(",") if c.strip()]

    index = fetch_channel_index()
    if not wanted:
        wanted = list(index)

    _write("channels",
           [{"snapshot_ts": ts, "channel": c, "version": v}
            for c, vs in index.items() for v in vs], ts)

    nodes_rows, edges_rows = [], []
    for ch in wanted:
        if ch not in index:
            print(f"ingest: skipping unknown channel {ch}")
            continue
        nodes, edges = fetch_graph(ch, arch)
        nodes_rows += [{"snapshot_ts": ts, "channel": ch, "arch": arch,
                        "version": n["version"], "payload": n.get("payload")}
                       for n in nodes]
        edges_rows += [{"snapshot_ts": ts, "channel": ch, "arch": arch,
                        "from_version": a, "to_version": b} for a, b in edges]
        print(f"ingest: {ch}: {len(nodes)} nodes / {len(edges)} edges")
    _write("graph_nodes", nodes_rows, ts)
    _write("graph_edges", edges_rows, ts)

    cv = fetch_cluster_version()
    if cv:
        _write("cluster_state",
               [{"snapshot_ts": ts, "version": cv[0], "channel": cv[1]}], ts)

    tags = fetch_nexus_tags()
    if tags:
        _write("nexus_releases",
               [{"snapshot_ts": ts, "image": os.environ["NEXUS_IMAGE"], "tag": t}
                for t in tags], ts)

    print(f"ingest: snapshot {ts.isoformat()} complete")
    return ts


if __name__ == "__main__":
    run_ingest()
