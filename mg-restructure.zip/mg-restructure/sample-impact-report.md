# Management group restructure: impact report

Generated 2026-11-10 18:36 from `target-hierarchy.json` (Archetype layout). Subscriptions changing: **15**.

> 15 mapping row(s) are not confirmed yet: Design Subscription, n0001aks, n0002app, n0003data, n0004ss, n00bs66, Non-Production Subscription, Non-Production Subscription 2, p0001app, p0001hub, p0002data, p0004ss, p0005aks, Production Subscription, s0001lab.

## Summary

| Subscription | From | To | Blocker | High | Medium | Low |
|---|---|---|---|---|---|---|
| Design Subscription | tenant-0000 | bd-sandbox | 0 | 3 | 0 | 1 |
| n0001aks | Default | bd-corp | 1 | 6 | 1 | 3 |
| n0002app | bd-legacy-dev | bd-corp | 0 | 0 | 0 | 0 |
| n0003data | bd-legacy-dev | bd-corp | 0 | 0 | 0 | 0 |
| n0004ss | Default | bd-management | 0 | 6 | 1 | 3 |
| n00bs66 | Default | bd-corp | 0 | 6 | 1 | 3 |
| Non-Production Subscription | tenant-0000 | bd-corp | 0 | 3 | 0 | 1 |
| Non-Production Subscription 2 | Default | bd-corp | 0 | 6 | 1 | 3 |
| p0001app | bd-legacy-prod | bd-corp | 0 | 2 | 0 | 0 |
| p0001hub | bd-shared | bd-connectivity | 0 | 0 | 0 | 0 |
| p0002data | bd-legacy-prod | bd-corp | 0 | 2 | 0 | 0 |
| p0004ss | Default | bd-management | 0 | 6 | 1 | 3 |
| p0005aks | Default | bd-corp | 1 | 6 | 1 | 3 |
| Production Subscription | tenant-0000 | bd-corp | 0 | 3 | 0 | 1 |
| s0001lab | bd-shared | bd-sandbox | 0 | 0 | 0 | 0 |

## Blockers (fix before moving)

- **n0001aks**: AKS Operator on <sub> - assignable scopes: /providers/Microsoft.Management/managementGroups/Default. Azure will refuse the move: add the target (or a common ancestor) to the role's assignable scopes, or remove the assignment
- **p0005aks**: AKS tag inheritance - definition stored on management group 'Default'. Move the custom definition to a common ancestor (intermediate root 'bd') before moving

## Management groups left empty

- Legacy Prod (`bd-legacy-prod`): 1 policy assignment(s) to retire or re-home, 1 role assignment(s). Delete after the last wave.
- Legacy Dev (`bd-legacy-dev`). Delete after the last wave.
- Shared (`bd-shared`). Delete after the last wave.
- Archive (`bd-archive`). Delete after the last wave.
- Default (`Default`): 1 policy assignment(s) to retire or re-home, 2 role assignment(s). Delete after the last wave (repoint the default management group first).

## Detail by subscription

### Design Subscription

`tenant-0000` → `bd-sandbox > bd > tenant-0000`

| Severity | Category | Change | Item | Detail | Action |
|---|---|---|---|---|---|
| High | Policy | Gain | Azure Security Benchmark | Deny:1 DeployIfNotExists:1 Audit:1 | Can block create/update (incl. Terraform applies). Preview with 03, add exemptions or fix resources first |
| High | Policy | Gain | Deny public IPs | Deny:1 | Can block create/update (incl. Terraform applies). Preview with 03, add exemptions or fix resources first |
| High | RBAC | Gain | Owner: Platform-Admins (Group) | new inherited access | Security review: privileged access gained |
| Low | RBAC | Gain | Reader: Platform-Readers (Group) | new inherited access | None |

### n0001aks

`Default > tenant-0000` → `bd-corp > bd-landingzones > bd > tenant-0000`

| Severity | Category | Change | Item | Detail | Action |
|---|---|---|---|---|---|
| Blocker | Blocker | CustomRole | AKS Operator on <sub> | assignable scopes: /providers/Microsoft.Management/managementGroups/Default | Azure will refuse the move: add the target (or a common ancestor) to the role's assignable scopes, or remove the assignment |
| High | Cost | Lose | Reservation D4s_v5 x20 (AKS) | scoped to management group 'Default': this subscription stops receiving the discount | Rescope the reservation (shared / target MG) before moving |
| High | Policy | Gain | Azure Security Benchmark | Deny:1 DeployIfNotExists:1 Audit:1 | Can block create/update (incl. Terraform applies). Preview with 03, add exemptions or fix resources first |
| High | Policy | Gain | Deny public IPs | Deny:1 | Can block create/update (incl. Terraform applies). Preview with 03, add exemptions or fix resources first |
| High | RBAC | Lose | Owner: AKS-Admins (Group) | access inherited from this management group is removed | Confirm nobody needs it, or assign at the target / subscription before moving |
| High | RBAC | Lose | Contributor: n-dev-team (Group) | access inherited from this management group is removed | Confirm nobody needs it, or assign at the target / subscription before moving |
| High | RBAC | Gain | Owner: Platform-Admins (Group) | new inherited access | Security review: privileged access gained |
| Medium | Exemption | Lose | AKS outside allowed regions | exemption for allowed-loc no longer applies | Resources it covered may become non-compliant or be denied: recreate at the target or subscription scope |
| Low | Cost | Lose | Budget aks-monthly | spend no longer counted in this management-group budget | Adjust budget amounts |
| Low | Policy | Lose | Audit VMs without managed disks | Audit:1 | Audit coverage removed |
| Low | RBAC | Gain | Reader: Platform-Readers (Group) | new inherited access | None |

### n0002app

`bd-legacy-dev > bd > tenant-0000` → `bd-corp > bd-landingzones > bd > tenant-0000`

No inherited policy, access or cost changes.

### n0003data

`bd-legacy-dev > bd > tenant-0000` → `bd-corp > bd-landingzones > bd > tenant-0000`

No inherited policy, access or cost changes.

### n0004ss

`Default > tenant-0000` → `bd-management > bd-platform > bd > tenant-0000`

| Severity | Category | Change | Item | Detail | Action |
|---|---|---|---|---|---|
| High | Cost | Lose | Reservation D4s_v5 x20 (AKS) | scoped to management group 'Default': this subscription stops receiving the discount | Rescope the reservation (shared / target MG) before moving |
| High | Policy | Gain | Deny public IPs | Deny:1 | Can block create/update (incl. Terraform applies). Preview with 03, add exemptions or fix resources first |
| High | Policy | Gain | Azure Security Benchmark | Deny:1 DeployIfNotExists:1 Audit:1 | Can block create/update (incl. Terraform applies). Preview with 03, add exemptions or fix resources first |
| High | RBAC | Gain | Owner: Platform-Admins (Group) | new inherited access | Security review: privileged access gained |
| High | RBAC | Lose | Owner: AKS-Admins (Group) | access inherited from this management group is removed | Confirm nobody needs it, or assign at the target / subscription before moving |
| High | RBAC | Lose | Contributor: n-dev-team (Group) | access inherited from this management group is removed | Confirm nobody needs it, or assign at the target / subscription before moving |
| Medium | Exemption | Lose | AKS outside allowed regions | exemption for allowed-loc no longer applies | Resources it covered may become non-compliant or be denied: recreate at the target or subscription scope |
| Low | Cost | Lose | Budget aks-monthly | spend no longer counted in this management-group budget | Adjust budget amounts |
| Low | Policy | Lose | Audit VMs without managed disks | Audit:1 | Audit coverage removed |
| Low | RBAC | Gain | Reader: Platform-Readers (Group) | new inherited access | None |

### n00bs66

`Default > tenant-0000` → `bd-corp > bd-landingzones > bd > tenant-0000`

| Severity | Category | Change | Item | Detail | Action |
|---|---|---|---|---|---|
| High | Cost | Lose | Reservation D4s_v5 x20 (AKS) | scoped to management group 'Default': this subscription stops receiving the discount | Rescope the reservation (shared / target MG) before moving |
| High | Policy | Gain | Deny public IPs | Deny:1 | Can block create/update (incl. Terraform applies). Preview with 03, add exemptions or fix resources first |
| High | Policy | Gain | Azure Security Benchmark | Deny:1 DeployIfNotExists:1 Audit:1 | Can block create/update (incl. Terraform applies). Preview with 03, add exemptions or fix resources first |
| High | RBAC | Lose | Owner: AKS-Admins (Group) | access inherited from this management group is removed | Confirm nobody needs it, or assign at the target / subscription before moving |
| High | RBAC | Gain | Owner: Platform-Admins (Group) | new inherited access | Security review: privileged access gained |
| High | RBAC | Lose | Contributor: n-dev-team (Group) | access inherited from this management group is removed | Confirm nobody needs it, or assign at the target / subscription before moving |
| Medium | Exemption | Lose | AKS outside allowed regions | exemption for allowed-loc no longer applies | Resources it covered may become non-compliant or be denied: recreate at the target or subscription scope |
| Low | Cost | Lose | Budget aks-monthly | spend no longer counted in this management-group budget | Adjust budget amounts |
| Low | Policy | Lose | Audit VMs without managed disks | Audit:1 | Audit coverage removed |
| Low | RBAC | Gain | Reader: Platform-Readers (Group) | new inherited access | None |

### Non-Production Subscription

`tenant-0000` → `bd-corp > bd-landingzones > bd > tenant-0000`

| Severity | Category | Change | Item | Detail | Action |
|---|---|---|---|---|---|
| High | Policy | Gain | Deny public IPs | Deny:1 | Can block create/update (incl. Terraform applies). Preview with 03, add exemptions or fix resources first |
| High | Policy | Gain | Azure Security Benchmark | Deny:1 DeployIfNotExists:1 Audit:1 | Can block create/update (incl. Terraform applies). Preview with 03, add exemptions or fix resources first |
| High | RBAC | Gain | Owner: Platform-Admins (Group) | new inherited access | Security review: privileged access gained |
| Low | RBAC | Gain | Reader: Platform-Readers (Group) | new inherited access | None |

### Non-Production Subscription 2

`Default > tenant-0000` → `bd-corp > bd-landingzones > bd > tenant-0000`

| Severity | Category | Change | Item | Detail | Action |
|---|---|---|---|---|---|
| High | Cost | Lose | Reservation D4s_v5 x20 (AKS) | scoped to management group 'Default': this subscription stops receiving the discount | Rescope the reservation (shared / target MG) before moving |
| High | Policy | Gain | Azure Security Benchmark | Deny:1 DeployIfNotExists:1 Audit:1 | Can block create/update (incl. Terraform applies). Preview with 03, add exemptions or fix resources first |
| High | Policy | Gain | Deny public IPs | Deny:1 | Can block create/update (incl. Terraform applies). Preview with 03, add exemptions or fix resources first |
| High | RBAC | Gain | Owner: Platform-Admins (Group) | new inherited access | Security review: privileged access gained |
| High | RBAC | Lose | Owner: AKS-Admins (Group) | access inherited from this management group is removed | Confirm nobody needs it, or assign at the target / subscription before moving |
| High | RBAC | Lose | Contributor: n-dev-team (Group) | access inherited from this management group is removed | Confirm nobody needs it, or assign at the target / subscription before moving |
| Medium | Exemption | Lose | AKS outside allowed regions | exemption for allowed-loc no longer applies | Resources it covered may become non-compliant or be denied: recreate at the target or subscription scope |
| Low | Cost | Lose | Budget aks-monthly | spend no longer counted in this management-group budget | Adjust budget amounts |
| Low | Policy | Lose | Audit VMs without managed disks | Audit:1 | Audit coverage removed |
| Low | RBAC | Gain | Reader: Platform-Readers (Group) | new inherited access | None |

### p0001app

`bd-legacy-prod > bd > tenant-0000` → `bd-corp > bd-landingzones > bd > tenant-0000`

| Severity | Category | Change | Item | Detail | Action |
|---|---|---|---|---|---|
| High | Policy | Lose | Deploy diagnostic settings | DeployIfNotExists:1 | Guardrail removed: make sure the target hierarchy assigns an equivalent |
| High | RBAC | Lose | Contributor: Prod-Ops (Group) | access inherited from this management group is removed | Confirm nobody needs it, or assign at the target / subscription before moving |

### p0001hub

`bd-shared > bd > tenant-0000` → `bd-connectivity > bd-platform > bd > tenant-0000`

No inherited policy, access or cost changes.

### p0002data

`bd-legacy-prod > bd > tenant-0000` → `bd-corp > bd-landingzones > bd > tenant-0000`

| Severity | Category | Change | Item | Detail | Action |
|---|---|---|---|---|---|
| High | Policy | Lose | Deploy diagnostic settings | DeployIfNotExists:1 | Guardrail removed: make sure the target hierarchy assigns an equivalent |
| High | RBAC | Lose | Contributor: Prod-Ops (Group) | access inherited from this management group is removed | Confirm nobody needs it, or assign at the target / subscription before moving |

### p0004ss

`Default > tenant-0000` → `bd-management > bd-platform > bd > tenant-0000`

| Severity | Category | Change | Item | Detail | Action |
|---|---|---|---|---|---|
| High | Cost | Lose | Reservation D4s_v5 x20 (AKS) | scoped to management group 'Default': this subscription stops receiving the discount | Rescope the reservation (shared / target MG) before moving |
| High | Policy | Gain | Deny public IPs | Deny:1 | Can block create/update (incl. Terraform applies). Preview with 03, add exemptions or fix resources first |
| High | Policy | Gain | Azure Security Benchmark | Deny:1 DeployIfNotExists:1 Audit:1 | Can block create/update (incl. Terraform applies). Preview with 03, add exemptions or fix resources first |
| High | RBAC | Lose | Owner: AKS-Admins (Group) | access inherited from this management group is removed | Confirm nobody needs it, or assign at the target / subscription before moving |
| High | RBAC | Lose | Contributor: n-dev-team (Group) | access inherited from this management group is removed | Confirm nobody needs it, or assign at the target / subscription before moving |
| High | RBAC | Gain | Owner: Platform-Admins (Group) | new inherited access | Security review: privileged access gained |
| Medium | Exemption | Lose | AKS outside allowed regions | exemption for allowed-loc no longer applies | Resources it covered may become non-compliant or be denied: recreate at the target or subscription scope |
| Low | Cost | Lose | Budget aks-monthly | spend no longer counted in this management-group budget | Adjust budget amounts |
| Low | Policy | Lose | Audit VMs without managed disks | Audit:1 | Audit coverage removed |
| Low | RBAC | Gain | Reader: Platform-Readers (Group) | new inherited access | None |

### p0005aks

`Default > tenant-0000` → `bd-corp > bd-landingzones > bd > tenant-0000`

| Severity | Category | Change | Item | Detail | Action |
|---|---|---|---|---|---|
| Blocker | Blocker | PolicyDefinition | AKS tag inheritance | definition stored on management group 'Default' | Move the custom definition to a common ancestor (intermediate root 'bd') before moving |
| High | Cost | Lose | Reservation D4s_v5 x20 (AKS) | scoped to management group 'Default': this subscription stops receiving the discount | Rescope the reservation (shared / target MG) before moving |
| High | Policy | Gain | Azure Security Benchmark | Deny:1 DeployIfNotExists:1 Audit:1 | Can block create/update (incl. Terraform applies). Preview with 03, add exemptions or fix resources first |
| High | Policy | Gain | Deny public IPs | Deny:1 | Can block create/update (incl. Terraform applies). Preview with 03, add exemptions or fix resources first |
| High | RBAC | Lose | Owner: AKS-Admins (Group) | access inherited from this management group is removed | Confirm nobody needs it, or assign at the target / subscription before moving |
| High | RBAC | Gain | Owner: Platform-Admins (Group) | new inherited access | Security review: privileged access gained |
| High | RBAC | Lose | Contributor: n-dev-team (Group) | access inherited from this management group is removed | Confirm nobody needs it, or assign at the target / subscription before moving |
| Medium | Exemption | Lose | AKS outside allowed regions | exemption for allowed-loc no longer applies | Resources it covered may become non-compliant or be denied: recreate at the target or subscription scope |
| Low | Cost | Lose | Budget aks-monthly | spend no longer counted in this management-group budget | Adjust budget amounts |
| Low | Policy | Lose | Audit VMs without managed disks | Audit:1 | Audit coverage removed |
| Low | RBAC | Gain | Reader: Platform-Readers (Group) | new inherited access | None |

### Production Subscription

`tenant-0000` → `bd-corp > bd-landingzones > bd > tenant-0000`

| Severity | Category | Change | Item | Detail | Action |
|---|---|---|---|---|---|
| High | Policy | Gain | Deny public IPs | Deny:1 | Can block create/update (incl. Terraform applies). Preview with 03, add exemptions or fix resources first |
| High | Policy | Gain | Azure Security Benchmark | Deny:1 DeployIfNotExists:1 Audit:1 | Can block create/update (incl. Terraform applies). Preview with 03, add exemptions or fix resources first |
| High | RBAC | Gain | Owner: Platform-Admins (Group) | new inherited access | Security review: privileged access gained |
| Low | RBAC | Gain | Reader: Platform-Readers (Group) | new inherited access | None |

### s0001lab

`bd-shared > bd > tenant-0000` → `bd-sandbox > bd > tenant-0000`

No inherited policy, access or cost changes.

## Hierarchy

### Today (moving subscriptions in red)

```mermaid
graph TD
  n00000001000000000000000000000001(["Design Subscription"])
  n00000002000000000000000000000002(["Non-Production Subscription"])
  n00000003000000000000000000000003(["Production Subscription"])
  n00000004000000000000000000000004(["p0001app"])
  n00000005000000000000000000000005(["p0002data"])
  n00000006000000000000000000000006(["n0002app"])
  n00000007000000000000000000000007(["n0003data"])
  n00000008000000000000000000000008(["p0001hub"])
  n00000009000000000000000000000009(["s0001lab"])
  n00000010000000000000000000000010(["n0001aks"])
  n00000011000000000000000000000011(["n0004ss"])
  n00000012000000000000000000000012(["n00bs66"])
  n00000013000000000000000000000013(["Non-Production Subscription 2"])
  n00000014000000000000000000000014(["p0004ss"])
  n00000015000000000000000000000015(["p0005aks"])
  nbd["Brewin Dolphin"]
  nbdarchive["Archive"]
  nbdlegacydev["Legacy Dev"]
  nbdlegacyprod["Legacy Prod"]
  nbdshared["Shared"]
  nDefault["Default"]
  ntenant0000["Tenant Root Group"]
  nbd --> nbdarchive
  nDefault --> n00000012000000000000000000000012
  nDefault --> n00000013000000000000000000000013
  ntenant0000 --> n00000002000000000000000000000002
  nbdlegacydev --> n00000006000000000000000000000006
  nDefault --> n00000011000000000000000000000011
  nbd --> nbdshared
  nDefault --> n00000014000000000000000000000014
  nbdlegacyprod --> n00000005000000000000000000000005
  nDefault --> n00000015000000000000000000000015
  nbdlegacydev --> n00000007000000000000000000000007
  nbdshared --> n00000009000000000000000000000009
  ntenant0000 --> nbd
  ntenant0000 --> nDefault
  ntenant0000 --> n00000003000000000000000000000003
  nbdlegacyprod --> n00000004000000000000000000000004
  nDefault --> n00000010000000000000000000000010
  ntenant0000 --> n00000001000000000000000000000001
  nbd --> nbdlegacydev
  nbd --> nbdlegacyprod
  nbdshared --> n00000008000000000000000000000008
  classDef sub fill:#fff4ce,stroke:#c19c00
  classDef moved fill:#ffd6d6,stroke:#d13438
  class n00000004000000000000000000000004,n00000005000000000000000000000005,n00000006000000000000000000000006,n00000007000000000000000000000007,n00000008000000000000000000000008,n00000009000000000000000000000009,n00000010000000000000000000000010,n00000011000000000000000000000011,n00000012000000000000000000000012,n00000013000000000000000000000013,n00000014000000000000000000000014,n00000015000000000000000000000015,n00000001000000000000000000000001,n00000002000000000000000000000002,n00000003000000000000000000000003 sub
  class n00000004000000000000000000000004,n00000005000000000000000000000005,n00000006000000000000000000000006,n00000007000000000000000000000007,n00000008000000000000000000000008,n00000009000000000000000000000009,n00000010000000000000000000000010,n00000011000000000000000000000011,n00000012000000000000000000000012,n00000013000000000000000000000013,n00000014000000000000000000000014,n00000015000000000000000000000015,n00000001000000000000000000000001,n00000002000000000000000000000002,n00000003000000000000000000000003 moved
```

### Target

```mermaid
graph TD
  n00000001000000000000000000000001(["Design Subscription"])
  n00000002000000000000000000000002(["Non-Production Subscription"])
  n00000003000000000000000000000003(["Production Subscription"])
  n00000004000000000000000000000004(["p0001app"])
  n00000005000000000000000000000005(["p0002data"])
  n00000006000000000000000000000006(["n0002app"])
  n00000007000000000000000000000007(["n0003data"])
  n00000008000000000000000000000008(["p0001hub"])
  n00000009000000000000000000000009(["s0001lab"])
  n00000010000000000000000000000010(["n0001aks"])
  n00000011000000000000000000000011(["n0004ss"])
  n00000012000000000000000000000012(["n00bs66"])
  n00000013000000000000000000000013(["Non-Production Subscription 2"])
  n00000014000000000000000000000014(["p0004ss"])
  n00000015000000000000000000000015(["p0005aks"])
  nbd["Brewin Dolphin"]
  nbdarchive["Archive"]
  nbdconnectivity["Connectivity"]
  nbdcorp["Corp"]
  nbddecommissioned["Decommissioned"]
  nbdidentity["Identity"]
  nbdlandingzones["Landing zones"]
  nbdlegacydev["Legacy Dev"]
  nbdlegacyprod["Legacy Prod"]
  nbdmanagement["Management"]
  nbdonline["Online"]
  nbdplatform["Platform"]
  nbdsandbox["Sandbox"]
  nbdshared["Shared"]
  nDefault["Default"]
  ntenant0000["Tenant Root Group"]
  ntenant0000 --> nbd
  nbdcorp --> n00000010000000000000000000000010
  nbdcorp --> n00000003000000000000000000000003
  nbd --> nbdarchive
  nbdcorp --> n00000012000000000000000000000012
  nbd --> nbdlegacyprod
  nbdmanagement --> n00000011000000000000000000000011
  nbdlandingzones --> nbdcorp
  nbd --> nbdlandingzones
  nbdcorp --> n00000013000000000000000000000013
  nbdcorp --> n00000007000000000000000000000007
  ntenant0000 --> nDefault
  nbd --> nbdlegacydev
  nbdcorp --> n00000015000000000000000000000015
  nbdcorp --> n00000006000000000000000000000006
  nbd --> nbdplatform
  nbdplatform --> nbdconnectivity
  nbdcorp --> n00000005000000000000000000000005
  nbdconnectivity --> n00000008000000000000000000000008
  nbdplatform --> nbdidentity
  nbd --> nbdsandbox
  nbdsandbox --> n00000009000000000000000000000009
  nbdcorp --> n00000002000000000000000000000002
  nbd --> nbdshared
  nbdmanagement --> n00000014000000000000000000000014
  nbdcorp --> n00000004000000000000000000000004
  nbd --> nbddecommissioned
  nbdlandingzones --> nbdonline
  nbdplatform --> nbdmanagement
  nbdsandbox --> n00000001000000000000000000000001
  classDef sub fill:#fff4ce,stroke:#c19c00
  classDef moved fill:#ffd6d6,stroke:#d13438
  class n00000004000000000000000000000004,n00000005000000000000000000000005,n00000006000000000000000000000006,n00000007000000000000000000000007,n00000008000000000000000000000008,n00000009000000000000000000000009,n00000010000000000000000000000010,n00000011000000000000000000000011,n00000012000000000000000000000012,n00000013000000000000000000000013,n00000014000000000000000000000014,n00000015000000000000000000000015,n00000001000000000000000000000001,n00000002000000000000000000000002,n00000003000000000000000000000003 sub
  class n00000004000000000000000000000004,n00000005000000000000000000000005,n00000006000000000000000000000006,n00000007000000000000000000000007,n00000008000000000000000000000008,n00000009000000000000000000000009,n00000010000000000000000000000010,n00000011000000000000000000000011,n00000012000000000000000000000012,n00000013000000000000000000000013,n00000014000000000000000000000014,n00000015000000000000000000000015,n00000001000000000000000000000001,n00000002000000000000000000000002,n00000003000000000000000000000003 moved
```

```text
Tenant Root Group (tenant-0000)
├─ Brewin Dolphin (bd)
│  ├─ Archive (bd-archive)
│  ├─ Decommissioned (bd-decommissioned)
│  ├─ Landing zones (bd-landingzones)
│  │  ├─ Corp (bd-corp)
│  │  │  ├─ [sub] n0001aks
│  │  │  ├─ [sub] n0002app
│  │  │  ├─ [sub] n0003data
│  │  │  ├─ [sub] n00bs66
│  │  │  ├─ [sub] Non-Production Subscription
│  │  │  ├─ [sub] Non-Production Subscription 2
│  │  │  ├─ [sub] p0001app
│  │  │  ├─ [sub] p0002data
│  │  │  ├─ [sub] p0005aks
│  │  │  └─ [sub] Production Subscription
│  │  └─ Online (bd-online)
│  ├─ Legacy Dev (bd-legacy-dev)
│  ├─ Legacy Prod (bd-legacy-prod)
│  ├─ Platform (bd-platform)
│  │  ├─ Connectivity (bd-connectivity)
│  │  │  └─ [sub] p0001hub
│  │  ├─ Identity (bd-identity)
│  │  └─ Management (bd-management)
│  │     ├─ [sub] n0004ss
│  │     └─ [sub] p0004ss
│  ├─ Sandbox (bd-sandbox)
│  │  ├─ [sub] Design Subscription
│  │  └─ [sub] s0001lab
│  └─ Shared (bd-shared)
└─ Default (Default)
```

