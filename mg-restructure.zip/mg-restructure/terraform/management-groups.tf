# Target hierarchy as code (Archetype layout). Use this INSTEAD of 04-Move-Subscriptions.ps1 -Execute if your
# management groups are already managed by Terraform, otherwise the next plan reverts the moves.
# Run 01/02/03 first either way: they are read-only and tell you what the apply will change.
#
# Existing groups: import before the first apply, e.g.
#   terraform import 'azurerm_management_group.root' /providers/Microsoft.Management/managementGroups/bd
# Subscriptions: azurerm_management_group_subscription_association moves the subscription on apply.

terraform {
  required_providers {
    azurerm = { source = "hashicorp/azurerm", version = "~> 4.0" }
  }
}
provider "azurerm" {
  features {}
}

variable "root_id" {
  type    = string
  default = "bd"
}
variable "root_display_name" {
  type    = string
  default = "Brewin Dolphin"
}

# subscription id => target key (management, connectivity, identity, corp, online, sandbox, decommissioned)
# Fill from out/target-hierarchy.json after review.
variable "subscription_placement" {
  type    = map(string)
  default = {}
}

data "azurerm_client_config" "current" {}

resource "azurerm_management_group" "root" {
  name                       = var.root_id
  display_name               = var.root_display_name
  parent_management_group_id = "/providers/Microsoft.Management/managementGroups/${data.azurerm_client_config.current.tenant_id}"
}

locals {
  level1 = {
    platform       = "Platform"
    landingzones   = "Landing zones"
    sandbox        = "Sandbox"
    decommissioned = "Decommissioned"
  }
  platform_children = { management = "Management", connectivity = "Connectivity", identity = "Identity" }
  lz_children       = { corp = "Corp", online = "Online" }
}

resource "azurerm_management_group" "l1" {
  for_each                   = local.level1
  name                       = "${var.root_id}-${each.key}"
  display_name               = each.value
  parent_management_group_id = azurerm_management_group.root.id
}

resource "azurerm_management_group" "platform" {
  for_each                   = local.platform_children
  name                       = "${var.root_id}-${each.key}"
  display_name               = each.value
  parent_management_group_id = azurerm_management_group.l1["platform"].id
}

resource "azurerm_management_group" "lz" {
  for_each                   = local.lz_children
  name                       = "${var.root_id}-${each.key}"
  display_name               = each.value
  parent_management_group_id = azurerm_management_group.l1["landingzones"].id
}

locals {
  mg_by_key = merge(
    { for k, v in azurerm_management_group.l1 : k => v.id },
    { for k, v in azurerm_management_group.platform : k => v.id },
    { for k, v in azurerm_management_group.lz : k => v.id },
  )
}

# Do NOT also set subscription_ids on the azurerm_management_group resources: the two approaches fight.
resource "azurerm_management_group_subscription_association" "this" {
  for_each            = var.subscription_placement
  management_group_id = local.mg_by_key[each.value]
  subscription_id     = "/subscriptions/${each.key}"
}

# New subscriptions land in Sandbox, and only callers with MG write at root can create management groups.
# (azurerm has no resource for hierarchy settings; use azapi or 04-Move-Subscriptions.ps1 -SetDefaultManagementGroup.)

output "management_group_ids" {
  value = local.mg_by_key
}
