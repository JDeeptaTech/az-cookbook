# Management group restructure kit

Move subscriptions into a platform / landing zones / sandbox hierarchy, with a measured impact before any change.
PowerShell 7.2+ driving the Azure CLI (`az login`). Plans are also emitted as plain `az` and Az PowerShell commands.

```
config/layouts.json          target layouts: Archetype (CAF, recommended) or Environment (prod/nonprod under Corp)
config/naming-rules.json     regexes used only to DRAFT the subscription mapping
lib/                         az wrappers + hierarchy helpers
scripts/00                   policy inventory: what is assigned at which level, what each subscription inherits
scripts/01..05               export -> impact -> policy preview -> move -> undo
queries/policy-by-level.kql  quick Resource Graph view of the same (portal / az graph)
terraform/                   same target layout as code (use instead of 04 if MGs are Terraform-managed)
```

| # | Script | Changes anything? | Output |
|---|--------|-------------------|--------|
| 00 | `00-Export-PolicyInventory.ps1 [-IntermediateRootId bd]` | No | `policy-assignments.csv` (every assignment by level), `effective-policies.csv` (what each subscription inherits, excluded / exempted), `policy-exemptions.csv`, `policy-inventory.md` (findings + tree with assignments at each level) |
| 01 | `01-Export-MgHierarchy.ps1 -IntermediateRootId bd -Layout Archetype` | No | current tree, findings, **draft** `target-hierarchy.json` |
| 02 | `02-Get-MgMoveImpact.ps1` | No | `impact.csv`, `impact-report.md` (policy, RBAC, exemptions, custom-role / definition blockers, reservations, budgets, empty MGs). Exit 2 on blockers |
| 03 | `03-Test-PolicyPreview.ps1` | Temporary DoNotEnforce assignments, removed at the end | `policy-preview.csv`: existing resources that would be denied / changed |
| 04 | `04-Move-Subscriptions.ps1 [-Wave n] [-Execute] [-SetDefaultManagementGroup]` | Only with `-Execute` | `move-plan.azcli.sh`, `move-plan.azps.ps1`, `move-log-*.json` |
| 05 | `05-Undo-MgMove.ps1 -LogPath <log> [-Execute]` | Only with `-Execute` | moves everything back, restores default MG |

Permissions: Reader at the Tenant Root Group for 01–02; Resource Policy Contributor on subscriptions for 03;
Owner on each subscription + Management Group Contributor on old and new parents for 04/05.

Order of work:
1. 01 → edit `out/target-hierarchy.json` (targets, waves, `confirmed: true`).
2. Move custom policy definitions and custom role assignable scopes up to the intermediate root (fixes most blockers, and lets 03 preview everything).
3. 02 until no blockers; 03 for High/Medium policy gains; fix or exempt the resources it lists.
4. Mirror the RBAC that 02 shows as "Lose" at the target scope before moving.
5. 04 wave by wave (sandbox + non-prod → platform → prod), 24 h soak between waves, re-run 02 after each.
6. Set the default management group, then delete the empty legacy groups listed in the report.

Tested against a simulated tenant (fake `az`) shaped like the current one: export, drafting, effect resolution through
initiative parameters, custom-role and policy-definition blockers, reservations/budgets, preview with identity retry,
gates (unconfirmed / blocker), Azure-side refusal mid-wave, default MG, and full rollback. Not yet run against a real tenant.
