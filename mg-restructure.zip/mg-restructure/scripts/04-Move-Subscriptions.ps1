#requires -Version 7.2
<#
.SYNOPSIS
  Create the target management groups and move subscriptions, wave by wave. Dry run unless -Execute.

.DESCRIPTION
  Always writes the exact plan as both Azure CLI and Az PowerShell commands (move-plan.azcli.sh,
  move-plan.azps.ps1) so it can go into the change record.

  With -Execute:
    1. Refuses to run if impact.csv has Blocker rows (override: -IgnoreBlockers) or if a selected row is not confirmed.
    2. Creates missing management groups, parents first. Existing ones are left where they are unless
       -MoveManagementGroups (then their parent is changed to the one in target-hierarchy.json).
    3. Moves the subscriptions in the selected -Wave, logging each move to move-log-<timestamp>.json
       (05-Undo-MgMove.ps1 uses it to put everything back).
    4. Verifies each subscription is under its target.
    5. -SetDefaultManagementGroup: new subscriptions land in the target's defaultManagementGroup, and only
       users with MG write at root can create management groups.

  Moving a subscription is a metadata change: no resource, network path or data plane is touched. What changes
  is inherited policy, access and cost scope (see 02). Azure caches the hierarchy for up to 30 minutes, and policy
  compliance for the moved subscription is re-evaluated within about 30 minutes.

  Permissions: Owner on each subscription (or MG + role assignment write), and Management Group Contributor
  on the current and target parents (not needed when the parent is the Tenant Root Group).

.EXAMPLE
  ./04-Move-Subscriptions.ps1 -TargetPath ./out/target-hierarchy.json                         # plan only
  ./04-Move-Subscriptions.ps1 -TargetPath ./out/target-hierarchy.json -Wave 1 -Execute        # move wave 1
  ./04-Move-Subscriptions.ps1 -TargetPath ./out/target-hierarchy.json -Wave 3 -Execute -SetDefaultManagementGroup
#>
[CmdletBinding()]
param(
    [string]$TargetPath = './out/target-hierarchy.json',
    [string]$ImpactCsv = './out/impact.csv',
    [string]$OutDir = './out',
    [int[]]$Wave,
    [switch]$Execute,
    [switch]$MoveManagementGroups,
    [switch]$SetDefaultManagementGroup,
    [switch]$IgnoreBlockers,
    [switch]$IgnoreUnconfirmed
)
$ErrorActionPreference = 'Stop'
Import-Module (Join-Path $PSScriptRoot '..' 'lib' 'AzCliHelpers.psm1') -Force
Import-Module (Join-Path $PSScriptRoot '..' 'lib' 'MgHierarchy.psm1') -Force
New-Item -ItemType Directory -Force -Path $OutDir | Out-Null

$target = Get-Content -Raw $TargetPath | ConvertFrom-Json -Depth 20
$tenantId = (Invoke-AzJson @('account', 'show')).tenantId
if ($target.tenantId -and $target.tenantId -ne $tenantId) { throw "target-hierarchy.json is for tenant $($target.tenantId) but az is signed in to $tenantId" }
$flat = ConvertTo-FlatHierarchy -Tree (Get-MgTreeLive -TenantId $tenantId)
$existing = @{}; foreach ($g in $flat.Groups) { $existing[$g.Id] = $g }

# ---- management groups in parent-first order ----
$mgs = @(@($target.intermediateRoot) + @($target.managementGroups) | Where-Object { $_ })
$ordered = [System.Collections.Generic.List[object]]::new(); $placed = @{ $tenantId = 1 }; foreach ($g in $flat.Groups) { $placed[$g.Id] = 1 }
$pending = [System.Collections.Generic.List[object]]::new(); $mgs | ForEach-Object { $pending.Add($_) }
for ($i = 0; $pending.Count -and $i -lt 20; $i++) {
    foreach ($g in @($pending)) { if ($placed[$g.parent] -or ($g.parent -in $ordered.id)) { $ordered.Add($g); $placed[$g.id] = 1; [void]$pending.Remove($g) } }
}
if ($pending.Count) { throw "Unresolvable parents for: $($pending.id -join ', ')" }

$mgActions = foreach ($g in $ordered) {
    $cur = $existing[$g.id]
    if (-not $cur) { [pscustomobject]@{ Kind = 'CreateMG'; Id = $g.id; DisplayName = $g.displayName; Parent = $g.parent } }
    elseif ($cur.Parent -ne $g.parent) {
        if ($MoveManagementGroups) { [pscustomobject]@{ Kind = 'MoveMG'; Id = $g.id; DisplayName = $g.displayName; Parent = $g.parent; From = $cur.Parent } }
        else { Write-Warning "Management group $($g.id) is under '$($cur.Parent)', target says '$($g.parent)'. Use -MoveManagementGroups to move it (moves everything below it)." }
    }
}
$mgActions = @($mgActions)

# ---- subscription moves ----
$rows = @($target.subscriptions | Where-Object { -not $Wave -or [int]$_.wave -in $Wave })
$subActions = foreach ($s in $rows) {
    $cur = $flat.Subscriptions | Where-Object Id -eq $s.id
    if (-not $cur) { Write-Warning "$($s.name) ($($s.id)) not found - skipped"; continue }
    if ($cur.Parent -eq $s.target) { continue }
    [pscustomobject]@{ Kind = 'MoveSub'; Id = $s.id; Name = $s.name; From = $cur.Parent; To = $s.target; Wave = $s.wave; Confirmed = [bool]$s.confirmed }
}
$subActions = @($subActions | Sort-Object Wave, To, Name)

# ---- plan files ----
$cli = [System.Collections.Generic.List[string]]::new(); $ps = [System.Collections.Generic.List[string]]::new()
$cli.Add('#!/usr/bin/env bash'); $cli.Add("# Generated $(Get-Date -Format s) by 04-Move-Subscriptions.ps1 - tenant $tenantId"); $cli.Add('set -euo pipefail')
$ps.Add("# Generated $(Get-Date -Format s) by 04-Move-Subscriptions.ps1 - tenant $tenantId"); $ps.Add("`$ErrorActionPreference = 'Stop'")
foreach ($a in $mgActions) {
    $parentId = "/providers/Microsoft.Management/managementGroups/$($a.Parent)"
    if ($a.Kind -eq 'CreateMG') {
        $cli.Add("az account management-group create --name '$($a.Id)' --display-name '$($a.DisplayName)' --parent '$($a.Parent)'")
        $ps.Add("New-AzManagementGroup -GroupName '$($a.Id)' -DisplayName '$($a.DisplayName)' -ParentId '$parentId'")
    } else {
        $cli.Add("az account management-group update --name '$($a.Id)' --parent '$($a.Parent)'   # was under $($a.From)")
        $ps.Add("Update-AzManagementGroup -GroupName '$($a.Id)' -ParentId '$parentId'   # was under $($a.From)")
    }
}
foreach ($w in $subActions | Group-Object Wave) {
    $cli.Add("`n# ---- wave $($w.Name) ----"); $ps.Add("`n# ---- wave $($w.Name) ----")
    foreach ($a in $w.Group) {
        $cli.Add("az account management-group subscription add --name '$($a.To)' --subscription '$($a.Id)'   # $($a.Name): $($a.From) -> $($a.To)")
        $ps.Add("New-AzManagementGroupSubscription -GroupName '$($a.To)' -SubscriptionId '$($a.Id)'   # $($a.Name): $($a.From) -> $($a.To)")
    }
}
if ($SetDefaultManagementGroup -and $target.defaultManagementGroup) {
    $cli.Add("`naz account management-group hierarchy-settings create --name '$tenantId' --default-management-group '/providers/Microsoft.Management/managementGroups/$($target.defaultManagementGroup)' --require-authorization-for-group-creation true")
    $ps.Add("`nNew-AzManagementGroupHierarchySetting -GroupName '$tenantId' -DefaultManagementGroup '/providers/Microsoft.Management/managementGroups/$($target.defaultManagementGroup)' -Authorization `$true")
}
$cli -join "`n" | Set-Content (Join-Path $OutDir 'move-plan.azcli.sh')
$ps -join "`n" | Set-Content (Join-Path $OutDir 'move-plan.azps.ps1')

Write-Host "`nPlan$(if ($Wave) { " (wave $($Wave -join ','))" })" -ForegroundColor Cyan
$mgActions | ForEach-Object { Write-Host ("  {0,-9} {1,-24} under {2}" -f $_.Kind, $_.Id, $_.Parent) }
$subActions | ForEach-Object { Write-Host ("  MoveSub   {0,-30} {1} -> {2}  (wave {3}{4})" -f $_.Name, $_.From, $_.To, $_.Wave, $(if (-not $_.Confirmed) { ', NOT CONFIRMED' })) }
Write-Host "Plan files: $(Join-Path $OutDir 'move-plan.azcli.sh'), $(Join-Path $OutDir 'move-plan.azps.ps1')"
if (-not $Execute) { Write-Host "`nDry run. Add -Execute to apply." -ForegroundColor Yellow; return }

# ---- gates ----
if (-not $IgnoreUnconfirmed) {
    $u = @($subActions | Where-Object { -not $_.Confirmed })
    if ($u) { throw "Unconfirmed rows in this run: $($u.Name -join ', '). Set confirmed=true in target-hierarchy.json (or -IgnoreUnconfirmed)." }
}
if (-not $IgnoreBlockers) {
    if (-not (Test-Path $ImpactCsv)) { throw "No impact analysis at $ImpactCsv. Run 02-Get-MgMoveImpact.ps1 first (or -IgnoreBlockers)." }
    $ids = @($subActions.Id)
    $b = @(Import-Csv $ImpactCsv | Where-Object { $_.Severity -eq 'Blocker' -and $_.SubscriptionId -in $ids })
    if ($b) { throw "Blockers for subscriptions in this run:`n$(($b | ForEach-Object { "  $($_.Subscription): $($_.Item)" }) -join "`n")" }
}

# ---- execute ----
$logPath = Join-Path $OutDir ("move-log-{0}.json" -f (Get-Date -Format 'yyyyMMdd-HHmmss'))
$log = [ordered]@{ tenantId = $tenantId; started = (Get-Date).ToString('o'); managementGroups = @(); subscriptions = @() }
$save = { $log | ConvertTo-Json -Depth 10 | Set-Content $logPath }
try {
    foreach ($a in $mgActions) {
        if ($a.Kind -eq 'CreateMG') {
            $null = Invoke-AzJson @('account', 'management-group', 'create', '--name', $a.Id, '--display-name', $a.DisplayName, '--parent', $a.Parent)
            $log.managementGroups += @{ action = 'created'; id = $a.Id; parent = $a.Parent }
        } else {
            $null = Invoke-AzJson @('account', 'management-group', 'update', '--name', $a.Id, '--parent', $a.Parent)
            $log.managementGroups += @{ action = 'moved'; id = $a.Id; from = $a.From; to = $a.Parent }
        }
        & $save; Write-Host "  ok $($a.Kind) $($a.Id)" -ForegroundColor Green
    }
    foreach ($a in $subActions) {
        $null = Invoke-AzJson @('account', 'management-group', 'subscription', 'add', '--name', $a.To, '--subscription', $a.Id)
        $log.subscriptions += @{ id = $a.Id; name = $a.Name; from = $a.From; to = $a.To; at = (Get-Date).ToString('o') }
        & $save; Write-Host "  ok moved $($a.Name): $($a.From) -> $($a.To)" -ForegroundColor Green
    }
    if ($SetDefaultManagementGroup -and $target.defaultManagementGroup) {
        $prev = try { @((Invoke-AzJson @('account', 'management-group', 'hierarchy-settings', 'list', '--name', $tenantId)).value)[0] } catch { $null }
        $log.previousDefaultManagementGroup = if ($prev) { $prev.defaultManagementGroup ?? $prev.properties.defaultManagementGroup } else { $null }
        $verb = if ($prev) { 'update' } else { 'create' }
        $null = Invoke-AzJson @('account', 'management-group', 'hierarchy-settings', $verb, '--name', $tenantId,
            '--default-management-group', "/providers/Microsoft.Management/managementGroups/$($target.defaultManagementGroup)", '--require-authorization-for-group-creation', 'true')
        & $save; Write-Host "  ok default management group = $($target.defaultManagementGroup)" -ForegroundColor Green
    }
} catch {
    Write-Error "Stopped: $($_.Exception.Message)`nCompleted steps are in $logPath. Undo with: ./05-Undo-MgMove.ps1 -LogPath $logPath" -ErrorAction Continue
    exit 1
}

# ---- verify (direct parent per subscription; the portal can lag up to 30 min) ----
$bad = foreach ($a in $subActions) {
    $under = @(Invoke-AzJson @('account', 'management-group', 'subscription', 'show-sub-under-mg', '--name', $a.To))
    if (-not ($under | Where-Object { $_.name -eq $a.Id -or $_.id -match $a.Id })) { $a }
}
if ($bad) { Write-Warning "Not yet visible under target (cache?): $(@($bad).Name -join ', '). Re-check in 30 minutes." }
Write-Host "`nDone. Log: $logPath`nNext: run 02 again (should show no changes for moved subscriptions) and watch compliance for 24 h." -ForegroundColor Cyan
