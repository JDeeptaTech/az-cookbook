#requires -Version 7.2
<#
.SYNOPSIS
  Put subscriptions (and management groups) back where a 04-Move-Subscriptions.ps1 run found them.

.DESCRIPTION
  Reads move-log-*.json, moves subscriptions back in reverse order, moves management groups back, restores the
  previous default management group, and (with -RemoveCreatedManagementGroups) deletes the management groups that
  run created, if they are empty. Dry run unless -Execute.

.EXAMPLE
  ./05-Undo-MgMove.ps1 -LogPath ./out/move-log-20261110-190501.json -Execute
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory)][string]$LogPath,
    [switch]$Execute,
    [switch]$RemoveCreatedManagementGroups
)
$ErrorActionPreference = 'Stop'
Import-Module (Join-Path $PSScriptRoot '..' 'lib' 'AzCliHelpers.psm1') -Force
$log = Get-Content -Raw $LogPath | ConvertFrom-Json -Depth 10
$tenantId = (Invoke-AzJson @('account', 'show')).tenantId
if ($log.tenantId -ne $tenantId) { throw "Log is for tenant $($log.tenantId), signed in to $tenantId" }

$steps = [System.Collections.Generic.List[object]]::new()
foreach ($s in @($log.subscriptions)[-1..-(@($log.subscriptions).Count)] | Where-Object { $_ }) {
    $steps.Add(@{ text = "move $($s.name) back to $($s.from)"; args = @('account', 'management-group', 'subscription', 'add', '--name', $s.from, '--subscription', $s.id) })
}
foreach ($m in @($log.managementGroups)[-1..-(@($log.managementGroups).Count)] | Where-Object { $_ }) {
    if ($m.action -eq 'moved') { $steps.Add(@{ text = "move management group $($m.id) back under $($m.from)"; args = @('account', 'management-group', 'update', '--name', $m.id, '--parent', $m.from) }) }
    elseif ($m.action -eq 'created' -and $RemoveCreatedManagementGroups) { $steps.Add(@{ text = "delete created management group $($m.id) (must be empty)"; args = @('account', 'management-group', 'delete', '--name', $m.id) }) }
}
if ($log.PSObject.Properties['previousDefaultManagementGroup']) {
    $prev = $log.previousDefaultManagementGroup ?? "/providers/Microsoft.Management/managementGroups/$tenantId"
    $steps.Add(@{ text = "restore default management group $prev"; args = @('account', 'management-group', 'hierarchy-settings', 'update', '--name', $tenantId, '--default-management-group', $prev) })
}
$steps | ForEach-Object { Write-Host "  $($_.text)`n      az $($_.args -join ' ')" }
if (-not $Execute) { Write-Host "`nDry run. Add -Execute to apply." -ForegroundColor Yellow; return }
foreach ($s in $steps) { $null = Invoke-AzJson $s.args; Write-Host "  ok $($s.text)" -ForegroundColor Green }
