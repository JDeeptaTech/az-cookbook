#requires -Version 7.2
<#
.SYNOPSIS
  Export the current management group hierarchy and draft a target mapping for review.

.DESCRIPTION
  Read-only. Needs Reader (or Management Group Reader) at the Tenant Root Group: a Global Administrator can
  elevate access once, or ask for Reader at root for the platform team.

  Writes to -OutDir:
    current-hierarchy.json    management groups + subscriptions with their parents
    current-tree.txt / .mmd   text tree and Mermaid diagram of today's layout
    subscriptions.csv         one row per subscription with its ancestor chain
    target-hierarchy.json     DRAFT target: management groups for -Layout + a mapping for every subscription,
                              guessed from naming rules and marked confirmed=false. Edit this file, then run 02.

.EXAMPLE
  az login
  ./01-Export-MgHierarchy.ps1 -IntermediateRootId bd -Layout Archetype
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory)][string]$IntermediateRootId,
    [ValidateSet('Archetype', 'Environment')][string]$Layout = 'Archetype',
    [string]$IntermediateRootDisplayName,
    [string]$OutDir = './out',
    [string]$NamingRulesPath = (Join-Path $PSScriptRoot '..' 'config' 'naming-rules.json'),
    [string]$LayoutsPath = (Join-Path $PSScriptRoot '..' 'config' 'layouts.json')
)
$ErrorActionPreference = 'Stop'
Import-Module (Join-Path $PSScriptRoot '..' 'lib' 'AzCliHelpers.psm1') -Force
Import-Module (Join-Path $PSScriptRoot '..' 'lib' 'MgHierarchy.psm1') -Force
New-Item -ItemType Directory -Force -Path $OutDir | Out-Null

$tenantId = (Invoke-AzJson @('account', 'show')).tenantId
$tree = Get-MgTreeLive -TenantId $tenantId
$flat = ConvertTo-FlatHierarchy -Tree $tree
$settings = try { @((Invoke-AzJson @('account', 'management-group', 'hierarchy-settings', 'list', '--name', $tenantId)).value)[0] } catch { $null }
$defaultMg = if ($settings) { ($settings.defaultManagementGroup ?? $settings.properties.defaultManagementGroup) -replace '.*/', '' } else { $null }

# ---- current state ----
@{ tenantId = $tenantId; exportedAt = (Get-Date).ToString('o'); defaultManagementGroup = $defaultMg
   managementGroups = $flat.Groups; subscriptions = $flat.Subscriptions } | ConvertTo-Json -Depth 10 | Set-Content (Join-Path $OutDir 'current-hierarchy.json')
$treeTxt = Format-MgTree -Flat $flat
$treeTxt | Set-Content (Join-Path $OutDir 'current-tree.txt')
ConvertTo-MgMermaid -Flat $flat | Set-Content (Join-Path $OutDir 'current-tree.mmd')
$flat.Subscriptions | ForEach-Object {
    $chain = Get-AncestorChain -Id $_.Id -ParentMap $flat.Parent
    [pscustomobject]@{ Name = $_.Name; SubscriptionId = $_.Id; Parent = $_.Parent; Depth = $chain.Count; Ancestors = ($chain -join ' > ') }
} | Sort-Object Ancestors, Name | Export-Csv (Join-Path $OutDir 'subscriptions.csv') -NoTypeInformation

Write-Host "`nCurrent hierarchy ($(@($flat.Groups).Count) management groups, $(@($flat.Subscriptions).Count) subscriptions)" -ForegroundColor Cyan
Write-Host $treeTxt

# ---- findings on today's layout ----
$findings = @()
$atRoot = @($flat.Subscriptions | Where-Object Parent -eq $tenantId)
if ($atRoot) { $findings += "$($atRoot.Count) subscription(s) sit directly under the Tenant Root Group: $($atRoot.Name -join ', ')" }
if (-not $defaultMg -or $defaultMg -eq $tenantId) { $findings += 'New subscriptions land in the Tenant Root Group (no default management group set)' }
else { $findings += "New subscriptions land in '$defaultMg'" }
if (-not ($flat.Groups | Where-Object Id -eq $IntermediateRootId)) { $findings += "Intermediate root '$IntermediateRootId' does not exist yet: it will be created under the Tenant Root Group" }
$empty = @($flat.Groups | Where-Object { $g = $_.Id; $g -ne $tenantId -and -not ($flat.Parent.Values -contains $g) })
if ($empty) { $findings += "$($empty.Count) empty management group(s): $($empty.Id -join ', ')" }
$deep = ($flat.Subscriptions | ForEach-Object { (Get-AncestorChain -Id $_.Id -ParentMap $flat.Parent).Count } | Measure-Object -Maximum).Maximum
if ($deep -gt 5) { $findings += "Deepest subscription is $deep levels below root (CAF suggests 3-4)" }
Write-Host "`nFindings" -ForegroundColor Cyan; $findings | ForEach-Object { Write-Host "  - $_" }

# ---- draft target ----
$rules = Get-Content -Raw $NamingRulesPath | ConvertFrom-Json
$lay = (Get-Content -Raw $LayoutsPath | ConvertFrom-Json).$Layout
$r = { param($s) $s.Replace('{root}', $IntermediateRootId) }
$mgs = @($lay.managementGroups | ForEach-Object { [ordered]@{ id = & $r $_.id; displayName = $_.displayName; parent = & $r $_.parent } })
$rootExisting = $flat.Groups | Where-Object Id -eq $IntermediateRootId
$rootEntry = [ordered]@{ id = $IntermediateRootId; displayName = ($IntermediateRootDisplayName ? $IntermediateRootDisplayName : ($rootExisting.DisplayName ?? $IntermediateRootId)); parent = $tenantId }

$mapRows = foreach ($s in $flat.Subscriptions | Sort-Object Name) {
    $env = ($rules.environment | Where-Object { $s.Name -match "(?i)$($_.pattern)" } | Select-Object -First 1).value ?? 'unknown'
    $arch = $rules.archetype | Where-Object { $s.Name -match "(?i)$($_.pattern)" } | Select-Object -First 1
    $key = "$($arch.value)|$env"
    $target = $lay.targets.$key ?? $lay.targets."$($arch.value)|*"
    $wave = $rules.waves.($arch.value) ?? $rules.waves.$env ?? 2
    if ($arch.value -eq 'corp' -or $arch.value -eq 'online') { $wave = $rules.waves.$env ?? 2 }
    [ordered]@{ name = $s.Name; id = $s.Id; currentParent = $s.Parent; archetype = $arch.value; environment = $env
                target = (& $r $target); wave = $wave; reason = $arch.why; confirmed = $false }
}
$draft = [ordered]@{
    '$comment' = "DRAFT from 01-Export-MgHierarchy.ps1 ($Layout layout). Review every subscription, set confirmed=true, adjust target/wave. Management groups listed here are created if missing (parents first)."
    tenantId = $tenantId; layout = $Layout
    intermediateRoot = $rootEntry
    managementGroups = $mgs
    defaultManagementGroup = (& $r $lay.defaultManagementGroup)
    subscriptions = @($mapRows)
}
$draftPath = Join-Path $OutDir 'target-hierarchy.json'
if (Test-Path $draftPath) { $draftPath = Join-Path $OutDir "target-hierarchy.draft-$(Get-Date -Format 'yyyyMMddHHmmss').json"; Write-Warning "target-hierarchy.json exists; draft written to $draftPath" }
$draft | ConvertTo-Json -Depth 10 | Set-Content $draftPath

Write-Host "`nDraft mapping ($Layout) - review before running 02" -ForegroundColor Cyan
$mapRows | ForEach-Object { [pscustomobject]$_ } | Format-Table name, environment, archetype, target, wave, reason -AutoSize | Out-String -Width 220 | Write-Host
Write-Host "Outputs in $(Resolve-Path $OutDir)"
