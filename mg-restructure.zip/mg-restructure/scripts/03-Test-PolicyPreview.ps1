#requires -Version 7.2
<#
.SYNOPSIS
  Measure, before moving, how many existing resources would be non-compliant (or denied on their next update)
  under the policies each subscription will GAIN.

.DESCRIPTION
  For every "Policy / Gain" row in impact.csv (default: High and Medium only), creates a copy of that assignment
  at the subscription scope with enforcementMode = DoNotEnforce (nothing is blocked or deployed), triggers a
  compliance scan, reads the results per policy and effect, then deletes the copies.

  Limitation: a custom definition can only be assigned below the management group that stores it. Definitions
  stored on a management group that is not yet above the subscription are skipped: keep custom definitions on
  the intermediate root and this limitation disappears.

  Outputs: policy-preview.csv (subscription, assignment, effect, non-compliant resources, examples).
  Needs Resource Policy Contributor on the subscriptions.

.EXAMPLE
  ./03-Test-PolicyPreview.ps1 -ImpactCsv ./out/impact.csv -Location uksouth
#>
[CmdletBinding()]
param(
    [string]$ImpactCsv = './out/impact.csv',
    [string]$OutDir = './out',
    [string]$Location = 'uksouth',
    [ValidateSet('High', 'Medium', 'Low')][string[]]$Severity = @('High', 'Medium'),
    [string[]]$Subscription,
    [int]$ScanTimeoutMinutes = 60,
    [switch]$KeepPreviewAssignments
)
$ErrorActionPreference = 'Stop'
Import-Module (Join-Path $PSScriptRoot '..' 'lib' 'AzCliHelpers.psm1') -Force
Import-Module (Join-Path $PSScriptRoot '..' 'lib' 'MgHierarchy.psm1') -Force

$rows = Import-Csv $ImpactCsv | Where-Object { $_.Category -eq 'Policy' -and $_.Change -eq 'Gain' -and $_.Severity -in $Severity }
if ($Subscription) { $rows = $rows | Where-Object { $_.Subscription -in $Subscription -or $_.SubscriptionId -in $Subscription } }
if (-not $rows) { Write-Host 'Nothing to preview.'; return }

$flat = ConvertTo-FlatHierarchy -Tree (Get-MgTreeLive -TenantId (Invoke-AzJson @('account', 'show')).tenantId)
$created = [System.Collections.Generic.List[object]]::new()
$results = [System.Collections.Generic.List[object]]::new()
$srcCache = @{}
try {
    foreach ($g in $rows | Group-Object SubscriptionId) {
        $subId = $g.Name; $subName = $g.Group[0].Subscription; $subScope = "/subscriptions/$subId"
        $ancestors = Get-AncestorChain -Id $subId -ParentMap $flat.Parent
        Write-Host "`n$subName" -ForegroundColor Cyan
        foreach ($r in $g.Group) {
            # find the source assignment at its management group
            if (-not $srcCache.ContainsKey($r.Scope)) { $srcCache[$r.Scope] = @(try { Invoke-AzJson @('policy', 'assignment', 'list', '--scope', $r.Scope) } catch { }) }
            $src = $srcCache[$r.Scope] | Where-Object { $_.displayName -eq $r.Item } | Select-Object -First 1
            if (-not $src) { $results.Add([pscustomobject]@{ Subscription = $subName; Assignment = $r.Item; Status = 'Skipped'; Detail = 'source assignment not found (planned?)' }); continue }
            $defId = Get-AzProp $src 'policyDefinitionId'
            if ($defId -match '/managementGroups/([^/]+)/providers/' -and $Matches[1] -notin $ancestors) {
                $results.Add([pscustomobject]@{ Subscription = $subName; Assignment = $r.Item; Status = 'Skipped'; Detail = "definition stored on '$($Matches[1])', not above this subscription yet" }); continue
            }
            $name = 'pv-' + ([BitConverter]::ToString([Security.Cryptography.SHA256]::HashData([Text.Encoding]::UTF8.GetBytes("$subId$($src.id)"))) -replace '-', '').Substring(0, 16).ToLower()
            $a = @('policy', 'assignment', 'create', '--name', $name, '--scope', $subScope, '--display-name', "PREVIEW $($r.Item)".Substring(0, [math]::Min(120, "PREVIEW $($r.Item)".Length)),
                   '--enforcement-mode', 'DoNotEnforce')
            $a += if ($defId -match '/policySetDefinitions/') { @('--policy-set-definition', $defId) } else { @('--policy', $defId) }
            $tmp = $null
            $p = Get-AzProp $src 'parameters'
            if ($p -and @($p.PSObject.Properties).Count) {
                $tmp = [IO.Path]::GetTempFileName(); $p | ConvertTo-Json -Depth 30 -Compress | Set-Content $tmp -Encoding utf8NoBOM
                $a += @('--params', "@$tmp")
            }
            try {
                try { $null = Invoke-AzJson $a }
                catch {
                    if ($_.Exception.Message -notmatch '(?i)identity') { throw }
                    $null = Invoke-AzJson ($a + @('--mi-system-assigned', '--location', $Location))   # DINE/Modify need an identity even in DoNotEnforce
                }
                $created.Add([pscustomobject]@{ Name = $name; Scope = $subScope; SubName = $subName; Item = $r.Item; Effects = $r.Detail })
                Write-Host "  created preview $name for '$($r.Item)'"
            } catch { $results.Add([pscustomobject]@{ Subscription = $subName; Assignment = $r.Item; Status = 'Error'; Detail = $_.Exception.Message }) }
            finally { if ($tmp) { Remove-Item $tmp -Force -ErrorAction SilentlyContinue } }
        }
    }

    foreach ($sub in $created | Group-Object Scope) {
        $subId = $sub.Name -replace '/subscriptions/', ''
        Write-Host "`nScanning $($sub.Group[0].SubName) (can take 5-30 min)..."
        $job = Start-Job { param($id) az policy state trigger-scan --subscription $id --only-show-errors 2>&1 } -ArgumentList $subId
        if (-not (Wait-Job $job -Timeout ($ScanTimeoutMinutes * 60))) { Write-Warning "Scan still running after $ScanTimeoutMinutes min; reading partial results"; Stop-Job $job }
        Receive-Job $job -ErrorAction SilentlyContinue | Out-Null; Remove-Job $job -Force
        foreach ($c in $sub.Group) {
            $aid = "$($c.Scope)/providers/Microsoft.Authorization/policyAssignments/$($c.Name)"
            $f = "`$filter=policyAssignmentId eq '$aid'"
            $sum = Invoke-AzRest post "$($c.Scope)/providers/Microsoft.PolicyInsights/policyStates/latest/summarize?api-version=2019-10-01" -UriParameters $f
            $nc = [int]$sum.value[0].results.nonCompliantResources
            $q = Invoke-AzRest post "$($c.Scope)/providers/Microsoft.PolicyInsights/policyStates/latest/queryResults?api-version=2019-10-01" -UriParameters "$f and complianceState eq 'NonCompliant'", '$top=200'
            $byEffect = @($q.value) | Group-Object policyDefinitionAction | ForEach-Object { "$($_.Name):$(@($_.Group.resourceId | Sort-Object -Unique).Count)" }
            $eg = (@($q.value.resourceId) | Sort-Object -Unique | Select-Object -First 5 | ForEach-Object { $_ -replace '.*/resourceGroups/', 'rg/' }) -join '; '
            $results.Add([pscustomobject]@{ Subscription = $c.SubName; Assignment = $c.Item; Status = 'Scanned'; NonCompliant = $nc
                ByEffect = ($byEffect -join ' '); Examples = $eg; Detail = $c.Effects })
        }
    }
}
finally {
    if ($KeepPreviewAssignments) { Write-Warning "Kept $($created.Count) preview assignment(s) (pv-*)" }
    else {
        foreach ($c in $created) {
            try { $null = Invoke-AzJson @('policy', 'assignment', 'delete', '--name', $c.Name, '--scope', $c.Scope) -AllowNotFound } catch { Write-Warning "Delete preview $($c.Name) at $($c.Scope) manually" }
        }
        if ($created.Count) { Write-Host "`nRemoved $($created.Count) preview assignment(s)." }
    }
}
$results | Export-Csv (Join-Path $OutDir 'policy-preview.csv') -NoTypeInformation
$results | Format-Table Subscription, Assignment, Status, NonCompliant, ByEffect, Detail -AutoSize | Out-String -Width 250 | Write-Host
Write-Host "Deny rows = resources that will be blocked on their next update (Terraform apply, portal edit). Fix or exempt them before moving."
