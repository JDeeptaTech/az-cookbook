#requires -Version 7.2
<#
.SYNOPSIS
  Predict what changes for every subscription when the hierarchy changes from today's tree to target-hierarchy.json.

.DESCRIPTION
  Read-only. For each subscription whose ancestor chain changes it compares what it inherits today with what it
  will inherit afterwards:

    Policy        assignments gained / lost, with their effects resolved (Deny, DeployIfNotExists, Modify, Audit ...)
                  through initiative and assignment parameters. Same definition on both sides = no change.
    Exemption     policy exemptions at management group scope that stop / start applying
    RBAC          role assignments at management group scope gained / lost (who loses or gains access)
    Blocker       custom roles assigned inside the subscription whose assignable scope will no longer cover it
                  (Azure refuses the move), and subscription / RG policy assignments that use a definition stored
                  on a management group that will no longer be an ancestor
    Cost          management-group-scoped reservations / savings plans and budgets the subscription leaves or joins

  Planned assignments for management groups that do not exist yet (e.g. from your Terraform) can be included with
  -PlannedAssignmentsPath: [{ "managementGroup": "bd-corp", "policyDefinitionId": "...", "parameters": {...}, "enforcementMode": "Default" }]

  Outputs: impact.csv, impact-report.md (summary, blockers, per-subscription detail, before/after Mermaid trees).
  Exit code 2 if any blocker.

.EXAMPLE
  ./02-Get-MgMoveImpact.ps1 -TargetPath ./out/target-hierarchy.json
#>
[CmdletBinding()]
param(
    [string]$TargetPath = './out/target-hierarchy.json',
    [string]$PlannedAssignmentsPath,
    [string]$OutDir = './out',
    [switch]$SkipCost
)
$ErrorActionPreference = 'Stop'
Import-Module (Join-Path $PSScriptRoot '..' 'lib' 'AzCliHelpers.psm1') -Force
Import-Module (Join-Path $PSScriptRoot '..' 'lib' 'MgHierarchy.psm1') -Force
Import-Module (Join-Path $PSScriptRoot '..' 'lib' 'PolicyEffects.psm1') -Force
New-Item -ItemType Directory -Force -Path $OutDir | Out-Null

$target = Get-Content -Raw $TargetPath | ConvertFrom-Json -Depth 20
$tenantId = (Invoke-AzJson @('account', 'show')).tenantId
$flat = ConvertTo-FlatHierarchy -Tree (Get-MgTreeLive -TenantId $tenantId)
$mgScope = { param($id) "/providers/Microsoft.Management/managementGroups/$id" }

# ---------------- target parent map ----------------
$newParent = @{} + $flat.Parent
$newNames = @{}
foreach ($g in @($target.intermediateRoot) + @($target.managementGroups)) {
    if (-not $g) { continue }
    $newParent[$g.id] = $g.parent; $newNames[$g.id] = $g.displayName
}
$unconfirmed = @($target.subscriptions | Where-Object { -not $_.confirmed })
if ($unconfirmed) { Write-Warning "$($unconfirmed.Count) mapping row(s) not confirmed yet (analysis still runs): $($unconfirmed.name -join ', ')" }
foreach ($s in $target.subscriptions) {
    if (-not ($flat.Subscriptions | Where-Object Id -eq $s.id)) { Write-Warning "Subscription $($s.name) ($($s.id)) not found in the tenant tree - skipped"; continue }
    if (-not $newParent.ContainsKey($s.target) -and $s.target -ne $tenantId -and -not ($flat.Groups.Id -contains $s.target)) { throw "Target '$($s.target)' for $($s.name) is not an existing or planned management group" }
    $newParent[$s.id] = $s.target
}
# cycle / depth check
foreach ($g in $newParent.Keys) {
    $chain = Get-AncestorChain -Id $g -ParentMap $newParent
    if ($chain -contains $g) { throw "Cycle in target hierarchy at $g" }
    if ($chain.Count -gt 7) { throw "$g would be $($chain.Count) levels deep (Azure limit: 6 below root)" }
}

# ---------------- which subscriptions change ----------------
$changes = foreach ($s in $flat.Subscriptions) {
    $cur = Get-AncestorChain -Id $s.Id -ParentMap $flat.Parent
    $new = Get-AncestorChain -Id $s.Id -ParentMap $newParent
    if (($cur -join '>') -eq ($new -join '>')) { continue }
    [pscustomobject]@{ Id = $s.Id; Name = $s.Name; Current = $cur; New = $new
        Lost = @($cur | Where-Object { $_ -notin $new }); Gained = @($new | Where-Object { $_ -notin $cur }); From = $flat.Parent[$s.Id]; To = $newParent[$s.Id] }
}
$changes = @($changes)
Write-Host "Subscriptions whose inheritance changes: $($changes.Count) of $(@($flat.Subscriptions).Count)" -ForegroundColor Cyan

# ---------------- per-MG inventory (lazy, cached) ----------------
$existingMg = @{}; foreach ($g in $flat.Groups) { $existingMg[$g.Id] = $true }
$mgData = @{}
function Get-MgData([string]$mg) {
    if ($mgData.ContainsKey($mg)) { return $mgData[$mg] }
    $scope = & $mgScope $mg
    $d = @{ Assignments = @(); Exemptions = @(); Roles = @(); Budgets = @() }
    if ($existingMg[$mg]) {
        $d.Assignments = @(Invoke-AzJson @('policy', 'assignment', 'list', '--scope', $scope) | Where-Object { (Get-AzProp $_ 'scope') -eq $scope })
        $d.Exemptions = @(try { Invoke-AzJson @('policy', 'exemption', 'list', '--scope', $scope) | Where-Object { $_.id -like "$scope/*" } } catch { Write-Verbose $_ })
        $d.Roles = @(Invoke-AzJson @('role', 'assignment', 'list', '--scope', $scope, '--fill-principal-name', 'true') | Where-Object { $_.scope -eq $scope })
        if (-not $SkipCost) { $d.Budgets = @(try { (Invoke-AzRest get "$scope/providers/Microsoft.Consumption/budgets?api-version=2023-05-01").value } catch { Write-Verbose $_ }) }
    }
    if ($planned) { $d.Assignments += @($planned | Where-Object managementGroup -eq $mg | ForEach-Object {
                [pscustomobject]@{ id = "planned:$($_.managementGroup)/$($_.policyDefinitionId -replace '.*/', '')"; name = 'planned'; displayName = ($_.displayName ?? "PLANNED $($_.policyDefinitionId -replace '.*/', '')")
                    policyDefinitionId = $_.policyDefinitionId; parameters = $_.parameters; enforcementMode = ($_.enforcementMode ?? 'Default'); scope = (& $mgScope $mg) } }) }
    $mgData[$mg] = $d; $d
}
$planned = if ($PlannedAssignmentsPath) { @(Get-Content -Raw $PlannedAssignmentsPath | ConvertFrom-Json -Depth 20) } else { @() }

# ---------------- policy effect resolution: lib/PolicyEffects.psm1 ----------------

# ---------------- cost: reservations scoped to MGs ----------------
$reservations = @()
if (-not $SkipCost) {
    try {
        $reservations = @((Invoke-AzRest get '/providers/Microsoft.Capacity/reservations?api-version=2022-11-01').value |
            Where-Object { (Get-AzProp $_ 'appliedScopeType') -eq 'ManagementGroup' })
    } catch { Write-Warning "Could not list reservations (needs Reservations Reader): $($_.Exception.Message)" }
}

# ---------------- build impact rows ----------------
$rows = [System.Collections.Generic.List[object]]::new()
function Add-Row($sub, $cat, $change, $sev, $item, $detail, $scope, $action) {
    $rows.Add([pscustomobject]@{ Subscription = $sub.Name; SubscriptionId = $sub.Id; From = $sub.From; To = $sub.To; Category = $cat; Change = $change
                                 Severity = $sev; Item = $item; Detail = $detail; Scope = $scope; Action = $action })
}
$privileged = 'Owner', 'Contributor', 'User Access Administrator', 'Role Based Access Control Administrator'

foreach ($c in $changes) {
    Write-Host "  analysing $($c.Name): $($c.From) -> $($c.To)"
    # --- policy ---
    $lost = @($c.Lost | ForEach-Object { (Get-MgData $_).Assignments })
    $gain = @($c.Gained | ForEach-Object { (Get-MgData $_).Assignments })
    $lostDefs = @($lost | ForEach-Object { (Get-AzProp $_ 'policyDefinitionId').ToLower() })
    $gainDefs = @($gain | ForEach-Object { (Get-AzProp $_ 'policyDefinitionId').ToLower() })
    foreach ($a in $gain) {
        $def = (Get-AzProp $a 'policyDefinitionId').ToLower()
        $eff = Get-EffectsCached $a; $effTxt = Format-Effects $eff
        $enforced = (Get-AzProp $a 'enforcementMode') -ne 'DoNotEnforce'
        if ($def -in $lostDefs) { Add-Row $c Policy Unchanged Info $a.displayName "same definition inherited before and after ($effTxt)" (Get-AzProp $a 'scope') 'Compare parameters if they differ'; continue }
        $sev, $act = if (-not $enforced) { 'Low', 'DoNotEnforce: compliance data only' }
                     elseif ($eff.Deny -or $eff.DenyAction) { 'High', 'Can block create/update (incl. Terraform applies). Preview with 03, add exemptions or fix resources first' }
                     elseif ($eff.DeployIfNotExists -or $eff.Modify -or $eff.Append) { 'Medium', 'Changes new/updated resources; existing ones need a remediation task' }
                     else { 'Low', 'Compliance reporting only' }
        Add-Row $c Policy Gain $sev $a.displayName $effTxt (Get-AzProp $a 'scope') $act
    }
    foreach ($a in $lost) {
        $def = (Get-AzProp $a 'policyDefinitionId').ToLower()
        if ($def -in $gainDefs) { continue }
        $eff = Get-EffectsCached $a; $effTxt = Format-Effects $eff
        $sev = if ((Get-AzProp $a 'enforcementMode') -ne 'DoNotEnforce' -and ($eff.Deny -or $eff.DenyAction -or $eff.DeployIfNotExists -or $eff.Modify)) { 'High' } else { 'Low' }
        Add-Row $c Policy Lose $sev $a.displayName $effTxt (Get-AzProp $a 'scope') $(if ($sev -eq 'High') { 'Guardrail removed: make sure the target hierarchy assigns an equivalent' } else { 'Audit coverage removed' })
    }
    # --- exemptions at MG scope ---
    foreach ($e in @($c.Lost | ForEach-Object { (Get-MgData $_).Exemptions })) {
        Add-Row $c Exemption Lose Medium ($e.displayName ?? $e.name) "exemption for $((Get-AzProp $e 'policyAssignmentId') -replace '.*/', '') no longer applies" ($e.id -replace '/providers/Microsoft.Authorization/policyExemptions/.*', '') 'Resources it covered may become non-compliant or be denied: recreate at the target or subscription scope'
    }
    foreach ($e in @($c.Gained | ForEach-Object { (Get-MgData $_).Exemptions })) {
        Add-Row $c Exemption Gain Low ($e.displayName ?? $e.name) "exemption for $((Get-AzProp $e 'policyAssignmentId') -replace '.*/', '') starts applying" ($e.id -replace '/providers/Microsoft.Authorization/policyExemptions/.*', '') 'Check it is intended for this subscription'
    }
    # --- RBAC at MG scope ---
    $rl = @($c.Lost | ForEach-Object { (Get-MgData $_).Roles }); $rg = @($c.Gained | ForEach-Object { (Get-MgData $_).Roles })
    $key = { param($r) "$($r.principalId)|$($r.roleDefinitionName)" }
    $rgKeys = @($rg | ForEach-Object { & $key $_ }); $rlKeys = @($rl | ForEach-Object { & $key $_ })
    foreach ($r in $rl | Where-Object { (& $key $_) -notin $rgKeys }) {
        $who = $r.principalName ? "$($r.principalName) ($($r.principalType))" : "$($r.principalId) ($($r.principalType))"
        Add-Row $c RBAC Lose $(if ($r.roleDefinitionName -in $privileged) { 'High' } else { 'Medium' }) "$($r.roleDefinitionName): $who" 'access inherited from this management group is removed' $r.scope 'Confirm nobody needs it, or assign at the target / subscription before moving'
    }
    foreach ($r in $rg | Where-Object { (& $key $_) -notin $rlKeys }) {
        $who = $r.principalName ? "$($r.principalName) ($($r.principalType))" : "$($r.principalId) ($($r.principalType))"
        Add-Row $c RBAC Gain $(if ($r.roleDefinitionName -in $privileged) { 'High' } else { 'Low' }) "$($r.roleDefinitionName): $who" 'new inherited access' $r.scope $(if ($r.roleDefinitionName -in $privileged) { 'Security review: privileged access gained' } else { 'None' })
    }
    # --- blockers: custom roles assigned inside the subscription ---
    $subScope = "/subscriptions/$($c.Id)"
    $assignsInSub = @(Invoke-AzJson @('role', 'assignment', 'list', '--subscription', $c.Id, '--all', '--fill-principal-name', 'false') | Where-Object { $_.scope -like "$subScope*" })
    $roleDefs = @{}
    foreach ($ra in $assignsInSub) {
        $rid = $ra.roleDefinitionId
        if (-not $roleDefs.ContainsKey($rid)) { $roleDefs[$rid] = try { Invoke-AzRest get "$($rid)?api-version=2022-04-01" } catch { $null } }
        $rd = $roleDefs[$rid]
        if (-not $rd -or (Get-AzProp $rd 'type') -notmatch 'CustomRole') { continue }
        $scopes = @(Get-AzProp $rd 'assignableScopes')
        $ok = $scopes | Where-Object {
            $_ -eq '/' -or $ra.scope -like "$_*" -or ($_ -match '/managementGroups/([^/]+)$' -and $Matches[1] -in $c.New)
        }
        if (-not $ok) {
            Add-Row $c Blocker CustomRole Blocker "$(Get-AzProp $rd 'roleName') on $($ra.scope -replace [regex]::Escape($subScope), '<sub>')" "assignable scopes: $($scopes -join ', ')" $ra.scope 'Azure will refuse the move: add the target (or a common ancestor) to the role''s assignable scopes, or remove the assignment'
        }
    }
    # --- blockers: sub/RG policy assignments using definitions stored on MGs that won't be ancestors ---
    $subAssign = @(Invoke-AzJson @('policy', 'assignment', 'list', '--subscription', $c.Id, '--disable-scope-strict-match') | Where-Object { (Get-AzProp $_ 'scope') -like "$subScope*" })
    foreach ($a in $subAssign) {
        $d = Get-AzProp $a 'policyDefinitionId'
        if ($d -match '/managementGroups/([^/]+)/providers/') {
            $defHome = $Matches[1]
            if ($defHome -notin $c.New) {
                Add-Row $c Blocker PolicyDefinition Blocker $a.displayName "definition stored on management group '$defHome'" (Get-AzProp $a 'scope') "Move the custom definition to a common ancestor (intermediate root '$($target.intermediateRoot.id)') before moving"
            }
        }
    }
    # --- cost ---
    foreach ($b in @($c.Lost | ForEach-Object { (Get-MgData $_).Budgets })) { Add-Row $c Cost Lose Low "Budget $($b.name)" 'spend no longer counted in this management-group budget' ($b.id -replace '/providers/Microsoft.Consumption/budgets/.*', '') 'Adjust budget amounts' }
    foreach ($b in @($c.Gained | ForEach-Object { (Get-MgData $_).Budgets })) { Add-Row $c Cost Gain Low "Budget $($b.name)" 'spend now counts towards this management-group budget' ($b.id -replace '/providers/Microsoft.Consumption/budgets/.*', '') 'Adjust budget amounts' }
    foreach ($r in $reservations) {
        $mg = (Get-AzProp $r 'appliedScopeProperties').managementGroupId -replace '.*/', ''
        $name = (Get-AzProp $r 'displayName') ?? $r.name
        if ($mg -in $c.Lost) { Add-Row $c Cost Lose High "Reservation $name" "scoped to management group '$mg': this subscription stops receiving the discount" $mg 'Rescope the reservation (shared / target MG) before moving' }
        if ($mg -in $c.Gained) { Add-Row $c Cost Gain Low "Reservation $name" "scoped to '$mg': discount starts applying" $mg 'None' }
    }
}

# ---------------- outputs ----------------
$sevOrder = @{ Blocker = 0; High = 1; Medium = 2; Low = 3; Info = 4 }
$sorted = $rows | Sort-Object { $sevOrder[$_.Severity] }, Subscription, Category
$sorted | Export-Csv (Join-Path $OutDir 'impact.csv') -NoTypeInformation

$moved = @($changes.Id)
$before = ConvertTo-MgMermaid -Flat $flat -Highlight $moved
$afterFlat = @{ Groups = @($flat.Groups) + @(@($target.intermediateRoot) + @($target.managementGroups) | Where-Object { $_ -and $_.id -notin $flat.Groups.Id } | ForEach-Object { [pscustomobject]@{ Id = $_.id; DisplayName = $_.displayName; Parent = $_.parent } })
                Subscriptions = $flat.Subscriptions; Parent = $newParent; RootId = $flat.RootId }
$after = ConvertTo-MgMermaid -Flat $afterFlat -ParentMap $newParent -Highlight $moved
$afterTxt = Format-MgTree -Flat $afterFlat -ParentMap $newParent
$afterTxt | Set-Content (Join-Path $OutDir 'target-tree.txt')

$md = [System.Text.StringBuilder]::new()
$null = $md.AppendLine("# Management group restructure: impact report`n")
$null = $md.AppendLine("Generated $(Get-Date -Format 'yyyy-MM-dd HH:mm') from ``$(Split-Path $TargetPath -Leaf)`` ($($target.layout) layout). Subscriptions changing: **$($changes.Count)**.`n")
if ($unconfirmed) { $null = $md.AppendLine("> $($unconfirmed.Count) mapping row(s) are not confirmed yet: $($unconfirmed.name -join ', ').`n") }
$null = $md.AppendLine("## Summary`n`n| Subscription | From | To | Blocker | High | Medium | Low |`n|---|---|---|---|---|---|---|")
foreach ($c in $changes | Sort-Object Name) {
    $r = @($rows | Where-Object SubscriptionId -eq $c.Id)
    $n = { param($s) @($r | Where-Object Severity -eq $s).Count }
    $null = $md.AppendLine("| $($c.Name) | $($c.From) | $($c.To) | $(& $n 'Blocker') | $(& $n 'High') | $(& $n 'Medium') | $(& $n 'Low') |")
}
$bl = @($rows | Where-Object Severity -eq 'Blocker')
$null = $md.AppendLine("`n## Blockers (fix before moving)`n")
if ($bl) { foreach ($b in $bl) { $null = $md.AppendLine("- **$($b.Subscription)**: $($b.Item) - $($b.Detail). $($b.Action)") } } else { $null = $md.AppendLine('None found.') }
$targetIds = @(@($target.intermediateRoot) + @($target.managementGroups) | Where-Object { $_ } | ForEach-Object id)
$emptyAfter = @($flat.Groups | Where-Object { $_.Id -ne $flat.RootId -and $_.Id -notin $targetIds -and -not ($newParent.Values -contains $_.Id) })
$null = $md.AppendLine("`n## Management groups left empty`n")
if ($emptyAfter) {
    foreach ($g in $emptyAfter) {
        $note = @()
        if ($assigned = @((Get-MgData $g.Id).Assignments).Count) { $note += "$assigned policy assignment(s) to retire or re-home" }
        if ($rbac = @((Get-MgData $g.Id).Roles).Count) { $note += "$rbac role assignment(s)" }
        $null = $md.AppendLine("- $($g.DisplayName) (``$($g.Id)``)$(if ($note) { ': ' + ($note -join ', ') }). Delete after the last wave$(if ($g.Id -eq ($target.defaultManagementGroup -replace '.*/','') -or $g.Id -eq 'Default') { ' (repoint the default management group first)' }).")
    }
} else { $null = $md.AppendLine('None.') }
$null = $md.AppendLine("`n## Detail by subscription")
foreach ($c in $changes | Sort-Object Name) {
    $null = $md.AppendLine("`n### $($c.Name)`n`n``$($c.Current -join ' > ')`` → ``$($c.New -join ' > ')```n")
    $r = @($sorted | Where-Object { $_.SubscriptionId -eq $c.Id -and $_.Severity -ne 'Info' })
    if (-not $r) { $null = $md.AppendLine('No inherited policy, access or cost changes.'); continue }
    $null = $md.AppendLine('| Severity | Category | Change | Item | Detail | Action |'); $null = $md.AppendLine('|---|---|---|---|---|---|')
    foreach ($x in $r) { $null = $md.AppendLine("| $($x.Severity) | $($x.Category) | $($x.Change) | $($x.Item -replace '\|', '/') | $($x.Detail -replace '\|', '/') | $($x.Action -replace '\|', '/') |") }
}
$null = $md.AppendLine("`n## Hierarchy`n`n### Today (moving subscriptions in red)`n`n``````mermaid`n$before`n```````n`n### Target`n`n``````mermaid`n$after`n```````n`n``````text`n$afterTxt`n``````")
$md.ToString() | Set-Content (Join-Path $OutDir 'impact-report.md')

Write-Host "`nTarget hierarchy" -ForegroundColor Cyan; Write-Host $afterTxt
Write-Host "`nImpact by severity" -ForegroundColor Cyan
$rows | Group-Object Severity | Sort-Object { $sevOrder[$_.Name] } | ForEach-Object { Write-Host ("  {0,-8} {1}" -f $_.Name, $_.Count) }
if ($bl) { Write-Host "`nBlockers:" -ForegroundColor Red; $bl | ForEach-Object { Write-Host "  $($_.Subscription): $($_.Item) - $($_.Action)" -ForegroundColor Red } }
Write-Host "`nReport: $(Join-Path $OutDir 'impact-report.md')   Rows: $(Join-Path $OutDir 'impact.csv')"
if ($bl) { exit 2 }
