#requires -Version 7.2
# Management group hierarchy helpers (pure functions + one az call), shared by the scripts.

function Get-MgTreeLive {
    # Whole tree from the tenant root. Needs Reader (or Management Group Reader) at the root.
    param([Parameter(Mandatory)][string]$TenantId)
    Invoke-AzJson @('account', 'management-group', 'show', '--name', $TenantId, '--expand', '--recurse')
}

function ConvertTo-FlatHierarchy {
    <# Returns @{ Groups = [ {Id, DisplayName, Parent} ]; Subscriptions = [ {Id, Name, Parent} ]; Parent = @{ id -> parentId } } #>
    param([Parameter(Mandatory)]$Tree)
    $groups = [System.Collections.Generic.List[object]]::new()
    $subs = [System.Collections.Generic.List[object]]::new()
    $parent = @{}
    $walk = {
        param($node, $parentId)
        $groups.Add([pscustomobject]@{ Id = $node.name; DisplayName = $node.displayName; Parent = $parentId })
        if ($parentId) { $parent[$node.name] = $parentId }
        foreach ($c in @($node.children)) {
            if (-not $c) { continue }
            if ($c.type -match 'subscriptions$') {
                $subs.Add([pscustomobject]@{ Id = $c.name; Name = $c.displayName; Parent = $node.name })
                $parent[$c.name] = $node.name
            } else { & $walk $c $node.name }
        }
    }
    & $walk $Tree $null
    @{ Groups = $groups.ToArray(); Subscriptions = $subs.ToArray(); Parent = $parent; RootId = $Tree.name }
}

function Get-AncestorChain {
    # Ancestors from direct parent up to the root (cycle-safe).
    param([Parameter(Mandatory)][string]$Id, [Parameter(Mandatory)][hashtable]$ParentMap)
    $chain = [System.Collections.Generic.List[string]]::new(); $cur = $ParentMap[$Id]; $seen = @{}
    while ($cur -and -not $seen.ContainsKey($cur)) { $seen[$cur] = 1; $chain.Add($cur); $cur = $ParentMap[$cur] }
    , $chain.ToArray()
}

function Format-MgTree {
    # Plain-text tree for consoles and change records.
    param([Parameter(Mandatory)]$Flat, [hashtable]$ParentMap = $Flat.Parent, [hashtable]$Names = @{})
    foreach ($g in $Flat.Groups) { $Names[$g.Id] = $g.DisplayName }
    foreach ($s in $Flat.Subscriptions) { $Names[$s.Id] = $s.Name }
    $children = @{}
    foreach ($k in $ParentMap.Keys) { $p = $ParentMap[$k]; if (-not $children[$p]) { $children[$p] = [System.Collections.Generic.List[string]]::new() }; $children[$p].Add($k) }
    $isSub = @{}; foreach ($s in $Flat.Subscriptions) { $isSub[$s.Id] = $true }
    $lines = [System.Collections.Generic.List[string]]::new()
    $render = {
        param($id, $prefix, $last, $top)
        $label = if ($isSub[$id]) { "[sub] $($Names[$id])" } else { "$($Names[$id] ?? $id) ($id)" }
        $lines.Add($(if ($top) { $label } else { "$prefix$(if ($last) { '└─ ' } else { '├─ ' })$label" }))
        $kids = @($children[$id] | Sort-Object { [int][bool]$isSub[$_] }, { $Names[$_] })
        for ($i = 0; $i -lt $kids.Count; $i++) {
            $np = if ($top) { '' } else { $prefix + $(if ($last) { '   ' } else { '│  ' }) }
            & $render $kids[$i] $np ($i -eq $kids.Count - 1) $false
        }
    }
    & $render $Flat.RootId '' $true $true
    $lines -join "`n"
}

function ConvertTo-MgMermaid {
    param([Parameter(Mandatory)]$Flat, [hashtable]$ParentMap = $Flat.Parent, [hashtable]$Names = @{}, [string[]]$Highlight = @())
    foreach ($g in $Flat.Groups) { $Names[$g.Id] = $g.DisplayName }
    foreach ($s in $Flat.Subscriptions) { $Names[$s.Id] = $s.Name }
    $isSub = @{}; foreach ($s in $Flat.Subscriptions) { $isSub[$s.Id] = $true }
    $nid = { param($x) 'n' + (($x -replace '[^A-Za-z0-9]', '') | ForEach-Object { if ($_.Length -gt 40) { $_.Substring(0, 40) } else { $_ } }) }
    $out = [System.Collections.Generic.List[string]]::new(); $out.Add('graph TD')
    $all = @($ParentMap.Keys) + @($Flat.RootId) | Sort-Object -Unique
    foreach ($id in $all) {
        $label = ($Names[$id] ?? $id) -replace '"', "'"
        $shape = if ($isSub[$id]) { "$(& $nid $id)([`"$label`"])" } else { "$(& $nid $id)[`"$label`"]" }
        $out.Add("  $shape")
    }
    foreach ($k in $ParentMap.Keys) { $out.Add("  $(& $nid $ParentMap[$k]) --> $(& $nid $k)") }
    $out.Add('  classDef sub fill:#fff4ce,stroke:#c19c00'); $out.Add('  classDef moved fill:#ffd6d6,stroke:#d13438')
    $subIds = @($Flat.Subscriptions.Id | ForEach-Object { & $nid $_ }); if ($subIds) { $out.Add("  class $($subIds -join ',') sub") }
    $hl = @($Highlight | ForEach-Object { & $nid $_ }); if ($hl) { $out.Add("  class $($hl -join ',') moved") }
    $out -join "`n"
}

Export-ModuleMember -Function Get-MgTreeLive, ConvertTo-FlatHierarchy, Get-AncestorChain, Format-MgTree, ConvertTo-MgMermaid
