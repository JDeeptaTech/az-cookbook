#requires -Version 7.2
# Resolve the effective effect(s) of a policy or initiative assignment through assignment, initiative and
# definition parameters. Definitions are fetched once with az rest and cached.
Import-Module (Join-Path $PSScriptRoot 'AzCliHelpers.psm1')

# ---------------- policy effect resolution ----------------
$script:defCache = @{}
function Get-PolicyDef([string]$id) {
    $k = $id.ToLower()
    if (-not $script:defCache.ContainsKey($k)) {
        $api = if ($id -match '/policySetDefinitions/') { '2023-04-01' } else { '2023-04-01' }
        $script:defCache[$k] = try { Invoke-AzRest get "$($id)?api-version=$api" } catch { $null }
    }
    $script:defCache[$k]
}
function Resolve-ParamValue($raw, [hashtable]$ctx) {
    if ($raw -is [string] -and $raw -match "^\[parameters\('([^']+)'\)\]$") { $p = $Matches[1]; return $(if ($ctx.ContainsKey($p)) { $ctx[$p] } else { $raw }) }
    $raw
}
function Get-DefinitionEffect($def, [hashtable]$passed) {
    $rule = Get-AzProp $def 'policyRule'; if (-not $rule) { return 'Unknown' }
    $e = $rule.then.effect
    if ($e -match "^\[parameters\('([^']+)'\)\]$") {
        $p = $Matches[1]
        if ($passed.ContainsKey($p)) { $e = $passed[$p] }
        else { $e = ((Get-AzProp $def 'parameters').$p.defaultValue) ?? 'Unknown' }
    }
    "$e"
}
function Get-AssignmentEffects($a) {
    <# returns hashtable effect -> count #>
    $assignParams = @{}
    $ap = Get-AzProp $a 'parameters'
    if ($ap) { foreach ($p in $ap.PSObject.Properties) { $assignParams[$p.Name] = $p.Value.value } }
    $defId = Get-AzProp $a 'policyDefinitionId'
    $counts = @{}
    $add = { param($eff) $n = switch -Regex ($eff) { '^(?i)deny$' { 'Deny' } '^(?i)denyaction$' { 'DenyAction' } '^(?i)deployifnotexists$' { 'DeployIfNotExists' } '^(?i)modify$' { 'Modify' } '^(?i)append$' { 'Append' } '^(?i)audit$' { 'Audit' } '^(?i)auditifnotexists$' { 'AuditIfNotExists' } '^(?i)disabled$' { 'Disabled' } '^(?i)manual$' { 'Manual' } default { 'Unknown' } }; $counts[$n] = 1 + ($counts[$n] ?? 0) }
    if ($defId -match '/policySetDefinitions/') {
        $set = Get-PolicyDef $defId
        if (-not $set) { & $add 'Unknown'; return $counts }
        $setCtx = @{}
        $sp = Get-AzProp $set 'parameters'
        if ($sp) { foreach ($p in $sp.PSObject.Properties) { $setCtx[$p.Name] = ($assignParams.ContainsKey($p.Name) ? $assignParams[$p.Name] : $p.Value.defaultValue) } }
        foreach ($m in @(Get-AzProp $set 'policyDefinitions')) {
            $md = Get-PolicyDef $m.policyDefinitionId
            if (-not $md) { & $add 'Unknown'; continue }
            $passed = @{}
            if ($m.parameters) { foreach ($p in $m.parameters.PSObject.Properties) { $passed[$p.Name] = Resolve-ParamValue $p.Value.value $setCtx } }
            & $add (Get-DefinitionEffect $md $passed)
        }
    } else {
        $d = Get-PolicyDef $defId
        if ($d) { & $add (Get-DefinitionEffect $d $assignParams) } else { & $add 'Unknown' }
    }
    $counts
}
$script:effCache = @{}
function Get-EffectsCached($a) { $k = "$($a.id)"; if (-not $script:effCache.ContainsKey($k)) { $script:effCache[$k] = Get-AssignmentEffects $a }; $script:effCache[$k] }
function Format-Effects([hashtable]$c) { ($c.GetEnumerator() | Sort-Object { @('Deny', 'DenyAction', 'DeployIfNotExists', 'Modify', 'Append', 'AuditIfNotExists', 'Audit', 'Manual', 'Disabled', 'Unknown').IndexOf($_.Key) } | ForEach-Object { "$($_.Key):$($_.Value)" }) -join ' ' }

function Get-DefinitionSource([string]$DefinitionId) {
    # BuiltIn, or Custom with where it is stored (management group / subscription)
    if ($DefinitionId -match '^/providers/Microsoft\.Authorization/') { return 'BuiltIn' }
    if ($DefinitionId -match '/managementGroups/([^/]+)/providers/') { return "Custom @ mg:$($Matches[1])" }
    if ($DefinitionId -match '^/subscriptions/([^/]+)/providers/') { return "Custom @ sub:$($Matches[1])" }
    'Unknown'
}

Export-ModuleMember -Function Get-PolicyDef, Get-AssignmentEffects, Get-EffectsCached, Format-Effects, Get-DefinitionSource
