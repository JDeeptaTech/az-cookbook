"""Centralised configuration. All paths and toggles live here."""
from __future__ import annotations

from functools import lru_cache
from pathlib import Path

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


def _find_project_root() -> Path:
    """
    Walk up from cwd until we find pyproject.toml. This works whether the
    package is installed editable, in a venv, or in a container - we always
    land on the actual project directory the user is running from.
    """
    cwd = Path.cwd().resolve()
    for parent in [cwd, *cwd.parents]:
        if (parent / "pyproject.toml").exists():
            return parent
    return cwd


class Settings(BaseSettings):
    """App-wide settings. Override via env vars or .env file."""

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        env_prefix="FWR_",
        extra="ignore",
    )

    # Paths (resolved relative to project root)
    project_root: Path = Field(default_factory=_find_project_root)
    data_raw_dir: Path = Path("data/raw")
    data_archive_dir: Path = Path("data/archive")
    warehouse_path: Path = Path("warehouse.duckdb")
    dbt_project_dir: Path = Path("dbt_project")
    logs_dir: Path = Path("logs")

    # Scheduler
    schedule_cron: str = "0 6 * * *"  # 06:00 daily
    scheduler_timezone: str = "Europe/London"

    # Ingestion behaviour
    archive_after_load: bool = True
    fail_fast: bool = False

    # Dashboard
    dashboard_port: int = 8501

    # Logging
    log_level: str = "INFO"
    log_json: bool = False

    def resolve(self, p: Path) -> Path:
        """Resolve a relative path against project root."""
        return p if p.is_absolute() else (self.project_root / p).resolve()

    @property
    def warehouse(self) -> Path:
        return self.resolve(self.warehouse_path)

    @property
    def raw_dir(self) -> Path:
        return self.resolve(self.data_raw_dir)

    @property
    def archive_dir(self) -> Path:
        return self.resolve(self.data_archive_dir)

    @property
    def dbt_dir(self) -> Path:
        return self.resolve(self.dbt_project_dir)

    @property
    def log_dir(self) -> Path:
        return self.resolve(self.logs_dir)


@lru_cache
def get_settings() -> Settings:
    return Settings()
