"""
`fwr` CLI - the operator entrypoint for everything.

Usage examples:
    fwr ingest                          # run bronze ingestion only
    fwr transform                       # run dbt only
    fwr etl                             # full ETL on demand
    fwr etl --source server_inventory   # subset
    fwr etl --full-refresh
    fwr scheduler                       # run the cron scheduler in foreground
    fwr dashboard                       # launch Streamlit
    fwr db                              # open DuckDB CLI on the warehouse
    fwr status                          # show recent run summaries
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
from pathlib import Path

import typer
from rich.console import Console
from rich.table import Table

from firmware_reporting.ingest import SOURCES, run_ingest
from firmware_reporting.orchestrator import run_etl
from firmware_reporting.settings import get_settings
from firmware_reporting.transform import dbt_deps, run_transform
from firmware_reporting.utils.logging import configure_logging, get_logger

app = typer.Typer(
    name="fwr",
    help="Firmware Upgrade Programme reporting platform.",
    no_args_is_help=True,
    add_completion=False,
)
console = Console()


@app.callback()
def _bootstrap() -> None:
    configure_logging()


@app.command()
def ingest(
    source: list[str] = typer.Option(
        None, "--source", "-s", help="Specific source(s) to ingest. Repeat for multiple."
    ),
) -> None:
    """Run bronze ingestion only."""
    summary = run_ingest(source_names=source or None)
    console.print_json(json.dumps(summary, default=str))
    raise typer.Exit(0 if summary.get("status") in ("success", "no_op") else 1)


@app.command()
def transform(
    select: str | None = typer.Option(None, "--select", help="dbt selector"),
    full_refresh: bool = typer.Option(False, "--full-refresh"),
    no_tests: bool = typer.Option(False, "--no-tests"),
) -> None:
    """Run dbt transformations only."""
    summary = run_transform(
        select=select, full_refresh=full_refresh, run_tests=not no_tests
    )
    console.print_json(json.dumps(summary, default=str))
    raise typer.Exit(0 if summary.get("status") == "success" else 1)


@app.command()
def etl(
    source: list[str] = typer.Option(None, "--source", "-s"),
    skip_transform: bool = typer.Option(False, "--skip-transform"),
    full_refresh: bool = typer.Option(False, "--full-refresh"),
    no_tests: bool = typer.Option(False, "--no-tests"),
    select: str | None = typer.Option(None, "--select"),
) -> None:
    """Run full ETL on demand (bronze + silver + gold)."""
    summary = run_etl(
        sources=source or None,
        skip_transform=skip_transform,
        full_refresh=full_refresh,
        run_tests=not no_tests,
        dbt_select=select,
    )
    console.print_json(json.dumps(summary, default=str))
    raise typer.Exit(0 if summary.get("status") == "success" else 1)


@app.command()
def scheduler() -> None:
    """Run the cron scheduler in the foreground."""
    from firmware_reporting.scheduler import start_blocking
    start_blocking()


@app.command()
def dashboard(
    port: int = typer.Option(None, "--port", "-p"),
) -> None:
    """Launch the Streamlit dashboard."""
    settings = get_settings()
    app_path = Path(__file__).resolve().parent / "dashboard" / "app.py"
    cmd = [
        sys.executable, "-m", "streamlit", "run",
        str(app_path),
        "--server.port", str(port or settings.dashboard_port),
        "--server.headless", "true",
    ]
    os.execvp(cmd[0], cmd)  # replace process


@app.command()
def db() -> None:
    """Open the DuckDB CLI on the warehouse file."""
    settings = get_settings()
    if not settings.warehouse.exists():
        console.print(f"[yellow]No warehouse yet at {settings.warehouse}[/yellow]")
        raise typer.Exit(1)
    os.execvp("duckdb", ["duckdb", str(settings.warehouse)])


@app.command()
def deps() -> None:
    """Install dbt packages."""
    rc = dbt_deps()
    raise typer.Exit(rc)


@app.command()
def sources() -> None:
    """List configured sources."""
    table = Table(title="Configured Sources")
    table.add_column("Name")
    table.add_column("Bronze table")
    table.add_column("File pattern")
    table.add_column("PK")
    table.add_column("Disposition")
    for s in SOURCES:
        table.add_row(
            s.name,
            f"bronze.{s.table_name}",
            s.pattern,
            ",".join(s.primary_key) or "-",
            s.write_disposition,
        )
    console.print(table)


@app.command()
def status(limit: int = 5) -> None:
    """Show recent ETL run summaries from logs/."""
    settings = get_settings()
    runs = sorted(settings.log_dir.glob("etl_run_*.json"), reverse=True)[:limit]
    if not runs:
        console.print("[yellow]No runs recorded yet.[/yellow]")
        return
    table = Table(title=f"Last {len(runs)} ETL runs")
    table.add_column("Run ID")
    table.add_column("Status")
    table.add_column("Started")
    table.add_column("Finished")
    for r in runs:
        data = json.loads(r.read_text())
        table.add_row(
            data.get("run_id", "?"),
            data.get("status", "?"),
            data.get("started_at", "?"),
            data.get("finished_at", "?"),
        )
    console.print(table)


if __name__ == "__main__":
    app()
