# VM TestOps — pytest + Allure framework

End-to-end test framework for the VM self-service platform. Covers
multi-OS provisioning (Linux + Windows variants) and asynchronous
day-2 operations (power, disk, snapshot, network) with rich Allure reporting.

## Layout

```
.
├── pytest.ini                  # markers, addopts, allure dir
├── conftest.py                 # CLI flags, OS parametrize, build->day2 routing
├── allure_categories.json      # failure bucketing in reports
├── azure-pipelines.yml         # ADO pipeline: build + day2 stages
├── requirements.txt
├── .env.example                # local env template
├── config/
│   ├── os_matrix.yaml          # all OS versions
│   ├── day2_matrix.yaml        # all day-2 ops
│   └── timeouts.yaml           # per-op timeouts + state map
├── lib/
│   ├── async_ops.py            # submit/poll/validate primitives
│   ├── vm_api_client.py        # HTTP client for your FastAPI
│   ├── state_store.py          # build->day2 handoff (vm_state.json)
│   └── allure_utils.py         # report helpers
├── tests/
│   ├── builds/
│   │   └── test_vm_build.py
│   └── day2/
│       ├── test_power_ops.py
│       ├── test_disk_ops.py
│       ├── test_snapshot_ops.py
│       └── test_network_ops.py
└── scripts/run.sh              # common run patterns
```

## Setup

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
# edit .env with your VM_API_BASE_URL and VM_API_TOKEN
```

Install Allure CLI (one-time, for local report viewing):
```bash
# macOS
brew install allure
# Linux
curl -o allure.tgz -L https://github.com/allure-framework/allure2/releases/download/2.27.0/allure-2.27.0.tgz
tar -xzf allure.tgz && export PATH=$PWD/allure-2.27.0/bin:$PATH
```

## Running

### Build + day2 in one shot
```bash
pytest --phase=all
```

### Two-phase (the typical CI pattern)
```bash
pytest --phase=build         # writes vm_state.json
pytest --phase=day2          # reads vm_state.json
```

### OS filtering
```bash
pytest --os=linux                          # all Linux variants
pytest --os-version=rhel8,win2022          # exact versions
pytest --os=windows --phase=build          # build only Windows VMs
```

### Day-2 op filtering
```bash
pytest --phase=day2 --day2-op=snapshot
pytest --phase=day2 --day2-op=power,disk
```

### Marker-based filtering (works alongside the flags)
```bash
pytest -m "day2 and snapshot and rhel8"
pytest -m "build and windows"
pytest -m smoke
```

### Combine
```bash
pytest --phase=day2 --os=linux --day2-op=power -m "not slow"
```

### Parallel execution
```bash
pytest -n auto --dist loadscope --phase=day2
```
`loadscope` is important: it keeps all tests of a given OS on the same
worker so the session-scoped `provisioned_vm` fixture works correctly.

### Keep VMs after the run (debugging)
```bash
pytest --phase=all --keep-vms
```

### Convenience wrapper
```bash
./scripts/run.sh build --os-version=rhel9
./scripts/run.sh day2 --day2-op=snapshot
./scripts/run.sh serve
```

## Adding a new OS

Append to `config/os_matrix.yaml`:
```yaml
  - id: rhel10
    family: linux
    image: rhel-10.0-x86_64
    flavor: small
    aap_template: vm_build_rhel
    boot_timeout: 600
    cloud_init: true
```
Then register the marker in `pytest.ini` and the `_OS_IDS` / `_LINUX_IDS`
sets in `conftest.py`. That's it — every existing test runs against the
new OS automatically.

## Adding a new day-2 operation

1. Add to `config/day2_matrix.yaml` under the appropriate family (or a new family).
2. Add the timeout to `config/timeouts.yaml` under `async_timeouts`.
3. Write the test in `tests/day2/test_<family>_ops.py` using the
   submit-then-wait pattern.

## How async ops work

Every day-2 op goes through three Allure-visible steps:

1. **Submit** — `submit_day2()` returns an `OpHandle` (with `request_id`
   and `correlation_id`). The handle is attached to Allure as JSON.
2. **Poll** — `waiter.wait(handle)` polls `/api/v1/requests/{id}` with
   exponential backoff (2s → 15s capped) until terminal state, or
   timeout from `config/timeouts.yaml`.
3. **Validate** — your test asserts on `result.success`, fetched VM
   state, or the final payload.

Every poll's state transition is attached to Allure, so when a 14-minute
snapshot fails, you see `PENDING → RUNNING → RUNNING → FAILED` with
timestamps — no need to SSH anywhere.

`correlation_id` is sent as `X-Correlation-Id` and ends up in your
Splunk/APIM logs, so the report pivots to logs with a single search.

## How phase routing works

`conftest.py` reads `--phase` and rewires test collection:

- `--phase=build` skips anything marked `@pytest.mark.day2`.
- `--phase=day2` skips anything marked `@pytest.mark.build` and makes
  the `provisioned_vm` fixture read from `vm_state.json` instead of
  provisioning. If the state is missing, day-2 tests are skipped with
  a clear reason rather than failing noisily.
- `--phase=all` runs both and reuses the same VM for both phases.

`vm_state.json` is the persistent handoff. Override with `VM_STATE_FILE`
env var to keep separate state per pipeline run.

## Report quality

`allure_categories.json` buckets failures into Build / Power / Snapshot /
Disk / Network / Timeout / API-network buckets so the dashboard tells
you *what kind* of failure dominates a run.

Each test gets `os_family` and `os_version` Allure labels, so the
Behaviors view lets you filter "all snapshot failures on Windows 2022"
without writing a query.

## Known gotchas

- **Parallel + same OS**: pytest-xdist with multiple workers all
  targeting the same OS id will race in the build phase. Use
  `--dist loadscope` to keep an OS pinned to one worker, or partition
  by OS at the CI level.
- **State map drift**: if your FastAPI emits a status string not in
  `state_map`, the waiter treats it as in-progress and you'll eventually
  hit a timeout. Check `poll-history-*.json` attachments — unknown
  states show up there. Add to `config/timeouts.yaml` and re-run.
- **Cleanup**: the `provisioned_vm` fixture deletes VMs on session
  teardown unless `--keep-vms` or `--phase=day2`. Day-2-only runs never
  delete, since they don't own the VM.
