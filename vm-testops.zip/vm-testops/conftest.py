"""
Central conftest: CLI flags, OS parametrization, build/day2 phase routing,
and shared fixtures.
"""
from __future__ import annotations

import os
from pathlib import Path
from typing import List

import allure
import pytest
import yaml

# Optional .env loading so local runs don't need exported vars
try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

from lib.allure_utils import attach_json, write_environment, write_executor
from lib.async_ops import OpHandle
from lib.state_store import get_vm, record_vm
from lib.vm_api_client import VMPlatformClient

CONFIG_DIR = Path(__file__).parent / "config"
ALLURE_RESULTS_DIR = "allure-results"


# ---------- CLI options ----------
def pytest_addoption(parser):
    g = parser.getgroup("vm-testops")
    g.addoption(
        "--phase",
        action="store",
        default="all",
        choices=["build", "day2", "all"],
        help="Which test phase to run (default: all)",
    )
    g.addoption(
        "--os",
        action="store",
        default="",
        help="Comma-separated OS family filter: linux,windows",
    )
    g.addoption(
        "--os-version",
        action="store",
        default="",
        help="Comma-separated OS id filter: rhel8,win2022",
    )
    g.addoption(
        "--day2-op",
        action="store",
        default="",
        help="Comma-separated day2 op family filter: power,disk,snapshot,network",
    )
    g.addoption(
        "--keep-vms",
        action="store_true",
        default=False,
        help="Don't delete VMs at session end (useful for debugging)",
    )


# ---------- Config loaders ----------
def _load_os_matrix() -> List[dict]:
    with (CONFIG_DIR / "os_matrix.yaml").open() as f:
        return yaml.safe_load(f)["os_versions"]


def _load_day2_matrix() -> dict:
    with (CONFIG_DIR / "day2_matrix.yaml").open() as f:
        return yaml.safe_load(f)["day2_operations"]


@pytest.fixture(scope="session")
def os_matrix() -> List[dict]:
    return _load_os_matrix()


@pytest.fixture(scope="session")
def day2_matrix() -> dict:
    return _load_day2_matrix()


@pytest.fixture(scope="session")
def vm_client():
    client = VMPlatformClient()
    yield client
    client.close()


# ---------- OS filtering + parametrization ----------
def _filter_os(items: List[dict], os_filter: str, version_filter: str) -> List[dict]:
    if os_filter:
        families = {f.strip() for f in os_filter.split(",") if f.strip()}
        items = [i for i in items if i["family"] in families]
    if version_filter:
        versions = {v.strip() for v in version_filter.split(",") if v.strip()}
        items = [i for i in items if i["id"] in versions]
    return items


def pytest_generate_tests(metafunc):
    """Inject the `os_spec` fixture wherever a test asks for it."""
    if "os_spec" in metafunc.fixturenames:
        matrix = _load_os_matrix()
        matrix = _filter_os(
            matrix,
            metafunc.config.getoption("--os"),
            metafunc.config.getoption("--os-version"),
        )
        if not matrix:
            # Empty parametrize yields a skipped placeholder rather than a hard error
            metafunc.parametrize("os_spec", [pytest.param(None, marks=pytest.mark.skip(
                reason="No OS matches --os / --os-version filters"
            ))])
            return
        metafunc.parametrize(
            "os_spec",
            matrix,
            ids=[m["id"] for m in matrix],
            scope="session",
        )


# ---------- Phase + day2-op filtering, dynamic markers ----------
_OS_IDS = {"rhel7", "rhel8", "rhel9", "win2019", "win2022"}
_LINUX_IDS = {"rhel7", "rhel8", "rhel9"}


def pytest_collection_modifyitems(config, items):
    phase = config.getoption("--phase")
    day2_filter = config.getoption("--day2-op")
    day2_ops = {o.strip() for o in day2_filter.split(",") if o.strip()} if day2_filter else None

    skip_build = pytest.mark.skip(reason="--phase=day2 active")
    skip_day2 = pytest.mark.skip(reason="--phase=build active")

    for item in items:
        # Auto-add OS family/version markers based on parametrize id
        for os_id in _OS_IDS:
            if f"[{os_id}]" in item.nodeid:
                item.add_marker(getattr(pytest.mark, os_id))
                family = "linux" if os_id in _LINUX_IDS else "windows"
                item.add_marker(getattr(pytest.mark, family))
                break

        is_build = "build" in item.keywords
        is_day2 = "day2" in item.keywords

        if phase == "build" and is_day2:
            item.add_marker(skip_day2)
        elif phase == "day2" and is_build:
            item.add_marker(skip_build)

        if day2_ops and is_day2:
            if not (set(item.keywords.keys()) & day2_ops):
                item.add_marker(
                    pytest.mark.skip(reason=f"day2 op filter excludes this: {day2_ops}")
                )


# ---------- Allure env + executor ----------
def pytest_sessionstart(session):
    write_environment(
        ALLURE_RESULTS_DIR,
        {
            "cluster": os.environ.get("OCP_CLUSTER", "unknown"),
            "namespace": os.environ.get("VM_NAMESPACE", "unknown"),
            "api_base_url": os.environ.get("VM_API_BASE_URL", "unknown"),
            "phase": session.config.getoption("--phase"),
            "os_filter": session.config.getoption("--os") or "all",
            "os_version_filter": session.config.getoption("--os-version") or "all",
            "day2_op_filter": session.config.getoption("--day2-op") or "all",
            "build_tag": os.environ.get("BUILD_TAG", "local"),
        },
    )
    write_executor(ALLURE_RESULTS_DIR)


# ---------- Provisioned VM fixture (the build->day2 contract) ----------
@pytest.fixture(scope="session")
def provisioned_vm(request, os_spec, vm_client):
    """
    Returns a VM record for the given os_spec.
    - phase=build or all: provisions, records, and yields the VM.
    - phase=day2: reads from state store; skips if not present.
    - At session teardown (unless --keep-vms): deletes the VM.
    """
    if os_spec is None:
        pytest.skip("No OS spec available")

    phase = request.config.getoption("--phase")
    keep = request.config.getoption("--keep-vms")
    existing = get_vm(os_spec["id"])

    if phase == "day2":
        if not existing:
            pytest.skip(
                f"VM not found in state for {os_spec['id']} -- "
                f"run --phase=build first"
            )
        yield existing
        return

    # build or all
    if existing and phase == "all":
        # Reuse existing within a single 'all' run too
        yield existing
        return

    payload = {
        "name": f"test-{os_spec['id']}-{os.environ.get('BUILD_TAG', 'local')}",
        "image": os_spec["image"],
        "flavor": os_spec["flavor"],
        "aap_template": os_spec["aap_template"],
        "cloud_init": os_spec.get("cloud_init", True),
    }
    with allure.step(f"Provision VM ({os_spec['id']})"):
        vm = vm_client.build_vm(payload)
        attach_json(f"vm-build-response-{os_spec['id']}", vm)
        record_vm(os_spec["id"], vm)

    yield vm

    if not keep and phase != "day2":
        try:
            with allure.step(f"Cleanup VM ({os_spec['id']})"):
                vm_client.delete_vm(vm["id"])
        except Exception as e:
            allure.attach(
                f"Cleanup failed for {vm.get('id')}: {e!r}",
                name="cleanup-error",
                attachment_type=allure.attachment_type.TEXT,
            )


# ---------- Async op helpers ----------
@pytest.fixture
def waiter(vm_client):
    return vm_client.waiter()


@pytest.fixture
def async_op_tracker(vm_client):
    """
    Tracks in-flight handles per test. On teardown, logs any unwaited handle
    and best-effort cancels it so failed tests don't leak AAP jobs.
    """
    handles: List[OpHandle] = []

    def _register(h: OpHandle) -> OpHandle:
        handles.append(h)
        return h

    yield _register

    for h in handles:
        try:
            status = vm_client.poll_request(h.request_id)
            state = (status.get("state") or status.get("status") or "").upper()
            if state in {"PENDING", "RUNNING", "IN_PROGRESS", "QUEUED", "WAITING", "STARTED"}:
                allure.attach(
                    f"Leaked in-flight request: {h.request_id} "
                    f"({h.operation}) still in state={state}. Attempting cancel.",
                    name="leaked-async-op",
                    attachment_type=allure.attachment_type.TEXT,
                )
                vm_client.cancel_request(h.request_id)
        except Exception:
            pass


# ---------- Per-test labels for Allure ----------
@pytest.fixture(autouse=True)
def _allure_labels(request):
    spec = None
    if hasattr(request.node, "funcargs"):
        spec = request.node.funcargs.get("os_spec")
    if spec:
        allure.dynamic.label("os_family", spec["family"])
        allure.dynamic.label("os_version", spec["id"])
        allure.dynamic.label("image", spec["image"])
    yield
