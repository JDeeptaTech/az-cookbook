"""
State store for the build -> day2 handoff.

Build tests write VM identifiers here; day2 tests read them.
File-based so it survives across pytest invocations:
  pytest --phase=build         # writes
  pytest --phase=day2          # reads
"""
from __future__ import annotations

import json
import os
from pathlib import Path
from threading import Lock
from typing import Optional

STATE_FILE = Path(os.environ.get("VM_STATE_FILE", "vm_state.json"))
_lock = Lock()


def _load() -> dict:
    if not STATE_FILE.exists():
        return {}
    try:
        with STATE_FILE.open() as f:
            return json.load(f)
    except json.JSONDecodeError:
        return {}


def _save(data: dict) -> None:
    STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
    tmp = STATE_FILE.with_suffix(".tmp")
    with tmp.open("w") as f:
        json.dump(data, f, indent=2, default=str)
    tmp.replace(STATE_FILE)


def record_vm(os_id: str, vm_info: dict) -> None:
    with _lock:
        data = _load()
        data[os_id] = vm_info
        _save(data)


def get_vm(os_id: str) -> Optional[dict]:
    return _load().get(os_id)


def all_vms() -> dict:
    return _load()


def clear() -> None:
    with _lock:
        if STATE_FILE.exists():
            STATE_FILE.unlink()
