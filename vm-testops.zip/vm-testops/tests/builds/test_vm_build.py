"""Build-phase tests: provision a VM and verify post-build state."""
from __future__ import annotations

import allure
import pytest

from lib.allure_utils import attach_json


@pytest.mark.build
@allure.feature("VM Provisioning")
class TestVMBuild:

    @allure.story("VM reaches RUNNING state")
    @allure.severity(allure.severity_level.BLOCKER)
    def test_vm_running(self, os_spec, provisioned_vm, vm_client):
        with allure.step(f"Verify VM is RUNNING ({os_spec['id']})"):
            vm = vm_client.get_vm(provisioned_vm["id"])
            attach_json(f"vm-state-{os_spec['id']}", vm)
            assert vm["status"] == "RUNNING", (
                f"VM {provisioned_vm['id']} not running: status={vm['status']}"
            )

    @allure.story("Guest agent is connected")
    @allure.severity(allure.severity_level.CRITICAL)
    def test_guest_agent_connected(self, os_spec, provisioned_vm, vm_client):
        vm = vm_client.get_vm(provisioned_vm["id"])
        attach_json(f"guest-info-{os_spec['id']}", vm.get("guest_info", {}))
        assert vm.get("guest_agent_connected") is True, (
            f"Guest agent not connected on {provisioned_vm['id']}"
        )

    @allure.story("VM has expected IP allocation")
    @allure.severity(allure.severity_level.NORMAL)
    def test_vm_has_ip(self, provisioned_vm, vm_client):
        vm = vm_client.get_vm(provisioned_vm["id"])
        ips = vm.get("ip_addresses") or []
        assert ips, f"No IPs allocated to VM {provisioned_vm['id']}"

    @allure.story("OS family matches request")
    @pytest.mark.smoke
    def test_os_family_matches(self, os_spec, provisioned_vm, vm_client):
        vm = vm_client.get_vm(provisioned_vm["id"])
        guest_os = (vm.get("guest_info", {}).get("os_family") or "").lower()
        assert os_spec["family"] in guest_os or not guest_os, (
            f"OS family mismatch: expected {os_spec['family']}, "
            f"guest reports {guest_os!r}"
        )
