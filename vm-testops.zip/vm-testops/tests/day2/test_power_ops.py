"""Day-2 power operations: start, stop, restart."""
from __future__ import annotations

import allure
import pytest

from lib.allure_utils import attach_json
from lib.async_ops import TerminalState


@pytest.mark.day2
@pytest.mark.power
@allure.feature("Day2 — Power Operations")
class TestPowerOps:

    @allure.story("Stop a running VM")
    @allure.severity(allure.severity_level.CRITICAL)
    def test_stop(self, provisioned_vm, vm_client, waiter, async_op_tracker):
        with allure.step("Submit power.stop"):
            handle = async_op_tracker(
                vm_client.submit_day2(provisioned_vm["id"], "power.stop")
            )
            attach_json("submit-handle", {
                "request_id": handle.request_id,
                "correlation_id": handle.correlation_id,
            })

        result = waiter.wait(handle, expect=TerminalState.SUCCESS)

        with allure.step("Verify VM is STOPPED"):
            vm = vm_client.get_vm(provisioned_vm["id"])
            assert vm["status"] in ("STOPPED", "POWERED_OFF"), (
                f"VM not stopped: {vm['status']}"
            )
            assert result.success

    @allure.story("Start a stopped VM")
    @allure.severity(allure.severity_level.CRITICAL)
    def test_start(self, provisioned_vm, vm_client, waiter, async_op_tracker):
        handle = async_op_tracker(
            vm_client.submit_day2(provisioned_vm["id"], "power.start")
        )
        result = waiter.wait(handle, expect=TerminalState.SUCCESS)

        with allure.step("Verify VM is RUNNING"):
            vm = vm_client.get_vm(provisioned_vm["id"])
            assert vm["status"] == "RUNNING"
            assert result.success

    @allure.story("Restart a running VM")
    def test_restart(self, provisioned_vm, vm_client, waiter, async_op_tracker):
        handle = async_op_tracker(
            vm_client.submit_day2(provisioned_vm["id"], "power.restart")
        )
        result = waiter.wait(handle, expect=TerminalState.SUCCESS)
        assert result.success
