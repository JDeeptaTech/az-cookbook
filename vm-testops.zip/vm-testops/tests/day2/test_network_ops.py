"""Day-2 network operations: add/remove NIC."""
from __future__ import annotations

import allure
import pytest

from lib.async_ops import TerminalState


@pytest.mark.day2
@pytest.mark.network
@allure.feature("Day2 — Network Operations")
class TestNetworkOps:

    @allure.story("Add a secondary NIC")
    def test_add_nic(self, provisioned_vm, vm_client, waiter, async_op_tracker):
        handle = async_op_tracker(
            vm_client.submit_day2(
                provisioned_vm["id"],
                "network.add_nic",
                params={"network": "secondary-net", "name": "eth1"},
            )
        )
        result = waiter.wait(handle, expect=TerminalState.SUCCESS)

        with allure.step("Verify NIC is attached"):
            vm = vm_client.get_vm(provisioned_vm["id"])
            nics = vm.get("nics", [])
            assert any(n.get("name") == "eth1" for n in nics), (
                f"Added NIC not present: {nics}"
            )
            assert result.success

    @allure.story("Remove the secondary NIC")
    def test_remove_nic(self, provisioned_vm, vm_client, waiter, async_op_tracker):
        handle = async_op_tracker(
            vm_client.submit_day2(
                provisioned_vm["id"],
                "network.remove_nic",
                params={"name": "eth1"},
            )
        )
        result = waiter.wait(handle)
        assert result.success
