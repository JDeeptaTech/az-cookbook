"""Day-2 snapshot operations: create, restore, delete."""
from __future__ import annotations

import allure
import pytest

from lib.allure_utils import attach_json
from lib.async_ops import AsyncOpFailure, TerminalState


@pytest.mark.day2
@pytest.mark.snapshot
@allure.feature("Day2 — Snapshot Operations")
class TestSnapshotOps:

    @allure.story("Create snapshot (async)")
    @allure.severity(allure.severity_level.CRITICAL)
    def test_create_snapshot(
        self, provisioned_vm, vm_client, waiter, async_op_tracker, request
    ):
        snap_name = f"snap-{provisioned_vm['name']}-{request.node.name}"
        with allure.step(f"Submit snapshot.create ({snap_name})"):
            handle = async_op_tracker(
                vm_client.submit_day2(
                    provisioned_vm["id"],
                    "snapshot.create",
                    params={"name": snap_name},
                )
            )

        result = waiter.wait(handle, expect=TerminalState.SUCCESS)

        with allure.step("Verify snapshot artifact"):
            snap_id = (result.final_payload.get("result") or {}).get("snapshot_id")
            assert snap_id, "snapshot_id missing from final payload"
            attach_json("snapshot-artifact", {"id": snap_id, "name": snap_name})

        # Stash for the restore test that follows in the same session
        request.session.last_snapshot_id = snap_id

    @allure.story("Restore from snapshot")
    def test_restore_snapshot(self, provisioned_vm, vm_client, waiter, async_op_tracker, request):
        snap_id = getattr(request.session, "last_snapshot_id", None)
        if not snap_id:
            pytest.skip("No snapshot from prior test; run create first")

        handle = async_op_tracker(
            vm_client.submit_day2(
                provisioned_vm["id"],
                "snapshot.restore",
                params={"snapshot_id": snap_id},
            )
        )
        result = waiter.wait(handle)
        assert result.success

    @allure.story("Delete snapshot")
    def test_delete_snapshot(self, provisioned_vm, vm_client, waiter, async_op_tracker, request):
        snap_id = getattr(request.session, "last_snapshot_id", None)
        if not snap_id:
            pytest.skip("No snapshot to delete")

        handle = async_op_tracker(
            vm_client.submit_day2(
                provisioned_vm["id"],
                "snapshot.delete",
                params={"snapshot_id": snap_id},
            )
        )
        result = waiter.wait(handle)
        assert result.success

    @allure.story("Restore with invalid id surfaces clean failure")
    def test_restore_invalid_fails_cleanly(
        self, provisioned_vm, vm_client, waiter, async_op_tracker
    ):
        handle = async_op_tracker(
            vm_client.submit_day2(
                provisioned_vm["id"],
                "snapshot.restore",
                params={"snapshot_id": "definitely-does-not-exist"},
            )
        )
        with pytest.raises(AsyncOpFailure) as exc_info:
            waiter.wait(handle)
        # Sanity: the framework actually classified it as a terminal failure,
        # not a timeout.
        assert exc_info.value.result.terminal_state == TerminalState.FAILED
