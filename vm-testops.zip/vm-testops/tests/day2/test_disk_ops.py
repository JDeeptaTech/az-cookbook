"""Day-2 disk operations: attach, resize, detach."""
from __future__ import annotations

import allure
import pytest

from lib.async_ops import TerminalState


@pytest.mark.day2
@pytest.mark.disk
@allure.feature("Day2 — Disk Operations")
class TestDiskOps:

    @allure.story("Attach a new data disk")
    def test_attach_disk(self, provisioned_vm, vm_client, waiter, async_op_tracker):
        handle = async_op_tracker(
            vm_client.submit_day2(
                provisioned_vm["id"],
                "disk.attach",
                params={"size_gb": 20, "name": "test-data-1"},
            )
        )
        result = waiter.wait(handle)

        with allure.step("Verify disk is attached and visible"):
            vm = vm_client.get_vm(provisioned_vm["id"])
            disks = vm.get("disks", [])
            assert any(d.get("name") == "test-data-1" for d in disks), (
                f"Attached disk not found in VM disks: {disks}"
            )
            assert result.success

    @allure.story("Resize attached disk")
    def test_resize_disk(self, provisioned_vm, vm_client, waiter, async_op_tracker):
        handle = async_op_tracker(
            vm_client.submit_day2(
                provisioned_vm["id"],
                "disk.resize",
                params={"disk_name": "test-data-1", "new_size_gb": 30},
            )
        )
        result = waiter.wait(handle)
        assert result.success

    @allure.story("Detach disk")
    def test_detach_disk(self, provisioned_vm, vm_client, waiter, async_op_tracker):
        handle = async_op_tracker(
            vm_client.submit_day2(
                provisioned_vm["id"],
                "disk.detach",
                params={"disk_name": "test-data-1"},
            )
        )
        result = waiter.wait(handle)
        assert result.success
