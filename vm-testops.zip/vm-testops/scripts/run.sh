#!/usr/bin/env bash
# Convenience wrapper for common run patterns. Pass extra args through to pytest.
set -euo pipefail

cmd="${1:-help}"
shift || true

case "$cmd" in
  build)
    pytest --phase=build "$@"
    ;;
  day2)
    pytest --phase=day2 "$@"
    ;;
  all)
    pytest --phase=all "$@"
    ;;
  smoke)
    pytest -m "smoke" --phase=all "$@"
    ;;
  rhel8-only)
    pytest --os-version=rhel8 "$@"
    ;;
  windows-only)
    pytest --os=windows "$@"
    ;;
  parallel)
    # Run OS combos in parallel — note: state_store uses file locking, but
    # if you're parallel across the SAME OS id, builds will race. Better to
    # parallelize across distinct OSes with -n auto + --dist loadscope.
    pytest -n auto --dist loadscope "$@"
    ;;
  report)
    allure generate allure-results -o allure-report --clean
    echo "Open allure-report/index.html"
    ;;
  serve)
    allure serve allure-results
    ;;
  clean)
    rm -rf allure-results allure-report vm_state.json
    ;;
  help|*)
    cat <<EOF
Usage: ./scripts/run.sh <command> [extra pytest args]

Commands:
  build           Build all VMs (skips day2 tests)
  day2            Run day2 tests against existing VMs (skips builds)
  all             Build + day2 in one session
  smoke           Smoke subset
  rhel8-only      All phases, only RHEL 8
  windows-only    All phases, only Windows
  parallel        Run with pytest-xdist (-n auto)
  report          Generate static Allure report
  serve           Serve Allure report locally
  clean           Remove results, state, report dirs

Extra args pass through, e.g.:
  ./scripts/run.sh day2 --day2-op=snapshot --os-version=rhel9
EOF
    ;;
esac
