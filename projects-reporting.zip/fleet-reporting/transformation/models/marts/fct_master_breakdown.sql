-- Active master inventory broken out by every dimension the master report uses.
select
    coalesce(country_code, 'UNKNOWN')                 as country_code,
    coalesce(business_line, '(blank)')                as business_line,
    coalesce(environment, '(blank)')                  as environment,
    coalesce(lifecycle_state, '(blank)')              as lifecycle_state,
    coalesce(network_identifier, '(blank)')           as network_identifier,
    coalesce(is_dmz::text, '(blank)')                 as is_dmz,
    coalesce(hosting_platform, '(blank)')             as hosting_platform,
    count(*)                                          as servers
from {{ ref('int_master_active') }}
group by 1,2,3,4,5,6,7
