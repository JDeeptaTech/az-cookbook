-- Conformed cross-reference. FULL OUTER so orphans survive.
with m as (select * from {{ ref('stg_master') }}),
     f as (select * from {{ ref('int_firmware_current') }}),
     c as (select * from {{ ref('int_connectivity_current') }})
select
    coalesce(m.server_id, f.server_id, c.host_name) as server_key,

    (m.server_id  is not null)                      as in_master,
    (f.server_id  is not null)                      as in_firmware,
    (c.host_name  is not null)                      as in_connectivity,

    m.lifecycle_state                               as master_lifecycle_state,
    f.fw_lifecycle_state,
    c.conn_lifecycle_state,
    coalesce(m.country_code, c.country_code)        as country_code,
    m.business_line, m.environment, m.hosting_platform,
    m.network_identifier, m.is_dmz,

    f.fw_status, f.m_scope, f.upgrade_type, f.lookup_completed,
    c.conn_status, c.dmz_zone, c.group_assignee, c.action_owner,
    c.fixed_flag, c.date_of_fixed, c.out_of_scope, c.conn_demise,

    m.hostname        as master_hostname,
    f.server_hostname as firmware_server_hostname,
    c.host_name       as connectivity_host_name
from m
full outer join f
    on m.{{ var('master_key') }} = f.{{ var('firmware_master_key') }}
full outer join c
    on f.{{ var('firmware_conn_key') }} = c.host_name
