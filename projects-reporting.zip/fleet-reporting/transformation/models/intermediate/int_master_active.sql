-- "Active" master inventory: excludes Demised/Demising.
-- Reports about live fleet ref() this; reconciliation marts ref() stg_master.
select * from {{ ref('stg_master') }}
where coalesce(lifecycle_state, '') not in ('Demised', 'Demising')
