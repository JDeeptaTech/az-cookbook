# fleet-reporting

Medallion reporting stack over three server-inventory sources: **dlt → bronze**, **dbt → silver/gold**, **Grafana** off the gold marts. Verified end-to-end against Postgres.

## Dashboards (auto-provisioned)

| URL | Dashboard | Purpose |
|---|---|---|
| `/d/fleet-overview` | **Overview (consolidated)** | Cross-project counts, presence matrix, coverage gaps, demised-but-tracked, lifecycle disagreement |
| `/d/fleet-master` | **Master Servers** | Single-source: lifecycle, country, business line, environment |
| `/d/fleet-connectivity` | **Connectivity Project** | Reachable/unreachable, by assignee, country, DMZ zone |
| `/d/fleet-firmware` | **Firmware Project** | Status, scope, upgrade type, lookup completion |
| `/d/fleet-server-detail` | **Server Detail (drilldown)** | Filtered list of servers; drill target from every overview panel |

The four top-level dashboards link to each other (top-right nav). Clickable panels open **Server Detail** filtered by the clicked value — e.g. click the "Demised" slice on Master, see the 2 Demised servers.

## Join topology (verify before trusting cross-project numbers)

Firmware is the bridge — there is no single shared key:

```
master.serverid ── firmware.serverid          (hop 1)
                   firmware.serverhostname ── connectivity.host_name   (hop 2)
```

`master ↔ connectivity` is **transitive through firmware** — surfaced in `fct_coverage_gaps`. Both hop keys are dbt `vars`; flip hop 2 to `hostname` if Tier-0 profiling says so:

```bash
dbt build --vars '{firmware_conn_key: hostname}'
```

## Run order

```bash
cp .env.example .env
docker compose up -d postgres grafana
pip install -r requirements.txt
python ingestion/pipeline.py                # daily

cd transformation
dbt run-operation verify_bridge             # check match rates first
dbt build                                   # silver + gold + tests
```

Grafana: http://localhost:3000 (admin/admin).

## Layout

```
ingestion/                  dlt → bronze (master replace, firmware replace, connectivity APPEND)
transformation/
  models/staging/           silver: stg_master / stg_firmware / stg_connectivity
  models/intermediate/      silver: int_*_current + int_server_xref (FULL OUTER spine)
  models/marts/             gold:  dim_server + 11 fct_* reports
  snapshots/                connectivity SCD2
  macros/                   verify_bridge, generate_schema_name
  tests/                    assert_bridge_hop1_match
  analyses/                 tier0_key_profiling
grafana/dashboards/         5 provisioned dashboards + _generate.py (regenerate from code)
docs/                       data-pipeline-design.md
```

## Notes

- Connectivity loads `append`; "current state" marts dedup to latest via `_ingested_at`.
- Master is system-of-record for lifecycle; project copies kept only for drift detection.
- Integration uses FULL OUTER joins so orphans survive — they are the coverage report.
- Edit dashboards by editing `_generate.py` and re-running it, not by hand-editing JSON.
