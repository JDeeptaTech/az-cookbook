"""
gunicorn.conf.py

UvicornWorker runs FastAPI lifespan in every worker.
The lifespan starts plugin_loader + scheduler per worker.
SELECT FOR UPDATE SKIP LOCKED handles cross-worker deduplication.
"""
import os

bind             = "0.0.0.0:8000"
workers          = int(os.getenv("GUNICORN_WORKERS", "4"))
worker_class     = "uvicorn.workers.UvicornWorker"
timeout          = 120
keepalive        = 5
graceful_timeout = 30

loglevel    = os.getenv("LOG_LEVEL", "info")
accesslog   = "-"
errorlog    = "-"
access_log_format = '%(h)s %(l)s %(u)s %(t)s "%(r)s" %(s)s %(b)s %(D)s'
