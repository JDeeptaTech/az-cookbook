"""
main.py — FastAPI application entry point.

Startup order per worker:
  1. Async DB engine + session factory
  2. Plugin loader  — loads all active plugins from DB into memory
                    — LISTEN 'vm_plugin_reload' for hot-reload
  3. Scheduler      — LISTEN 'vm_scheduler' for dispatch events
                    — boot recovery: populates heap from pending schedules
"""
from __future__ import annotations

import logging
import os
from contextlib import asynccontextmanager

from fastapi import FastAPI
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine

from scheduler.plugin_loader   import init_plugin_loader, shutdown_plugin_loader
from scheduler.plugin_router   import router as plugin_router
from scheduler.schedule_router import router as schedule_router
from scheduler                 import scheduler as sched_module

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(name)s %(levelname)s %(message)s",
)
logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    # ── Database ──────────────────────────────────────────────────────────
    engine = create_async_engine(
        os.environ["DATABASE_URL"],
        pool_size=int(os.getenv("DB_POOL_SIZE", "5")),
        max_overflow=int(os.getenv("DB_MAX_OVERFLOW", "10")),
        pool_pre_ping=True,
    )
    session_factory = async_sessionmaker(
        engine, class_=AsyncSession, expire_on_commit=False
    )
    app.state.db_session_factory = session_factory

    # ── Plugin loader (must come before scheduler) ────────────────────────
    await init_plugin_loader(session_factory)
    logger.info("Plugin loader ready")

    # ── Scheduler ─────────────────────────────────────────────────────────
    sched_module.init_scheduler(session_factory)
    logger.info("Scheduler ready")

    yield

    # ── Shutdown ──────────────────────────────────────────────────────────
    await sched_module.stop_scheduler()
    await shutdown_plugin_loader()
    await engine.dispose()
    logger.info("Shutdown complete")


app = FastAPI(
    title="VM Platform Ansible Scheduler",
    version="1.0.0",
    lifespan=lifespan,
)

app.include_router(plugin_router,   prefix="/api/v1")
app.include_router(schedule_router, prefix="/api/v1")


@app.get("/healthz", tags=["Health"])
async def healthz():
    from scheduler.plugin_loader import list_registry
    return {
        "status":         "ok",
        "plugins_loaded": len(list_registry()),
    }
