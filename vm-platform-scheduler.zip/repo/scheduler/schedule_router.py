"""scheduler/schedule_router.py — Schedule CRUD endpoints."""
from __future__ import annotations

import uuid
from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, Query, Request, status

from .schemas import ApiResponse, ScheduleCreate, ScheduleListResponse, ScheduleResponse, ScheduleUpdate
from .schedule_service import (
    DuplicateScheduleError, PluginNotFoundError, ScheduleNotFoundError,
    create_schedule, delete_schedule, get_schedule, list_schedules,
    toggle_schedule, update_schedule,
)

router = APIRouter(prefix="/schedules", tags=["Schedules"])


async def get_db(request: Request):
    async with request.app.state.db_session_factory() as session:
        yield session

def current_user(request: Request) -> str:
    return request.headers.get("X-User-Id", "system")

DbDep   = Annotated[object, Depends(get_db)]
UserDep = Annotated[str, Depends(current_user)]

def _ok(data, message: str | None = None) -> ApiResponse:
    return ApiResponse(success=True, data=data, message=message)


@router.get("", response_model=ApiResponse, summary="List schedules")
async def list_all(
    db: DbDep,
    user: UserDep,
    plugin_name: str | None   = Query(None),
    enabled:     bool | None  = Query(None),
    mine_only:   bool         = Query(False),
    offset:      int          = Query(0, ge=0),
    limit:       int          = Query(50, ge=1, le=200),
):
    result = await list_schedules(
        db,
        plugin_name=plugin_name,
        created_by=user if mine_only else None,
        enabled=enabled,
        offset=offset,
        limit=limit,
    )
    return _ok(result)


@router.post("", response_model=ApiResponse, status_code=status.HTTP_201_CREATED, summary="Create schedule")
async def create(payload: ScheduleCreate, db: DbDep, user: UserDep):
    try:
        return _ok(await create_schedule(db, payload, created_by=user), message="Schedule created")
    except PluginNotFoundError as exc:
        raise HTTPException(404, str(exc))
    except DuplicateScheduleError as exc:
        raise HTTPException(409, str(exc))
    except ValueError as exc:
        raise HTTPException(422, str(exc))


@router.get("/{schedule_id}", response_model=ApiResponse, summary="Get schedule")
async def get_one(schedule_id: uuid.UUID, db: DbDep):
    try:
        return _ok(await get_schedule(db, schedule_id))
    except ScheduleNotFoundError:
        raise HTTPException(404, "Schedule not found")


@router.patch("/{schedule_id}", response_model=ApiResponse, summary="Update schedule")
async def update(schedule_id: uuid.UUID, payload: ScheduleUpdate, db: DbDep, user: UserDep):
    try:
        return _ok(await update_schedule(db, schedule_id, payload, updated_by=user), message="Schedule updated")
    except ScheduleNotFoundError:
        raise HTTPException(404, "Schedule not found")
    except PluginNotFoundError as exc:
        raise HTTPException(404, str(exc))
    except DuplicateScheduleError as exc:
        raise HTTPException(409, str(exc))
    except ValueError as exc:
        raise HTTPException(422, str(exc))


@router.delete("/{schedule_id}", response_model=ApiResponse, summary="Delete schedule")
async def delete(schedule_id: uuid.UUID, db: DbDep):
    try:
        await delete_schedule(db, schedule_id)
        return _ok(None, message="Schedule deleted")
    except ScheduleNotFoundError:
        raise HTTPException(404, "Schedule not found")


@router.post("/{schedule_id}/enable", response_model=ApiResponse, summary="Enable schedule")
async def enable(schedule_id: uuid.UUID, db: DbDep, user: UserDep):
    try:
        return _ok(await toggle_schedule(db, schedule_id, True, user), message="Schedule enabled")
    except ScheduleNotFoundError:
        raise HTTPException(404, "Schedule not found")


@router.post("/{schedule_id}/disable", response_model=ApiResponse, summary="Disable schedule")
async def disable(schedule_id: uuid.UUID, db: DbDep, user: UserDep):
    try:
        return _ok(await toggle_schedule(db, schedule_id, False, user), message="Schedule disabled")
    except ScheduleNotFoundError:
        raise HTTPException(404, "Schedule not found")
