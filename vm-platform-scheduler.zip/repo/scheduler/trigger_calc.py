"""scheduler/trigger_calc.py — compute next_run_at from trigger definitions."""
from __future__ import annotations

from datetime import datetime, timedelta, timezone
from typing import Any

from croniter import croniter


def _utc(dt: datetime) -> datetime:
    return dt.replace(tzinfo=timezone.utc) if dt.tzinfo is None else dt.astimezone(timezone.utc)


def compute_next_run(
    trigger_type: str,
    trigger_args: dict[str, Any],
    after: datetime | None = None,
) -> datetime | None:
    """
    Return the next UTC datetime this trigger should fire.
    Returns None for exhausted date triggers (run_date already in the past).
    """
    base = _utc(after) if after else datetime.now(timezone.utc)

    if trigger_type == "cron":
        expr = (
            f"{trigger_args.get('minute', '0')} "
            f"{trigger_args.get('hour', '0')} "
            f"{trigger_args.get('day', '*')} "
            f"{trigger_args.get('month', '*')} "
            f"{trigger_args.get('day_of_week', '*')}"
        )
        return _utc(croniter(expr, base).get_next(datetime))

    if trigger_type == "interval":
        delta = timedelta(
            weeks=trigger_args.get("weeks", 0),
            days=trigger_args.get("days", 0),
            hours=trigger_args.get("hours", 0),
            minutes=trigger_args.get("minutes", 0),
            seconds=trigger_args.get("seconds", 0),
        )
        if delta.total_seconds() == 0:
            raise ValueError("Interval trigger must have at least one non-zero field")
        return base + delta

    if trigger_type == "date":
        run_date = trigger_args.get("run_date")
        if isinstance(run_date, str):
            run_date = datetime.fromisoformat(run_date)
        run_date = _utc(run_date)
        return run_date if run_date > datetime.now(timezone.utc) else None

    raise ValueError(f"Unknown trigger_type: {trigger_type!r}")


def validate_trigger_args(trigger_type: str, raw: dict[str, Any]) -> dict[str, Any]:
    """Validate trigger args via Pydantic and return the cleaned dict."""
    from .schemas import CronTriggerArgs, IntervalTriggerArgs, DateTriggerArgs
    mapping = {
        "cron":     CronTriggerArgs,
        "interval": IntervalTriggerArgs,
        "date":     DateTriggerArgs,
    }
    cls = mapping.get(trigger_type)
    if not cls:
        raise ValueError(f"Unknown trigger_type: {trigger_type!r}")
    return cls.model_validate(raw).model_dump(exclude_none=True)
