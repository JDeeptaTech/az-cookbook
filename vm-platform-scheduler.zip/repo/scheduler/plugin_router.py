"""
scheduler/plugin_router.py — Plugin management endpoints.

Recommended workflow:
  1. POST /plugins/validate          — syntax + interface check (no save, no run)
  2. POST /plugins/test              — full dry-run; record saved to plugin_test_runs
  3. POST /plugins                   — save to DB; all workers reload via NOTIFY
  4. PUT  /plugins/{name}            — update source; version bumped; NOTIFY sent
  5. GET  /plugins/{name}/test-runs  — view full test history
"""
from __future__ import annotations

import logging
from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, Query, Request, status

from .schemas import (
    ApiResponse,
    PluginCreate, PluginListResponse, PluginResponse,
    PluginTestRequest, PluginTestRunResponse, PluginUpdate,
    PluginValidateRequest,
)
from .plugin_service import (
    DuplicatePluginError, PluginNotFoundError,
    create_plugin, delete_plugin, get_plugin, list_plugins,
    list_test_runs, test_plugin, update_plugin,
)
from .plugin_loader import list_registry, validate_source

router = APIRouter(prefix="/plugins", tags=["Plugins"])
logger = logging.getLogger(__name__)


# ── Dependencies ──────────────────────────────────────────────────────────

async def get_db(request: Request):
    async with request.app.state.db_session_factory() as session:
        yield session

def current_user(request: Request) -> str:
    return request.headers.get("X-User-Id", "system")

DbDep   = Annotated[object, Depends(get_db)]
UserDep = Annotated[str, Depends(current_user)]


def _ok(data, message: str | None = None) -> ApiResponse:
    return ApiResponse(success=True, data=data, message=message)

def _err(data, message: str) -> ApiResponse:
    return ApiResponse(success=False, data=data, message=message)


# ── CRUD ──────────────────────────────────────────────────────────────────

@router.get("", response_model=ApiResponse, summary="List plugins")
async def list_all(
    db: DbDep,
    is_active: bool | None = Query(None),
    offset: int = Query(0, ge=0),
    limit:  int = Query(50, ge=1, le=200),
):
    return _ok(await list_plugins(db, is_active=is_active, offset=offset, limit=limit))


@router.get("/registry", response_model=ApiResponse, summary="In-memory registry (this worker)")
async def registry():
    """Shows which plugins are currently loaded in this worker's memory."""
    return _ok(list_registry())


@router.get("/{name}", response_model=ApiResponse, summary="Get plugin")
async def get_one(name: str, db: DbDep):
    try:
        return _ok(await get_plugin(db, name))
    except PluginNotFoundError:
        raise HTTPException(404, f"Plugin '{name}' not found")


@router.post(
    "", response_model=ApiResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Save plugin to DB",
)
async def create(payload: PluginCreate, db: DbDep, user: UserDep):
    """Validates source before saving. Returns 422 if source has errors."""
    try:
        return _ok(await create_plugin(db, payload, created_by=user), message="Plugin created")
    except DuplicatePluginError as exc:
        raise HTTPException(409, str(exc))
    except ValueError as exc:
        raise HTTPException(422, str(exc))


@router.put("/{name}", response_model=ApiResponse, summary="Update plugin")
async def update(name: str, payload: PluginUpdate, db: DbDep, user: UserDep):
    """Updates source code, bumps version, validates, sends NOTIFY."""
    try:
        return _ok(await update_plugin(db, name, payload, updated_by=user), message="Plugin updated")
    except PluginNotFoundError:
        raise HTTPException(404, f"Plugin '{name}' not found")
    except ValueError as exc:
        raise HTTPException(422, str(exc))


@router.delete("/{name}", response_model=ApiResponse, summary="Delete plugin")
async def delete(name: str, db: DbDep):
    """Returns 409 if any schedules still reference this plugin."""
    try:
        await delete_plugin(db, name)
        return _ok(None, message="Plugin deleted")
    except PluginNotFoundError:
        raise HTTPException(404, f"Plugin '{name}' not found")
    except Exception as exc:
        if "violates foreign key" in str(exc).lower():
            raise HTTPException(409, f"Cannot delete '{name}' — active schedules reference it")
        raise


# ── Validate (no execution, no DB write) ──────────────────────────────────

@router.post("/validate", response_model=ApiResponse, summary="Syntax + interface check only")
async def validate(payload: PluginValidateRequest):
    """
    Fast check: compile + validate interface.
    Does NOT execute code. Does NOT write to DB.
    """
    result = validate_source(payload.source_code)
    if result.status != "success":
        return _err({"error": result.error}, message="Validation failed")
    return _ok({"valid": True}, message="Plugin is valid")


# ── Test (runs code, saves test_run record) ───────────────────────────────

@router.post("/test", response_model=ApiResponse, summary="Dry-run unsaved plugin")
async def test_unsaved(payload: PluginTestRequest, db: DbDep, user: UserDep):
    """
    Validates interface and calls run() with provided extra_vars.
    Saves result to plugin_test_runs (plugin_name = 'unsaved').
    Does NOT save the plugin source.
    """
    if not payload.source_code:
        raise HTTPException(422, "source_code is required for unsaved plugin test")
    result, test_run = await test_plugin(
        db=db,
        source_code=payload.source_code,
        extra_vars=payload.extra_vars,
        ran_by=user,
        schedule_id=payload.schedule_id,
        timeout_seconds=payload.timeout_seconds,
    )
    data = {"test_run": test_run, "result": result.to_dict()}
    if result.status == "error":
        return _err(data, message="Test failed")
    return _ok(data, message=f"Test completed: {result.status}")


@router.post("/{name}/test", response_model=ApiResponse, summary="Test a saved plugin")
async def test_saved(name: str, payload: PluginTestRequest, db: DbDep, user: UserDep):
    """
    Tests a saved plugin. Uses stored source unless payload.source_code is provided.
    Updates last_test_status on the plugin row.
    """
    try:
        plugin_row = await get_plugin(db, name)
    except PluginNotFoundError:
        raise HTTPException(404, f"Plugin '{name}' not found")

    source = payload.source_code or plugin_row.source_code
    result, test_run = await test_plugin(
        db=db,
        source_code=source,
        extra_vars=payload.extra_vars,
        ran_by=user,
        schedule_id=payload.schedule_id,
        timeout_seconds=payload.timeout_seconds,
        plugin_name=name,
    )
    data = {"test_run": test_run, "result": result.to_dict()}
    if result.status == "error":
        return _err(data, message="Test failed")
    return _ok(data, message=f"Test completed: {result.status}")


@router.get("/{name}/test-runs", response_model=ApiResponse, summary="Test run history")
async def get_test_runs(
    name: str,
    db: DbDep,
    offset: int = Query(0, ge=0),
    limit:  int = Query(20, ge=1, le=100),
):
    runs = await list_test_runs(db, plugin_name=name, offset=offset, limit=limit)
    return _ok(runs)
