"""scheduler/schemas.py — Pydantic v2 request/response schemas."""
from __future__ import annotations

import uuid
from datetime import datetime
from typing import Annotated, Any, Literal

from pydantic import BaseModel, Field, model_validator


# ── Trigger arg schemas ───────────────────────────────────────────────────

class CronTriggerArgs(BaseModel):
    minute:      str = "0"
    hour:        str = "0"
    day:         str = "*"
    month:       str = "*"
    day_of_week: str = "*"
    timezone:    str = "UTC"
    model_config = {"extra": "forbid"}


class IntervalTriggerArgs(BaseModel):
    weeks:   int = 0
    days:    int = 0
    hours:   int = 0
    minutes: int = 0
    seconds: int = 0
    model_config = {"extra": "forbid"}

    @model_validator(mode="after")
    def at_least_one(self) -> "IntervalTriggerArgs":
        if not any([self.weeks, self.days, self.hours, self.minutes, self.seconds]):
            raise ValueError("At least one interval field must be > 0")
        return self


class DateTriggerArgs(BaseModel):
    run_date: datetime
    timezone: str = "UTC"
    model_config = {"extra": "forbid"}


# ── Plugin schemas ────────────────────────────────────────────────────────

class PluginCreate(BaseModel):
    name:         Annotated[str, Field(min_length=1, max_length=100, pattern=r"^[a-z0-9_-]+$")]
    description:  str | None = None
    source_code:  Annotated[str, Field(min_length=1)]
    trigger_type: Literal["cron", "interval", "date"]
    trigger_args: dict[str, Any]
    model_config  = {"extra": "forbid"}


class PluginUpdate(BaseModel):
    description:  str | None = None
    source_code:  str | None = None
    trigger_type: Literal["cron", "interval", "date"] | None = None
    trigger_args: dict[str, Any] | None = None
    is_active:    bool | None = None
    model_config  = {"extra": "forbid"}


class PluginValidateRequest(BaseModel):
    source_code: str


class PluginTestRequest(BaseModel):
    source_code:     str | None = None       # if None, uses saved source
    extra_vars:      dict[str, Any] = Field(default_factory=dict)
    schedule_id:     str = "test-run"
    timeout_seconds: Annotated[int, Field(ge=1, le=300)] = 30


class PluginTestRunResponse(BaseModel):
    id:          uuid.UUID
    plugin_name: str
    ran_by:      str
    extra_vars:  dict[str, Any]
    status:      str
    output:      str | None
    error:       str | None
    duration_ms: int | None
    ran_at:      datetime
    model_config = {"from_attributes": True}


class PluginResponse(BaseModel):
    id:               uuid.UUID
    name:             str
    description:      str | None
    source_code:      str
    trigger_type:     str
    trigger_args:     dict[str, Any]
    is_active:        bool
    version:          int
    last_tested_at:   datetime | None
    last_test_status: str | None
    last_test_output: str | None
    created_by:       str
    updated_by:       str | None
    created_at:       datetime
    updated_at:       datetime
    model_config      = {"from_attributes": True}


class PluginListResponse(BaseModel):
    total: int
    items: list[PluginResponse]


# ── Schedule schemas ──────────────────────────────────────────────────────

class ScheduleCreate(BaseModel):
    name:         Annotated[str, Field(min_length=1, max_length=255)]
    description:  str | None = None
    plugin_name:  str
    trigger_type: Literal["cron", "interval", "date"] | None = None  # inherits from plugin if omitted
    trigger_args: dict[str, Any] | None = None
    extra_vars:   dict[str, Any] = Field(default_factory=dict)
    enabled:      bool = True
    model_config  = {"extra": "forbid"}


class ScheduleUpdate(BaseModel):
    name:         str | None = None
    description:  str | None = None
    plugin_name:  str | None = None
    trigger_type: Literal["cron", "interval", "date"] | None = None
    trigger_args: dict[str, Any] | None = None
    extra_vars:   dict[str, Any] | None = None
    enabled:      bool | None = None
    model_config  = {"extra": "forbid"}


class ScheduleResponse(BaseModel):
    id:              uuid.UUID
    name:            str
    description:     str | None
    plugin_name:     str
    trigger_type:    str
    trigger_args:    dict[str, Any]
    extra_vars:      dict[str, Any]
    enabled:         bool
    next_run_at:     datetime | None
    last_run_at:     datetime | None
    last_run_status: str | None
    last_run_output: str | None
    run_count:       int
    failure_count:   int
    locked_at:       datetime | None
    locked_by:       str | None
    created_by:      str
    updated_by:      str | None
    created_at:      datetime
    updated_at:      datetime
    model_config     = {"from_attributes": True}


class ScheduleListResponse(BaseModel):
    total: int
    items: list[ScheduleResponse]


# ── API envelope ──────────────────────────────────────────────────────────

class ApiResponse(BaseModel):
    success:        bool = True
    data:           Any  = None
    message:        str | None = None
    correlation_id: str | None = None
