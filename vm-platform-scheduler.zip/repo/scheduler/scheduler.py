"""
scheduler/scheduler.py — Event-driven job dispatcher.

Uses PostgreSQL LISTEN/NOTIFY + heapq. Zero polling.

Two asyncio Tasks per worker:
  _listener_task   — maintains one asyncpg LISTEN connection
                     pushes (fire_time, schedule_id) onto the heap
  _dispatcher_task — sleeps via asyncio.sleep(δt) until the soonest job
                     wakes early if a new/earlier NOTIFY arrives

Execution is delegated to the plugin registry:
  plugin_loader.get_plugin(name).run(schedule_id, extra_vars)

Deduplication:
  SELECT FOR UPDATE SKIP LOCKED — only one worker across all pods
  claims a given schedule row at a time.
"""
from __future__ import annotations

import asyncio
import heapq
import json
import logging
import os
import socket
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta, timezone

import asyncpg
from sqlalchemy import select, update, text
from sqlalchemy.ext.asyncio import async_sessionmaker

from .models import Schedule
from .trigger_calc import compute_next_run

logger = logging.getLogger(__name__)

NOTIFY_CHANNEL     = os.getenv("SCHEDULER_NOTIFY_CHANNEL", "vm_scheduler")
STALE_LOCK_MINUTES = int(os.getenv("SCHEDULER_STALE_LOCK_MIN", "10"))
MAX_OUTPUT_CHARS   = int(os.getenv("SCHEDULER_MAX_OUTPUT",    "4000"))
BOOT_RECOVERY      = os.getenv("SCHEDULER_BOOT_RECOVERY", "true").lower() == "true"

# Stable identity stored in locked_by column for observability
_WORKER_ID = f"{socket.gethostname()}:{os.getpid()}"

_session_factory: async_sessionmaker | None = None
_executor:        ThreadPoolExecutor | None  = None
_listener_task:   asyncio.Task | None        = None
_dispatcher_task: asyncio.Task | None        = None

# Min-heap: (fire_time: datetime, schedule_id: str)
_heap:       list[tuple[datetime, str]] = []
_heap_event: asyncio.Event                   # set when a new entry is pushed


# ── Public lifecycle ──────────────────────────────────────────────────────

def init_scheduler(session_factory: async_sessionmaker) -> None:
    """Call once per worker in FastAPI lifespan."""
    global _session_factory, _executor, _listener_task, _dispatcher_task, _heap_event
    _session_factory = session_factory
    _heap_event      = asyncio.Event()
    _executor        = ThreadPoolExecutor(
        max_workers=int(os.getenv("SCHEDULER_THREAD_WORKERS", "5")),
        thread_name_prefix="ansible-job",
    )
    _listener_task   = asyncio.ensure_future(_listener_loop())
    _dispatcher_task = asyncio.ensure_future(_dispatcher_loop())
    logger.info("Scheduler started — worker %s", _WORKER_ID)


async def stop_scheduler() -> None:
    for task in (_listener_task, _dispatcher_task):
        if task and not task.done():
            task.cancel()
            try:
                await task
            except asyncio.CancelledError:
                pass
    if _executor:
        _executor.shutdown(wait=False)
    logger.info("Scheduler stopped — worker %s", _WORKER_ID)


# ── Heap helper ───────────────────────────────────────────────────────────

def _push(fire_time: datetime, schedule_id: str) -> None:
    heapq.heappush(_heap, (fire_time, schedule_id))
    _heap_event.set()


# ── Listener task — one asyncpg LISTEN connection per worker ──────────────

async def _listener_loop() -> None:
    dsn = os.environ["DATABASE_URL"].replace("+asyncpg", "")
    while True:
        try:
            conn = await asyncpg.connect(dsn)
            try:
                await conn.add_listener(NOTIFY_CHANNEL, _on_notify)
                logger.info("LISTEN '%s' — worker %s", NOTIFY_CHANNEL, _WORKER_ID)
                if BOOT_RECOVERY:
                    await _load_pending_schedules()
                while True:
                    await asyncio.sleep(30)
                    await conn.execute("SELECT 1")   # keepalive
            finally:
                await conn.close()
        except asyncio.CancelledError:
            raise
        except Exception:
            logger.exception("LISTEN connection lost — reconnecting in 5s")
            await asyncio.sleep(5)


def _on_notify(_conn, _pid, _channel, payload_str: str) -> None:
    """asyncpg callback is synchronous — push to heap via the event loop."""
    try:
        p   = json.loads(payload_str)
        sid = p.get("id")
        nrat = p.get("next_run_at")
        if not sid or not nrat:
            return   # schedule disabled or deleted
        ft = datetime.fromisoformat(nrat)
        if ft.tzinfo is None:
            ft = ft.replace(tzinfo=timezone.utc)
        asyncio.get_event_loop().call_soon_threadsafe(_push, ft, sid)
    except Exception:
        logger.exception("Malformed scheduler NOTIFY payload: %s", payload_str)


async def _load_pending_schedules() -> None:
    """Boot recovery — populate heap from DB to catch schedules missed during downtime."""
    assert _session_factory is not None
    async with _session_factory() as session:
        rows = (await session.execute(
            select(Schedule.id, Schedule.next_run_at)
            .where(Schedule.enabled == True, Schedule.next_run_at.is_not(None))
        )).all()
    for r in rows:
        ft = r.next_run_at
        if ft.tzinfo is None:
            ft = ft.replace(tzinfo=timezone.utc)
        _push(ft, str(r.id))
    logger.info("Boot recovery: %d schedule(s) loaded into heap", len(rows))


# ── Dispatcher task — sleeps until the soonest job is due ─────────────────

async def _dispatcher_loop() -> None:
    while True:
        try:
            await _wait_and_dispatch()
        except asyncio.CancelledError:
            raise
        except Exception:
            logger.exception("Dispatcher error — retrying in 5s")
            await asyncio.sleep(5)


async def _wait_and_dispatch() -> None:
    _heap_event.clear()

    if not _heap:
        await _heap_event.wait()   # nothing queued — block until NOTIFY
        return

    fire_time, schedule_id = _heap[0]
    delta = (fire_time - datetime.now(timezone.utc)).total_seconds()

    if delta > 0:
        try:
            # Sleep until job is due — or wake early if an earlier job arrives
            await asyncio.wait_for(_heap_event.wait(), timeout=delta)
            return   # re-evaluate from top of heap
        except asyncio.TimeoutError:
            pass     # delta elapsed — time to fire

    heapq.heappop(_heap)
    asyncio.ensure_future(_claim_and_dispatch(schedule_id))


# ── Claim + dispatch ──────────────────────────────────────────────────────

async def _claim_and_dispatch(schedule_id: str) -> None:
    """
    Atomically claim the schedule row with SKIP LOCKED.
    If another worker already claimed it, this is a silent no-op.
    """
    import uuid
    assert _session_factory is not None

    now          = datetime.now(timezone.utc)
    stale_cutoff = now - timedelta(minutes=STALE_LOCK_MINUTES)

    async with _session_factory() as session:
        async with session.begin():
            row = (await session.execute(
                select(Schedule)
                .where(
                    Schedule.id == uuid.UUID(schedule_id),
                    Schedule.enabled == True,
                    Schedule.next_run_at <= now,
                    (Schedule.locked_at.is_(None)) | (Schedule.locked_at < stale_cutoff),
                )
                .with_for_update(skip_locked=True)
            )).scalar_one_or_none()

            if row is None:
                # Claimed by another worker, disabled, or deleted
                return

            snapshot = {
                "id":           str(row.id),
                "plugin_name":  row.plugin_name,
                "extra_vars":   dict(row.extra_vars),
                "trigger_type": row.trigger_type,
                "trigger_args": dict(row.trigger_args),
            }
            await session.execute(
                update(Schedule)
                .where(Schedule.id == row.id)
                .values(locked_at=now, locked_by=_WORKER_ID, last_run_status="running")
            )

    logger.info("Dispatching schedule '%s' via plugin '%s'", schedule_id, snapshot["plugin_name"])

    loop = asyncio.get_running_loop()
    fut  = loop.run_in_executor(_executor, _run_sync, snapshot)
    fut.add_done_callback(
        lambda f, s=snapshot: asyncio.ensure_future(_on_done(s, f))
    )


def _run_sync(snapshot: dict) -> tuple[str, str]:
    """
    Runs in a thread pool thread — never on the event loop.
    Looks up the plugin from the in-memory registry and calls run().
    """
    from .plugin_loader import get_plugin
    try:
        plugin = get_plugin(snapshot["plugin_name"])
        return plugin.run(snapshot["id"], snapshot["extra_vars"])
    except KeyError as exc:
        return "failure", f"Plugin not found in registry: {exc}"
    except Exception as exc:
        import traceback
        return "failure", f"{exc}\n{traceback.format_exc()}"


async def _on_done(snapshot: dict, future: asyncio.Future) -> None:
    """Write result back to DB, compute next_run_at, NOTIFY all workers."""
    import uuid
    assert _session_factory is not None

    status, output = "failure", ""
    try:
        status, output = future.result()
    except Exception as exc:
        import traceback
        output = f"{exc}\n{traceback.format_exc()}"

    now      = datetime.now(timezone.utc)
    next_run = None

    async with _session_factory() as session:
        async with session.begin():
            row = await session.get(Schedule, uuid.UUID(snapshot["id"]))
            if not row:
                return

            if row.trigger_type != "date":
                try:
                    next_run = compute_next_run(row.trigger_type, row.trigger_args, after=now)
                except Exception as exc:
                    logger.error("next_run compute error for %s: %s", snapshot["id"], exc)
            else:
                row.enabled = False   # one-shot: auto-disable after firing

            row.last_run_at     = now
            row.last_run_status = status
            row.last_run_output = output[:MAX_OUTPUT_CHARS]
            row.next_run_at     = next_run
            row.run_count      += 1
            if status == "failure":
                row.failure_count += 1
            row.locked_at = None
            row.locked_by = None

            # NOTIFY all workers atomically with the row update
            payload = json.dumps({
                "id":          snapshot["id"],
                "next_run_at": next_run.isoformat() if next_run else None,
            })
            await session.execute(
                text(f"SELECT pg_notify('{NOTIFY_CHANNEL}', :p)"),
                {"p": payload},
            )

    logger.info(
        "Schedule '%s' plugin:'%s' → %s | next=%s",
        snapshot["id"], snapshot["plugin_name"], status, next_run,
    )
