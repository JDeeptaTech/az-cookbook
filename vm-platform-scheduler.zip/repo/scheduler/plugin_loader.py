"""
scheduler/plugin_loader.py — DB-backed plugin registry.

Lifecycle
─────────
  init_plugin_loader(session_factory)
    → SELECT all active plugins from DB → exec each into isolated namespace
    → LISTEN 'vm_plugin_reload' (one asyncpg connection per worker)

  On NOTIFY (any worker saves/updates a plugin):
    → fetch updated row from DB
    → re-exec source code into fresh namespace
    → replace _registry[name] atomically

  Scheduler dispatcher calls:
    get_plugin(name).run(schedule_id, extra_vars)

Plugin contract
───────────────
  Required exports:
    METADATA: dict    — keys: name (str), description (str)
    run(schedule_id: str, extra_vars: dict) -> tuple[str, str]
              returns ("success" | "failure", output_string)

  Optional exports:
    validate_extra_vars(extra_vars: dict) -> list[str]
              returns error strings; empty list means valid
"""
from __future__ import annotations

import asyncio
import inspect
import logging
import os
import threading
import time
import traceback
from dataclasses import dataclass, field
from typing import Any, Callable

import asyncpg
from sqlalchemy import select
from sqlalchemy.ext.asyncio import async_sessionmaker

from .models import Plugin as PluginModel

logger = logging.getLogger(__name__)

PLUGIN_NOTIFY_CHANNEL = os.getenv("PLUGIN_NOTIFY_CHANNEL", "vm_plugin_reload")
MAX_OUTPUT            = int(os.getenv("PLUGIN_MAX_OUTPUT", "8000"))


# ── Registry entry ────────────────────────────────────────────────────────

@dataclass
class LoadedPlugin:
    name:                str
    description:         str
    trigger_type:        str
    trigger_args:        dict[str, Any]
    run:                 Callable[[str, dict], tuple[str, str]]
    validate_extra_vars: Callable[[dict], list[str]] | None = None
    version:             int = 1
    namespace:           dict[str, Any] = field(default_factory=dict, repr=False)
    load_error:          str | None = None


# name → LoadedPlugin (all workers share nothing — each has its own copy)
_registry:      dict[str, LoadedPlugin] = {}
_registry_lock: threading.Lock          = threading.Lock()

_session_factory: async_sessionmaker | None = None
_notify_task:     asyncio.Task | None       = None


# ── Public API ────────────────────────────────────────────────────────────

async def init_plugin_loader(session_factory: async_sessionmaker) -> None:
    """Call once per worker process in FastAPI lifespan."""
    global _session_factory, _notify_task
    _session_factory = session_factory
    await _load_all_from_db()
    _notify_task = asyncio.ensure_future(_notify_listener_loop())
    logger.info("Plugin loader ready — %d plugin(s) loaded", len(_registry))


async def shutdown_plugin_loader() -> None:
    if _notify_task and not _notify_task.done():
        _notify_task.cancel()
        try:
            await _notify_task
        except asyncio.CancelledError:
            pass


def get_plugin(name: str) -> LoadedPlugin:
    with _registry_lock:
        plugin = _registry.get(name)
    if plugin is None:
        raise KeyError(f"Plugin '{name}' not found in registry")
    if plugin.load_error:
        raise RuntimeError(f"Plugin '{name}' has load error: {plugin.load_error}")
    return plugin


def list_registry() -> list[dict]:
    with _registry_lock:
        return [
            {
                "name":       p.name,
                "version":    p.version,
                "load_error": p.load_error,
            }
            for p in _registry.values()
        ]


# ── DB loading ────────────────────────────────────────────────────────────

async def _load_all_from_db() -> None:
    assert _session_factory is not None
    async with _session_factory() as session:
        rows = (await session.execute(
            select(PluginModel).where(PluginModel.is_active == True)
        )).scalars().all()

    for row in rows:
        loaded = _exec_plugin(row.source_code, row.name, row.version)
        # Trigger from DB overrides any METADATA defaults
        loaded.trigger_type = row.trigger_type
        loaded.trigger_args = dict(row.trigger_args)
        with _registry_lock:
            _registry[row.name] = loaded
        if loaded.load_error:
            logger.error("Plugin '%s' load error: %s", row.name, loaded.load_error)
        else:
            logger.info("Plugin loaded: '%s' v%d", row.name, row.version)


async def _reload_one_from_db(name: str) -> None:
    assert _session_factory is not None
    async with _session_factory() as session:
        row = (await session.execute(
            select(PluginModel).where(PluginModel.name == name)
        )).scalar_one_or_none()

    if row is None or not row.is_active:
        with _registry_lock:
            _registry.pop(name, None)
        logger.info("Plugin '%s' removed from registry", name)
        return

    loaded = _exec_plugin(row.source_code, row.name, row.version)
    loaded.trigger_type = row.trigger_type
    loaded.trigger_args = dict(row.trigger_args)
    with _registry_lock:
        _registry[name] = loaded

    if loaded.load_error:
        logger.error("Plugin '%s' reloaded with error: %s", name, loaded.load_error)
    else:
        logger.info("Plugin '%s' hot-reloaded → v%d", name, row.version)


# ── exec() sandbox ────────────────────────────────────────────────────────

def _exec_plugin(source_code: str, name: str, version: int) -> LoadedPlugin:
    """
    Compile and exec plugin source into an isolated namespace dict.
    Returns LoadedPlugin with load_error set on any failure.

    exec() is used instead of importlib because source lives in the DB,
    not on disk.  Each plugin gets its own namespace dict so there is
    zero cross-plugin variable pollution.
    """
    # Step 1: syntax check (fast, no execution)
    try:
        code = compile(source_code, f"<plugin:{name}>", "exec")
    except SyntaxError as exc:
        return _error_plugin(name, version, f"SyntaxError: {exc}")

    # Step 2: execute into isolated namespace
    namespace: dict[str, Any] = {
        "__name__":     f"__plugin_{name}__",
        "__file__":     f"<plugin:{name}>",
        "__builtins__": __builtins__,
    }
    try:
        exec(code, namespace)  # noqa: S102
    except Exception as exc:
        return _error_plugin(name, version, f"Execution error: {exc}\n{traceback.format_exc()}")

    # Step 3: interface validation
    return _validate_namespace(namespace, name, version)


def _validate_namespace(namespace: dict, name: str, version: int) -> LoadedPlugin:
    errors: list[str] = []

    meta = namespace.get("METADATA")
    if not isinstance(meta, dict):
        errors.append("METADATA must be a dict")
    else:
        for key in ("name", "description"):
            if key not in meta:
                errors.append(f"METADATA missing required key: '{key}'")

    run_fn = namespace.get("run")
    if run_fn is None or not callable(run_fn):
        errors.append("Missing required callable: run(schedule_id, extra_vars)")
    else:
        params = list(inspect.signature(run_fn).parameters)
        if params != ["schedule_id", "extra_vars"]:
            errors.append(
                f"run() signature must be (schedule_id, extra_vars), got ({', '.join(params)})"
            )

    if errors:
        return _error_plugin(name, version, "; ".join(errors))

    validate_fn = namespace.get("validate_extra_vars")
    return LoadedPlugin(
        name=meta.get("name", name),
        description=meta.get("description", ""),
        trigger_type=meta.get("trigger_type", "cron"),
        trigger_args=meta.get("trigger_args", {}),
        run=namespace["run"],
        validate_extra_vars=validate_fn if callable(validate_fn) else None,
        version=version,
        namespace=namespace,
    )


def _error_plugin(name: str, version: int, error: str) -> LoadedPlugin:
    return LoadedPlugin(
        name=name, description="", trigger_type="cron", trigger_args={},
        run=lambda *a, **kw: ("failure", ""),
        version=version,
        load_error=error,
    )


# ── NOTIFY listener — hot reload ──────────────────────────────────────────

async def _notify_listener_loop() -> None:
    dsn = os.environ["DATABASE_URL"].replace("+asyncpg", "")
    while True:
        try:
            conn = await asyncpg.connect(dsn)
            try:
                await conn.add_listener(PLUGIN_NOTIFY_CHANNEL, _on_plugin_notify)
                logger.info("Plugin loader: LISTEN '%s'", PLUGIN_NOTIFY_CHANNEL)
                while True:
                    await asyncio.sleep(30)
                    await conn.execute("SELECT 1")  # keepalive
            finally:
                await conn.close()
        except asyncio.CancelledError:
            raise
        except Exception:
            logger.exception("Plugin LISTEN connection lost — reconnecting in 5s")
            await asyncio.sleep(5)


def _on_plugin_notify(_conn, _pid, _channel, plugin_name: str) -> None:
    """asyncpg callback is synchronous — schedule the async reload via the event loop."""
    logger.info("Plugin reload NOTIFY received: '%s'", plugin_name)
    loop = asyncio.get_event_loop()
    loop.call_soon_threadsafe(
        lambda: asyncio.ensure_future(_reload_one_from_db(plugin_name))
    )


# ── Test runner (used by plugin_service, never saves to DB) ───────────────

class TestResult:
    def __init__(
        self,
        status: str,
        output: str = "",
        error: str | None = None,
        duration_ms: int | None = None,
    ):
        self.status      = status
        self.output      = output[:MAX_OUTPUT] if output else output
        self.error       = error
        self.duration_ms = duration_ms

    def to_dict(self) -> dict:
        return {
            "status":      self.status,
            "output":      self.output,
            "error":       self.error,
            "duration_ms": self.duration_ms,
        }


def validate_source(source_code: str) -> TestResult:
    """Syntax + interface check only. No execution."""
    loaded = _exec_plugin(source_code, "__validate__", 0)
    if loaded.load_error:
        return TestResult("error", error=loaded.load_error)
    return TestResult("success", output="Interface valid")


def run_test(
    source_code: str,
    extra_vars: dict,
    schedule_id: str = "test-run",
    timeout_seconds: int = 30,
) -> TestResult:
    """
    Blocking — call via run_in_executor from async context.
    Validates interface then calls run() with a wall-clock timeout.
    """
    loaded = _exec_plugin(source_code, "__test__", 0)
    if loaded.load_error:
        return TestResult("error", error=loaded.load_error)

    if loaded.validate_extra_vars:
        errs = loaded.validate_extra_vars(extra_vars)
        if errs:
            return TestResult("error", error="validate_extra_vars: " + "; ".join(errs))

    result_box: list[TestResult] = []

    def _run() -> None:
        t0 = time.monotonic()
        try:
            status, output = loaded.run(schedule_id, extra_vars)
            ms = int((time.monotonic() - t0) * 1000)
            result_box.append(TestResult(status, output, duration_ms=ms))
        except Exception as exc:
            ms = int((time.monotonic() - t0) * 1000)
            result_box.append(
                TestResult("error", error=f"{exc}\n{traceback.format_exc()}", duration_ms=ms)
            )

    thread = threading.Thread(target=_run, daemon=True)
    thread.start()
    thread.join(timeout=timeout_seconds)

    if thread.is_alive():
        return TestResult("error", error=f"Timed out after {timeout_seconds}s")

    return result_box[0] if result_box else TestResult("error", error="No result returned")
