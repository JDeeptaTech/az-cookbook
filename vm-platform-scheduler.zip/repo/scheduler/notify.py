"""
scheduler/notify.py — pg_notify helpers.

All NOTIFYs are issued inside an open transaction so they are:
  - delivered to all LISTEN connections on commit
  - discarded automatically on rollback (no phantom wakeups)
"""
from __future__ import annotations

import json
import os
from datetime import datetime

from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

SCHEDULER_CHANNEL = os.getenv("SCHEDULER_NOTIFY_CHANNEL", "vm_scheduler")
PLUGIN_CHANNEL    = os.getenv("PLUGIN_NOTIFY_CHANNEL",    "vm_plugin_reload")


async def notify_schedule_updated(
    session: AsyncSession,
    schedule_id: str,
    next_run_at: datetime | None,
) -> None:
    """Call inside an active transaction after writing to platform.schedules."""
    payload = json.dumps({
        "id":          schedule_id,
        "next_run_at": next_run_at.isoformat() if next_run_at else None,
    })
    await session.execute(
        text(f"SELECT pg_notify('{SCHEDULER_CHANNEL}', :p)"),
        {"p": payload},
    )


async def notify_schedule_deleted(session: AsyncSession, schedule_id: str) -> None:
    """Notify with no next_run_at — workers will find no row and skip."""
    await notify_schedule_updated(session, schedule_id, None)


async def notify_plugin_changed(session: AsyncSession, plugin_name: str) -> None:
    """Call inside an active transaction after writing to platform.plugins."""
    await session.execute(
        text(f"SELECT pg_notify('{PLUGIN_CHANNEL}', :name)"),
        {"name": plugin_name},
    )
