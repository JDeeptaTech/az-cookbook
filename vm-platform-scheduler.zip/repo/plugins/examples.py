"""
plugins/examples.py

Paste these into POST /api/v1/plugins → source_code.
Each plugin must export METADATA dict and run() function.
"""

# ── Plugin 1: Local ansible-playbook subprocess ────────────────────────────
PLUGIN_SUBPROCESS = '''
import json
import subprocess

METADATA = {
    "name":         "nightly-patch",
    "description":  "Run OS patching playbook via ansible-playbook",
    "trigger_type": "cron",
    "trigger_args": {"hour": "2", "minute": "30"},
}


def validate_extra_vars(extra_vars: dict) -> list[str]:
    errors = []
    if "env" not in extra_vars:
        errors.append("'env' is required")
    if extra_vars.get("env") not in ("dev", "test", "prod"):
        errors.append("'env' must be dev, test, or prod")
    return errors


def run(schedule_id: str, extra_vars: dict) -> tuple[str, str]:
    cmd = [
        "ansible-playbook",
        f"/playbooks/{extra_vars.get('playbook', 'patch_vms.yml')}",
        "-i", extra_vars.get("inventory", "localhost,"),
        "--extra-vars", json.dumps({**extra_vars, "schedule_id": schedule_id}),
    ]
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=3600)
    output = (result.stdout + result.stderr).strip()
    return ("success" if result.returncode == 0 else "failure"), output
'''


# ── Plugin 2: Ansible Automation Platform (AAP) REST API ──────────────────
PLUGIN_AAP = '''
import json
import os
import urllib.request

METADATA = {
    "name":         "aap-health-check",
    "description":  "Launch AAP job template for VM health checks",
    "trigger_type": "interval",
    "trigger_args": {"hours": 6},
}

_AAP_BASE    = os.environ["AAP_BASE_URL"]
_AAP_TOKEN   = os.environ["AAP_TOKEN"]
_TEMPLATE_ID = int(os.environ.get("AAP_TEMPLATE_ID", "42"))


def validate_extra_vars(extra_vars: dict) -> list[str]:
    if "target_group" not in extra_vars:
        return ["'target_group' is required"]
    return []


def run(schedule_id: str, extra_vars: dict) -> tuple[str, str]:
    body = json.dumps({
        "extra_vars": json.dumps({**extra_vars, "schedule_id": schedule_id})
    }).encode()
    req = urllib.request.Request(
        f"{_AAP_BASE}/api/v2/job_templates/{_TEMPLATE_ID}/launch/",
        data=body,
        headers={
            "Authorization": f"Bearer {_AAP_TOKEN}",
            "Content-Type":  "application/json",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            data = json.loads(resp.read())
        return "success", f"AAP job {data['id']} launched"
    except Exception as exc:
        return "failure", str(exc)
'''


# ── Plugin 3: One-shot date trigger ───────────────────────────────────────
PLUGIN_ONESHOT = '''
import json
import subprocess

METADATA = {
    "name":         "migration-cutover",
    "description":  "One-shot VM migration cutover",
    "trigger_type": "date",
    "trigger_args": {"run_date": "2025-09-01T00:00:00", "timezone": "UTC"},
}


def run(schedule_id: str, extra_vars: dict) -> tuple[str, str]:
    cmd = [
        "ansible-playbook", "/playbooks/vm_migrate.yml",
        "--extra-vars", json.dumps({**extra_vars, "schedule_id": schedule_id}),
    ]
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=7200)
    output = (result.stdout + result.stderr).strip()
    return ("success" if result.returncode == 0 else "failure"), output
    # Note: schedule auto-disables after firing (trigger_type = "date")
'''
