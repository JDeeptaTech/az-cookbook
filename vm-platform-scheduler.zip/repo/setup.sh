#!/usr/bin/env bash
# =============================================================================
# setup.sh — one-shot local development setup
#
# Usage:  bash setup.sh
# =============================================================================
set -euo pipefail

# ── Colours ───────────────────────────────────────────────────────────────────
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; BLUE='\033[0;34m'; NC='\033[0m'
info()    { echo -e "${BLUE}[INFO]${NC}  $*"; }
success() { echo -e "${GREEN}[OK]${NC}    $*"; }
warn()    { echo -e "${YELLOW}[WARN]${NC}  $*"; }
error()   { echo -e "${RED}[ERROR]${NC} $*"; exit 1; }

echo ""
echo "==========================================="
echo "  VM Platform Scheduler — Local Setup"
echo "==========================================="
echo ""

# ── 1. Check Python ───────────────────────────────────────────────────────────
info "Checking Python version..."
PYTHON=$(command -v python3 || command -v python || error "Python not found")
PY_VERSION=$($PYTHON --version 2>&1 | grep -oP '\d+\.\d+')
PY_MAJOR=$(echo "$PY_VERSION" | cut -d. -f1)
PY_MINOR=$(echo "$PY_VERSION" | cut -d. -f2)

if [ "$PY_MAJOR" -lt 3 ] || { [ "$PY_MAJOR" -eq 3 ] && [ "$PY_MINOR" -lt 11 ]; }; then
    error "Python 3.11+ required (found $PY_VERSION)"
fi
success "Python $PY_VERSION"

# ── 2. Check Docker ───────────────────────────────────────────────────────────
info "Checking Docker..."
if ! command -v docker &>/dev/null; then
    error "Docker not found. Install from https://docs.docker.com/get-docker/"
fi
if ! docker info &>/dev/null; then
    error "Docker daemon is not running. Start Docker Desktop or the docker service."
fi
if ! command -v docker-compose &>/dev/null && ! docker compose version &>/dev/null 2>&1; then
    error "docker-compose not found. Install from https://docs.docker.com/compose/install/"
fi
success "Docker OK"

# ── 3. Virtual environment ────────────────────────────────────────────────────
info "Creating virtual environment (.venv)..."
if [ ! -d ".venv" ]; then
    $PYTHON -m venv .venv
    success "Virtual environment created"
else
    warn ".venv already exists — skipping creation"
fi

# Activate
# shellcheck disable=SC1091
source .venv/bin/activate
success "Virtual environment activated"

# ── 4. Install dependencies ───────────────────────────────────────────────────
info "Installing dependencies..."
pip install --upgrade pip -q
pip install -e ".[dev]" -q
success "Dependencies installed"

# ── 5. Environment file ───────────────────────────────────────────────────────
info "Setting up .env file..."
if [ ! -f ".env" ]; then
    cp .env.example .env
    success ".env created from .env.example"
else
    warn ".env already exists — skipping"
fi

# ── 6. Start PostgreSQL ───────────────────────────────────────────────────────
info "Starting PostgreSQL via docker-compose..."

# Support both 'docker-compose' and 'docker compose'
DC="docker-compose"
if ! command -v docker-compose &>/dev/null; then
    DC="docker compose"
fi

$DC up -d postgres

info "Waiting for PostgreSQL to be ready..."
RETRIES=30
until $DC exec -T postgres pg_isready -U platform -q 2>/dev/null; do
    RETRIES=$((RETRIES - 1))
    if [ "$RETRIES" -le 0 ]; then
        error "PostgreSQL did not become ready in time. Check: docker-compose logs postgres"
    fi
    sleep 1
done
success "PostgreSQL ready"

# ── 7. Run migration ──────────────────────────────────────────────────────────
info "Running database migration..."
# shellcheck disable=SC1091
source .env 2>/dev/null || true
export DATABASE_URL="${DATABASE_URL:-postgresql+asyncpg://platform:platform@localhost:5432/platform}"

# Convert asyncpg URL to psql URL for migration
PSQL_URL="${DATABASE_URL/+asyncpg/}"

psql "$PSQL_URL" -f migrations/V001__platform_schema.sql -q
success "Migration applied"

# ── 8. Smoke test ─────────────────────────────────────────────────────────────
info "Running import smoke test..."
python3 -c "
from scheduler.models import Plugin, PluginTestRun, Schedule
from scheduler.schemas import PluginCreate, ScheduleCreate
from scheduler.trigger_calc import compute_next_run
from scheduler.plugin_loader import validate_source, _exec_plugin
print('  All imports OK')
"
success "Import smoke test passed"

# ── Done ──────────────────────────────────────────────────────────────────────
echo ""
echo "==========================================="
echo -e "  ${GREEN}Setup complete!${NC}"
echo "==========================================="
echo ""
echo "  Activate environment:   source .venv/bin/activate"
echo ""
echo "  Start (single worker):  make run"
echo "  Start (multi-worker):   make run-multi"
echo ""
echo "  API docs:               http://localhost:8000/docs"
echo "  Health check:           http://localhost:8000/healthz"
echo ""
echo "  Manage database:        make psql"
echo "  Reset database:         make db-reset"
echo ""
