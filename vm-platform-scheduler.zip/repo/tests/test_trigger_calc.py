"""
tests/test_trigger_calc.py

Unit tests for trigger calculation — no database required.
Run with: pytest tests/test_trigger_calc.py -v
"""
import pytest
from datetime import datetime, timezone, timedelta

from scheduler.trigger_calc import compute_next_run, validate_trigger_args
from scheduler.schemas import CronTriggerArgs, IntervalTriggerArgs, DateTriggerArgs


# ── compute_next_run ──────────────────────────────────────────────────────────

class TestCronTrigger:
    def test_daily_at_midnight(self):
        after = datetime(2024, 1, 15, 0, 0, 0, tzinfo=timezone.utc)
        result = compute_next_run("cron", {"hour": "0", "minute": "0"}, after=after)
        assert result == datetime(2024, 1, 16, 0, 0, 0, tzinfo=timezone.utc)

    def test_specific_hour_and_minute(self):
        after = datetime(2024, 1, 15, 1, 0, 0, tzinfo=timezone.utc)
        result = compute_next_run("cron", {"hour": "2", "minute": "30"}, after=after)
        assert result == datetime(2024, 1, 15, 2, 30, 0, tzinfo=timezone.utc)

    def test_past_time_rolls_to_next_day(self):
        after = datetime(2024, 1, 15, 3, 0, 0, tzinfo=timezone.utc)
        result = compute_next_run("cron", {"hour": "2", "minute": "30"}, after=after)
        assert result == datetime(2024, 1, 16, 2, 30, 0, tzinfo=timezone.utc)

    def test_weekday_filter(self):
        # 2024-01-15 is Monday; day_of_week=fri should fire on Friday 2024-01-19
        after = datetime(2024, 1, 15, 0, 0, 0, tzinfo=timezone.utc)
        result = compute_next_run("cron", {"hour": "8", "minute": "0", "day_of_week": "fri"}, after=after)
        assert result.weekday() == 4  # Friday

    def test_default_args_fires_at_midnight(self):
        after = datetime(2024, 1, 15, 1, 0, 0, tzinfo=timezone.utc)
        result = compute_next_run("cron", {}, after=after)
        assert result.hour == 0
        assert result.minute == 0


class TestIntervalTrigger:
    def test_hours(self):
        after = datetime(2024, 1, 15, 0, 0, 0, tzinfo=timezone.utc)
        result = compute_next_run("interval", {"hours": 6}, after=after)
        assert result == datetime(2024, 1, 15, 6, 0, 0, tzinfo=timezone.utc)

    def test_minutes(self):
        after = datetime(2024, 1, 15, 0, 0, 0, tzinfo=timezone.utc)
        result = compute_next_run("interval", {"minutes": 30}, after=after)
        assert result == datetime(2024, 1, 15, 0, 30, 0, tzinfo=timezone.utc)

    def test_combined(self):
        after = datetime(2024, 1, 15, 0, 0, 0, tzinfo=timezone.utc)
        result = compute_next_run("interval", {"hours": 1, "minutes": 30}, after=after)
        assert result == datetime(2024, 1, 15, 1, 30, 0, tzinfo=timezone.utc)

    def test_days(self):
        after = datetime(2024, 1, 15, 0, 0, 0, tzinfo=timezone.utc)
        result = compute_next_run("interval", {"days": 7}, after=after)
        assert result == datetime(2024, 1, 22, 0, 0, 0, tzinfo=timezone.utc)

    def test_all_zeros_raises(self):
        with pytest.raises(ValueError, match="non-zero"):
            compute_next_run("interval", {"hours": 0, "minutes": 0})


class TestDateTrigger:
    def test_future_date_returns_date(self):
        future = datetime(2099, 6, 1, 0, 0, 0, tzinfo=timezone.utc)
        result = compute_next_run("date", {"run_date": future.isoformat()})
        assert result == future

    def test_past_date_returns_none(self):
        past = datetime(2000, 1, 1, 0, 0, 0, tzinfo=timezone.utc)
        result = compute_next_run("date", {"run_date": past.isoformat()})
        assert result is None

    def test_naive_datetime_string(self):
        result = compute_next_run("date", {"run_date": "2099-01-01T00:00:00"})
        assert result is not None

    def test_datetime_object(self):
        future = datetime(2099, 6, 1, 0, 0, 0, tzinfo=timezone.utc)
        result = compute_next_run("date", {"run_date": future})
        assert result == future


class TestUnknownTrigger:
    def test_unknown_type_raises(self):
        with pytest.raises(ValueError, match="Unknown trigger_type"):
            compute_next_run("weekly", {})


# ── validate_trigger_args ─────────────────────────────────────────────────────

class TestValidateTriggerArgs:
    def test_valid_cron(self):
        result = validate_trigger_args("cron", {"hour": "2", "minute": "30"})
        assert result["hour"] == "2"
        assert result["minute"] == "30"

    def test_cron_defaults(self):
        result = validate_trigger_args("cron", {})
        assert result["hour"] == "0"
        assert result["minute"] == "0"

    def test_valid_interval(self):
        result = validate_trigger_args("interval", {"hours": 6})
        assert result["hours"] == 6

    def test_interval_all_zeros_raises(self):
        with pytest.raises(Exception):
            validate_trigger_args("interval", {"hours": 0})

    def test_valid_date(self):
        result = validate_trigger_args("date", {"run_date": "2099-01-01T00:00:00"})
        assert "run_date" in result

    def test_unknown_type_raises(self):
        with pytest.raises(ValueError):
            validate_trigger_args("monthly", {})


# ── Plugin sandbox ────────────────────────────────────────────────────────────

class TestPluginSandbox:
    def test_valid_plugin_loads(self):
        from scheduler.plugin_loader import _exec_plugin

        source = '''
METADATA = {"name": "test", "description": "test plugin"}
def run(schedule_id, extra_vars):
    return "success", f"ok:{schedule_id}"
'''
        plugin = _exec_plugin(source, "test", 1)
        assert plugin.load_error is None
        assert plugin.name == "test"
        status, output = plugin.run("s-123", {})
        assert status == "success"
        assert "s-123" in output

    def test_syntax_error_caught(self):
        from scheduler.plugin_loader import _exec_plugin

        source = "def run(schedule_id extra_vars): pass"
        plugin = _exec_plugin(source, "bad", 1)
        assert plugin.load_error is not None
        assert "SyntaxError" in plugin.load_error

    def test_missing_metadata_caught(self):
        from scheduler.plugin_loader import _exec_plugin

        source = "def run(schedule_id, extra_vars): return 'success', ''"
        plugin = _exec_plugin(source, "no-meta", 1)
        assert plugin.load_error is not None

    def test_missing_run_caught(self):
        from scheduler.plugin_loader import _exec_plugin

        source = 'METADATA = {"name": "x", "description": "y"}'
        plugin = _exec_plugin(source, "no-run", 1)
        assert plugin.load_error is not None

    def test_wrong_run_signature_caught(self):
        from scheduler.plugin_loader import _exec_plugin

        source = '''
METADATA = {"name": "x", "description": "y"}
def run(only_one_arg):
    return "success", ""
'''
        plugin = _exec_plugin(source, "bad-sig", 1)
        assert plugin.load_error is not None
        assert "signature" in plugin.load_error

    def test_validate_source_valid(self):
        from scheduler.plugin_loader import validate_source

        source = '''
METADATA = {"name": "x", "description": "y"}
def run(schedule_id, extra_vars):
    return "success", ""
'''
        result = validate_source(source)
        assert result.status == "success"

    def test_validate_source_invalid(self):
        from scheduler.plugin_loader import validate_source

        result = validate_source("this is not valid python @@@@")
        assert result.status == "error"

    def test_plugin_isolation(self):
        """Plugins cannot see each other's namespaces."""
        from scheduler.plugin_loader import _exec_plugin

        source_a = '''
METADATA = {"name": "a", "description": "plugin a"}
SECRET = "plugin_a_secret"
def run(schedule_id, extra_vars):
    return "success", SECRET
'''
        source_b = '''
METADATA = {"name": "b", "description": "plugin b"}
def run(schedule_id, extra_vars):
    try:
        return "success", SECRET
    except NameError:
        return "success", "isolated"
'''
        plugin_a = _exec_plugin(source_a, "a", 1)
        plugin_b = _exec_plugin(source_b, "b", 1)

        _, out_a = plugin_a.run("s", {})
        _, out_b = plugin_b.run("s", {})

        assert out_a == "plugin_a_secret"
        assert out_b == "isolated"   # SECRET is not visible in plugin_b

    def test_run_test_with_timeout(self):
        from scheduler.plugin_loader import run_test

        source = '''
METADATA = {"name": "slow", "description": "slow plugin"}
import time
def run(schedule_id, extra_vars):
    time.sleep(10)
    return "success", ""
'''
        result = run_test(source, {}, timeout_seconds=1)
        assert result.status == "error"
        assert "Timed out" in result.error

    def test_run_test_validate_extra_vars(self):
        from scheduler.plugin_loader import run_test

        source = '''
METADATA = {"name": "validated", "description": "validates extra_vars"}
def validate_extra_vars(extra_vars):
    return [] if "env" in extra_vars else ["env is required"]
def run(schedule_id, extra_vars):
    return "success", extra_vars["env"]
'''
        # Missing env
        result = run_test(source, {}, timeout_seconds=5)
        assert result.status == "error"
        assert "env is required" in result.error

        # Valid extra_vars
        result = run_test(source, {"env": "dev"}, timeout_seconds=5)
        assert result.status == "success"
        assert result.output == "dev"
