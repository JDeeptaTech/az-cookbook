-- =============================================================
-- Platform Scheduler — complete schema
-- =============================================================
-- Tables
--   platform.plugins          source of truth for plugin code
--   platform.plugin_test_runs history of every test run
--   platform.schedules        user-managed schedules (job store)
-- =============================================================

CREATE SCHEMA IF NOT EXISTS platform;

-- -----------------------------------------------------------
-- 1. PLUGINS
--    Source code lives in the DB — no shared filesystem.
--    Workers hot-reload via pg_notify on every save/update.
-- -----------------------------------------------------------
CREATE TABLE IF NOT EXISTS platform.plugins (
    id            UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
    name          TEXT        NOT NULL UNIQUE,
    description   TEXT,
    source_code   TEXT        NOT NULL,

    -- Default trigger (schedules may override per-row)
    trigger_type  TEXT        NOT NULL CHECK (trigger_type IN ('cron','interval','date')),
    trigger_args  JSONB       NOT NULL DEFAULT '{}',

    is_active     BOOLEAN     NOT NULL DEFAULT TRUE,
    version       INT         NOT NULL DEFAULT 1,

    -- Denormalised last test result for quick display
    last_tested_at     TIMESTAMPTZ,
    last_test_status   TEXT CHECK (last_test_status IN ('success','failure','error')),
    last_test_output   TEXT,

    created_by    TEXT        NOT NULL,
    updated_by    TEXT,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_plugins_is_active
    ON platform.plugins (is_active);


-- -----------------------------------------------------------
-- 2. PLUGIN TEST RUNS
--    Full history of every /validate and /test call.
-- -----------------------------------------------------------
CREATE TABLE IF NOT EXISTS platform.plugin_test_runs (
    id            UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
    plugin_name   TEXT        NOT NULL,
    plugin_id     UUID        REFERENCES platform.plugins(id) ON DELETE SET NULL,
    ran_by        TEXT        NOT NULL,
    extra_vars    JSONB       NOT NULL DEFAULT '{}',
    status        TEXT        NOT NULL CHECK (status IN ('success','failure','error')),
    output        TEXT,
    error         TEXT,
    duration_ms   INT,
    ran_at        TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_test_runs_plugin_id
    ON platform.plugin_test_runs (plugin_id);
CREATE INDEX IF NOT EXISTS idx_test_runs_ran_at
    ON platform.plugin_test_runs (ran_at DESC);


-- -----------------------------------------------------------
-- 3. SCHEDULES
--    This table IS the job store — no separate APScheduler table.
--    Distributed dispatch via SELECT FOR UPDATE SKIP LOCKED.
-- -----------------------------------------------------------
CREATE TABLE IF NOT EXISTS platform.schedules (
    id            UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
    name          TEXT        NOT NULL,
    description   TEXT,

    -- Plugin reference — name is stable; plugin can be updated in-place
    plugin_name   TEXT        NOT NULL
                  REFERENCES platform.plugins(name)
                  ON UPDATE CASCADE ON DELETE RESTRICT,

    -- Trigger (overrides plugin default when set)
    trigger_type  TEXT        NOT NULL CHECK (trigger_type IN ('cron','interval','date')),
    trigger_args  JSONB       NOT NULL,

    -- Passed to plugin.run() at execution time
    extra_vars    JSONB       NOT NULL DEFAULT '{}',

    -- Scheduler state
    enabled           BOOLEAN     NOT NULL DEFAULT TRUE,
    next_run_at       TIMESTAMPTZ,
    last_run_at       TIMESTAMPTZ,
    last_run_status   TEXT CHECK (last_run_status IN ('success','failure','running')),
    last_run_output   TEXT,
    run_count         BIGINT      NOT NULL DEFAULT 0,
    failure_count     BIGINT      NOT NULL DEFAULT 0,

    -- Distributed lock columns (SELECT FOR UPDATE SKIP LOCKED)
    locked_at     TIMESTAMPTZ,
    locked_by     TEXT,

    created_by    TEXT        NOT NULL,
    updated_by    TEXT,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at    TIMESTAMPTZ NOT NULL DEFAULT now(),

    CONSTRAINT uq_schedule_name UNIQUE (name, created_by)
);

-- Primary polling index — partial, only enabled rows
CREATE INDEX IF NOT EXISTS idx_schedules_poll
    ON platform.schedules (next_run_at, locked_at)
    WHERE enabled = TRUE;

CREATE INDEX IF NOT EXISTS idx_schedules_plugin_name
    ON platform.schedules (plugin_name);

CREATE INDEX IF NOT EXISTS idx_schedules_created_by
    ON platform.schedules (created_by);


-- -----------------------------------------------------------
-- Auto-update updated_at
-- -----------------------------------------------------------
CREATE OR REPLACE FUNCTION platform.set_updated_at()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_plugins_updated_at   ON platform.plugins;
DROP TRIGGER IF EXISTS trg_schedules_updated_at ON platform.schedules;

CREATE TRIGGER trg_plugins_updated_at
    BEFORE UPDATE ON platform.plugins
    FOR EACH ROW EXECUTE FUNCTION platform.set_updated_at();

CREATE TRIGGER trg_schedules_updated_at
    BEFORE UPDATE ON platform.schedules
    FOR EACH ROW EXECUTE FUNCTION platform.set_updated_at();
