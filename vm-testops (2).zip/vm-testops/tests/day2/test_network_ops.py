"""Day-2 network operations with API + OCP validation."""
from __future__ import annotations

import allure
import pytest

from lib.async_ops import TerminalState


@pytest.mark.day2
@pytest.mark.network
@allure.feature("Day2 — Network Operations")
class TestNetworkOps:

    NIC_NAME = "eth1"
    NETWORK = "secondary-net"

    @allure.story("Add a secondary NIC")
    def test_add_nic(self, provisioned_vm, vm_client, waiter, async_op_tracker, ocp_validator):
        handle = async_op_tracker(
            vm_client.submit_day2(
                provisioned_vm["id"],
                "network.add_nic",
                params={"network": self.NETWORK, "name": self.NIC_NAME},
            )
        )
        result = waiter.wait(handle, expect=TerminalState.SUCCESS)

        with allure.step("[API] NIC visible in VM record"):
            vm = vm_client.get_vm(provisioned_vm["id"])
            nics = vm.get("nics", [])
            assert any(n.get("name") == self.NIC_NAME for n in nics), (
                f"Added NIC not present: {nics}"
            )
            assert result.success

        # Cluster-side: interface + network in VM spec, on the right Multus net.
        ocp_validator.expect_nic_attached(
            provisioned_vm["name"], self.NIC_NAME, self.NETWORK,
        )

    @allure.story("Remove the secondary NIC")
    def test_remove_nic(self, provisioned_vm, vm_client, waiter, async_op_tracker, ocp_validator):
        handle = async_op_tracker(
            vm_client.submit_day2(
                provisioned_vm["id"],
                "network.remove_nic",
                params={"name": self.NIC_NAME},
            )
        )
        result = waiter.wait(handle)
        assert result.success

        ocp_validator.expect_nic_detached(provisioned_vm["name"], self.NIC_NAME)
