"""Day-2 snapshot operations with API + OCP validation."""
from __future__ import annotations

import allure
import pytest

from lib.allure_utils import attach_json
from lib.async_ops import AsyncOpFailure, TerminalState


@pytest.mark.day2
@pytest.mark.snapshot
@allure.feature("Day2 — Snapshot Operations")
class TestSnapshotOps:

    @allure.story("Create snapshot (API + OCP)")
    @allure.severity(allure.severity_level.CRITICAL)
    def test_create_snapshot(
        self, provisioned_vm, vm_client, waiter, async_op_tracker, ocp_validator, request
    ):
        snap_name = f"snap-{provisioned_vm['name']}-{request.node.name}"
        with allure.step(f"[API] Submit snapshot.create ({snap_name})"):
            handle = async_op_tracker(
                vm_client.submit_day2(
                    provisioned_vm["id"],
                    "snapshot.create",
                    params={"name": snap_name},
                )
            )

        result = waiter.wait(handle, expect=TerminalState.SUCCESS)

        with allure.step("[API] Snapshot artifact returned"):
            snap_id = (result.final_payload.get("result") or {}).get("snapshot_id")
            assert snap_id, "snapshot_id missing from final payload"
            attach_json("snapshot-artifact", {"id": snap_id, "name": snap_name})

        # Cluster-side: VirtualMachineSnapshot CR exists with readyToUse=true.
        ocp_validator.expect_snapshot_ready(snap_name)

        # Stash for restore/delete tests in the same session
        request.session.last_snapshot_id = snap_id
        request.session.last_snapshot_name = snap_name

    @allure.story("Restore from snapshot")
    def test_restore_snapshot(
        self, provisioned_vm, vm_client, waiter, async_op_tracker, ocp_validator, request
    ):
        snap_id = getattr(request.session, "last_snapshot_id", None)
        if not snap_id:
            pytest.skip("No snapshot from prior test; run create first")

        handle = async_op_tracker(
            vm_client.submit_day2(
                provisioned_vm["id"],
                "snapshot.restore",
                params={"snapshot_id": snap_id},
            )
        )
        result = waiter.wait(handle)
        assert result.success

        # VM should be healthy after restore — no warnings since submit.
        ocp_validator.expect_vm_healthy(
            provisioned_vm["name"],
            since_iso=handle.submitted_at.isoformat(),
        )

    @allure.story("Delete snapshot")
    def test_delete_snapshot(
        self, provisioned_vm, vm_client, waiter, async_op_tracker, ocp_validator, request
    ):
        snap_id = getattr(request.session, "last_snapshot_id", None)
        snap_name = getattr(request.session, "last_snapshot_name", None)
        if not snap_id:
            pytest.skip("No snapshot to delete")

        handle = async_op_tracker(
            vm_client.submit_day2(
                provisioned_vm["id"],
                "snapshot.delete",
                params={"snapshot_id": snap_id},
            )
        )
        result = waiter.wait(handle)
        assert result.success

        # CR should be gone from the cluster.
        if snap_name:
            ocp_validator.expect_snapshot_absent(snap_name)

    @allure.story("Restore with invalid id surfaces clean failure")
    def test_restore_invalid_fails_cleanly(
        self, provisioned_vm, vm_client, waiter, async_op_tracker
    ):
        handle = async_op_tracker(
            vm_client.submit_day2(
                provisioned_vm["id"],
                "snapshot.restore",
                params={"snapshot_id": "definitely-does-not-exist"},
            )
        )
        with pytest.raises(AsyncOpFailure) as exc_info:
            waiter.wait(handle)
        assert exc_info.value.result.terminal_state == TerminalState.FAILED
