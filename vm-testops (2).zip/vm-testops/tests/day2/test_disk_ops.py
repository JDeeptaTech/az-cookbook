"""Day-2 disk operations with API + OCP validation."""
from __future__ import annotations

import allure
import pytest

from lib.async_ops import TerminalState


@pytest.mark.day2
@pytest.mark.disk
@allure.feature("Day2 — Disk Operations")
class TestDiskOps:

    DISK_NAME = "test-data-1"

    @allure.story("Attach a new data disk")
    def test_attach_disk(self, provisioned_vm, vm_client, waiter, async_op_tracker, ocp_validator):
        handle = async_op_tracker(
            vm_client.submit_day2(
                provisioned_vm["id"],
                "disk.attach",
                params={"size_gb": 20, "name": self.DISK_NAME},
            )
        )
        result = waiter.wait(handle)
        assert result.success

        with allure.step("[API] Disk visible in VM record"):
            vm = vm_client.get_vm(provisioned_vm["id"])
            disks = vm.get("disks", [])
            assert any(d.get("name") == self.DISK_NAME for d in disks), (
                f"Attached disk not found in VM disks: {disks}"
            )

        # Cluster-side: disk in spec AND PVC is Bound at the right size.
        ocp_validator.expect_disk_attached(
            provisioned_vm["name"], self.DISK_NAME, size_gb=20,
        )

    @allure.story("Resize attached disk")
    def test_resize_disk(self, provisioned_vm, vm_client, waiter, async_op_tracker, ocp_validator):
        handle = async_op_tracker(
            vm_client.submit_day2(
                provisioned_vm["id"],
                "disk.resize",
                params={"disk_name": self.DISK_NAME, "new_size_gb": 30},
            )
        )
        result = waiter.wait(handle)
        assert result.success

        # PVC capacity should reflect the new size.
        ocp_validator.expect_disk_attached(
            provisioned_vm["name"], self.DISK_NAME, size_gb=30,
        )

    @allure.story("Detach disk")
    def test_detach_disk(self, provisioned_vm, vm_client, waiter, async_op_tracker, ocp_validator):
        handle = async_op_tracker(
            vm_client.submit_day2(
                provisioned_vm["id"],
                "disk.detach",
                params={"disk_name": self.DISK_NAME},
            )
        )
        result = waiter.wait(handle)
        assert result.success

        ocp_validator.expect_disk_detached(provisioned_vm["name"], self.DISK_NAME)
