"""Day-2 power operations: start, stop, restart.

Each op asserts on the API result, then cross-checks the cluster state
via the ocp_validator fixture.
"""
from __future__ import annotations

import allure
import pytest

from lib.allure_utils import attach_json
from lib.async_ops import TerminalState


@pytest.mark.day2
@pytest.mark.power
@allure.feature("Day2 — Power Operations")
class TestPowerOps:

    @allure.story("Stop a running VM")
    @allure.severity(allure.severity_level.CRITICAL)
    def test_stop(self, provisioned_vm, vm_client, waiter, async_op_tracker, ocp_validator):
        with allure.step("[API] Submit power.stop"):
            handle = async_op_tracker(
                vm_client.submit_day2(provisioned_vm["id"], "power.stop")
            )
            attach_json("submit-handle", {
                "request_id": handle.request_id,
                "correlation_id": handle.correlation_id,
            })

        result = waiter.wait(handle, expect=TerminalState.SUCCESS)
        assert result.success

        # API-side
        with allure.step("[API] VM status is STOPPED"):
            vm = vm_client.get_vm(provisioned_vm["id"])
            assert vm["status"] in ("STOPPED", "POWERED_OFF"), (
                f"VM not stopped: {vm['status']}"
            )

        # Cluster-side
        ocp_validator.expect_vm_stopped(provisioned_vm["name"])
        ocp_validator.expect_no_warning_events(
            provisioned_vm["name"],
            since_iso=handle.submitted_at.isoformat(),
        )

    @allure.story("Start a stopped VM")
    @allure.severity(allure.severity_level.CRITICAL)
    def test_start(self, provisioned_vm, vm_client, waiter, async_op_tracker, ocp_validator):
        handle = async_op_tracker(
            vm_client.submit_day2(provisioned_vm["id"], "power.start")
        )
        result = waiter.wait(handle, expect=TerminalState.SUCCESS)

        with allure.step("[API] VM status is RUNNING"):
            vm = vm_client.get_vm(provisioned_vm["id"])
            assert vm["status"] == "RUNNING"
            assert result.success

        ocp_validator.expect_vm_running(provisioned_vm["name"])
        ocp_validator.expect_no_warning_events(
            provisioned_vm["name"],
            since_iso=handle.submitted_at.isoformat(),
        )

    @allure.story("Restart a running VM")
    def test_restart(self, provisioned_vm, vm_client, waiter, async_op_tracker, ocp_validator):
        handle = async_op_tracker(
            vm_client.submit_day2(provisioned_vm["id"], "power.restart")
        )
        result = waiter.wait(handle, expect=TerminalState.SUCCESS)
        assert result.success

        # After restart the VM should be Running again, with a fresh VMI.
        ocp_validator.expect_vm_healthy(
            provisioned_vm["name"],
            since_iso=handle.submitted_at.isoformat(),
        )
