"""
Thin HTTP client for the VM self-service FastAPI platform.

Adapt the endpoint paths and response envelope to match your actual API.
This assumes:
  POST /api/v1/vms                       -> build VM (sync or async-with-job)
  GET  /api/v1/vms/{vm_id}               -> get VM state
  POST /api/v1/vms/{vm_id}/day2          -> submit day-2 op, returns {request_id}
  GET  /api/v1/requests/{request_id}     -> poll request status
  POST /api/v1/requests/{request_id}/cancel  -> best-effort cancel
"""
from __future__ import annotations

import os
import uuid
from datetime import datetime, timezone
from typing import Optional

import httpx
from tenacity import (
    retry,
    retry_if_exception_type,
    stop_after_attempt,
    wait_exponential,
)

from lib.async_ops import AsyncOpWaiter, OpHandle, new_correlation_id


class VMPlatformClient:
    def __init__(
        self,
        base_url: Optional[str] = None,
        token: Optional[str] = None,
        timeout: float = 60.0,
    ):
        self.base_url = base_url or os.environ["VM_API_BASE_URL"]
        self.token = token or os.environ["VM_API_TOKEN"]
        self.client = httpx.Client(
            base_url=self.base_url,
            headers={
                "Authorization": f"Bearer {self.token}",
                "Accept": "application/json",
            },
            timeout=timeout,
        )

    def close(self) -> None:
        self.client.close()

    # ---------- Build ----------
    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(min=2, max=10),
        retry=retry_if_exception_type(httpx.TransportError),
    )
    def build_vm(self, payload: dict, correlation_id: Optional[str] = None) -> dict:
        corr = correlation_id or new_correlation_id()
        r = self.client.post(
            "/api/v1/vms",
            json=payload,
            headers={"X-Correlation-Id": corr},
        )
        r.raise_for_status()
        return r.json().get("data", r.json())

    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(min=2, max=10),
        retry=retry_if_exception_type(httpx.TransportError),
    )
    def get_vm(self, vm_id: str) -> dict:
        r = self.client.get(f"/api/v1/vms/{vm_id}")
        r.raise_for_status()
        return r.json().get("data", r.json())

    def delete_vm(self, vm_id: str) -> dict:
        r = self.client.delete(f"/api/v1/vms/{vm_id}")
        r.raise_for_status()
        return r.json().get("data", r.json())

    # ---------- Day-2 (async submit + poll) ----------
    def submit_day2(
        self,
        vm_id: str,
        operation: str,                # "snapshot.create", "power.stop", etc.
        params: Optional[dict] = None,
        correlation_id: Optional[str] = None,
    ) -> OpHandle:
        corr = correlation_id or new_correlation_id()
        if "." not in operation:
            raise ValueError(
                f"operation must be 'family.action' form, got {operation!r}"
            )
        op_family, op_name = operation.split(".", 1)
        r = self.client.post(
            f"/api/v1/vms/{vm_id}/day2",
            json={"operation": op_name, "params": params or {}},
            headers={"X-Correlation-Id": corr},
        )
        r.raise_for_status()
        body = r.json().get("data", r.json())
        request_id = body.get("request_id") or body.get("id")
        if not request_id:
            raise RuntimeError(
                f"submit_day2 response missing request_id: {body}"
            )
        return OpHandle(
            request_id=request_id,
            operation=operation,
            vm_id=vm_id,
            correlation_id=corr,
            submitted_at=datetime.now(timezone.utc),
            metadata={"op_family": op_family, "params": params or {}},
        )

    def poll_request(self, request_id: str) -> dict:
        r = self.client.get(f"/api/v1/requests/{request_id}")
        r.raise_for_status()
        return r.json().get("data", r.json())

    def cancel_request(self, request_id: str) -> Optional[dict]:
        try:
            r = self.client.post(f"/api/v1/requests/{request_id}/cancel")
            r.raise_for_status()
            return r.json().get("data", r.json())
        except httpx.HTTPError:
            return None

    def waiter(self) -> AsyncOpWaiter:
        return AsyncOpWaiter(poll_fn=self.poll_request)
