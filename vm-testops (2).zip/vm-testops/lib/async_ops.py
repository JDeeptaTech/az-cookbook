"""
Async operation handling for day-2 ops.

Pattern: submit -> get OpHandle (request_id) -> waiter polls -> OpResult.
Every poll, every state transition, and the final payload is attached
to Allure for forensic debugging.
"""
from __future__ import annotations

import json
import time
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Any, Callable, List, Optional

import allure
import yaml

CONFIG_PATH = Path(__file__).parent.parent / "config" / "timeouts.yaml"
CONFIG = yaml.safe_load(CONFIG_PATH.read_text())


class TerminalState(str, Enum):
    SUCCESS = "SUCCESS"
    FAILED = "FAILED"
    CANCELLED = "CANCELLED"
    TIMEOUT = "TIMEOUT"


@dataclass
class OpHandle:
    """Returned by submit_day2; identifies an in-flight async op."""
    request_id: str
    operation: str            # e.g. "snapshot.create"
    vm_id: str
    correlation_id: str
    submitted_at: datetime
    metadata: dict = field(default_factory=dict)


@dataclass
class OpResult:
    """Result of waiting on an OpHandle to reach a terminal state."""
    handle: OpHandle
    terminal_state: TerminalState
    raw_final_state: str
    success: bool
    elapsed_seconds: float
    poll_count: int
    poll_history: List[dict]
    final_payload: dict
    error: Optional[str] = None

    def as_summary(self) -> dict:
        return {
            "request_id": self.handle.request_id,
            "correlation_id": self.handle.correlation_id,
            "operation": self.handle.operation,
            "vm_id": self.handle.vm_id,
            "terminal_state": self.terminal_state.value,
            "raw_final_state": self.raw_final_state,
            "success": self.success,
            "elapsed_seconds": round(self.elapsed_seconds, 2),
            "poll_count": self.poll_count,
            "error": self.error,
        }


class AsyncOpTimeout(Exception):
    """Op did not reach terminal state within budget."""


class AsyncOpFailure(AssertionError):
    """Op reached a non-success terminal state (FAILED/CANCELLED)."""
    def __init__(self, result: OpResult):
        self.result = result
        super().__init__(
            f"{result.handle.operation} did not succeed: "
            f"state={result.raw_final_state} error={result.error} "
            f"request_id={result.handle.request_id}"
        )


def _classify(raw_state: str) -> Optional[TerminalState]:
    """Map a raw API state string to a TerminalState, or None if in-progress."""
    s = (raw_state or "").upper()
    sm = CONFIG["state_map"]
    if s in [x.upper() for x in sm["success"]]:
        return TerminalState.SUCCESS
    if s in [x.upper() for x in sm["failed"]]:
        return TerminalState.FAILED
    if s in [x.upper() for x in sm["cancelled"]]:
        return TerminalState.CANCELLED
    if s in [x.upper() for x in sm["in_progress"]]:
        return None
    # Unknown state: treat as in-progress but it'll show in poll_history,
    # which is your hint to extend state_map.
    return None


def _resolve_timeout(operation: str, override: Optional[int]) -> int:
    if override is not None:
        return override
    return CONFIG["async_timeouts"].get(
        operation, CONFIG["defaults"]["default_timeout"]
    )


def _attach(name: str, payload: Any) -> None:
    allure.attach(
        json.dumps(payload, indent=2, default=str),
        name=name,
        attachment_type=allure.attachment_type.JSON,
    )


def _attach_result(result: OpResult) -> None:
    _attach(f"async-op-summary-{result.handle.request_id}", result.as_summary())
    _attach(f"poll-history-{result.handle.request_id}", result.poll_history)
    _attach(f"final-payload-{result.handle.request_id}", result.final_payload)


class AsyncOpWaiter:
    """
    Polls a request_id until it reaches a terminal state.

    `poll_fn(request_id) -> dict` must return latest status with at least
    a 'state' or 'status' field. Optional fields: 'progress', 'message',
    'error', 'error_message', 'result'.
    """

    def __init__(self, poll_fn: Callable[[str], dict]):
        self.poll_fn = poll_fn
        d = CONFIG["defaults"]
        self.initial_interval = d["poll_initial_interval"]
        self.max_interval = d["poll_max_interval"]
        self.backoff = d["poll_backoff_factor"]

    def wait(
        self,
        handle: OpHandle,
        timeout: Optional[int] = None,
        expect: TerminalState = TerminalState.SUCCESS,
    ) -> OpResult:
        budget = _resolve_timeout(handle.operation, timeout)
        start = time.monotonic()
        deadline = start + budget
        interval = self.initial_interval
        history: List[dict] = []
        last_payload: dict = {}
        poll_count = 0
        last_state = "UNKNOWN"

        step_title = (
            f"Poll request {handle.request_id} "
            f"({handle.operation}, timeout={budget}s)"
        )
        with allure.step(step_title):
            while True:
                if time.monotonic() > deadline:
                    elapsed = time.monotonic() - start
                    result = OpResult(
                        handle=handle,
                        terminal_state=TerminalState.TIMEOUT,
                        raw_final_state=last_state,
                        success=False,
                        elapsed_seconds=elapsed,
                        poll_count=max(poll_count - 1, 0),
                        poll_history=history,
                        final_payload=last_payload,
                        error=f"Timeout after {budget}s in state={last_state}",
                    )
                    _attach_result(result)
                    raise AsyncOpTimeout(result.error)

                poll_count += 1
                try:
                    last_payload = self.poll_fn(handle.request_id)
                except Exception as e:
                    history.append({
                        "ts": datetime.now(timezone.utc).isoformat(),
                        "poll": poll_count,
                        "error": f"poll_fn raised: {e!r}",
                    })
                    time.sleep(interval)
                    interval = min(interval * self.backoff, self.max_interval)
                    continue

                last_state = (
                    last_payload.get("state")
                    or last_payload.get("status")
                    or "UNKNOWN"
                )
                history.append({
                    "ts": datetime.now(timezone.utc).isoformat(),
                    "poll": poll_count,
                    "state": last_state,
                    "progress": last_payload.get("progress"),
                    "message": last_payload.get("message"),
                })

                terminal = _classify(last_state)
                if terminal is not None:
                    elapsed = time.monotonic() - start
                    result = OpResult(
                        handle=handle,
                        terminal_state=terminal,
                        raw_final_state=last_state,
                        success=(terminal == expect),
                        elapsed_seconds=elapsed,
                        poll_count=poll_count,
                        poll_history=history,
                        final_payload=last_payload,
                        error=last_payload.get("error")
                              or last_payload.get("error_message"),
                    )
                    _attach_result(result)
                    if not result.success:
                        raise AsyncOpFailure(result)
                    return result

                time.sleep(interval)
                interval = min(interval * self.backoff, self.max_interval)


def wait_all(
    waiter: AsyncOpWaiter,
    handles: List[OpHandle],
    expect: TerminalState = TerminalState.SUCCESS,
    max_workers: int = 8,
) -> List[OpResult]:
    """Wait for many handles in parallel. Aggregates failures."""
    from concurrent.futures import ThreadPoolExecutor, as_completed

    results: List[OpResult] = []
    errors: List[Exception] = []
    with ThreadPoolExecutor(max_workers=max_workers) as ex:
        futures = {ex.submit(waiter.wait, h, expect=expect): h for h in handles}
        for fut in as_completed(futures):
            try:
                results.append(fut.result())
            except (AsyncOpFailure, AsyncOpTimeout) as e:
                errors.append(e)
    if errors:
        raise AssertionError(
            f"{len(errors)}/{len(handles)} async ops failed: "
            + "; ".join(str(e) for e in errors)
        )
    return results


def new_correlation_id() -> str:
    return str(uuid.uuid4())
