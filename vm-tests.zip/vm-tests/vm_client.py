"""
Client for the VM platform API.

How it works:
  - Every operation is one short method (start, stop, add_disk, ...).
  - Operations on the API are asynchronous: the API replies with an
    "invocationId" and the real work happens in the background.
  - So every method here sends the request AND waits for it to finish.
    When a method returns, the operation is really done.
  - If the operation fails, the method raises an error and the test fails.

Reading order: look at _send_and_wait() first. Every public method below
it is a one-liner that calls it with a different URL.
"""

import json
import os
import time

import allure
import requests

import config


class OperationFailed(Exception):
    """The API reported that the operation failed."""


class OperationTimedOut(Exception):
    """The operation did not finish in time."""


class VMClient:

    def __init__(self, base_url=None, token=None):
        self.base_url = (base_url or os.environ["VM_API_URL"]).rstrip("/")
        self.token = token or os.environ["VM_API_TOKEN"]
        self.session = requests.Session()
        self.session.headers.update({
            "Authorization": f"Bearer {self.token}",
            "Accept": "application/json",
        })
        # Set VM_API_VERIFY_SSL=false for test environments with self-signed certs.
        self.session.verify = os.environ.get("VM_API_VERIFY_SSL", "true") != "false"

    # ------------------------------------------------------------------
    # The two helpers everything else uses
    # ------------------------------------------------------------------

    def _send_and_wait(self, name, path, body=None, timeout=None):
        """
        Send a POST request, then wait until the operation finishes.

        Returns the final response from the API.
        Raises OperationFailed or OperationTimedOut if it doesn't succeed.
        """
        timeout = timeout or config.DEFAULT_TIMEOUT

        with allure.step(name):
            # 1. Send the request
            url = self.base_url + path
            response = self.session.post(url, json=body, timeout=60)
            _attach("request", {"url": url, "body": body})
            response.raise_for_status()
            result = response.json()
            _attach("response", result)

            # 2. Find the invocation id so we know what to wait for.
            #    Some operations finish immediately and don't return one.
            invocation_id = result.get("invocationId") or result.get("id")
            if not invocation_id:
                return result

            # 3. Wait for it to finish
            return self._wait_for(invocation_id, timeout)

    def _wait_for(self, invocation_id, timeout):
        """Ask the API every few seconds whether the operation is done yet."""
        deadline = time.time() + timeout
        history = []

        while time.time() < deadline:
            url = f"{self.base_url}/requests/{invocation_id}"
            status = self.session.get(url, timeout=60).json()
            state = str(status.get("status") or status.get("state") or "UNKNOWN")
            history.append({"time": time.strftime("%H:%M:%S"), "state": state})

            if state.upper() in config.SUCCESS_STATES:
                _attach("progress", history)
                return status

            if state.upper() in config.FAILED_STATES:
                _attach("progress", history)
                _attach("failure details", status)
                raise OperationFailed(
                    f"Operation {invocation_id} failed with state '{state}'. "
                    f"Details: {status.get('error') or status}"
                )

            # Any other state means "still working" - wait and check again.
            time.sleep(config.POLL_SECONDS)

        _attach("progress", history)
        raise OperationTimedOut(
            f"Operation {invocation_id} did not finish within {timeout} seconds. "
            f"Last state was '{history[-1]['state'] if history else 'unknown'}'."
        )

    # ------------------------------------------------------------------
    # Build a VM
    # ------------------------------------------------------------------

    def build_vm(self, vm_name, os_info):
        """Build a new VM. os_info comes from config.OS_VERSIONS."""
        return self._send_and_wait(
            name=f"Build VM '{vm_name}' ({os_info['id']})",
            path=os_info["build_path"],
            body={"name": vm_name, "image": os_info["image"]},
            timeout=config.BUILD_TIMEOUT,
        )

    def delete_vm(self, vm_name):
        """Decommission a VM."""
        return self._send_and_wait(
            name=f"Delete VM '{vm_name}'",
            path=f"/virtualmachines/{vm_name}/lifecycle/demise",
            timeout=config.BUILD_TIMEOUT,
        )

    # ------------------------------------------------------------------
    # Day-2 operations - power
    # ------------------------------------------------------------------

    def start(self, vm_name):
        return self._send_and_wait(
            f"Start '{vm_name}'", f"/virtualmachines/{vm_name}/power/start")

    def stop(self, vm_name):
        return self._send_and_wait(
            f"Stop '{vm_name}'", f"/virtualmachines/{vm_name}/power/stop")

    def restart(self, vm_name):
        return self._send_and_wait(
            f"Restart '{vm_name}'", f"/virtualmachines/{vm_name}/power/restart")

    # ------------------------------------------------------------------
    # Day-2 operations - disks
    # ------------------------------------------------------------------

    def add_disk(self, vm_name, disk_name, size_gb):
        return self._send_and_wait(
            f"Add {size_gb}GB disk '{disk_name}' to '{vm_name}'",
            f"/virtualmachines/{vm_name}/disks/add",
            body={"name": disk_name, "size_gb": size_gb},
        )

    def detach_disk(self, vm_name, disk_name):
        return self._send_and_wait(
            f"Detach disk '{disk_name}' from '{vm_name}'",
            f"/virtualmachines/{vm_name}/disks/detach",
            body={"name": disk_name},
        )

    # ------------------------------------------------------------------
    # Day-2 operations - network cards
    # ------------------------------------------------------------------

    def attach_nic(self, vm_name, nic_name, network):
        return self._send_and_wait(
            f"Attach NIC '{nic_name}' to '{vm_name}'",
            f"/virtualmachines/{vm_name}/nics/attach",
            body={"name": nic_name, "network": network},
        )

    def detach_nic(self, vm_name, nic_name):
        return self._send_and_wait(
            f"Detach NIC '{nic_name}' from '{vm_name}'",
            f"/virtualmachines/{vm_name}/nics/detach",
            body={"name": nic_name},
        )

    # ------------------------------------------------------------------
    # Day-2 operations - snapshots
    # ------------------------------------------------------------------

    def create_snapshot(self, vm_name, snapshot_name):
        return self._send_and_wait(
            f"Create snapshot '{snapshot_name}' of '{vm_name}'",
            f"/virtualmachines/{vm_name}/snapshots/create",
            body={"name": snapshot_name},
            timeout=config.SNAPSHOT_TIMEOUT,
        )

    def revert_snapshot(self, vm_name, snapshot_name):
        return self._send_and_wait(
            f"Revert '{vm_name}' to snapshot '{snapshot_name}'",
            f"/virtualmachines/{vm_name}/snapshots/revert",
            body={"snapshot_name": snapshot_name},
            timeout=config.SNAPSHOT_TIMEOUT,
        )

    def delete_snapshot(self, vm_name, snapshot_name):
        return self._send_and_wait(
            f"Delete snapshot '{snapshot_name}' of '{vm_name}'",
            f"/virtualmachines/{vm_name}/snapshots/delete",
            body={"snapshot_name": snapshot_name},
        )

    # ------------------------------------------------------------------
    # Day-2 operations - CPU and memory
    # ------------------------------------------------------------------

    def resize(self, vm_name, cpu=None, memory_mb=None):
        """Change CPU count, memory, or both. Leave one out to keep it as-is."""
        body = {}
        if cpu is not None:
            body["cpu"] = cpu
        if memory_mb is not None:
            body["memory_mb"] = memory_mb

        return self._send_and_wait(
            f"Resize '{vm_name}' to {body}",
            f"/virtualmachines/{vm_name}/compute/resize",
            body=body,
        )

    # ------------------------------------------------------------------
    # Read-only: fetch VM details
    # ------------------------------------------------------------------

    def get_vm(self, vm_name):
        """Get the current details of a VM (status, cpu, memory, disks...)."""
        with allure.step(f"Get details of '{vm_name}'"):
            url = f"{self.base_url}/virtualmachines/{vm_name}"
            response = self.session.get(url, timeout=60)
            response.raise_for_status()
            details = response.json()
            _attach("vm details", details)
            return details


def _attach(title, data):
    """Put some data into the Allure report so we can see it after the run."""
    allure.attach(
        json.dumps(data, indent=2, default=str),
        name=title,
        attachment_type=allure.attachment_type.JSON,
    )
