# VM Tests

Automated tests for the VM platform. Builds a VM, runs day-2 operations
on it, and produces an Allure report.

## The whole project in one minute

```
vm-tests/
├── config.py          <- settings: OS list, timeouts
├── vm_client.py       <- talks to the API (one method per operation)
├── conftest.py        <- gives each test a `client` and a `vm`
├── tests/
│   ├── test_01_build.py     <- VM was built and is running
│   ├── test_02_power.py     <- stop / start / restart
│   ├── test_03_disk.py      <- add / detach a disk
│   ├── test_04_nic.py       <- attach / detach a network card
│   ├── test_05_snapshot.py  <- create / revert / delete a snapshot
│   └── test_06_compute.py   <- change CPU and memory
└── Jenkinsfile        <- runs all of the above in Jenkins
```

Only three files aren't tests. Read them in this order:
`config.py` → `vm_client.py` → `conftest.py`. That's about 15 minutes.

## Setup

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt

export VM_API_URL=https://your-api-host/cto-pa-hic-vm/api/v3
export VM_API_TOKEN=your-token-here
```

## Running tests

```bash
# Build a VM, run every test, delete the VM at the end
pytest

# Build a Windows VM instead
pytest --os=win2022

# Only the power tests
pytest -m power

# Only disk and snapshot tests
pytest -m "disk or snapshot"

# Test a VM that already exists (nothing is built, nothing is deleted)
pytest --vm=my-existing-vm

# Only snapshot tests, against an existing VM
pytest --vm=my-existing-vm -m snapshot

# Keep the VM after the run so you can look at it
pytest --keep-vm
```

## Seeing the results

```bash
allure serve allure-results
```

Every API call is recorded in the report: the URL, the request body, the
response, and how long the operation took to finish.

## How it works

### Where the VM comes from

Every test asks for a fixture called `vm`, which is just the VM's name.
`conftest.py` decides where that name comes from:

1. You passed `--vm=some-name` → uses that VM, never deletes it.
2. `vm_state.json` exists from an earlier run → reuses that VM.
3. Otherwise → builds a new VM, and deletes it when the tests finish.

All the tests in one run share the same VM. That's what
`scope="session"` means on the fixture.

### Why the tests don't have any waiting code

The API is asynchronous. When you ask it to stop a VM, it replies
immediately with an `invocationId` and does the work in the background.

`vm_client.py` handles all of that for you. Every method sends the
request, then polls `/requests/{invocationId}` every 5 seconds until
the API says it finished. So when `client.stop(vm)` returns, the VM is
really stopped.

If the operation fails or takes too long, the method raises an error
and your test fails with a message explaining what happened:

```
OperationFailed: Operation abc123 failed with state 'FAILED'.
Details: storage pool out of capacity
```

### What a test looks like

```python
@pytest.mark.day2
@pytest.mark.disk
def test_add_disk(client, vm):
    client.add_disk(vm, "test-disk", 20)          # do the thing

    details = client.get_vm(vm)                   # check it worked
    disk_names = [d["name"] for d in details["disks"]]
    assert "test-disk" in disk_names
```

That's the whole pattern: call one method, fetch the VM, assert.

## Making changes

### Add a new OS

Add an entry to `OS_VERSIONS` in `config.py`:

```python
{
    "id": "rhel10",
    "image": "rhel-10.0-x86_64",
    "build_path": "/builds/smartlinux",
},
```

Then `pytest --os=rhel10` works. Nothing else to change.

### Add a new operation

Add one method to `vm_client.py`:

```python
def migrate(self, vm_name):
    return self._send_and_wait(
        f"Migrate '{vm_name}'",
        f"/virtualmachines/{vm_name}/migrations/live",
        timeout=1800,
    )
```

Then write a test that calls it. Copy any existing test file as a
starting point.

### Change a timeout

All timeouts are at the top of `config.py`.

## Jenkins

| Parameter | What it does |
|---|---|
| `VM_NAME` | Leave empty to build new VMs. Fill it in to test one existing VM. |
| `OS_LIST` | Which OSes to build, comma separated. **Each one runs in parallel.** Ignored when `VM_NAME` is set. |
| `TESTS` | `all`, or groups separated by commas: `power,disk` |
| `KEEP_VM` | Keep the VMs after the run, for debugging |

### Mode 1: build several OSes at the same time

Leave `VM_NAME` empty and list the OSes you want:

```
OS_LIST = rhel8,rhel9,win2022
TESTS   = all
```

Jenkins starts one branch per OS, all at once. Each branch builds its own
VM, runs the tests, and deletes its VM at the end. Three OSes take about
as long as one.

In Blue Ocean you get one column per OS, so you can see at a glance that
(say) win2022 failed while the others passed. One OS failing does not
cancel the others — that is `failFast: false` in the Jenkinsfile.

### Mode 2: some operations on a VM you already have

Fill in `VM_NAME`:

```
VM_NAME = prod-canary-01
TESTS   = power,disk
```

Nothing is built, nothing is deleted. `TESTS = power,disk` becomes
`pytest -m "power or disk"`.

These run one after another on purpose, **not** in parallel. They all act
on the same VM, and you cannot stop a VM and resize it at the same moment.

### Why parallelism lives in Jenkins, not in pytest

We do not use `pytest-xdist`. Jenkins' own `parallel` step does the job
and is much easier to follow: one branch per OS, one log per branch,
separate results that get merged into a single Allure report at the end.

Two things make the branches safe to run side by side:

- **`VM_STATE_FILE`** — each branch gets its own (`vm_state-rhel8.json`,
  `vm_state-win2022.json`). Without this, one branch would overwrite
  another's VM name and could delete the wrong VM at cleanup.
- **`--alluredir`** — each branch writes to its own folder
  (`allure-results-rhel8`, ...) because `--clean-alluredir` empties the
  folder at startup, and a shared folder would mean the last branch to
  start wipes the others' results. The `Publish report` stage copies them
  all into one folder afterwards.

### Setup

Two Jenkins credentials of type *Secret text*: `vm-api-url` and
`vm-api-token`. Plus the Allure Jenkins plugin.

Failing tests make the build **UNSTABLE** (yellow), not failed (red).
Red means the pipeline itself broke — checkout failed, pip failed, etc.

### Running several OSes locally

The same thing without Jenkins:

```bash
VM_STATE_FILE=vm_state-rhel8.json \
  pytest --os=rhel8 --alluredir=allure-results-rhel8 &

VM_STATE_FILE=vm_state-win2022.json \
  pytest --os=win2022 --alluredir=allure-results-win2022 &

wait
allure serve allure-results-rhel8 allure-results-win2022
```

## Troubleshooting

**Every test is skipped or errors with a connection problem**
Check `VM_API_URL` and `VM_API_TOKEN` are exported in your shell.

**Tests fail with a certificate error**
For test environments with self-signed certificates:
`export VM_API_VERIFY_SSL=false`

**The run reuses an old VM that no longer exists**
Delete `vm_state.json` and run again.

**Two runs at once deleted each other's VM**
Each concurrent run needs its own state file:
`VM_STATE_FILE=vm_state-rhel8.json pytest --os=rhel8`
The Jenkinsfile does this for you.

**An operation times out**
The default is 5 minutes (30 for builds). If your environment is slower,
raise the value in `config.py`. The Allure report shows every status the
API reported while waiting, which usually tells you where it got stuck.
