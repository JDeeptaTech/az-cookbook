<!--
Maintainer note: this file is loaded into Claude Code at the start of every
session. Keep it under ~200 lines. HTML comments like this one are stripped
before Claude sees it, so they cost nothing.
-->

# VM Tests

Pytest + Allure test suite for the VM platform API. Builds a VM, runs day-2
operations against it, reports results in Allure.

## Commands

```bash
# Setup
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
export VM_API_URL=https://host/cto-pa-hic-vm/api/v3
export VM_API_TOKEN=...

# Run everything (builds a VM, tests it, deletes it)
pytest

# One OS
pytest --os=win2022

# One group of tests
pytest -m power
pytest -m "power or disk"

# Against a VM that already exists (builds nothing, deletes nothing)
pytest --vm=my-vm-name

# Keep the VM afterwards for debugging
pytest --keep-vm

# View the report
allure serve allure-results
```

## Layout

| File | What it is |
|---|---|
| `config.py` | OS list, timeouts, state file name |
| `vm_client.py` | All API calls. One short method per operation |
| `conftest.py` | The `client` and `vm` fixtures |
| `tests/test_0N_*.py` | One file per operation group |
| `Jenkinsfile` | CI: parallel OS builds, or day-2 on one named VM |

## Audience: keep it simple

The people maintaining this are junior engineers. Simplicity beats
cleverness every time. When there are two ways to do something, pick the
one that reads more plainly, even if it is longer.

This suite was deliberately simplified from a much larger version. **Do not
reintroduce** any of the following without being asked:

- `pytest-xdist` or any in-pytest parallelism (Jenkins does the parallelism)
- OpenShift / KubeVirt / `kubernetes` client checks
- A config-driven endpoint registry with `${...}` template substitution
- Extra abstraction layers, base classes, or metaclasses
- Extra dependencies. The three in `requirements.txt` are the whole list

If a change would add a new concept someone has to learn before they can
read a test, say so before writing it.

## Conventions

**Tests follow one shape.** Call one client method, fetch the VM, assert:

```python
@pytest.mark.day2
@pytest.mark.disk
def test_add_disk(client, vm):
    client.add_disk(vm, "test-disk", 20)

    details = client.get_vm(vm)
    disk_names = [d["name"] for d in details["disks"]]
    assert "test-disk" in disk_names, (
        f"Expected to find disk 'test-disk', but the VM has: {disk_names}"
    )
```

**Assertion messages state expected vs actual.** Someone reading a CI
failure should not need to open the code. Never leave a bare `assert x`.

**Client methods block until the operation finishes.** `_send_and_wait()`
sends the request, then polls `/requests/{invocationId}` until the API
reports success. Tests contain no waiting, polling, or retry code — if you
find yourself adding a `sleep` to a test, fix the client instead.

**New operations go in `vm_client.py` as one method**, following the
existing pattern, then get a test. Do not call `requests` from a test file.

**New OS versions are one entry in `config.OS_VERSIONS`.** Nothing else
changes.

**Timeouts live in `config.py`.** No timeout numbers inside test files.

## Things that will bite you

**Never run day-2 operations against the same VM in parallel.** They
conflict — you cannot stop a VM and resize it at the same moment. Parallel
execution is per-OS only, one VM per branch.

**Concurrent runs each need their own state file and Allure directory:**

```bash
VM_STATE_FILE=vm_state-rhel8.json pytest --os=rhel8 --alluredir=allure-results-rhel8
```

Without `VM_STATE_FILE`, both runs write `vm_state.json` and one deletes the
other's VM at cleanup. Without a separate `--alluredir`, `--clean-alluredir`
wipes the other run's results. The Jenkinsfile handles both; anything new
that runs tests concurrently must do the same.

**`--vm` mode must never delete the VM.** It may be a production canary.
The `vm` fixture returns early before the cleanup code for this reason —
don't restructure that without preserving the behaviour.

**Never commit credentials.** `VM_API_URL` and `VM_API_TOKEN` come from the
environment locally and from Jenkins credentials in CI. No tokens, hostnames,
or real VM names in the repo.

**`vm_state.json` is generated**, not source. It is gitignored. If a run
reuses a VM that no longer exists, delete the file.

## Testing your changes

There is no mock server in the repo. To check changes without hitting the
real API, write a throwaway `http.server` stub that returns
`{"invocationId": "..."}` for POSTs and `{"status": "SUCCESS"}` for
`/requests/<id>`, point `VM_API_URL` at it, and run the suite. Delete the
stub afterwards; don't commit it.

Before saying a change works, actually run `pytest --collect-only` at
minimum. Don't claim a test passes without running it.
