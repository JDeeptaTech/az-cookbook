"""Check that a VM can be built and is running."""

import allure
import pytest


@pytest.mark.build
@allure.feature("Build")
def test_vm_is_running(client, vm):
    """After building, the VM should exist and be running."""
    details = client.get_vm(vm)

    assert details["status"] == "Running", (
        f"Expected the VM to be Running, but it is '{details['status']}'"
    )


@pytest.mark.build
@allure.feature("Build")
def test_vm_has_correct_name(client, vm):
    """The VM we got back should be the one we asked for."""
    details = client.get_vm(vm)

    assert details["name"] == vm, (
        f"Expected VM name '{vm}', but the API returned '{details['name']}'"
    )
