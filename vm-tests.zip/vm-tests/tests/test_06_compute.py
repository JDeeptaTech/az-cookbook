"""CPU and memory resize."""

import allure
import pytest

NEW_CPU = 4
NEW_MEMORY_MB = 8192


@pytest.mark.day2
@pytest.mark.compute
@allure.feature("Compute")
def test_resize_cpu(client, vm):
    """Changing only the CPU count should update the CPU count."""
    client.resize(vm, cpu=NEW_CPU)

    details = client.get_vm(vm)
    assert details["cpu"] == NEW_CPU, (
        f"Expected {NEW_CPU} CPUs after the resize, but the VM has {details['cpu']}"
    )


@pytest.mark.day2
@pytest.mark.compute
@allure.feature("Compute")
def test_resize_memory(client, vm):
    """Changing only the memory should update the memory."""
    client.resize(vm, memory_mb=NEW_MEMORY_MB)

    details = client.get_vm(vm)
    assert details["memory_mb"] == NEW_MEMORY_MB, (
        f"Expected {NEW_MEMORY_MB}MB of memory after the resize, "
        f"but the VM has {details['memory_mb']}MB"
    )


@pytest.mark.day2
@pytest.mark.compute
@allure.feature("Compute")
def test_resize_cpu_and_memory(client, vm):
    """Changing both at once should update both."""
    client.resize(vm, cpu=8, memory_mb=16384)

    details = client.get_vm(vm)
    assert details["cpu"] == 8, f"Expected 8 CPUs, got {details['cpu']}"
    assert details["memory_mb"] == 16384, (
        f"Expected 16384MB of memory, got {details['memory_mb']}MB"
    )
