"""Network card operations: attach and detach."""

import allure
import pytest

NIC_NAME = "eth1"
NETWORK = "secondary-net"


@pytest.mark.day2
@pytest.mark.nic
@allure.feature("Network")
def test_attach_nic(client, vm):
    """A newly attached NIC should show up in the VM's NIC list."""
    client.attach_nic(vm, NIC_NAME, NETWORK)

    details = client.get_vm(vm)
    nic_names = [nic["name"] for nic in details.get("nics", [])]

    assert NIC_NAME in nic_names, (
        f"Expected to find NIC '{NIC_NAME}' after attaching it, "
        f"but the VM only has: {nic_names}"
    )


@pytest.mark.day2
@pytest.mark.nic
@allure.feature("Network")
def test_detach_nic(client, vm):
    """A detached NIC should no longer be in the VM's NIC list."""
    client.detach_nic(vm, NIC_NAME)

    details = client.get_vm(vm)
    nic_names = [nic["name"] for nic in details.get("nics", [])]

    assert NIC_NAME not in nic_names, (
        f"Expected NIC '{NIC_NAME}' to be gone after detaching it, "
        f"but the VM still has: {nic_names}"
    )
