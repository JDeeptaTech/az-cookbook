"""Snapshot operations: create, revert, delete."""

import allure
import pytest

SNAPSHOT_NAME = "test-snapshot"


@pytest.mark.day2
@pytest.mark.snapshot
@allure.feature("Snapshots")
def test_create_snapshot(client, vm):
    """A newly created snapshot should show up in the VM's snapshot list."""
    client.create_snapshot(vm, SNAPSHOT_NAME)

    details = client.get_vm(vm)
    snapshot_names = [s["name"] for s in details.get("snapshots", [])]

    assert SNAPSHOT_NAME in snapshot_names, (
        f"Expected to find snapshot '{SNAPSHOT_NAME}' after creating it, "
        f"but the VM only has: {snapshot_names}"
    )


@pytest.mark.day2
@pytest.mark.snapshot
@allure.feature("Snapshots")
def test_revert_snapshot(client, vm):
    """Reverting to a snapshot should finish successfully."""
    client.revert_snapshot(vm, SNAPSHOT_NAME)

    # After a revert the VM should still be usable.
    details = client.get_vm(vm)
    assert details["status"] in ("Running", "Stopped"), (
        f"VM is in an unexpected state after revert: '{details['status']}'"
    )


@pytest.mark.day2
@pytest.mark.snapshot
@allure.feature("Snapshots")
def test_delete_snapshot(client, vm):
    """A deleted snapshot should no longer be in the VM's snapshot list."""
    client.delete_snapshot(vm, SNAPSHOT_NAME)

    details = client.get_vm(vm)
    snapshot_names = [s["name"] for s in details.get("snapshots", [])]

    assert SNAPSHOT_NAME not in snapshot_names, (
        f"Expected snapshot '{SNAPSHOT_NAME}' to be gone after deleting it, "
        f"but the VM still has: {snapshot_names}"
    )
