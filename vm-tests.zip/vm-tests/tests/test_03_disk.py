"""Disk operations: add and detach."""

import allure
import pytest

DISK_NAME = "test-disk"
DISK_SIZE_GB = 20


@pytest.mark.day2
@pytest.mark.disk
@allure.feature("Disks")
def test_add_disk(client, vm):
    """A newly added disk should show up in the VM's disk list."""
    client.add_disk(vm, DISK_NAME, DISK_SIZE_GB)

    details = client.get_vm(vm)
    disk_names = [disk["name"] for disk in details.get("disks", [])]

    assert DISK_NAME in disk_names, (
        f"Expected to find disk '{DISK_NAME}' after adding it, "
        f"but the VM only has: {disk_names}"
    )


@pytest.mark.day2
@pytest.mark.disk
@allure.feature("Disks")
def test_detach_disk(client, vm):
    """A detached disk should no longer be in the VM's disk list."""
    client.detach_disk(vm, DISK_NAME)

    details = client.get_vm(vm)
    disk_names = [disk["name"] for disk in details.get("disks", [])]

    assert DISK_NAME not in disk_names, (
        f"Expected disk '{DISK_NAME}' to be gone after detaching it, "
        f"but the VM still has: {disk_names}"
    )
