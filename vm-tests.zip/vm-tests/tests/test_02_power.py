"""Power operations: stop, start, restart."""

import allure
import pytest


@pytest.mark.day2
@pytest.mark.power
@allure.feature("Power")
def test_stop(client, vm):
    """Stopping a running VM should leave it stopped."""
    client.stop(vm)

    details = client.get_vm(vm)
    assert details["status"] == "Stopped", (
        f"Expected the VM to be Stopped, but it is '{details['status']}'"
    )


@pytest.mark.day2
@pytest.mark.power
@allure.feature("Power")
def test_start(client, vm):
    """Starting a stopped VM should leave it running."""
    client.start(vm)

    details = client.get_vm(vm)
    assert details["status"] == "Running", (
        f"Expected the VM to be Running, but it is '{details['status']}'"
    )


@pytest.mark.day2
@pytest.mark.power
@allure.feature("Power")
def test_restart(client, vm):
    """Restarting a running VM should leave it running."""
    client.restart(vm)

    details = client.get_vm(vm)
    assert details["status"] == "Running", (
        f"Expected the VM to be Running, but it is '{details['status']}'"
    )
