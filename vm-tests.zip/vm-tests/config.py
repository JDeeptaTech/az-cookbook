"""
All the settings for the test suite live here.

To add a new OS version, add one entry to OS_VERSIONS below.
Nothing else needs to change.
"""

# Each OS we can build. "build_path" is the API endpoint used to build it.
OS_VERSIONS = [
    {
        "id": "rhel8",
        "image": "rhel-8.10-x86_64",
        "build_path": "/builds/smartlinux",
    },
    {
        "id": "rhel9",
        "image": "rhel-9.4-x86_64",
        "build_path": "/builds/smartlinux",
    },
    {
        "id": "rhel7",
        "image": "rhel-7.9-x86_64",
        "build_path": "/builds/linux",
    },
    {
        "id": "win2019",
        "image": "win-2019-std",
        "build_path": "/builds/windows",
    },
    {
        "id": "win2022",
        "image": "win-2022-std",
        "build_path": "/builds/smartwindows",
    },
]

# How long (in seconds) we wait for each kind of operation to finish.
BUILD_TIMEOUT = 1800      # building a VM (Windows can be slow)
DEFAULT_TIMEOUT = 300     # most day-2 operations
SNAPSHOT_TIMEOUT = 900    # snapshots take longer

# How often we check whether an operation has finished.
POLL_SECONDS = 5

# Where we remember the VM we built, so a later run can reuse it.
STATE_FILE = "vm_state.json"

# Words the API uses to say an operation finished.
SUCCESS_STATES = ["SUCCESS", "SUCCEEDED", "COMPLETED", "OK", "DONE"]
FAILED_STATES = ["FAILED", "ERROR", "FAILURE", "CANCELLED"]


def find_os(os_id):
    """Look up one OS entry by its id. Raises if the id is unknown."""
    for os_info in OS_VERSIONS:
        if os_info["id"] == os_id:
            return os_info
    valid = [o["id"] for o in OS_VERSIONS]
    raise ValueError(f"Unknown OS '{os_id}'. Valid options: {valid}")
