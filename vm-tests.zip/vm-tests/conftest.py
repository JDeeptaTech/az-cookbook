"""
Shared test setup.

There are only two things to understand here:

  1. The `client` fixture - gives every test a VMClient to call the API with.
  2. The `vm` fixture     - gives every test the name of a VM to work on.

The `vm` fixture decides where that VM comes from:
  - you passed --vm=some-name        -> use that VM, never delete it
  - a VM from an earlier run exists  -> reuse it
  - otherwise                        -> build a new one, delete it at the end
"""

import json
import os
import time
from pathlib import Path

import pytest

import config
from vm_client import VMClient


# ----------------------------------------------------------------------
# Command line options
# ----------------------------------------------------------------------

def pytest_addoption(parser):
    parser.addoption(
        "--vm",
        default="",
        help="Name of an existing VM to test against. "
             "If set, no VM is built and the VM is never deleted.",
    )
    parser.addoption(
        "--os",
        default="rhel8",
        help=f"Which OS to build. One of: "
             f"{[o['id'] for o in config.OS_VERSIONS]}",
    )
    parser.addoption(
        "--keep-vm",
        action="store_true",
        help="Don't delete the VM at the end of the run (useful for debugging).",
    )


# ----------------------------------------------------------------------
# Fixtures
# ----------------------------------------------------------------------

@pytest.fixture(scope="session")
def client():
    """The API client. Shared by every test."""
    return VMClient()


@pytest.fixture(scope="session")
def vm(request, client):
    """
    The name of the VM to run tests against.

    Runs once per test session, not once per test - so all the tests
    share the same VM instead of each building their own.
    """
    given_vm = request.config.getoption("--vm")
    keep = request.config.getoption("--keep-vm")

    # Case 1: the user told us which VM to use.
    if given_vm:
        print(f"\nUsing existing VM: {given_vm} (it will NOT be deleted)")
        yield given_vm
        return

    # Case 2: a previous run left us a VM we can reuse.
    saved = _load_saved_vm()
    if saved:
        print(f"\nReusing VM from a previous run: {saved}")
        yield saved
        return

    # Case 3: build a new one.
    os_id = request.config.getoption("--os")
    os_info = config.find_os(os_id)
    vm_name = f"test-{os_id}-{int(time.time())}"

    print(f"\nBuilding a new VM: {vm_name} ({os_id})")
    client.build_vm(vm_name, os_info)
    _save_vm(vm_name)

    yield vm_name

    # Clean up after all the tests have run.
    if keep:
        print(f"\nLeaving VM {vm_name} in place (--keep-vm was used)")
        return
    print(f"\nDeleting VM {vm_name}")
    try:
        client.delete_vm(vm_name)
        _forget_vm()
    except Exception as error:
        print(f"Could not delete {vm_name}: {error}")


@pytest.fixture(scope="session")
def os_info(request):
    """Details of the OS we are testing (image name, build endpoint...)."""
    return config.find_os(request.config.getoption("--os"))


# ----------------------------------------------------------------------
# Remembering the VM between runs
# ----------------------------------------------------------------------

def _load_saved_vm():
    path = Path(config.STATE_FILE)
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text())["vm_name"]
    except (json.JSONDecodeError, KeyError):
        return None


def _save_vm(vm_name):
    Path(config.STATE_FILE).write_text(json.dumps({"vm_name": vm_name}, indent=2))


def _forget_vm():
    path = Path(config.STATE_FILE)
    if path.exists():
        path.unlink()
