"""End-to-end agent test in mock mode - the 'start testing the agent' suite."""
import json, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from workflow.state import AgentState
from workflow import graph
from tools.mock.skyline import MockSkyline
from tools.mock.ansible import MockAnsible
from tools.mock.nexus import MockNexus
from tools.mock.gitops import MockGitops

ROOT = Path(__file__).resolve().parents[1]


class Ctx:
    def __init__(self, scenario, approved):
        self.scenario, self.approved = scenario, approved
        self.skyline = MockSkyline(scenario)
        self.ansible = MockAnsible(scenario)
        self.nexus = MockNexus(scenario, self.ansible)
        self.gitops = MockGitops(scenario)


def _load(name):
    return json.loads((ROOT / "scenarios" / name).read_text())


def test_interrupts_at_approval_when_delta_nonempty():
    state, interrupted = graph.run(AgentState(), Ctx(_load("missing_releases.json"), False))
    assert interrupted and state.result is None
    assert state.plan.releases_to_mirror == ["4.18.49"]


def test_full_run_executes_and_verifies_after_approval():
    state, interrupted = graph.run(AgentState(), Ctx(_load("missing_releases.json"), True))
    assert not interrupted
    assert state.result.mirrored == ["4.18.49"]
    assert state.result.verification_passed is True


def test_gitops_wiring_gap_is_flagged():
    # scenario IDMS only covers a16/a17 -> newly mirrored a49 is unwired
    state, _ = graph.run(AgentState(), Ctx(_load("missing_releases.json"), True))
    assert state.result.gitops_wired is False
    assert any("not referenced by any IDMS" in l for l in state.log)


def test_no_op_never_asks_approval_or_executes():
    state, interrupted = graph.run(AgentState(), Ctx(_load("no_op.json"), False))
    assert not interrupted and state.plan.no_op and state.result is None


def test_aap_failure_fails_verification():
    s = _load("missing_releases.json"); s["inject"] = {"aap_failure": True}
    state, _ = graph.run(AgentState(), Ctx(s, True))
    assert state.result.verification_passed is False
