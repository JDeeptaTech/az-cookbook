import json, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from tools.gitops import GitopsExtractor
from tools.skyline_api import SkylinePush

FIX = Path(__file__).parent / "fixtures" / "cluster-config"


def test_gitops_extractor_parses_idms_and_catalogs():
    st = GitopsExtractor(FIX).get_cluster_config()
    assert "sha256:a16aaa" in st.idms_digests
    assert "redhat-operator-index" in st.catalog_sources
    assert st.collected_at and st.source  # provenance mandatory


def test_gitops_state_is_valid_json_contract():
    payload = json.loads(GitopsExtractor(FIX).get_cluster_config().to_json())
    for key in ("source", "commit", "idms_digests", "catalog_sources", "collected_at"):
        assert key in payload


def test_skyline_push_file_sink(tmp_path):
    push = SkylinePush(sink=f"file://{tmp_path}")
    st = GitopsExtractor(FIX).get_cluster_config()
    sid = push.push("gitops", st.to_json())
    assert (tmp_path / f"{sid}.json").exists()
