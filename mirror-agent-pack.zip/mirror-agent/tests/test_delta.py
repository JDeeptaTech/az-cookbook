import json, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from tools.mock.skyline import MockSkyline
from rules.delta import compute_mirror_delta

ROOT = Path(__file__).resolve().parents[1]


def _evidence(name):
    s = json.loads((ROOT / "scenarios" / name).read_text())
    sky = MockSkyline(s)
    cluster = sky.get_cluster_state()
    return s, {
        "channel": s["trigger"]["channel"],
        "cluster_version": cluster["version"],
        "upgrade_path": sky.get_upgrade_path(cluster["version"],
                                             s["trigger"]["target_version"]),
        "nexus_digests": sky.get_nexus_inventory(),
    }


def test_missing_releases():
    s, ev = _evidence("missing_releases.json")
    p = compute_mirror_delta(ev)
    assert p.releases_to_mirror == s["expected"]["releases_to_mirror"]
    assert p.no_op is False and p.confidence == 1.0 and p.requires_approval


def test_shortest_path_is_used():
    _, ev = _evidence("missing_releases.json")
    p = compute_mirror_delta(ev)
    # direct edge 4.17.21 -> 4.18.49 exists, so 4.18.44 must NOT be mirrored
    assert "4.18.44" not in p.releases_to_mirror


def test_no_op():
    _, ev = _evidence("no_op.json")
    p = compute_mirror_delta(ev)
    assert p.no_op is True and p.releases_to_mirror == [] and not p.requires_approval


def test_unreachable_escalates():
    _, ev = _evidence("unreachable_target.json")
    assert compute_mirror_delta(ev) is None
