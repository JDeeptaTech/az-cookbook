"""LangGraph workflow tests - interrupt/resume on a real checkpointer."""
import json, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from langgraph.checkpoint.memory import MemorySaver
from langgraph.types import Command

from workflow.lg_graph import build_graph
from tools.mock.skyline import MockSkyline
from tools.mock.ansible import MockAnsible
from tools.mock.nexus import MockNexus
from tools.mock.gitops import MockGitops

ROOT = Path(__file__).resolve().parents[1]


class Ctx:
    def __init__(self, scenario):
        self.scenario = scenario
        self.skyline = MockSkyline(scenario)
        self.ansible = MockAnsible(scenario)
        self.nexus = MockNexus(scenario, self.ansible)
        self.gitops = MockGitops(scenario)


def _graph(name):
    s = json.loads((ROOT / "scenarios" / name).read_text())
    return build_graph(Ctx(s), MemorySaver())


def test_pauses_on_interrupt_then_resumes_approved():
    g = _graph("missing_releases.json")
    cfg = {"configurable": {"thread_id": "t1"}}
    out = g.invoke({"log": []}, cfg)
    assert "__interrupt__" in out
    assert out["__interrupt__"][0].value["releases_to_mirror"] == ["4.18.49"]
    assert "result" not in out  # nothing executed before approval

    out = g.invoke(Command(resume=True), cfg)
    assert out["result"]["mirrored"] == ["4.18.49"]
    assert out["result"]["verification_passed"] is True
    assert out["result"]["gitops_wired"] is False  # a49 unwired in scenario


def test_deny_executes_nothing():
    g = _graph("missing_releases.json")
    cfg = {"configurable": {"thread_id": "t2"}}
    g.invoke({"log": []}, cfg)
    out = g.invoke(Command(resume=False), cfg)
    assert out.get("denied") is True and "result" not in out


def test_no_op_ends_without_interrupt():
    g = _graph("no_op.json")
    out = g.invoke({"log": []}, {"configurable": {"thread_id": "t3"}})
    assert "__interrupt__" not in out
    assert out["plan"]["no_op"] is True and "result" not in out


def test_unreachable_escalates_without_interrupt():
    g = _graph("unreachable_target.json")
    out = g.invoke({"log": []}, {"configurable": {"thread_id": "t4"}})
    assert "__interrupt__" not in out and "plan" not in out
