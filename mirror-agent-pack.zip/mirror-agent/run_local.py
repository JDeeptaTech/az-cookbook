#!/usr/bin/env python3
"""Local mock runner - no external APIs, no AI calls.

  python run_local.py scenarios/missing_releases.json            # runs to approval interrupt
  python run_local.py scenarios/missing_releases.json --approve  # resumes from checkpoint
  python run_local.py scenarios/no_op.json                       # no-op short circuit
"""
import argparse, json, sys
from pathlib import Path

from workflow.state import AgentState
from workflow import graph
from tools.mock.skyline import MockSkyline
from tools.mock.ansible import MockAnsible
from tools.mock.nexus import MockNexus

CKPT = Path(".checkpoint.json")


class Ctx:
    def __init__(self, scenario, approved):
        self.scenario = scenario
        self.approved = approved
        self.skyline = MockSkyline(scenario)
        self.ansible = MockAnsible(scenario)
        self.nexus = MockNexus(scenario, self.ansible)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("scenario")
    ap.add_argument("--approve", action="store_true",
                    help="resume from the approval checkpoint")
    args = ap.parse_args()

    scenario = json.loads(Path(args.scenario).read_text())
    ctx = Ctx(scenario, approved=args.approve)

    if args.approve and CKPT.exists():
        print(">> resuming from checkpoint (simulated interrupt/resume)\n")
    state, interrupted = graph.run(AgentState(), ctx)

    print("=" * 62)
    for line in state.log:
        print(line)
    print("=" * 62)

    if interrupted:
        CKPT.write_text(json.dumps(state.to_dict(), default=str, indent=2))
        print("\nSTATUS: awaiting approval - checkpoint saved to .checkpoint.json")
        print(f"Approver would see: releases_to_mirror = {state.plan.releases_to_mirror}")
        print("Resume with:  python run_local.py " + args.scenario + " --approve")
        sys.exit(2)

    CKPT.unlink(missing_ok=True)
    if state.result:
        print(f"\nRESULT: mirrored={state.result.mirrored} "
              f"verified={state.result.verification_passed} "
              f"job={state.result.aap_job_id}")
    elif state.plan and state.plan.no_op:
        print("\nRESULT: no-op - everything on the path already in Nexus")
    else:
        print("\nRESULT: inconclusive - escalated for human triage")


if __name__ == "__main__":
    main()
