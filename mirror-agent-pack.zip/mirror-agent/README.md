# mirror-agent — mock-mode implementation (no external APIs)

Cortex Domain Agent Pack pattern: deterministic-first, single write action,
approval-gated, independently verified. Runs entirely locally.

## Quick start
    python run_local.py scenarios/missing_releases.json            # runs to approval interrupt (exit 2)
    python run_local.py scenarios/missing_releases.json --approve  # resume from checkpoint -> execute -> verify
    python run_local.py scenarios/no_op.json                       # delta empty -> no-op, no approval needed
    python run_local.py scenarios/unreachable_target.json          # rule returns None -> escalate (AI branch in prod)
    python -m pytest tests/ -q

## Layout
    agent.yaml            identity, authority A1, allowed_tools, model_policy (deterministic_first)
    workflow/graph.py     intake -> evidence -> plan -> approval(interrupt) -> execute -> verify
    rules/delta.py        MIRROR-DELTA-001: shortest path minus Nexus digests, confidence 1.0
    contracts/            MirrorPlan / MirrorResult structured outputs
    tools/mock/           skyline (evidence), ansible (single write action), nexus (verification)
    scenarios/            synthetic evidence + expected results
    tests/                delta rule behavior incl. shortest-path guarantee

## Porting to the Cortex template
1. Each function in workflow/graph.py becomes a LangGraph node; AgentState becomes the
   graph's TypedDict state; the approval interrupt becomes a real LangGraph checkpoint.
2. tools/mock/* are replaced by MCP adapters with the SAME signatures
   (mode 2/3 in the pack: development MCP gateway or local stub).
3. rules/, contracts/, scenarios/ move unchanged — that is the point of the pack contract.
4. Fault injection: add {"inject": {"aap_failure": true}} to any scenario to test
   the verification-failed path.

## LangGraph implementation (workflow/lg_graph.py)
    python run_langgraph.py scenarios/missing_releases.json            # pauses on real interrupt()
    python run_langgraph.py scenarios/missing_releases.json --approve  # resumes SAME thread, new process
    python run_langgraph.py scenarios/missing_releases.json --deny

Approval = langgraph interrupt() on a SqliteSaver checkpoint (survives process
restarts; thread_id = scenario name). rules/, contracts/, tools/ are shared
byte-for-byte with the pure-python workflow - only orchestration changed.
Deny path routes to END without executing. Tests: tests/test_langgraph.py.
