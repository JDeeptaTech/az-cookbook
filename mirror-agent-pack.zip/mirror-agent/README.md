# mirror-agent (Cortex Domain Agent Pack)

Detects when OpenShift channel content is missing from Nexus and drives an
approved, incremental mirror run. Deterministic-first: the delta is graph
math over Skyline evidence and reaches zero-token conclusions; the model
is consulted only for inconclusive cases (unreachable targets, conflicting
evidence).

Triggers: operator request OR scheduled Skyline drift analysis.
Write action: exactly one - ansible.launch_job_template (mirror-execute).
Approval: Cortex approval-gated; approver sees MirrorPlan.releases_to_mirror.
Verification: independent nexus.verify_digests after the run.

workflow/   intake -> evidence -> plan (rules first) -> approval -> execute -> verify
rules/      delta.py            deterministic MIRROR-DELTA-001
tools/      skyline / ansible / nexus / servicenow MCP adapters
contracts/  MirrorPlan / MirrorResult
scenarios/  missing_releases, no_op, unreachable_target
