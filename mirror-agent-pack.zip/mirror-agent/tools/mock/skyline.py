"""Mock Skyline MCP adapter - serves evidence from a scenario file.
Same function signatures as the real adapter; only the source differs."""
from collections import deque


class MockSkyline:
    def __init__(self, scenario):
        self.s = scenario
        self.digest = {n["version"]: n["digest"] for n in scenario["graph"]["nodes"]}
        self.adj = {}
        for a, b in scenario["graph"]["edges"]:
            self.adj.setdefault(a, []).append(b)

    def get_cluster_state(self):
        return dict(self.s["cluster"])

    def get_nexus_inventory(self):
        return set(self.s["nexus_digests"])

    def get_upgrade_path(self, frm, to):
        """BFS shortest path; returns [{version, digest}] or []."""
        q, seen = deque([[frm]]), {frm}
        while q:
            path = q.popleft()
            if path[-1] == to:
                return [{"version": v, "digest": self.digest[v]} for v in path]
            for nxt in self.adj.get(path[-1], []):
                if nxt not in seen:
                    seen.add(nxt); q.append(path + [nxt])
        return []
