"""Mock AAP adapter - the agent's single write action."""
import random


class MockAnsible:
    def __init__(self, scenario):
        self.fail = scenario.get("inject", {}).get("aap_failure", False)
        self.launched = []

    def launch_job_template(self, name, extra_vars):
        job_id = f"mock-{random.randint(1000, 9999)}"
        self.launched.append({"job_id": job_id, "template": name, "vars": extra_vars})
        return {"job_id": job_id, "status": "failed" if self.fail else "successful"}
