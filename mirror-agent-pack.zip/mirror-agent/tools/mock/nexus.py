"""Mock Nexus adapter - independent post-run verification."""


class MockNexus:
    def __init__(self, scenario, ansible):
        self.s, self.ansible = scenario, ansible

    def verify_digests(self, digests):
        """After a successful mock run, mirrored digests are 'present'."""
        base = set(self.s["nexus_digests"])
        ran_ok = any(True for _ in self.ansible.launched) and not self.ansible.fail
        if ran_ok:
            for job in self.ansible.launched:
                base |= set(job["vars"].get("digests", []))
        return {d: (d in base) for d in digests}
