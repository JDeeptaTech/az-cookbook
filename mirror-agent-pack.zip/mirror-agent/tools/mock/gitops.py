"""Mock GitOps adapter - scenario-fed, same signature as the real one."""
from contracts.evidence import GitopsState


class MockGitops:
    def __init__(self, scenario):
        g = scenario.get("gitops", {})
        self.state = GitopsState(source="mock://cluster-config",
                                 commit=g.get("commit", "deadbeef"),
                                 idms_digests=g.get("idms_digests", []),
                                 catalog_sources=g.get("catalog_sources", []))

    def get_cluster_config(self):
        return self.state
