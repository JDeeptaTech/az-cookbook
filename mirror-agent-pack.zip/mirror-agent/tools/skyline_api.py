"""Push evidence payloads as JSON. Sink is pluggable:
file:// dir for local/mock, https:// endpoint for the real Skyline API."""
import json
import time
from pathlib import Path


class SkylinePush:
    def __init__(self, sink="file:///tmp/skyline-evidence"):
        self.sink = sink

    def push(self, kind: str, payload_json: str) -> str:
        if self.sink.startswith("file://"):
            d = Path(self.sink[7:]); d.mkdir(parents=True, exist_ok=True)
            snapshot_id = f"{kind}-{int(time.time())}"
            (d / f"{snapshot_id}.json").write_text(payload_json)
            return snapshot_id
        import requests  # real mode
        r = requests.post(f"{self.sink}/api/v1/evidence/{kind}",
                          data=payload_json, timeout=60,
                          headers={"Content-Type": "application/json"})
        r.raise_for_status()
        return r.json()["snapshot_id"]
