"""Nexus extractor - real adapter skeleton (same signature as the mock).
Digest-based inventory via the registry v2 API / Nexus search."""
import os

import requests

from contracts.evidence import NexusInventory


class NexusExtractor:
    def __init__(self, base_url=None, image=None, auth=None):
        self.base = (base_url or os.environ.get("NEXUS_URL", "")).rstrip("/")
        self.image = image or os.environ.get("NEXUS_IMAGE", "")
        self.auth = auth

    def get_inventory(self) -> NexusInventory:
        digests, token = set(), None
        while True:
            params = {"repository": self.image.split("/")[0], "format": "docker"}
            if token:
                params["continuationToken"] = token
            r = requests.get(f"{self.base}/service/rest/v1/search",
                             params=params, auth=self.auth, timeout=60)
            r.raise_for_status()
            body = r.json()
            for item in body.get("items", []):
                sha = (item.get("assets") or [{}])[0].get("checksum", {}).get("sha256")
                if sha:
                    digests.add(f"sha256:{sha}")
            token = body.get("continuationToken")
            if not token:
                return NexusInventory(source=f"{self.base}/{self.image}",
                                      digests=sorted(digests))
