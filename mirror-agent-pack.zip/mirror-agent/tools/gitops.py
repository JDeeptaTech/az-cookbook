"""GitOps repo extractor - parses IDMS / CatalogSource manifests from a
checked-out cluster-config repo. File-based: no network required, fully
testable against fixtures. Real deployment points repo_path at a fresh clone."""
import re
import subprocess
from pathlib import Path

import yaml  # falls back to naive parse if unavailable (mock/test envs)

from contracts.evidence import GitopsState

DIGEST_RE = re.compile(r"sha256:[0-9a-f]{6,64}")


class GitopsExtractor:
    def __init__(self, repo_path):
        self.repo = Path(repo_path)

    def _commit(self):
        try:
            return subprocess.run(["git", "-C", str(self.repo), "rev-parse", "HEAD"],
                                  capture_output=True, text=True, timeout=10
                                  ).stdout.strip() or "unknown"
        except Exception:
            return "unknown"

    def get_cluster_config(self) -> GitopsState:
        idms_digests, catalogs = set(), []
        for path in sorted(self.repo.rglob("*.y*ml")):
            text = path.read_text(errors="ignore")
            for doc in yaml.safe_load_all(text):
                if not isinstance(doc, dict):
                    continue
                kind = doc.get("kind", "")
                if kind in ("ImageDigestMirrorSet", "ImageContentSourcePolicy"):
                    idms_digests |= set(DIGEST_RE.findall(text))
                elif kind == "CatalogSource":
                    catalogs.append(doc.get("metadata", {}).get("name", "unnamed"))
        return GitopsState(source=str(self.repo), commit=self._commit(),
                           idms_digests=sorted(idms_digests),
                           catalog_sources=sorted(catalogs))
