"""Workflow graph: intake -> evidence -> plan -> approval -> execute -> verify.

Pure-python state machine in mock mode. Port path to LangGraph: each node
function becomes a graph node; the approval interrupt becomes a real
LangGraph checkpoint interrupt.
"""
from rules.delta import compute_mirror_delta
from contracts.mirror_plan import MirrorResult

AUTHORITY = "A1"


def intake(state, ctx):
    t = ctx.scenario["trigger"]
    state.trigger = t
    state.note("intake", f"{t['type']}: channel={t['channel']} target={t['target_version']}")
    return state


def gather_evidence(state, ctx):
    cluster = ctx.skyline.get_cluster_state()
    path = ctx.skyline.get_upgrade_path(cluster["version"], state.trigger["target_version"])
    gitops = ctx.gitops.get_cluster_config()
    state.evidence = {
        "channel": state.trigger["channel"],
        "cluster_version": cluster["version"],
        "upgrade_path": path,
        "nexus_digests": ctx.skyline.get_nexus_inventory(),
        "gitops_idms_digests": set(gitops.idms_digests),
        "gitops_commit": gitops.commit,
    }
    state.note("evidence", f"cluster={cluster['version']} path_len={len(path)} "
                           f"nexus_digests={len(state.evidence['nexus_digests'])}")
    return state


def plan(state, ctx):
    p = compute_mirror_delta(state.evidence)
    if p is None:
        state.note("plan", "INCONCLUSIVE: no upgrade path. In production this is the "
                           "only branch that may consult the approved AI API; in mock "
                           "mode we stop for human triage.")
        return state
    state.plan = p
    state.note("plan", f"{p.rule_id} confidence={p.confidence} no_op={p.no_op} "
                       f"releases_to_mirror={p.releases_to_mirror}")
    return state


def approval_gate(state, ctx):
    """Simulated Cortex approval-gated action (checkpoint interrupt)."""
    if state.plan is None or state.plan.no_op:
        state.note("approval", "skipped (no-op or no plan)")
        return state, False
    if not ctx.approved:
        state.note("approval", "INTERRUPT: awaiting human approval of "
                               f"{state.plan.releases_to_mirror}")
        return state, True  # interrupt
    state.approved = True
    state.note("approval", "approved by human (mock)")
    return state, False


def execute(state, ctx):
    if not state.approved or state.plan.no_op:
        return state
    digests = [r["digest"] for r in state.evidence["upgrade_path"][1:]
               if r["version"] in state.plan.releases_to_mirror]
    run = ctx.ansible.launch_job_template(
        "mirror-execute",
        {"channel": state.plan.channel,
         "releases": state.plan.releases_to_mirror,
         "digests": digests})
    state.result = MirrorResult(aap_job_id=run["job_id"],
                                mirrored=state.plan.releases_to_mirror)
    state.note("execute", f"AAP job {run['job_id']} -> {run['status']}")
    return state


def verify(state, ctx):
    if state.result is None:
        return state
    digests = [r["digest"] for r in state.evidence["upgrade_path"][1:]
               if r["version"] in state.result.mirrored]
    checks = ctx.nexus.verify_digests(digests)
    state.result.verified_digests = [d for d, ok in checks.items() if ok]
    state.result.verification_passed = all(checks.values())
    state.note("verify", f"independent digest check passed={state.result.verification_passed}")

    # three-way diff: mirrored (Nexus) but not wired into clusters (GitOps IDMS)
    wired = state.evidence.get("gitops_idms_digests", set())
    unwired = [d for d in state.result.verified_digests if d not in wired]
    state.result.gitops_wired = not unwired
    if unwired:
        state.note("verify", f"WARNING: {len(unwired)} mirrored digest(s) not referenced "
                             f"by any IDMS in GitOps (commit {state.evidence['gitops_commit']}) "
                             "- content available but clusters not wired to use it")
    return state


def run(state, ctx):
    """Returns (state, interrupted)."""
    state = intake(state, ctx)
    state = gather_evidence(state, ctx)
    state = plan(state, ctx)
    state, interrupted = approval_gate(state, ctx)
    if interrupted:
        return state, True
    state = execute(state, ctx)
    state = verify(state, ctx)
    return state, False
