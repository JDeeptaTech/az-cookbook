"""LangGraph port of the mirror-agent workflow.

Graph:  intake -> evidence -> plan -+-> approval -> execute -> verify -> END
                                    +-> END (no-op)
                                    +-> END (inconclusive/escalate)

The approval gate is a real langgraph interrupt(): the run pauses on a
checkpoint and resumes with Command(resume=True/False). rules/, contracts/
and tools/ are the SAME modules the pure-python workflow uses - only the
orchestration layer changed (the pack contract).
"""
# pydantic models: .model_dump() replaces dataclasses.asdict
from typing import Annotated, TypedDict
import operator

from langgraph.graph import StateGraph, START, END
from langgraph.types import interrupt

from rules.delta import compute_mirror_delta
from contracts.mirror_plan import MirrorResult


class MirrorState(TypedDict, total=False):
    trigger: dict
    evidence: dict
    plan: dict            # asdict(MirrorPlan) - keeps checkpoints serializable
    approved: bool
    denied: bool
    result: dict          # asdict(MirrorResult)
    log: Annotated[list, operator.add]


def build_graph(ctx, checkpointer):
    """ctx carries the tool adapters (mock or real - same signatures)."""

    def intake(state: MirrorState):
        t = ctx.scenario["trigger"]
        return {"trigger": t,
                "log": [f"[intake] {t['type']}: channel={t['channel']} "
                        f"target={t['target_version']}"]}

    def gather_evidence(state: MirrorState):
        cluster = ctx.skyline.get_cluster_state()
        path = ctx.skyline.get_upgrade_path(cluster["version"],
                                            state["trigger"]["target_version"])
        gitops = ctx.gitops.get_cluster_config()
        ev = {"channel": state["trigger"]["channel"],
              "cluster_version": cluster["version"],
              "upgrade_path": path,
              "nexus_digests": set(ctx.skyline.get_nexus_inventory()),
              "gitops_idms_digests": set(gitops.idms_digests),
              "gitops_commit": gitops.commit}
        return {"evidence": ev,
                "log": [f"[evidence] cluster={cluster['version']} "
                        f"path_len={len(path)} nexus_digests={len(ev['nexus_digests'])}"]}

    def plan(state: MirrorState):
        p = compute_mirror_delta(state["evidence"])
        if p is None:
            return {"log": ["[plan] INCONCLUSIVE: no upgrade path - escalate. "
                            "(only branch that may consult the approved AI API)"]}
        return {"plan": p.model_dump(),
                "log": [f"[plan] {p.rule_id} confidence={p.confidence} "
                        f"no_op={p.no_op} releases_to_mirror={p.releases_to_mirror}"]}

    def route_after_plan(state: MirrorState):
        if "plan" not in state:
            return "escalate"
        if state["plan"]["no_op"]:
            return "no_op"
        return "approval"

    def approval(state: MirrorState):
        # REAL interrupt: run pauses here on the checkpointer; the approver's
        # decision arrives via Command(resume=<bool>) on the same thread_id.
        decision = interrupt({
            "question": "Approve mirror run?",
            "releases_to_mirror": state["plan"]["releases_to_mirror"],
            "upgrade_path": state["plan"]["upgrade_path"],
        })
        if not decision:
            return {"denied": True, "log": ["[approval] denied by human"]}
        return {"approved": True, "log": ["[approval] approved by human"]}

    def route_after_approval(state: MirrorState):
        return "execute" if state.get("approved") else "denied"

    def execute(state: MirrorState):
        pl = state["plan"]
        digests = [r["digest"] for r in state["evidence"]["upgrade_path"][1:]
                   if r["version"] in pl["releases_to_mirror"]]
        run = ctx.ansible.launch_job_template(
            "mirror-execute",
            {"channel": pl["channel"], "releases": pl["releases_to_mirror"],
             "digests": digests})
        res = MirrorResult(aap_job_id=run["job_id"],
                           mirrored=pl["releases_to_mirror"])
        return {"result": res.model_dump(),
                "log": [f"[execute] AAP job {run['job_id']} -> {run['status']}"]}

    def verify(state: MirrorState):
        res = dict(state["result"])
        digests = [r["digest"] for r in state["evidence"]["upgrade_path"][1:]
                   if r["version"] in res["mirrored"]]
        checks = ctx.nexus.verify_digests(digests)
        res["verified_digests"] = [d for d, ok in checks.items() if ok]
        res["verification_passed"] = all(checks.values())
        logs = [f"[verify] independent digest check passed={res['verification_passed']}"]

        wired = state["evidence"]["gitops_idms_digests"]
        unwired = [d for d in res["verified_digests"] if d not in wired]
        res["gitops_wired"] = not unwired
        if unwired:
            logs.append(f"[verify] WARNING: {len(unwired)} mirrored digest(s) not "
                        f"referenced by any IDMS in GitOps "
                        f"(commit {state['evidence']['gitops_commit']})")
        return {"result": res, "log": logs}

    g = StateGraph(MirrorState)
    g.add_node("intake", intake)
    g.add_node("evidence", gather_evidence)
    g.add_node("plan", plan)
    g.add_node("approval", approval)
    g.add_node("execute", execute)
    g.add_node("verify", verify)

    g.add_edge(START, "intake")
    g.add_edge("intake", "evidence")
    g.add_edge("evidence", "plan")
    g.add_conditional_edges("plan", route_after_plan,
                            {"approval": "approval", "no_op": END, "escalate": END})
    g.add_conditional_edges("approval", route_after_approval,
                            {"execute": "execute", "denied": END})
    g.add_edge("execute", "verify")
    g.add_edge("verify", END)

    return g.compile(checkpointer=checkpointer)
