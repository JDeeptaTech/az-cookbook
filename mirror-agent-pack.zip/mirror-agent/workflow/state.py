"""Workflow state (pure-python runner) - pydantic model."""
from pydantic import BaseModel, Field

from contracts.mirror_plan import MirrorPlan, MirrorResult


class AgentState(BaseModel):
    trigger: dict = Field(default_factory=dict)
    evidence: dict = Field(default_factory=dict)
    plan: MirrorPlan | None = None
    approved: bool = False
    result: MirrorResult | None = None
    log: list[str] = Field(default_factory=list)

    def note(self, node, msg):
        self.log.append(f"[{node}] {msg}")

    def to_dict(self):
        return self.model_dump()
