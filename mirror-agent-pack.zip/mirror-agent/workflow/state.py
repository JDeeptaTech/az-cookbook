"""Workflow state - becomes the LangGraph TypedDict state when ported."""
from dataclasses import dataclass, field, asdict
from contracts.mirror_plan import MirrorPlan, MirrorResult


@dataclass
class AgentState:
    trigger: dict = field(default_factory=dict)
    evidence: dict = field(default_factory=dict)
    plan: MirrorPlan | None = None
    approved: bool = False
    result: MirrorResult | None = None
    log: list = field(default_factory=list)

    def note(self, node, msg):
        self.log.append(f"[{node}] {msg}")

    def to_dict(self):
        return asdict(self)
