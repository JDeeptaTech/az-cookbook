"""Structured output contracts for the mirror agent."""
from dataclasses import dataclass, field


@dataclass
class MirrorPlan:
    channel: str
    upgrade_path: list
    releases_to_mirror: list
    no_op: bool
    confidence: float
    rule_id: str
    requires_approval: bool


@dataclass
class MirrorResult:
    aap_job_id: str
    mirrored: list
    verified_digests: list = field(default_factory=list)
    verification_passed: bool = False
