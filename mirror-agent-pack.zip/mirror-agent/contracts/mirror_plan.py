"""Structured output contracts for the mirror agent."""
from dataclasses import dataclass, field


@dataclass
class MirrorPlan:
    channel: str
    upgrade_path: list[str]
    releases_to_mirror: list[str]
    no_op: bool
    confidence: float
    rule_id: str
    requires_approval: bool
    evidence_required: tuple = ("cluster_version", "channel_graph",
                                "nexus_digest_inventory")


@dataclass
class MirrorResult:
    plan: MirrorPlan
    aap_job_id: str
    mirrored: list[str]
    verified_digests: list[str] = field(default_factory=list)
    verification_passed: bool = False
