"""Structured output contracts - pydantic models.

Pydantic (not dataclasses) because this is what the contract layer is FOR:
validated, schema-exportable structured outputs. model_json_schema() is what
you hand the Cortex model gateway as output_schema for the escalate branch.
"""
from pydantic import BaseModel, Field


class MirrorPlan(BaseModel):
    channel: str
    upgrade_path: list[str]
    releases_to_mirror: list[str]
    no_op: bool
    confidence: float = Field(ge=0.0, le=1.0)
    rule_id: str
    requires_approval: bool


class MirrorResult(BaseModel):
    aap_job_id: str
    mirrored: list[str]
    verified_digests: list[str] = Field(default_factory=list)
    verification_passed: bool = False
    gitops_wired: bool = False
