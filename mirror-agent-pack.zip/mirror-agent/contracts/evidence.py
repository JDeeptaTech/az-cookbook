"""Evidence contracts - every extractor emits one of these as JSON.
Provenance (collected_at, source) is mandatory and now VALIDATED."""
from datetime import datetime, timezone

from pydantic import BaseModel, Field


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


class NexusInventory(BaseModel):
    source: str = Field(min_length=1)
    digests: list[str]
    collected_at: str = Field(default_factory=_now)

    def to_json(self) -> str:
        return self.model_dump_json(indent=2)


class GitopsState(BaseModel):
    source: str = Field(min_length=1)
    commit: str
    idms_digests: list[str]
    catalog_sources: list[str]
    collected_at: str = Field(default_factory=_now)

    def to_json(self) -> str:
        return self.model_dump_json(indent=2)
