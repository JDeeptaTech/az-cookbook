"""Evidence contracts - every extractor emits one of these as JSON.
Provenance fields (collected_at, source) are mandatory: evidence must be auditable."""
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
import json


@dataclass
class NexusInventory:
    source: str                      # registry URL + repo
    digests: list
    collected_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

    def to_json(self): return json.dumps(asdict(self), indent=2)


@dataclass
class GitopsState:
    source: str                      # repo URL or path
    commit: str
    idms_digests: list               # digests referenced by ImageDigestMirrorSet
    catalog_sources: list
    collected_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

    def to_json(self): return json.dumps(asdict(self), indent=2)
