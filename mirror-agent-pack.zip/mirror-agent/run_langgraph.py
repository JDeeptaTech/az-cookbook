#!/usr/bin/env python3
"""LangGraph runner with persistent checkpoints (sqlite) - survives processes.

  python run_langgraph.py scenarios/missing_releases.json           # pauses at approval interrupt
  python run_langgraph.py scenarios/missing_releases.json --approve # resumes the SAME thread
  python run_langgraph.py scenarios/missing_releases.json --deny
"""
import argparse, json
from pathlib import Path

from langgraph.checkpoint.sqlite import SqliteSaver
from langgraph.types import Command

from workflow.lg_graph import build_graph
from tools.mock.skyline import MockSkyline
from tools.mock.ansible import MockAnsible
from tools.mock.nexus import MockNexus
from tools.mock.gitops import MockGitops


class Ctx:
    def __init__(self, scenario):
        self.scenario = scenario
        self.skyline = MockSkyline(scenario)
        self.ansible = MockAnsible(scenario)
        self.nexus = MockNexus(scenario, self.ansible)
        self.gitops = MockGitops(scenario)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("scenario")
    grp = ap.add_mutually_exclusive_group()
    grp.add_argument("--approve", action="store_true")
    grp.add_argument("--deny", action="store_true")
    args = ap.parse_args()

    scenario = json.loads(Path(args.scenario).read_text())
    thread = {"configurable": {"thread_id": Path(args.scenario).stem}}

    with SqliteSaver.from_conn_string("checkpoints.db") as saver:
        graph = build_graph(Ctx(scenario), saver)

        if args.approve or args.deny:
            out = graph.invoke(Command(resume=args.approve), thread)
        else:
            out = graph.invoke({"log": []}, thread)

        for line in out.get("log", []):
            print(line)

        if "__interrupt__" in out:
            payload = out["__interrupt__"][0].value
            print("\nSTATUS: paused on LangGraph checkpoint - awaiting approval")
            print(f"Approver sees: {payload['releases_to_mirror']}")
            print(f"Resume: python run_langgraph.py {args.scenario} --approve")
            return

        res = out.get("result")
        if res:
            print(f"\nRESULT: mirrored={res['mirrored']} "
                  f"verified={res['verification_passed']} "
                  f"gitops_wired={res['gitops_wired']} job={res['aap_job_id']}")
        elif out.get("denied"):
            print("\nRESULT: denied by approver - nothing executed")
        elif out.get("plan", {}).get("no_op"):
            print("\nRESULT: no-op - everything on the path already in Nexus")
        else:
            print("\nRESULT: inconclusive - escalated for human triage")


if __name__ == "__main__":
    main()
