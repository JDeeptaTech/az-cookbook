"""Deterministic mirror-delta rule - reaches zero-token conclusions.

Pack convention: pure function over evidence, returns a structured
conclusion with confidence and rule_id, or None to escalate.
"""
from contracts.mirror_plan import MirrorPlan


def compute_mirror_delta(evidence):
    """evidence: cluster_version, channel, target_version, graph, nexus_digests"""
    path = evidence.graph.shortest_path(
        evidence.cluster_version, evidence.target_version)

    if not path:
        return None  # unreachable target -> AI/human triage, never guessed

    missing = [r for r in path[1:] if r.payload_digest not in evidence.nexus_digests]

    return MirrorPlan(
        channel=evidence.channel,
        upgrade_path=[r.version for r in path],
        releases_to_mirror=[r.version for r in missing],
        no_op=(len(missing) == 0),
        confidence=1.0,
        rule_id="MIRROR-DELTA-001",
        requires_approval=(len(missing) > 0),
    )
