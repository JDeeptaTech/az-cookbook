"""Deterministic mirror-delta rule - zero-token conclusion (MIRROR-DELTA-001)."""
from contracts.mirror_plan import MirrorPlan


def compute_mirror_delta(evidence):
    path = evidence["upgrade_path"]
    if not path:
        return None  # unreachable -> escalate; never guessed

    have = evidence["nexus_digests"]
    missing = [r for r in path[1:] if r["digest"] not in have]

    return MirrorPlan(
        channel=evidence["channel"],
        upgrade_path=[r["version"] for r in path],
        releases_to_mirror=[r["version"] for r in missing],
        no_op=not missing,
        confidence=1.0,
        rule_id="MIRROR-DELTA-001",
        requires_approval=bool(missing),
    )
