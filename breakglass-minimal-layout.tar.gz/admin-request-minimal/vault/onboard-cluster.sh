#!/usr/bin/env bash
# OWNER: Vault team        RUN: once per managed cluster, and again whenever an account is added
#                               or its cap changes. Safe to re-run.
# Minimal layout: reuses the hub's EXISTING Kubernetes auth mount and the EXISTING service
# account that already logs in to Vault. New in Vault per cluster: one PKI mount with its CA,
# one signing role per account and one policy. New once: one login role on the existing mount.
#
# Usage:
#   export VAULT_NAMESPACE=ITID/20016285_EOS            # if your mounts live in a namespace
#   CLUSTER=ocp-prod-01 ACCOUNTS="eos-cluster-admin=1h eos-cluster-reader=4h" \
#   VAULT_K8S_AUTH_MOUNT=kubernetes/eos_<hub-cluster-name> ./onboard-cluster.sh
#
# Optional: SIGNER_SA (default vault-auth), SIGNER_NS (default infra-secrets),
#           AUTH_ROLE (default eos-breakglass-sign).
set -euo pipefail
: "${CLUSTER:?set CLUSTER to the ACM managed cluster name}"
: "${ACCOUNTS:?set ACCOUNTS, e.g. ACCOUNTS=\"eos-cluster-admin=1h eos-cluster-reader=4h\"}"
: "${VAULT_K8S_AUTH_MOUNT:?set VAULT_K8S_AUTH_MOUNT to the existing Kubernetes auth mount of the hub}"
SIGNER_SA=${SIGNER_SA:-vault-auth}
SIGNER_NS=${SIGNER_NS:-infra-secrets}
AUTH_ROLE=${AUTH_ROLE:-eos-breakglass-sign}
MOUNT="pki-eos-breakglass-$CLUSTER"
# Absolute ceiling for any account. Raising it is a security decision, not a config change.
CEILING_HOURS=4

# ---- one PKI mount and CA per cluster (created once; the key never leaves Vault)
if vault secrets list -format=json | grep -q "\"$MOUNT/\""; then
  echo "$CLUSTER: PKI mount $MOUNT already exists, CA left alone"
else
  vault secrets enable -path="$MOUNT" -max-lease-ttl=43800h pki
  vault write "$MOUNT/root/generate/internal" \
    common_name="EOS breakglass CA $CLUSTER" organization="EOS breakglass" \
    key_type=ec key_bits=384 ttl=43800h issuer_name=breakglass-ca >/dev/null
fi

# ---- one signing role per account: the control that matters
for entry in $ACCOUNTS; do
  if [[ ! $entry =~ ^([a-z0-9]([a-z0-9-]*[a-z0-9])?)=([0-9]+)h$ ]]; then
    echo "bad ACCOUNTS entry '$entry' (want <account>=<hours>h)" >&2; exit 1
  fi
  ACCOUNT=${BASH_REMATCH[1]}; HOURS=${BASH_REMATCH[3]}
  if (( HOURS < 1 || HOURS > CEILING_HOURS )); then
    echo "$ACCOUNT: ${HOURS}h is outside 1..${CEILING_HOURS}h" >&2; exit 1
  fi
  # cn_validations=hostname (NOT disabled): with "disabled" Vault skips the allowed_domains
  # check on the common name and signs any name. enforce_hostnames=false lets the
  # colon-separated names through the hostname syntax check. In this layout every Issuer
  # shares one login, so this name restriction is the ONLY thing that keeps an admin name
  # out of the reader role. Confirm it with the Verify commands in README.md before go-live.
  vault write "$MOUNT/roles/breakglass-$ACCOUNT" \
    max_ttl="${HOURS}h" ttl="${HOURS}h" not_before_duration=30s \
    allowed_domains="eos-breakglass:$ACCOUNT:*" allow_glob_domains=true \
    allow_any_name=false allow_bare_domains=false allow_subdomains=false \
    allow_localhost=false allow_wildcard_certificates=false allow_ip_sans=false \
    allowed_uri_sans="" allowed_other_sans="" \
    enforce_hostnames=false cn_validations=hostname require_cn=true \
    use_csr_common_name=true use_csr_sans=false \
    organization="eos-breakglass" \
    key_type=ec key_bits=256 \
    key_usage=DigitalSignature ext_key_usage="" \
    client_flag=true server_flag=false code_signing_flag=false email_protection_flag=false \
    no_store=false >/dev/null
  echo "$CLUSTER/$ACCOUNT: role $MOUNT/roles/breakglass-$ACCOUNT (max ${HOURS}h)"
done

# ---- one policy per cluster: may use this cluster's signing roles, nothing else
vault policy write "eos-breakglass-sign-$CLUSTER" - >/dev/null <<POLICY
path "$MOUNT/sign/breakglass-*" {
  capabilities = ["create", "update"]
}
POLICY

# ---- one login role on the existing auth mount, for the existing service account.
# It carries the sign policy of every onboarded cluster, and nothing else.
POLICIES=$(vault policy list | grep '^eos-breakglass-sign-' | paste -sd, -)
vault write "auth/$VAULT_K8S_AUTH_MOUNT/role/$AUTH_ROLE" \
  bound_service_account_names="$SIGNER_SA" \
  bound_service_account_namespaces="$SIGNER_NS" \
  token_policies="$POLICIES" \
  token_ttl=1m token_max_ttl=5m >/dev/null
echo "Login role auth/$VAULT_K8S_AUTH_MOUNT/role/$AUTH_ROLE -> $SIGNER_NS/$SIGNER_SA, policies: $POLICIES"
