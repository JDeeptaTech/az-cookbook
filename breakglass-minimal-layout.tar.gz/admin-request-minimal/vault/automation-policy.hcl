# OWNER: Vault team        APPLY: once (inside the namespace, if you use one)
# For the AppRole / identity that RUNS the playbooks (AAP). Attach to that, not to people:
# whoever can read the hub token can request breakglass certificates.
#   vault policy write eos-breakglass-automation automation-policy.hcl
#
# Replace KV_MOUNT and TOKEN_PATH with where the automation service account's hub token is
# stored (KV v2), e.g. KV_MOUNT=secrets/kv_v2/eos  TOKEN_PATH=infra-secrets/eos-breakglass-automation
path "KV_MOUNT/data/TOKEN_PATH" {
  capabilities = ["read"]
}

# bootstrap_cluster.yml reads each signing role (config only: TTL and allowed names, no keys)
# and refuses to continue if it differs from the account catalogue.
path "+/roles/breakglass-*" {
  capabilities = ["read"]
}
