# Minimal layout: reuse the existing Vault-enabled service account

An alternative to `admin-request/` for hubs that already have a service account logging in to
Vault (here: `vault-auth` in `infra-secrets`, on the Kubernetes auth mount
`kubernetes/eos_<hub>`, Vault namespace `ITID/20016285_EOS`). Use one layout or the other.

## What is reused and what is new

| | `admin-request/` (full) | This layout |
|---|---|---|
| Hub namespaces | 2 new | 0 new (uses `infra-secrets`) |
| Hub service accounts | 4 new | 0 new |
| Hub token Secrets | 3 new | 0 new (uses the existing `vault-auth` token Secret) |
| Hub RBAC objects | 12, plus 1 per cluster | 5, plus 1 per cluster |
| Vault auth mount + reviewer | new | existing |
| Vault login roles | 1 per cluster and account | 1 in total |
| Vault PKI mount + CA | 1 per cluster | 1 per cluster (unavoidable) |
| Vault signing roles | 1 per cluster and account | same (unavoidable) |
| Vault policies | 1 per cluster and account, plus 2 | 1 per cluster, plus 1 |

**New on the hub:** `hub/01-rbac.yaml` (2 ClusterRoles, 1 ClusterRoleBinding, 1 Role,
1 RoleBinding) and one RoleBinding per managed cluster (`hub/02`). All of it binds to a service
account you already have.

**New in Vault:** `vault/onboard-cluster.sh` per cluster, and `vault/automation-policy.hcl` once.

## Assumptions to confirm

1. `infra-secrets/vault-auth` and its token Secret `vault-auth` exist **on the hub**, not only
   on managed clusters.
2. The hub has a Kubernetes auth mount in Vault whose reviewer works (`kubernetes/eos_<hub>`).
3. You have an existing hub service account for the automation, and its token is (or can be)
   stored in Vault KV. It must not be `vault-auth` itself.
4. You may create PKI mounts, policies and one auth role inside the Vault namespace.

## Steps

1. **Hub admin, once**
   ```bash
   sed -e 's/AUTOMATION_SA/<sa>/g' -e 's/AUTOMATION_NS/<ns>/g' -e 's/REQUEST_NS/infra-secrets/g' \
     hub/01-rbac.yaml | oc apply -f -
   ```
2. **Vault team, once:** create the policy from `vault/automation-policy.hcl` and attach it to
   the AppRole that runs the playbooks. Store the automation service account's hub token in KV
   (key `token`) at the path you set in `group_vars-minimal.yml`.
3. **Vault team, per managed cluster**
   ```bash
   export VAULT_NAMESPACE=ITID/20016285_EOS
   CLUSTER=<cluster> ACCOUNTS="eos-cluster-admin=1h eos-cluster-reader=4h" \
   VAULT_K8S_AUTH_MOUNT=kubernetes/eos_<hub> vault/onboard-cluster.sh
   ```
4. **Hub admin, per managed cluster**
   ```bash
   sed -e 's/CLUSTER_NAME/<cluster>/g' -e 's/AUTOMATION_SA/<sa>/g' -e 's/AUTOMATION_NS/<ns>/g' \
     hub/02-onboard-cluster-TEMPLATE.yaml | oc apply -f -
   ```
5. **Platform:** fill in `group_vars-minimal.yml`, then
   ```bash
   export VAULT_NAMESPACE=ITID/20016285_EOS
   ansible-playbook playbooks/bootstrap_cluster.yml -e @admin-request-minimal/group_vars-minimal.yml -e target_cluster=<cluster>
   ansible-playbook playbooks/generate_kubeconfig.yml -e @admin-request-minimal/group_vars-minimal.yml -e target_cluster=<cluster> ...
   ```

## Verify before go-live

```bash
export VAULT_NAMESPACE=ITID/20016285_EOS; M=pki-eos-breakglass-<cluster>
openssl req -new -newkey ec -pkeyopt ec_paramgen_curve:P-256 -nodes -keyout /dev/null \
  -subj "/CN=eos-breakglass:eos-cluster-admin:test/O=system:masters" -out ok.csr
vault write -field=certificate $M/sign/breakglass-eos-cluster-admin csr=@ok.csr ttl=2160h \
  | openssl x509 -noout -subject -dates
#   expect: O = eos-breakglass, CN kept, notAfter about now+1h
vault write $M/sign/breakglass-eos-cluster-reader csr=@ok.csr      # expect: refused (admin name, reader role)
openssl req -new -newkey ec -pkeyopt ec_paramgen_curve:P-256 -nodes -keyout /dev/null -subj "/CN=kube-admin" -out bad.csr
vault write $M/sign/breakglass-eos-cluster-admin csr=@bad.csr      # expect: refused

oc -n infra-secrets get issuer            # after bootstrap: READY True
```

The two "refused" lines are the ones that matter. If either is signed, do not go live.

## What you give up compared with the full layout

- **Account separation rests on one control.** In the full layout each Issuer can only reach
  its own account's signing role (token audience). Here every Issuer shares one login, so the
  only thing that stops an admin-named certificate coming out of the 4h reader role is the
  signing role's name restriction. That is why the script sets `cn_validations=hostname`.
- **No dedicated namespace.** Anyone who can create CertificateRequests or Issuers in
  `infra-secrets` can request breakglass certificates, within the role limits. Check who has
  `edit` there: cert-manager adds CertificateRequest rights to the standard `edit` role.
- **A long-lived token signs.** cert-manager logs in with the static `vault-auth` token, not a
  short-lived one. Anyone who can read that Secret can log in to Vault as `vault-auth` and
  sign directly, leaving no CertificateRequest on the hub (Vault's audit log still records it).
- **`vault-auth` is already powerful.** In your GitOps manifests it holds `system:auth-delegator`
  and may create tokens for any service account. It now also signs breakglass certificates.
- **One automation identity.** The same hub token requests certificates and bootstraps clusters.

One extra object removes the last three: a dedicated signer service account in a dedicated
namespace (the full layout's `eos-breakglass-vault-signer`).

## Not tested

Rendered and applied against the repository's local rig (the Issuer comes out with
`namespace`, `secretRef` and the shared role), but not against a real cert-manager or a real
Vault. In particular unverified: login with the long-lived token through your existing mount,
and Vault namespace handling end to end.
