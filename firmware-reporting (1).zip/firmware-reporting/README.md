# firmware-reporting

Medallion reporting stack over three server-inventory sources.

```
sources (csv/xlsx)            bronze (dlt)              silver (dbt)                 gold (dbt)            grafana
─────────────────             ────────────              ────────────                 ──────────            ───────
master_inventory.csv   ─┐                      ┌─ stg_master ─────────┐
firmware_inventory.csv ─┼─► raw, append-only ─┼─ stg_firmware ───────┼─ int_server_xref ─┬─ dim_server          panels
connectivity.xlsx      ─┘     + _file_hash     └─ stg_connectivity ──┘   (firmware =      ├─ fct_project_overlap
                                                        │                  bridge)         ├─ fct_demised_tracked
                                            snapshot (daily SCD2) ◄────────┘                └─ fct_coverage_gaps
```

## Join topology (load-bearing — verify before trusting any cross-project number)

There is **no single shared key**. Firmware is the bridge:

```
master.serverid (int) ── firmware.serverid (varchar) ── firmware.name ── connectivity.hostname
        master side  ◄────────── bridge ──────────►  connectivity side
```

master↔connectivity is **transitive through firmware**. A server absent from firmware is
invisible to that comparison. This is a data limitation, surfaced in `fct_coverage_gaps`,
not a code bug.

## Run order

```bash
cp .env.example .env                      # set creds
docker compose up -d postgres grafana     # warehouse + dashboards
pip install -r requirements.txt
python ingestion/pipeline.py              # land bronze (run daily for connectivity trends)
cd transformation
dbt deps
dbt run-operation verify_bridge           # CHECK MATCH RATES FIRST
dbt snapshot                              # connectivity SCD2
dbt build                                 # silver + gold + tests
```

Grafana: http://localhost:3000 (admin/admin), dashboard auto-provisioned.
