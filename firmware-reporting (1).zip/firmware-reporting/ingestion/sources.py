"""dlt resources that land raw exports into the `bronze` schema.

Design notes:
- Bronze is RAW. No cleaning, no typecasting, no joins — that is dbt's job.
- Every row carries _source_file, _file_hash, _load_date. The hash makes a re-run of
  the same file a no-op (merge on _row_hash); _load_date lets connectivity be snapshotted.
- Connectivity is point-in-time and MUST be appended daily (write_disposition="append"),
  never replaced, or you lose the ability to trend reachability over time.
- Master/firmware are slowly-changing full extracts -> "replace" is fine (bronze just
  holds the latest raw extract; history that matters is derived in dbt snapshots).
"""
from __future__ import annotations

import hashlib
import os
from datetime import date, datetime, timezone
from pathlib import Path
from typing import Iterator

import dlt
import pandas as pd


def _file_hash(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _enrich(rows: list[dict], src_path: str) -> Iterator[dict]:
    fh = _file_hash(src_path)
    fname = Path(src_path).name
    now = datetime.now(timezone.utc)
    today = date.today().isoformat()
    for r in rows:
        # normalise keys to snake-ish lower; dbt staging does the real renaming
        clean = {(k or "").strip().lower().replace(" ", "_"): v for k, v in r.items()}
        clean["_source_file"] = fname
        clean["_file_hash"] = fh
        clean["_ingested_at"] = now
        clean["_load_date"] = today
        yield clean


@dlt.resource(name="master_inventory", write_disposition="replace")
def master_inventory():
    path = os.environ["SOURCE_MASTER_CSV"]
    # leading empty `id` col in the export is dropped; serverid is the real key
    df = pd.read_csv(path, dtype=str, keep_default_na=False).rename(columns=str.strip)
    if df.columns[0] == "" or df.columns[0].lower() == "id":
        df = df.iloc[:, 1:]
    yield from _enrich(df.to_dict("records"), path)


@dlt.resource(name="firmware_inventory", write_disposition="replace")
def firmware_inventory():
    path = os.environ["SOURCE_FIRMWARE_CSV"]
    df = pd.read_csv(path, dtype=str, keep_default_na=False)
    yield from _enrich(df.to_dict("records"), path)


@dlt.resource(name="connectivity_status", write_disposition="append")
def connectivity_status():
    """APPEND each daily export. _load_date partitions the snapshots."""
    path = os.environ["SOURCE_CONNECTIVITY_XLSX"]
    sheet = os.environ.get("SOURCE_CONNECTIVITY_SHEET", "Unreachables")
    df = pd.read_excel(path, sheet_name=sheet, dtype=str, engine="openpyxl").dropna(how="all")
    yield from _enrich(df.to_dict("records"), path)
