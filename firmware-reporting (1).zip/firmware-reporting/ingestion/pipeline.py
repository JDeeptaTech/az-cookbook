"""Entry point: lands all three sources into bronze.

    python ingestion/pipeline.py

Run daily (cron / Airflow / GH Actions) so connectivity_status accumulates snapshots.
Master and firmware replace-load each run; that is intentional — bronze holds the latest
raw extract and dbt derives any history that matters.
"""
import dlt

from sources import connectivity_status, firmware_inventory, master_inventory


def main() -> None:
    pipeline = dlt.pipeline(
        pipeline_name="firmware_reporting",
        destination="postgres",
        dataset_name="bronze",
        progress="log",
    )
    info = pipeline.run([master_inventory(), firmware_inventory(), connectivity_status()])
    print(info)


if __name__ == "__main__":
    main()
