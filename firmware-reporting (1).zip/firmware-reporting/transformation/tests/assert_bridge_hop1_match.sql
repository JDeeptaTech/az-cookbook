-- Fails (returns rows) if <50% of master servers resolve through the firmware bridge.
-- A failing test here means the join topology is broken — investigate, don't ship.
with r as (
  select count(*) filter (where f.fw_serverid is not null)::numeric
         / nullif(count(*),0) as pct
  from {{ ref('stg_master') }} m
  left join {{ ref('stg_firmware') }} f on m.master_serverid = f.fw_serverid
)
select pct from r where pct < 0.50
