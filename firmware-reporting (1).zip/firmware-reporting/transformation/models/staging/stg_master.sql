-- Authoritative inventory. serverid is the key. lifecycle_state here = source of truth.
with src as (select * from {{ source('bronze', 'master_inventory') }})
select
    trim(serverid)                          as master_serverid,
    lower(trim(hostname))                    as hostname,
    upper(trim(country_code))                as country_code,
    nullif(trim(lifecycle_state), '')        as lifecycle_state,
    nullif(trim(business_line), '')          as business_line,
    nullif(trim(hosting_platform), '')       as hosting_platform,
    nullif(trim(environment), '')            as environment,
    _source_file, _ingested_at
from src
where nullif(trim(serverid), '') is not null
