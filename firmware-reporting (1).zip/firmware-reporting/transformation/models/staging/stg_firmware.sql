-- THE BRIDGE. Carries both serverid (->master) and name (->connectivity).
with src as (select * from {{ source('bronze', 'firmware_inventory') }})
select
    trim(serverid)                  as fw_serverid,     -- joins master.master_serverid
    lower(trim(name))               as fw_name,          -- joins connectivity.hostname
    lower(trim(serverhostname))     as fw_serverhostname,-- fallback hop to master.hostname
    nullif(trim(status), '')        as fw_status,
    nullif(trim(m_scope), '')       as m_scope,
    nullif(trim(upgrade_type), '')  as upgrade_type,
    nullif(trim(lookup_against_completed), '') as lookup_completed,
    nullif(trim(serverlifecyclestate), '')     as fw_lifecycle_state,
    nullif(trim(serverenvironment), '')        as fw_environment,
    _source_file, _ingested_at
from src
where nullif(trim(serverid), '') is not null
