-- Point-in-time reachability. One row per host per _load_date.
with src as (select * from {{ source('bronze', 'connectivity_status') }})
select
    lower(trim(host_name))           as hostname,        -- joins firmware.fw_name
    nullif(trim(status), '')         as conn_status,     -- Reachable / Not Reachable
    upper(trim(countrycode))         as country_code,
    nullif(trim(lifecyclestate_name), '') as conn_lifecycle_state,
    nullif(trim(dmz_non_dmz), '')    as dmz_zone,
    nullif(trim(group_assignee), '') as group_assignee,
    nullif(trim(action_on), '')      as action_owner,
    _load_date::date                 as load_date,
    _ingested_at
from src
where nullif(trim(host_name), '') is not null
