-- int_server_xref.sql
-- The conformed spine. FULL OUTER joins so orphans survive (they ARE the coverage report).
-- master ── firmware (bridge) ── connectivity. Anchored on whichever id exists.
with m as (select * from {{ ref('stg_master') }}),
     f as (select * from {{ ref('stg_firmware') }}),
     c as (
        -- collapse connectivity to latest state per host before joining
        select distinct on (hostname) hostname, conn_status, group_assignee,
               country_code as conn_country, load_date
        from {{ ref('stg_connectivity') }}
        order by hostname, load_date desc
     )
select
    {{ dbt_utils.generate_surrogate_key([
        'coalesce(m.master_serverid, f.fw_serverid, c.hostname)'
    ]) }}                                            as server_key,
    m.master_serverid,
    f.fw_serverid,
    f.fw_name,
    c.hostname                                       as conn_hostname,

    (m.master_serverid is not null)                  as in_master,
    (f.fw_serverid     is not null)                  as in_firmware,
    (c.hostname        is not null)                  as in_connectivity,

    -- master = source of truth for lifecycle; keep project copies for staleness checks
    m.lifecycle_state                                as master_lifecycle_state,
    f.fw_lifecycle_state,
    c.conn_status,
    m.environment, m.business_line,
    coalesce(m.country_code, c.conn_country)         as country_code,
    f.m_scope, f.upgrade_type, f.lookup_completed,
    c.group_assignee
from m
full outer join f on m.master_serverid = f.fw_serverid
full outer join c on f.fw_name        = c.hostname
