-- Completeness: of Live master servers, how many are missing from each project?
-- Plus orphans (no master row) = bad keys or shadow inventory.
with x as (select * from {{ ref('int_server_xref') }})
select 'live_master_not_in_firmware'      as gap, count(*) as servers from x
  where in_master and master_lifecycle_state = 'Live' and not in_firmware
union all
select 'live_master_not_in_connectivity',       count(*) from x
  where in_master and master_lifecycle_state = 'Live' and not in_connectivity
union all
select 'orphan_no_master',                       count(*) from x
  where not in_master
union all
select 'lifecycle_disagreement_master_demised',  count(*) from x
  where master_lifecycle_state = 'Demised' and fw_lifecycle_state = 'Live'
