-- Conformed server dimension. Master is source of truth; project attrs enrich.
select
    server_key, master_serverid, fw_serverid, fw_name, conn_hostname,
    master_lifecycle_state as lifecycle_state,
    country_code, environment, business_line,
    in_master, in_firmware, in_connectivity,
    m_scope, upgrade_type, conn_status, group_assignee
from {{ ref('int_server_xref') }}
