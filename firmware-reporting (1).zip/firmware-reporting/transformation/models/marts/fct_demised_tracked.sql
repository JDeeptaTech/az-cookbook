-- Risk/waste: servers master marks Demised but projects still actively track.
select
    coalesce(country_code, 'UNKNOWN')              as country_code,
    count(*) filter (where master_lifecycle_state = 'Demised' and in_connectivity) as demised_in_conn,
    count(*) filter (where master_lifecycle_state = 'Demised' and in_firmware)     as demised_in_fw,
    count(*) filter (where master_lifecycle_state = 'Demised'
                          and (in_firmware or in_connectivity))                    as demised_tracked_anywhere
from {{ ref('int_server_xref') }}
where master_lifecycle_state = 'Demised'
group by 1
order by demised_tracked_anywhere desc
