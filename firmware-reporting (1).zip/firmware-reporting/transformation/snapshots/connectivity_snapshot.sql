{% snapshot connectivity_snapshot %}
{{
  config(
    target_schema='silver',
    unique_key='hostname',
    strategy='check',
    check_cols=['conn_status', 'group_assignee', 'action_owner'],
    invalidate_hard_deletes=True
  )
}}
-- SCD2 over the latest connectivity load. Captures when a host flips
-- Reachable<->Not Reachable or changes owner, giving you reachability history
-- even though bronze only appends daily snapshots.
select * from {{ ref('stg_connectivity') }}
where load_date = (select max(load_date) from {{ ref('stg_connectivity') }})
{% endsnapshot %}
