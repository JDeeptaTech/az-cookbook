{% macro verify_bridge() %}
-- Run BEFORE building marts. Prints match rates for both bridge hops.
-- If either is low, the name=hostname / serverid topology is wrong — stop and rework.
{% set q %}
with hop1 as (
  select count(*) filter (where f.fw_serverid is not null) as matched,
         count(*) as master_rows
  from {{ ref('stg_master') }} m
  left join {{ ref('stg_firmware') }} f on m.master_serverid = f.fw_serverid
),
hop2 as (
  select count(*) filter (where c.hostname is not null) as matched,
         count(*) as fw_rows
  from {{ ref('stg_firmware') }} f
  left join (select distinct hostname from {{ ref('stg_connectivity') }}) c
    on f.fw_name = c.hostname
)
select 'hop1 master<->firmware.serverid' as hop, matched, master_rows as total,
       round(100.0*matched/nullif(master_rows,0),1) as pct from hop1
union all
select 'hop2 firmware.name<->connectivity', matched, fw_rows,
       round(100.0*matched/nullif(fw_rows,0),1) from hop2
{% endset %}
{% if execute %}
  {% set results = run_query(q) %}
  {% do log('=== BRIDGE MATCH RATES ===', info=True) %}
  {% for row in results.rows %}
    {% do log(row[0] ~ ': ' ~ row[1] ~ '/' ~ row[2] ~ ' (' ~ row[3] ~ '%)', info=True) %}
  {% endfor %}
{% endif %}
{% endmacro %}
