# Firmware Reporting

A small monolith for ingesting CSV exports from the Firmware Upgrade Programme,
modelling them with a medallion (bronze → silver → gold) architecture, and
publishing dashboards. Built for an MVP with a clear path to scale.

## Stack

| Layer          | Tool                                       |
|----------------|--------------------------------------------|
| Storage        | DuckDB (single-file analytical DB)         |
| Ingestion      | dlt — schema inference, incremental loads  |
| Transformation | dbt-duckdb — SQL models with tests + docs  |
| Orchestration  | APScheduler (cron) + Typer CLI             |
| Dashboard      | Streamlit + Plotly                         |
| Config         | pydantic-settings + `.env`                 |
| Logging        | structlog (console + file, JSON optional)  |

Everything runs in one Python process or one container. When you outgrow
APScheduler, swap it for Dagster/Prefect — `run_etl()` does not change.

## Architecture

```
data/raw/*.csv ──► dlt ──► DuckDB(bronze)
                                 │
                              dbt run
                                 │
                          ┌──────┴──────┐
                          │             │
                       silver.*       gold.*
                                        │
                                        ▼
                                   Streamlit
                                        ▲
                                        │
                                  cron / on-demand
                                  (same run_etl())
```

## Quickstart

```bash
# 1. install
make dev-install

# 2. drop CSVs in data/raw/ (or generate sample data)
make sample-data

# 3. run the full ETL once
make etl

# 4. open the dashboard
make dashboard            # http://localhost:8501

# 5. (optional) run the scheduler in another terminal
make scheduler
```

## CLI

The `fwr` command is the operator's friend.

```
fwr ingest                          # bronze only
fwr ingest --source server_inventory
fwr transform                       # dbt only
fwr transform --select +gold.rag_summary --full-refresh
fwr etl                             # full pipeline (used by scheduler too)
fwr etl --skip-transform            # bronze only via the orchestrator
fwr etl --no-tests                  # skip dbt tests
fwr scheduler                       # run cron scheduler in foreground
fwr dashboard                       # launch Streamlit
fwr db                              # DuckDB CLI on the warehouse
fwr sources                         # list configured sources
fwr status                          # last 5 ETL run summaries
fwr deps                            # install dbt packages
```

## Configuration

All config is via env vars (or `.env`), prefixed `FWR_`. See `.env.example`.

| Var                          | Default              | Notes                              |
|------------------------------|----------------------|------------------------------------|
| `FWR_SCHEDULE_CRON`          | `0 6 * * *`          | 5-field cron                       |
| `FWR_SCHEDULER_TIMEZONE`     | `Europe/London`      | Any IANA TZ                        |
| `FWR_WAREHOUSE_PATH`         | `warehouse.duckdb`   | Relative to project root           |
| `FWR_DATA_RAW_DIR`           | `data/raw`           | Where new CSVs are dropped         |
| `FWR_DATA_ARCHIVE_DIR`       | `data/archive`       | Loaded files are moved here        |
| `FWR_ARCHIVE_AFTER_LOAD`     | `true`               | Set false to keep files in raw/    |
| `FWR_FAIL_FAST`              | `false`              | If true, an ingest error stops all |
| `FWR_LOG_LEVEL`              | `INFO`               |                                    |
| `FWR_LOG_JSON`               | `false`              | Set true for production logs       |
| `FWR_DASHBOARD_PORT`         | `8501`               |                                    |

## Adding a new source

Two steps:

1. Add a `SourceSpec` to `src/firmware_reporting/ingest/sources.py`:
   ```python
   SourceSpec(
       name="aap_jobs",
       table_name="aap_jobs",
       pattern="aap_jobs_*.csv",
       primary_key=("job_id",),
       write_disposition="merge",
       description="Ansible Automation Platform job runs.",
   ),
   ```
2. Drop matching files in `data/raw/`. Next `fwr ingest` picks them up.

To model them, add SQL files under `dbt_project/models/silver/` and `gold/`.

## Project layout

```
firmware-reporting/
├── pyproject.toml              # deps + `fwr` entry point
├── Makefile                    # all common operations
├── Dockerfile + docker-compose # containerised deploy
├── .env.example                # config reference
│
├── data/
│   ├── raw/                    # drop CSVs here
│   └── archive/YYYY/MM/DD/     # auto-archived loads
├── logs/                       # rotating logs + per-run JSON summaries
├── warehouse.duckdb            # the entire DB, one file
│
├── src/firmware_reporting/
│   ├── settings.py             # pydantic-settings
│   ├── orchestrator.py         # the single run_etl() entrypoint
│   ├── cli.py                  # `fwr ...`
│   ├── ingest/
│   │   ├── sources.py          # declarative source registry
│   │   └── pipeline.py         # dlt → DuckDB bronze
│   ├── transform/runner.py     # subprocess wrapper around dbt
│   ├── scheduler/scheduler.py  # APScheduler with cron
│   ├── dashboard/app.py        # Streamlit
│   └── utils/logging.py        # structlog
│
├── dbt_project/
│   ├── dbt_project.yml + profiles.yml
│   ├── macros/                 # generate_schema_name override
│   └── models/
│       ├── bronze/_sources.yml
│       ├── silver/             # cleaned, typed, deduped
│       └── gold/               # marts the dashboard reads
│
├── scripts/
│   ├── generate_sample_data.py # produces realistic CSVs
│   └── fwr-*.service           # systemd units
│
└── tests/                      # pytest
```

## Medallion layout

**Bronze** — raw, append-only, written by dlt. Every row carries
`_ingested_at`, `_source_file`, `_file_hash` for lineage.

**Silver** — cleaned and typed. Region normalised, booleans cast, owners
deduped, status enums uppercased. Tested for not-null and uniqueness.

**Gold** — marts. Single-row KPI summaries, region pivots, burndown time
series, owner follow-up. The dashboard reads only from gold.

## Operating

### On-demand
```bash
fwr etl                              # full pipeline
fwr etl --source server_inventory    # subset
fwr etl --full-refresh               # rebuild from scratch
```
The dashboard sidebar also has a **▶ Run full ETL now** button.

### Scheduled
```bash
fwr scheduler   # runs in foreground; supervise with systemd / docker
```
Cron is configured via `FWR_SCHEDULE_CRON`. Default: `0 6 * * *`
(06:00 daily, Europe/London).

### Production deploy

**systemd** (recommended for a VM):
```bash
sudo cp scripts/fwr-scheduler.service /etc/systemd/system/
sudo cp scripts/fwr-dashboard.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now fwr-scheduler fwr-dashboard
journalctl -u fwr-scheduler -f
```

**Docker Compose**:
```bash
docker compose up -d
docker compose logs -f scheduler
```

## Run summaries

Every ETL run is persisted to `logs/etl_run_<UTC_TIMESTAMP>.json` with
ingest counts, dbt return codes, and a tail of stdout. View recent runs:
```bash
fwr status
```

## Tests

```bash
make test                  # pytest smoke tests
cd dbt_project && dbt test --profiles-dir .   # SQL data tests
```

## When to outgrow this

- Replace **APScheduler** with **Dagster** or **Prefect** when you need
  retries-with-backoff, cross-pipeline dependencies, or remote execution.
  `run_etl()` is the seam.
- Replace **DuckDB** with **PostgreSQL** by changing the dbt profile
  destination and pointing dlt at Postgres. Models do not change.
- Replace **CSVs** with **DB extracts / API pulls** by adding new dlt
  resources next to the existing CSV reader. The medallion stays the same.
- Replace **Streamlit** with **Evidence.dev** (git-versioned reports) or
  **Superset** (self-serve BI) by pointing them at the same DuckDB / Postgres.
