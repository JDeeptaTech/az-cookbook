"""
Gold sync: export every gold.* table from DuckDB into a dedicated Postgres
schema that Grafana reads.

Design notes
------------
- Runs as the last step of run_etl() when FWR_POSTGRES_URL is set.
- Each sync is a full replace of the target table (gold marts are small).
- Uses pandas + SQLAlchemy so no DuckDB Postgres extension is needed.
- The Postgres schema is created if it doesn't exist.
- Idempotent: safe to call multiple times.
"""
from __future__ import annotations

from datetime import datetime, timezone
from typing import Any

import duckdb
import pandas as pd

from firmware_reporting.settings import get_settings
from firmware_reporting.utils.logging import get_logger

log = get_logger(__name__)

GOLD_TABLES = [
    "rag_summary",
    "region_status",
    "firmware_burndown",
    "so_followup_by_owner",
    "dmz_blockers",
]


def _engine():
    """Build a SQLAlchemy engine. Lazy import so psycopg2 is optional."""
    try:
        from sqlalchemy import create_engine, text
    except ImportError as e:
        raise RuntimeError(
            "sqlalchemy is required for Postgres sync. "
            "Run: pip install sqlalchemy psycopg2-binary"
        ) from e
    settings = get_settings()
    engine = create_engine(settings.postgres_url)
    schema = settings.postgres_schema
    with engine.connect() as conn:
        conn.execute(text(f"CREATE SCHEMA IF NOT EXISTS {schema}"))
        conn.commit()
    return engine


def run_gold_sync() -> dict[str, Any]:
    """
    Read every gold table from DuckDB, write to Postgres.
    Returns a summary dict. Skips gracefully if POSTGRES_URL is not set.
    """
    settings = get_settings()
    if not settings.postgres_url:
        log.info("gold_sync_skipped", reason="FWR_POSTGRES_URL not set")
        return {"status": "skipped", "reason": "no postgres_url"}

    summary: dict[str, Any] = {
        "started_at": datetime.now(timezone.utc).isoformat(),
        "tables": {},
    }

    try:
        engine = _engine()
    except Exception as e:
        log.error("gold_sync_engine_failed", error=str(e))
        return {"status": "failed", "error": str(e)}

    con = duckdb.connect(str(settings.warehouse), read_only=True)
    schema = settings.postgres_schema

    for table in GOLD_TABLES:
        try:
            df: pd.DataFrame = con.execute(f"SELECT * FROM gold.{table}").fetch_df()

            # Cast Timestamps that SQLAlchemy/PG can't handle directly
            for col in df.select_dtypes(include=["datetime64[ns, UTC]", "datetimetz"]).columns:
                df[col] = df[col].dt.tz_localize(None)

            df.to_sql(
                name=table,
                con=engine,
                schema=schema,
                if_exists="replace",
                index=False,
                method="multi",
                chunksize=500,
            )
            log.info("gold_sync_table_ok", table=table, rows=len(df))
            summary["tables"][table] = {"rows": len(df), "status": "ok"}
        except Exception as e:  # noqa: BLE001
            log.error("gold_sync_table_failed", table=table, error=str(e))
            summary["tables"][table] = {"status": "failed", "error": str(e)}

    con.close()
    summary["status"] = (
        "success"
        if all(v.get("status") == "ok" for v in summary["tables"].values())
        else "partial"
    )
    summary["finished_at"] = datetime.now(timezone.utc).isoformat()
    return summary
