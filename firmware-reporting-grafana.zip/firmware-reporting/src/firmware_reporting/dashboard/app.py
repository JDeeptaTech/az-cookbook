"""
Streamlit dashboard - reads from gold.* tables in the DuckDB warehouse.

Run with:    fwr dashboard
            (or)  streamlit run src/firmware_reporting/dashboard/app.py
"""
from __future__ import annotations

import json
from datetime import datetime

import duckdb
import pandas as pd
import plotly.express as px
import streamlit as st

from firmware_reporting.orchestrator import run_etl
from firmware_reporting.settings import get_settings

st.set_page_config(
    page_title="Firmware Upgrade Programme",
    page_icon="🔧",
    layout="wide",
)

settings = get_settings()


@st.cache_resource
def get_conn() -> duckdb.DuckDBPyConnection:
    # read_only so multiple Streamlit reruns don't clash with scheduled writes
    return duckdb.connect(str(settings.warehouse), read_only=True)


def query(sql: str) -> pd.DataFrame:
    try:
        return get_conn().execute(sql).fetch_df()
    except Exception as e:
        st.error(f"Query failed: {e}")
        return pd.DataFrame()


def table_exists(fqn: str) -> bool:
    schema, table = fqn.split(".")
    df = query(
        f"""
        SELECT 1 FROM information_schema.tables
        WHERE table_schema = '{schema}' AND table_name = '{table}'
        """
    )
    return not df.empty


# ---------- Sidebar ----------
with st.sidebar:
    st.title("🔧 Firmware Reporting")
    st.caption(f"Warehouse: `{settings.warehouse.name}`")

    st.divider()
    st.subheader("On-demand ETL")
    if st.button("▶ Run full ETL now", use_container_width=True):
        with st.spinner("Running ETL..."):
            summary = run_etl()
        if summary.get("status") == "success":
            st.success(f"ETL completed: {summary['run_id']}")
        else:
            st.error(f"ETL: {summary.get('status')}")
        st.json(summary, expanded=False)
        get_conn().close()
        st.cache_resource.clear()

    if st.button("🥉 Bronze only", use_container_width=True):
        with st.spinner("Ingesting..."):
            summary = run_etl(skip_transform=True)
        st.json(summary, expanded=False)

    st.divider()
    st.subheader("Recent runs")
    runs = sorted(settings.log_dir.glob("etl_run_*.json"), reverse=True)[:5]
    for r in runs:
        try:
            data = json.loads(r.read_text())
            status = data.get("status", "?")
            icon = "✅" if status == "success" else "❌" if "fail" in status else "⚠️"
            st.caption(f"{icon} {data.get('run_id')} — {status}")
        except Exception:  # noqa: BLE001
            pass

# ---------- Header ----------
st.title("Firmware Upgrade Programme — Status")
st.caption(f"Last viewed: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")

if not settings.warehouse.exists():
    st.warning(
        "No warehouse yet. Drop CSVs into `data/raw/` and click **Run full ETL now** "
        "in the sidebar (or run `fwr etl` from the terminal)."
    )
    st.stop()

# ---------- KPI strip ----------
if table_exists("gold.rag_summary"):
    rag = query("SELECT * FROM gold.rag_summary LIMIT 1")
    if not rag.empty:
        c1, c2, c3, c4 = st.columns(4)
        c1.metric("Overall RAG", rag.iloc[0].get("overall_rag", "?"))
        c2.metric("% Complete", f"{rag.iloc[0].get('pct_complete', 0):.1f}%")
        c3.metric("Servers Upgraded", int(rag.iloc[0].get("upgraded", 0)))
        c4.metric("Pending", int(rag.iloc[0].get("pending", 0)))
else:
    st.info("Gold tables not built yet. Run the ETL from the sidebar.")

# ---------- Burndown ----------
st.subheader("Firmware Burndown")
if table_exists("gold.firmware_burndown"):
    bd = query("SELECT * FROM gold.firmware_burndown ORDER BY snapshot_date")
    if not bd.empty:
        fig = px.line(
            bd.melt(id_vars=["snapshot_date"], var_name="series", value_name="remaining"),
            x="snapshot_date",
            y="remaining",
            color="series",
            markers=True,
        )
        st.plotly_chart(fig, use_container_width=True)
else:
    st.caption("`gold.firmware_burndown` not available.")

# ---------- Region split + DMZ blockers ----------
col_a, col_b = st.columns(2)

with col_a:
    st.subheader("By Region")
    if table_exists("gold.region_status"):
        df = query("SELECT * FROM gold.region_status")
        if not df.empty:
            fig = px.bar(df, x="region", y=["upgraded", "pending"], barmode="stack")
            st.plotly_chart(fig, use_container_width=True)
            st.dataframe(df, use_container_width=True, hide_index=True)

with col_b:
    st.subheader("DMZ Blockers")
    if table_exists("gold.dmz_blockers"):
        df = query("SELECT * FROM gold.dmz_blockers ORDER BY pending_count DESC LIMIT 20")
        st.dataframe(df, use_container_width=True, hide_index=True)

# ---------- SO follow-up ----------
st.subheader("Service Owner Follow-up")
if table_exists("gold.so_followup_by_owner"):
    so = query(
        """
        SELECT * FROM gold.so_followup_by_owner
        ORDER BY pending DESC
        LIMIT 50
        """
    )
    st.dataframe(so, use_container_width=True, hide_index=True)
