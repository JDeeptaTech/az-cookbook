"""
Background scheduler. Long-running process that triggers run_etl() on a cron
schedule. Also exposes an in-memory record of recent runs for the dashboard.

For a monolith MVP this is fine. When you outgrow it, swap APScheduler for
Dagster/Prefect without changing run_etl().
"""
from __future__ import annotations

import signal
import threading
from collections import deque
from datetime import datetime, timezone
from typing import Any

from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.schedulers.blocking import BlockingScheduler
from apscheduler.triggers.cron import CronTrigger

from firmware_reporting.orchestrator import run_etl
from firmware_reporting.settings import get_settings
from firmware_reporting.utils.logging import configure_logging, get_logger

log = get_logger(__name__)

# Thread-safe ring buffer of recent runs (also persisted to logs/)
_RUN_HISTORY: deque[dict[str, Any]] = deque(maxlen=50)
_HISTORY_LOCK = threading.Lock()


def get_run_history() -> list[dict[str, Any]]:
    with _HISTORY_LOCK:
        return list(_RUN_HISTORY)


def _scheduled_job() -> None:
    log.info("scheduled_job_triggered")
    try:
        summary = run_etl()
    except Exception as e:  # noqa: BLE001
        log.error("scheduled_job_crashed", error=str(e), exc_info=True)
        summary = {
            "status": "crashed",
            "error": str(e),
            "finished_at": datetime.now(timezone.utc).isoformat(),
        }
    with _HISTORY_LOCK:
        _RUN_HISTORY.append(summary)


def _build_trigger(cron_expr: str, tz: str) -> CronTrigger:
    parts = cron_expr.split()
    if len(parts) != 5:
        raise ValueError(f"Cron expr must have 5 fields, got: {cron_expr!r}")
    minute, hour, day, month, day_of_week = parts
    return CronTrigger(
        minute=minute,
        hour=hour,
        day=day,
        month=month,
        day_of_week=day_of_week,
        timezone=tz,
    )


def start_blocking() -> None:
    """Start a foreground scheduler (used by `fwr scheduler`)."""
    configure_logging()
    settings = get_settings()
    log.info(
        "scheduler_starting",
        cron=settings.schedule_cron,
        tz=settings.scheduler_timezone,
    )

    scheduler = BlockingScheduler(timezone=settings.scheduler_timezone)
    scheduler.add_job(
        _scheduled_job,
        trigger=_build_trigger(settings.schedule_cron, settings.scheduler_timezone),
        id="etl_main",
        name="firmware_reporting_etl",
        replace_existing=True,
        max_instances=1,
        coalesce=True,
        misfire_grace_time=60 * 30,
    )

    def _shutdown(signum, frame):  # noqa: ARG001
        log.info("scheduler_shutdown_signal", signum=signum)
        scheduler.shutdown(wait=False)

    signal.signal(signal.SIGINT, _shutdown)
    signal.signal(signal.SIGTERM, _shutdown)

    log.info("scheduler_running", next_run="see logs")
    scheduler.start()


def start_background() -> BackgroundScheduler:
    """Start a background scheduler (used when running inside another process)."""
    settings = get_settings()
    scheduler = BackgroundScheduler(timezone=settings.scheduler_timezone)
    scheduler.add_job(
        _scheduled_job,
        trigger=_build_trigger(settings.schedule_cron, settings.scheduler_timezone),
        id="etl_main",
        replace_existing=True,
        max_instances=1,
        coalesce=True,
    )
    scheduler.start()
    log.info("background_scheduler_started")
    return scheduler
