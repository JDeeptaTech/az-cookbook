"""Firmware Upgrade Programme reporting platform."""
__version__ = "0.1.0"
