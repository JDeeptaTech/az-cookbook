"""Bronze layer ingestion."""
from firmware_reporting.ingest.pipeline import run_ingest
from firmware_reporting.ingest.sources import SOURCES, SourceSpec, get_source

__all__ = ["run_ingest", "SOURCES", "SourceSpec", "get_source"]
