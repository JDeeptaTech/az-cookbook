"""
Source registry: declarative description of every CSV source.

To add a new source: append a SourceSpec below. The ingestion pipeline
discovers files matching `pattern` under data/raw/, types them, and loads
them into bronze.<table_name>.
"""
from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True)
class SourceSpec:
    name: str                         # logical name
    table_name: str                   # bronze.<table_name>
    pattern: str                      # glob under data/raw/, e.g. "server_inventory_*.csv"
    primary_key: tuple[str, ...] = ()  # used for upsert / dedup in silver
    write_disposition: str = "append"  # dlt: "append" | "merge" | "replace"
    description: str = ""
    tags: tuple[str, ...] = field(default_factory=tuple)


SOURCES: list[SourceSpec] = [
    SourceSpec(
        name="server_inventory",
        table_name="server_inventory",
        pattern="server_inventory_*.csv",
        primary_key=("serverid",),
        write_disposition="merge",
        description="Master HSBC server inventory (UnicornGlobalExports).",
        tags=("inventory", "weekly"),
    ),
    SourceSpec(
        name="firmware_status",
        table_name="firmware_status",
        pattern="firmware_status_*.csv",
        primary_key=("serverid", "snapshot_date"),
        write_disposition="merge",
        description="Per-server firmware upgrade status snapshots.",
        tags=("status", "weekly"),
    ),
    SourceSpec(
        name="so_followup",
        table_name="so_followup",
        pattern="so_followup_*.csv",
        primary_key=("so_name", "snapshot_date"),
        write_disposition="merge",
        description="Service Owner follow-up: completed vs pending counts.",
        tags=("ownership", "weekly"),
    ),
    SourceSpec(
        name="ssl_cert_venafi",
        table_name="ssl_cert_venafi",
        pattern="ssl_cert_*.csv",
        primary_key=("serverid", "cert_id"),
        write_disposition="merge",
        description="Monthly Venafi SSL cert renewal export.",
        tags=("ssl", "monthly"),
    ),
    SourceSpec(
        name="weekly_progress",
        table_name="weekly_progress",
        pattern="weekly_progress_*.csv",
        primary_key=("week_number", "year"),
        write_disposition="merge",
        description="Planned vs Approved vs Completed per week.",
        tags=("progress", "weekly"),
    ),
]


def get_source(name: str) -> SourceSpec:
    for s in SOURCES:
        if s.name == name:
            return s
    raise KeyError(f"Unknown source: {name}. Known: {[s.name for s in SOURCES]}")
