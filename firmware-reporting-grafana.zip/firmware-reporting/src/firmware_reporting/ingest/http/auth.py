"""
Authentication strategies for HTTP extraction.

Each strategy implements `apply(request)` which mutates the outgoing request
(adds headers / params). Strategies are pure data + a small bit of behaviour
so they can be constructed from YAML config and reused across extractors.

Adding a new auth scheme:
    1. Subclass `AuthStrategy`
    2. Register it in AUTH_STRATEGIES at the bottom of this module
    3. Reference it by `type:` in your extractor YAML
"""
from __future__ import annotations

import base64
import os
import time
from dataclasses import dataclass, field
from typing import Any, ClassVar

import httpx


def _resolve_secret(value: str | None) -> str | None:
    """Resolve `${ENV_VAR}` references against os.environ.

    A literal value is returned unchanged. Missing env vars raise so config
    errors surface at startup rather than mid-extraction.
    """
    if value is None:
        return None
    if value.startswith("${") and value.endswith("}"):
        var = value[2:-1]
        resolved = os.environ.get(var)
        if resolved is None:
            raise RuntimeError(f"Required env var {var!r} not set (referenced in auth config)")
        return resolved
    return value


class AuthStrategy:
    """Abstract auth strategy. Subclasses implement `apply`."""

    type_name: ClassVar[str] = ""

    def apply(self, request: httpx.Request) -> None:
        raise NotImplementedError

    @classmethod
    def from_config(cls, cfg: dict[str, Any]) -> AuthStrategy:
        type_name = cfg.get("type")
        if type_name not in AUTH_STRATEGIES:
            raise ValueError(
                f"Unknown auth type {type_name!r}. Known: {list(AUTH_STRATEGIES)}"
            )
        impl = AUTH_STRATEGIES[type_name]
        return impl._build(cfg)  # type: ignore[attr-defined]


@dataclass
class NoAuth(AuthStrategy):
    """Public endpoints / internal services with network-level auth."""

    type_name: ClassVar[str] = "none"

    def apply(self, request: httpx.Request) -> None:
        return None

    @classmethod
    def _build(cls, cfg: dict[str, Any]) -> NoAuth:  # noqa: ARG003
        return cls()


@dataclass
class BearerToken(AuthStrategy):
    """`Authorization: Bearer <token>`. Common for AAP, GitHub, internal APIs."""

    type_name: ClassVar[str] = "bearer"
    token: str = ""

    def apply(self, request: httpx.Request) -> None:
        request.headers["Authorization"] = f"Bearer {self.token}"

    @classmethod
    def _build(cls, cfg: dict[str, Any]) -> BearerToken:
        token = _resolve_secret(cfg.get("token"))
        if not token:
            raise ValueError("bearer auth requires `token`")
        return cls(token=token)


@dataclass
class BasicAuth(AuthStrategy):
    """HTTP Basic. Common for ServiceNow Table API, legacy systems."""

    type_name: ClassVar[str] = "basic"
    username: str = ""
    password: str = ""

    def apply(self, request: httpx.Request) -> None:
        creds = f"{self.username}:{self.password}".encode()
        request.headers["Authorization"] = f"Basic {base64.b64encode(creds).decode()}"

    @classmethod
    def _build(cls, cfg: dict[str, Any]) -> BasicAuth:
        u = _resolve_secret(cfg.get("username"))
        p = _resolve_secret(cfg.get("password"))
        if not u or not p:
            raise ValueError("basic auth requires `username` and `password`")
        return cls(username=u, password=p)


@dataclass
class ApiKeyHeader(AuthStrategy):
    """API key in a custom header (e.g. `X-API-Key`, `apikey`)."""

    type_name: ClassVar[str] = "api_key_header"
    header: str = "X-API-Key"
    key: str = ""

    def apply(self, request: httpx.Request) -> None:
        request.headers[self.header] = self.key

    @classmethod
    def _build(cls, cfg: dict[str, Any]) -> ApiKeyHeader:
        key = _resolve_secret(cfg.get("key"))
        if not key:
            raise ValueError("api_key_header requires `key`")
        return cls(header=cfg.get("header", "X-API-Key"), key=key)


@dataclass
class OAuth2ClientCredentials(AuthStrategy):
    """
    OAuth2 client credentials grant. Used for Azure AD (Resource Graph,
    Azure Management API), Okta machine-to-machine, etc.

    Tokens are cached in-memory and refreshed when they hit `expires_at - 60s`.
    """

    type_name: ClassVar[str] = "oauth2_client_credentials"
    token_url: str = ""
    client_id: str = ""
    client_secret: str = ""
    scope: str | None = None
    extra_params: dict[str, str] = field(default_factory=dict)

    # state
    _access_token: str | None = field(default=None, repr=False, init=False)
    _expires_at: float = field(default=0.0, repr=False, init=False)

    def apply(self, request: httpx.Request) -> None:
        if not self._access_token or time.time() >= self._expires_at - 60:
            self._refresh()
        request.headers["Authorization"] = f"Bearer {self._access_token}"

    def _refresh(self) -> None:
        data = {
            "grant_type": "client_credentials",
            "client_id": self.client_id,
            "client_secret": self.client_secret,
            **self.extra_params,
        }
        if self.scope:
            data["scope"] = self.scope
        with httpx.Client(timeout=30.0) as c:
            resp = c.post(self.token_url, data=data)
            resp.raise_for_status()
            payload = resp.json()
        self._access_token = payload["access_token"]
        self._expires_at = time.time() + int(payload.get("expires_in", 3600))

    @classmethod
    def _build(cls, cfg: dict[str, Any]) -> OAuth2ClientCredentials:
        return cls(
            token_url=cfg["token_url"],
            client_id=_resolve_secret(cfg["client_id"]) or "",
            client_secret=_resolve_secret(cfg["client_secret"]) or "",
            scope=cfg.get("scope"),
            extra_params=cfg.get("extra_params", {}) or {},
        )


AUTH_STRATEGIES: dict[str, type[AuthStrategy]] = {
    NoAuth.type_name: NoAuth,
    BearerToken.type_name: BearerToken,
    BasicAuth.type_name: BasicAuth,
    ApiKeyHeader.type_name: ApiKeyHeader,
    OAuth2ClientCredentials.type_name: OAuth2ClientCredentials,
}
