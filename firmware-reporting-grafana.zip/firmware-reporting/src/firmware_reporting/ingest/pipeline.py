"""
Bronze layer ingestion using dlt.

Each source is a separate dlt resource so we get per-source state, schemas,
and incremental load tracking without rolling our own.
"""
from __future__ import annotations

import hashlib
import shutil
from collections.abc import Iterator
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import dlt
import pandas as pd

from firmware_reporting.ingest.sources import SOURCES, SourceSpec, get_source
from firmware_reporting.settings import get_settings
from firmware_reporting.utils.logging import get_logger

log = get_logger(__name__)


def _file_hash(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 16), b""):
            h.update(chunk)
    return h.hexdigest()


def _read_csv_with_metadata(path: Path, source_name: str) -> Iterator[dict[str, Any]]:
    """Stream rows from a CSV, normalising columns and adding lineage cols."""
    log.info("reading_csv", path=str(path), source=source_name)

    # pandas handles dirty CSVs (mixed types, #N/A) better than dlt's built-in reader
    df = pd.read_csv(
        path,
        dtype=str,                 # everything as string in bronze; cast in silver
        keep_default_na=False,
        na_values=["", "#N/A", "N/A", "NA", "null", "NULL"],
        on_bad_lines="warn",
    )

    # normalise column names: lower_snake_case
    df.columns = [
        c.strip().replace(" ", "_").replace("-", "_").lower()
        for c in df.columns
    ]

    ingested_at = datetime.now(timezone.utc).isoformat()
    src_file = path.name
    src_hash = _file_hash(path)

    for row in df.to_dict(orient="records"):
        row["_ingested_at"] = ingested_at
        row["_source_file"] = src_file
        row["_file_hash"] = src_hash
        yield row


def _archive(path: Path) -> None:
    settings = get_settings()
    dest_dir = settings.archive_dir / datetime.now().strftime("%Y/%m/%d")
    dest_dir.mkdir(parents=True, exist_ok=True)
    dest = dest_dir / path.name
    shutil.move(str(path), str(dest))
    log.info("archived", src=str(path), dest=str(dest))


def _build_resource(spec: SourceSpec, files: list[Path]):
    """Create a dlt resource for a given source and its discovered files."""

    @dlt.resource(
        name=spec.table_name,
        primary_key=list(spec.primary_key) if spec.primary_key else None,
        write_disposition=spec.write_disposition,  # type: ignore[arg-type]
    )
    def _resource() -> Iterator[dict[str, Any]]:
        for f in files:
            yield from _read_csv_with_metadata(f, spec.name)

    return _resource


def run_ingest(source_names: list[str] | None = None) -> dict[str, Any]:
    """
    Run the bronze ingestion. If source_names is None, runs all sources.
    Returns a summary dict.
    """
    settings = get_settings()
    settings.raw_dir.mkdir(parents=True, exist_ok=True)

    targets = (
        [get_source(n) for n in source_names] if source_names else list(SOURCES)
    )

    pipeline = dlt.pipeline(
        pipeline_name="firmware_bronze",
        destination=dlt.destinations.duckdb(str(settings.warehouse)),
        dataset_name="bronze",
        progress="log",
    )

    summary: dict[str, Any] = {
        "started_at": datetime.now(timezone.utc).isoformat(),
        "sources": {},
        "total_files": 0,
    }

    resources = []
    files_by_source: dict[str, list[Path]] = {}

    for spec in targets:
        files = sorted(settings.raw_dir.glob(spec.pattern))
        files_by_source[spec.name] = files
        if not files:
            log.warning("no_files_found", source=spec.name, pattern=spec.pattern)
            summary["sources"][spec.name] = {"files": 0, "status": "skipped"}
            continue
        log.info("source_discovered", source=spec.name, file_count=len(files))
        summary["total_files"] += len(files)
        resources.append(_build_resource(spec, files))

    if not resources:
        log.warning("nothing_to_ingest")
        summary["status"] = "no_op"
        return summary

    try:
        load_info = pipeline.run(resources)
        log.info("ingest_complete", load_info=str(load_info))
        summary["status"] = "success"
        summary["load_info"] = str(load_info)
    except Exception as e:
        log.error("ingest_failed", error=str(e), exc_info=True)
        summary["status"] = "failed"
        summary["error"] = str(e)
        if settings.fail_fast:
            raise
        return summary

    # archive successfully loaded files
    if settings.archive_after_load:
        for spec in targets:
            for f in files_by_source.get(spec.name, []):
                try:
                    _archive(f)
                except Exception as e:  # noqa: BLE001
                    log.error("archive_failed", file=str(f), error=str(e))
            summary["sources"][spec.name] = {
                "files": len(files_by_source.get(spec.name, [])),
                "status": "loaded",
            }

    summary["finished_at"] = datetime.now(timezone.utc).isoformat()
    return summary
