"""Structured logging configured once at startup."""
from __future__ import annotations

import logging
import sys
from pathlib import Path

import structlog

from firmware_reporting.settings import get_settings


def configure_logging() -> None:
    """Configure structlog + stdlib logging. Idempotent."""
    settings = get_settings()
    settings.log_dir.mkdir(parents=True, exist_ok=True)

    log_file = settings.log_dir / "firmware_reporting.log"

    # stdlib handlers (console + rotating file)
    handlers: list[logging.Handler] = [logging.StreamHandler(sys.stdout)]
    file_handler = logging.FileHandler(log_file, encoding="utf-8")
    handlers.append(file_handler)

    logging.basicConfig(
        format="%(message)s",
        level=settings.log_level,
        handlers=handlers,
        force=True,
    )

    processors: list = [
        structlog.contextvars.merge_contextvars,
        structlog.processors.add_log_level,
        structlog.processors.TimeStamper(fmt="iso"),
        structlog.processors.StackInfoRenderer(),
        structlog.processors.format_exc_info,
    ]
    if settings.log_json:
        processors.append(structlog.processors.JSONRenderer())
    else:
        processors.append(structlog.dev.ConsoleRenderer(colors=True))

    structlog.configure(
        processors=processors,
        wrapper_class=structlog.make_filtering_bound_logger(
            logging.getLevelName(settings.log_level)
        ),
        logger_factory=structlog.stdlib.LoggerFactory(),
        cache_logger_on_first_use=True,
    )


def get_logger(name: str | None = None) -> structlog.stdlib.BoundLogger:
    return structlog.get_logger(name)
