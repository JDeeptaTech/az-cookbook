"""
Run dbt as a subprocess. Keeping dbt as the transformation engine means
SQL stays in version-controlled .sql files with tests, lineage, and docs
- exactly what platform engineering wants.
"""
from __future__ import annotations

import os
import subprocess
from datetime import datetime, timezone
from typing import Any

from firmware_reporting.settings import get_settings
from firmware_reporting.utils.logging import get_logger

log = get_logger(__name__)


def _run(cmd: list[str], cwd: str) -> subprocess.CompletedProcess:
    log.info("dbt_exec", cmd=" ".join(cmd), cwd=cwd)
    proc = subprocess.run(
        cmd,
        cwd=cwd,
        capture_output=True,
        text=True,
        env={**os.environ},
    )
    if proc.returncode != 0:
        log.error("dbt_failed", stdout=proc.stdout, stderr=proc.stderr)
    else:
        log.info("dbt_ok")
    return proc


def run_transform(
    select: str | None = None,
    full_refresh: bool = False,
    run_tests: bool = True,
) -> dict[str, Any]:
    """
    Execute `dbt run` then `dbt test` against the project.

    Args:
        select: optional dbt selector e.g. "silver.* gold.*" or "+gold.firmware_burndown"
        full_refresh: pass --full-refresh
        run_tests: also run `dbt test`
    """
    settings = get_settings()
    cwd = str(settings.dbt_dir)
    summary: dict[str, Any] = {
        "started_at": datetime.now(timezone.utc).isoformat(),
        "select": select,
        "full_refresh": full_refresh,
    }

    run_cmd = ["dbt", "run", "--profiles-dir", cwd]
    if select:
        run_cmd += ["--select", select]
    if full_refresh:
        run_cmd.append("--full-refresh")

    proc = _run(run_cmd, cwd)
    summary["run_returncode"] = proc.returncode
    summary["run_stdout_tail"] = proc.stdout[-2000:]
    if proc.returncode != 0:
        summary["status"] = "run_failed"
        return summary

    if run_tests:
        test_cmd = ["dbt", "test", "--profiles-dir", cwd]
        if select:
            test_cmd += ["--select", select]
        tproc = _run(test_cmd, cwd)
        summary["test_returncode"] = tproc.returncode
        summary["test_stdout_tail"] = tproc.stdout[-2000:]
        summary["status"] = "success" if tproc.returncode == 0 else "tests_failed"
    else:
        summary["status"] = "success"

    summary["finished_at"] = datetime.now(timezone.utc).isoformat()
    return summary


def dbt_deps() -> int:
    """Install dbt packages declared in packages.yml."""
    settings = get_settings()
    proc = _run(["dbt", "deps", "--profiles-dir", str(settings.dbt_dir)], str(settings.dbt_dir))
    return proc.returncode
