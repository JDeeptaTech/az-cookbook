{# 
  Override default schema naming: use the custom schema as-is (no prefix).
  Without this, dbt-duckdb produces 'main_silver' etc. With this, we get
  clean 'silver' and 'gold' schemas matching what bronze (written by dlt) uses.
#}
{% macro generate_schema_name(custom_schema_name, node) -%}
    {%- if custom_schema_name is none -%}
        {{ target.schema }}
    {%- else -%}
        {{ custom_schema_name | trim }}
    {%- endif -%}
{%- endmacro %}
