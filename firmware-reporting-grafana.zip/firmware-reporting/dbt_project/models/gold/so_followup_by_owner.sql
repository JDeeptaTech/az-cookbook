{{ config(materialized='table') }}

-- gold.so_followup_by_owner
-- Per-owner pending vs completed, joined with derived counts from the live inventory.

with from_followup as (
    select
        so_name,
        completed,
        pending,
        snapshot_date
    from {{ ref('so_assignments') }}
),

from_inventory as (
    select
        serviceowner as so_name,
        count(*) filter (where upgrade_status = 'COMPLETED') as inv_completed,
        count(*) filter (where upgrade_status <> 'COMPLETED') as inv_pending
    from {{ ref('servers') }}
    where serviceowner is not null
    group by serviceowner
)

select
    coalesce(f.so_name, i.so_name) as so_name,
    coalesce(f.completed, i.inv_completed, 0) as completed,
    coalesce(f.pending,   i.inv_pending,   0) as pending,
    f.snapshot_date
from from_followup f
full outer join from_inventory i using (so_name)
order by pending desc
