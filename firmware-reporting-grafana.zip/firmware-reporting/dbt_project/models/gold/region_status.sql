{{ config(materialized='table') }}

-- gold.region_status
-- Pivot: region x upgraded/pending. Mirrors the "Overall Firmware Upgrade Status" table.

select
    region,
    count(*) as total,
    count(*) filter (where upgrade_status = 'COMPLETED') as upgraded,
    count(*) filter (where upgrade_status <> 'COMPLETED') as pending
from {{ ref('servers') }}
group by region
order by total desc
