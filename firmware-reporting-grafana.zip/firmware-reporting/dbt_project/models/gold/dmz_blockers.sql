{{ config(materialized='table') }}

-- gold.dmz_blockers
-- DMZ servers that still need firmware upgrade - the 883-server problem from the WSR.
-- Aggregated by location to highlight where the manual effort lands.

select
    location,
    region,
    count(*) as pending_count,
    count(distinct serviceowner) as distinct_owners
from {{ ref('servers') }}
where is_dmz = true
  and upgrade_status <> 'COMPLETED'
group by location, region
order by pending_count desc
