{{ config(materialized='table') }}

-- gold.rag_summary
-- Single-row summary used in the dashboard KPI strip.

with totals as (
    select
        count(*) as total_servers,
        count(*) filter (where upgrade_status = 'COMPLETED') as upgraded,
        count(*) filter (where upgrade_status <> 'COMPLETED') as pending
    from {{ ref('servers') }}
)

select
    total_servers,
    upgraded,
    pending,
    case when total_servers = 0 then 0
         else (upgraded * 100.0) / total_servers
    end as pct_complete,
    case
        when total_servers = 0 then 'GREY'
        when (upgraded * 1.0) / total_servers >= 0.80 then 'GREEN'
        when (upgraded * 1.0) / total_servers >= 0.50 then 'AMBER'
        else 'RED'
    end as overall_rag,
    current_timestamp as generated_at
from totals
