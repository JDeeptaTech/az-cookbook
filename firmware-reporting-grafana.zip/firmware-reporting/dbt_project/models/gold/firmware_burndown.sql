{{ config(materialized='table') }}

-- gold.firmware_burndown
-- Time series for the burndown chart. Combines weekly_progress with cumulative
-- counts derived from snapshots.

with wp as (
    select
        -- ISO date for each (year, week_number) - first day of that ISO week
        date_trunc('week', make_date(year, 1, 1)) + (week_number - 1) * interval 7 day as snapshot_date,
        planned,
        approved,
        completed
    from {{ ref('weekly_progress') }}
),

cum as (
    select
        snapshot_date,
        sum(coalesce(completed, 0)) over (order by snapshot_date)
            as cumulative_completed,
        sum(coalesce(planned, 0)) over (order by snapshot_date)
            as cumulative_planned
    from wp
)

select
    snapshot_date,
    cumulative_completed,
    cumulative_planned,
    cumulative_planned - cumulative_completed as remaining
from cum
order by snapshot_date
