{{ config(materialized='table') }}

-- silver.servers
-- Deduped, typed, region-normalised server inventory.
-- Source: bronze.server_inventory (typed as VARCHAR; cast here)

with src as (
    select
        serverid,
        name              as server_name,
        serialnumber,
        model,
        manufacturer,
        location,
        country,
        spacename,
        rackname,
        gridlocation,
        case
            when lower(coalesce(isactive, '')) in ('true', '1', 'yes') then true
            else false
        end as is_active,
        consoleipaddress,
        consolemacaddress,
        consolefqdn,
        case
            when lower(coalesce(dmz_yes_nox, '')) in ('yes','y','true','1') then true
            else false
        end as is_dmz,
        upper(coalesce(status, 'UNKNOWN')) as upgrade_status,
        upper(coalesce(upgradetype, 'UNKNOWN')) as upgrade_type,
        upper(coalesce(serverenvironment, 'UNKNOWN')) as server_environment,
        serverbusiness,
        servertier,
        serverlifecycle,
        servicename,
        serviceowner,
        case
            when upper(country) in ('GB','UK') then 'UK'
            when upper(country) = 'HK' then 'HK'
            when upper(country) = 'US' then 'US'
            else 'OTHERS'
        end as region,
        _ingested_at,
        _source_file,
        _file_hash,
        row_number() over (
            partition by serverid
            order by _ingested_at desc
        ) as rn
    from {{ source('bronze', 'server_inventory') }}
)

select
    serverid,
    server_name,
    serialnumber,
    model,
    manufacturer,
    location,
    country,
    region,
    spacename,
    rackname,
    gridlocation,
    is_active,
    is_dmz,
    upgrade_status,
    upgrade_type,
    server_environment,
    serverbusiness,
    servertier,
    serverlifecycle,
    servicename,
    serviceowner,
    consoleipaddress,
    consolemacaddress,
    consolefqdn,
    _ingested_at  as last_seen_at,
    _source_file  as last_source_file
from src
where rn = 1
