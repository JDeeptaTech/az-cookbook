{{ config(materialized='table') }}

-- silver.so_assignments
-- Latest snapshot per (so_name) from bronze.so_followup.

with ranked as (
    select
        trim(so_name) as so_name,
        try_cast(completed as integer) as completed,
        try_cast(pending   as integer) as pending,
        try_cast(snapshot_date as date) as snapshot_date,
        _ingested_at,
        row_number() over (
            partition by trim(so_name)
            order by try_cast(snapshot_date as date) desc nulls last,
                     _ingested_at desc
        ) as rn
    from {{ source('bronze', 'so_followup') }}
)

select
    so_name,
    completed,
    pending,
    snapshot_date,
    _ingested_at as last_seen_at
from ranked
where rn = 1
  and so_name is not null
