{{ config(materialized='table') }}

-- silver.weekly_progress
-- Latest figures per (year, week_number) from bronze.weekly_progress.

with ranked as (
    select
        try_cast(year as integer)         as year,
        try_cast(week_number as integer)  as week_number,
        try_cast(planned as integer)      as planned,
        try_cast(approved as integer)     as approved,
        try_cast(completed as integer)    as completed,
        _ingested_at,
        row_number() over (
            partition by try_cast(year as integer), try_cast(week_number as integer)
            order by _ingested_at desc
        ) as rn
    from {{ source('bronze', 'weekly_progress') }}
)

select
    year,
    week_number,
    planned,
    approved,
    completed,
    _ingested_at as last_seen_at
from ranked
where rn = 1
