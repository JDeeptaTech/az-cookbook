"""
Generate realistic sample CSVs for local development.

Schemas mirror what we saw in the HSBC firmware programme spreadsheet:
- server_inventory: ~9800 servers across UK/HK/US/Others, with DMZ flag
- weekly_progress: planned/approved/completed by ISO week
- so_followup: ~80 service owners with completed/pending counts
"""
from __future__ import annotations

import csv
import random
from datetime import date, datetime, timedelta
from pathlib import Path

random.seed(42)

OUT = Path(__file__).resolve().parents[1] / "data" / "raw"
OUT.mkdir(parents=True, exist_ok=True)

TODAY = date.today().isoformat()


def gen_inventory(n: int = 9801) -> Path:
    path = OUT / f"server_inventory_{TODAY}.csv"
    regions = ["GB"] * 6021 + ["HK"] * 3066 + ["US"] * 623 + ["IN"] * 91
    random.shuffle(regions)
    statuses = ["Completed"] * 2271 + ["Pending"] * 7530
    random.shuffle(statuses)

    owners = [f"Owner_{i:03d}" for i in range(80)]

    with path.open("w", newline="") as f:
        w = csv.writer(f)
        w.writerow([
            "id", "serverid", "name", "serialNumber", "model", "manufacturer",
            "location", "country", "spaceName", "rackName", "gridLocation",
            "isActive", "consoleIpAddress", "consoleMacAddress", "consoleFqdn",
            "DMZ(Yes/No)", "Status", "UpgradeType", "M Scope",
            "serverEnvironment", "serverBusiness", "serverTier",
            "serverLifeCycle", "serviceName", "serviceOwner",
            "snapshot_date",
        ])
        for i in range(n):
            country = regions[i] if i < len(regions) else "GB"
            loc_prefix = {"GB": "GB-LSITDC", "HK": "HK-TKOGDC", "US": "US-NY6TDC", "IN": "IN-MUMDC"}[country]
            w.writerow([
                i,
                f"srv{i:07d}",
                f"server-{i:05d}",
                f"SN{i:08d}",
                "PROLIANT DL",
                "HEWLETT PACKARD",
                loc_prefix,
                country,
                f"{loc_prefix}-Row{(i % 20) + 1:02d}",
                f"R{(i % 50) + 1:02d}",
                f"{(i % 30) + 1}{random.choice('ABCDEF')}",
                "TRUE",
                f"10.{(i % 255)}.{(i // 255) % 255}.{i % 255}",
                f"AA:BB:CC:{i % 256:02X}:{(i*3) % 256:02X}:{(i*7) % 256:02X}",
                f"srv{i:07d}.example.com",
                "Yes" if (i % 11 == 0) else "No",
                statuses[i] if i < len(statuses) else "Pending",
                "Completed via" if random.random() < 0.5 else "Pending",
                "Maruthi scope",
                random.choice(["Production", "UAT", "Contingency", "Development"]),
                random.choice(["GCIO", "Corp & Inst Banking", "Markets Core", "FICC Tech"]),
                "Live",
                "Live",
                random.choice(["GLOBAL-ACT", "KEYSTONE-G", "RANWEB-LD", "GFX-COMPL"]),
                random.choice(owners),
                TODAY,
            ])
    print(f"wrote {path} ({n} rows)")
    return path


def gen_weekly_progress() -> Path:
    path = OUT / f"weekly_progress_{TODAY}.csv"
    with path.open("w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["year", "week_number", "planned", "approved", "completed"])
        # Mirror what we saw: weeks 14-21 with planned 300-400, partial completion
        rows = [
            (2026, 14, 300, 261, 261),
            (2026, 15, 375, 251, 250),
            (2026, 16, 375, 365, 365),
            (2026, 17, 400, 480, 430),
            (2026, 18, 400, 115, 68),
            (2026, 19, 400, 419, 0),
            (2026, 20, 400, 325, 0),
            (2026, 21, 400, 325, 0),
            (2026, 22, 400, 0, 0),
            (2026, 23, 400, 0, 0),
        ]
        for r in rows:
            w.writerow(r)
    print(f"wrote {path}")
    return path


def gen_so_followup() -> Path:
    path = OUT / f"so_followup_{TODAY}.csv"
    with path.open("w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["so_name", "completed", "pending", "snapshot_date"])
        owners = [f"Owner_{i:03d}" for i in range(80)]
        for o in owners:
            w.writerow([o, random.randint(0, 300), random.randint(0, 400), TODAY])
    print(f"wrote {path}")
    return path


def gen_ssl_cert() -> Path:
    path = OUT / f"ssl_cert_{TODAY}.csv"
    with path.open("w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["serverid", "cert_id", "expires_on", "status", "snapshot_date"])
        for i in range(2000):
            expires = date.today() + timedelta(days=random.randint(-30, 365))
            status = "Renewed" if random.random() < 0.94 else "Pending"
            w.writerow([f"srv{i:07d}", f"cert{i:06d}", expires.isoformat(), status, TODAY])
    print(f"wrote {path}")
    return path


def gen_firmware_status() -> Path:
    path = OUT / f"firmware_status_{TODAY}.csv"
    with path.open("w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["serverid", "current_version", "target_version", "status", "snapshot_date"])
        for i in range(9801):
            status = random.choices(
                ["Completed", "InProgress-Green", "InProgress-Amber", "InProgress-Red", "NotStarted"],
                weights=[2271, 3473, 1524, 594, 1939],
            )[0]
            w.writerow([f"srv{i:07d}", "v1.2.3", "v2.0.1", status, TODAY])
    print(f"wrote {path}")
    return path


if __name__ == "__main__":
    gen_inventory()
    gen_weekly_progress()
    gen_so_followup()
    gen_ssl_cert()
    gen_firmware_status()
    print("\nSample data ready. Now run: fwr etl")
