"""Tests for gold sync module."""
from __future__ import annotations

from unittest.mock import patch

from firmware_reporting.dashboard.gold_sync import run_gold_sync


def test_gold_sync_skips_without_postgres_url():
    """Sync must be a no-op (not raise) when POSTGRES_URL is not configured."""
    with patch("firmware_reporting.dashboard.gold_sync.get_settings") as mock_settings:
        mock_settings.return_value.postgres_url = None
        result = run_gold_sync()
    assert result["status"] == "skipped"
    assert "no postgres_url" in result["reason"]
