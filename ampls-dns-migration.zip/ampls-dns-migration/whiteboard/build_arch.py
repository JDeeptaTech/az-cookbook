"""Generate the target-architecture board from one layout spec:
  - arch.svg.html : inline SVG with official Azure icons embedded (for the whiteboard artifact)
  - ampls-dns-architecture.drawio : editable draw.io file using draw.io's built-in azure2 icon library
Usage: python3 build_arch.py <path-to drawio/src/main/webapp>
"""
import base64, html, re, sys, pathlib

WEBAPP = pathlib.Path(sys.argv[1])
OUT = pathlib.Path(__file__).parent

ICONS = {
    "resolver": "networking/DNS_Private_Resolver.svg", "zone": "networking/DNS_Zones.svg",
    "pe": "networking/Private_Endpoint.svg", "pl": "networking/Private_Link.svg",
    "vnet": "networking/Virtual_Networks.svg", "subnet": "networking/Subnet.svg",
    "fw": "networking/Firewalls.svg", "er": "networking/ExpressRoute_Circuits.svg",
    "conn": "networking/Connections.svg", "kv": "security/Key_Vaults.svg",
    "sql": "databases/SQL_Database.svg", "st": "storage/Storage_Accounts.svg",
    "sb": "integration/Service_Bus.svg", "vm": "compute/Virtual_Machine.svg",
    "aro": "containers/Azure_Red_Hat_OpenShift.svg", "acr": "containers/Container_Registries.svg",
    "law": "management_governance/Log_Analytics_Workspaces.svg", "appi": "management_governance/Application_Insights.svg",
    "monitor": "management_governance/Monitor.svg", "dcr": "other/Data_Collection_Rules.svg",
    "policy": "management_governance/Policy.svg", "mg": "general/Management_Groups.svg",
    "sub": "general/Subscriptions.svg", "rg": "general/Resource_Groups.svg",
    "mi": "identity/Managed_Identities.svg", "servers": "general/Server_Farm.svg",
    "users": "identity/Users.svg", "arc": "management_governance/Arc_Machines.svg",
}

# light-theme hex for draw.io (no CSS variables there)
HEX = {"ink": "#1f2a37", "soft": "#5b6878", "board": "#ffffff", "blue": "#1f6fd1", "blue-bg": "#e6f0fc",
       "green": "#1d9a5b", "green-bg": "#e3f6ec", "purple": "#7c3aed", "purple-bg": "#f0e9fe",
       "orange": "#e2700f", "orange-bg": "#fff0e1", "red": "#d9363e", "red-bg": "#fde8e9", "teal": "#0f8b8d"}
FONTS = {"h": "Caveat", "b": "Kalam", "m": "JetBrains Mono"}

E = []  # layout spec
def box(x, y, w, h, c, fill=None, dash=False, sw=2.5, r=12, sk=True): E.append(("box", locals()))
def icon(k, x, y, s=40, label=None): E.append(("icon", locals()))
def text(x, y, t, cls="b", size=15, c="ink", anchor="start", weight=None, rot=None, strike=False): E.append(("text", locals()))
def pill(x, y, w, t, c, ic=None, h=24, size=11): E.append(("pill", locals()))
def edge(pts, c, w=2.5, dash=None, flow=False, arrow=True): E.append(("edge", locals()))
def badge(x, y, n): E.append(("badge", locals()))

# ---------------- ON-PREM ----------------
box(20, 60, 300, 660, "orange", "orange-bg", sw=3, r=18)
text(40, 98, "On-premises", "h", 30, "orange")
box(36, 112, 268, 58, "orange", "board", sw=2, r=10)
icon("users", 46, 120, 40)
text(96, 138, "Clients / app servers", size=15)
text(96, 158, "resolv → 10.10.0.10/.11", "m", 12, "soft")
box(36, 184, 268, 326, "orange", "board", r=10)
icon("servers", 46, 194, 44)
text(100, 214, "Enterprise DNS", "h", 24)
text(100, 234, "DCs / Infoblox", size=13, c="soft")
text(48, 262, "Conditional forwarders → 10.0.0.4", size=14)
for i, z in enumerate(["blob.core.windows.net", "file|queue|table|dfs.core…", "(vault|vaultcore).azure.net",
                       "database.windows.net", "monitor.azure.com", "oms|ods.opinsights.azure.com",
                       "agentsvc.azure-automation.net", "applicationinsights.azure.com"]):
    text(52, 286 + i * 19, z, "m", 12)
text(48, 452, "privatelink.* zones — removed", size=14, c="red", strike=True)
text(48, 480, "forward the PUBLIC zone,", size=13, c="soft")
text(48, 498, "never privatelink.*", size=13, c="soft")
box(36, 524, 268, 84, "orange", "board", sw=2, r=10)
icon("arc", 46, 536, 40)
text(96, 552, "Servers with AMA / Arc", size=15)
text(96, 572, "logs → DCE / ods", "m", 12, "soft")
text(96, 590, "over ER to the AMPLS PE", "m", 12, "soft")
text(40, 652, "owner: DNS / network ops", "h", 21, "orange")
text(40, 676, "no Azure records live here any more", size=13, c="soft")


# ---------------- CONNECTIVITY ----------------
box(410, 60, 560, 600, "blue", "blue-bg", sw=3, r=18)
icon("sub", 426, 72, 30)
text(464, 98, "Network / connectivity subscription", "h", 28, "blue")
box(426, 112, 528, 342, "blue", None, dash=True, sw=2)
icon("vnet", 438, 120, 26)
text(470, 139, "vnet-hub · DNS = Azure-provided", size=14, c="blue")
box(440, 152, 250, 120, "blue", "board", r=10)
icon("resolver", 452, 164, 46)
text(504, 186, "DNS Private Resolver", "h", 20)
text(506, 207, "Inbound endpoint", size=14)
text(452, 240, "inbound 10.0.0.4 (static) /28", "m", 12, "red", weight="600")
text(452, 260, "← on-prem + every spoke", "m", 12, "soft")
box(702, 152, 238, 120, "blue", "board", sw=2, r=10)
icon("conn", 714, 164, 38)
text(758, 186, "Outbound + ruleset", "h", 20)
text(714, 228, "corp.contoso.com. →", "m", 12)
text(714, 246, "  10.10.0.10/.11", "m", 12)
text(714, 264, "on-prem names only", size=13, c="soft")
box(440, 286, 500, 76, "purple", "board", r=10)
icon("subnet", 452, 296, 28)
text(488, 316, "snet-privateendpoints · 10.0.1.0/24", size=14)
pill(488, 328, 268, "pe-ampls-shared · azuremonitor", "purple", ic="pe", h=26, size=12)
box(440, 376, 240, 64, "blue", "board", dash=True, sw=2, r=10)
icon("fw", 450, 386, 40)
text(498, 404, "Azure Firewall", size=15)
text(498, 424, "DNS proxy (optional)", size=13, c="soft")
box(700, 376, 240, 64, "teal", "board", sw=2, r=10)
text(714, 402, "Azure-provided DNS", size=15, c="teal")
text(714, 424, "168.63.129.16 → linked zones", "m", 12, "soft")
box(426, 468, 528, 176, "blue", "board", r=12)
icon("rg", 438, 478, 28)
text(474, 500, "rg-dns-privatezones · CanNotDelete lock", "h", 21)
for i, (a, b) in enumerate([("privatelink.blob.core.windows.net", "privatelink.monitor.azure.com"),
                            ("privatelink.vaultcore.azure.net", "privatelink.oms.opinsights.azure.com"),
                            ("privatelink.database.windows.net", "privatelink.ods.opinsights.azure.com"),
                            ("+ azurecr · web · file · queue …", "privatelink.agentsvc.azure-automation.net")]):
    pill(438, 514 + i * 30, 252, a, "blue", ic="zone")
    pill(696, 514 + i * 30, 252, b, "purple", ic="zone", size=9 if "agentsvc" in b else 10)
edge([(954, 560), (986, 560), (986, 126), (956, 126)], "blue", dash="3 6")
text(1000, 200, "VNet link → hub only", "h", 17, "blue", rot=90)

# ---------------- EXPRESSROUTE ----------------
edge([(304, 330), (428, 330)], "ink", w=7, arrow=False)
icon("er", 341, 304, 48)
text(365, 372, "ExpressRoute", "h", 16, anchor="middle")
text(365, 390, "/ VPN", "h", 16, anchor="middle")

# ---------------- MANAGEMENT ----------------
box(410, 676, 560, 232, "purple", "purple-bg", sw=3, r=18)
icon("sub", 426, 688, 30)
text(464, 714, "Shared production / management sub", "h", 28, "purple")
box(426, 728, 262, 124, "purple", "board", r=10)
icon("pl", 438, 740, 40)
icon("monitor", 466, 764, 22)
text(492, 762, "ampls-shared", "h", 23)
text(492, 782, "Monitor Private Link Scope", size=12, c="soft")
text(438, 806, "ingest: Open → PrivateOnly", "m", 12)
text(438, 824, "query:  Open", "m", 12)
text(438, 844, "ONE per DNS namespace", size=13, c="purple")
box(700, 728, 254, 56, "purple", "board", sw=2, r=10)
icon("law", 710, 738, 36)
text(754, 761, "law-shared-prod (+ scoped)", size=14)
box(700, 794, 124, 58, "purple", "board", sw=2, r=10)
icon("dcr", 708, 806, 32)
text(746, 828, "DCE / DCR", size=13)
box(830, 794, 124, 58, "purple", "board", sw=2, r=10)
icon("appi", 838, 806, 32)
text(876, 828, "App Insights", size=13)
text(430, 878, "AMPLS PE resource lives here · NIC in the hub PE subnet", size=13, c="soft")
text(430, 898, "scopes workspaces · components · DCEs from any subscription", size=13, c="soft")
edge([(470, 728), (396, 600), (396, 380), (486, 346)], "purple", w=3)
text(392, 640, "private link", "h", 18, "purple", rot=-90)

# ---------------- WORKLOADS ----------------
box(1000, 60, 380, 848, "green", "green-bg", sw=3, r=18)
icon("sub", 1016, 72, 30)
text(1054, 98, "Workload subscriptions", "h", 28, "green")
box(1016, 112, 348, 262, "green", "board", r=12)
icon("vnet", 1028, 122, 28)
text(1064, 144, "vnet-app1 (spoke)", "h", 22)
text(1028, 170, "dns_servers = [10.0.0.4]", "m", 12, "red", weight="600")
for i, (k, lab) in enumerate([("kv", "Key Vault"), ("sql", "SQL DB"), ("st", "Storage"), ("sb", "Service Bus")]):
    x = 1040 + i * 82
    icon(k, x, 184, 40)
    icon("pe", x + 28, 210, 20)
    text(x + 20, 248, lab, size=12, anchor="middle")
icon("vm", 1028, 262, 32)
text(1068, 284, "VMs + AMA → DCR → DCE", size=14)
text(1028, 316, "no private DNS zones in this subscription", size=13, c="soft")
text(1028, 336, "zone groups added by DINE policy", size=13, c="soft")
text(1028, 356, "(Terraform: ignore_changes on zone group)", size=13, c="soft")
box(1016, 390, 348, 212, "green", "board", r=12)
icon("aro", 1028, 400, 40)
text(1076, 428, "ARO / OpenShift spoke", "h", 22)
text(1028, 462, "VNet DNS = 10.0.0.4", "m", 12, "red", weight="600")
text(1028, 486, "pod → CoreDNS → node → VNet DNS", size=13)
icon("acr", 1028, 500, 32)
text(1066, 522, "ACR · pe registry", size=13)
icon("monitor", 1196, 500, 32)
text(1234, 522, "Container Insights", size=13)
text(1028, 566, "leave ARO/AKS-managed zones alone", size=13, c="soft")
text(1028, 588, "test from a node: oc debug node/…", size=13, c="soft")
box(1016, 618, 348, 166, "green", "board", r=12)
icon("law", 1028, 630, 32)
icon("appi", 1064, 630, 32)
text(1106, 654, "App LAW / App Insights", "h", 22)
text(1028, 688, "✔ add to the central ampls-shared", size=14)
text(1028, 710, "✘ never a 2nd AMPLS + PE here", size=14, c="red")
text(1028, 734, "a second AMPLS on the same DNS", size=13, c="soft")
text(1028, 754, "overwrites the shared records", size=13, c="soft")
text(1028, 774, "(api.monitor.azure.com etc.)", size=13, c="soft")
text(1028, 822, "peered to hub · UDR via firewall", "h", 20, "green")
text(1028, 846, "owner: app team — creates PEs only", size=13, c="soft")
edge([(970, 250), (1016, 250)], "green", w=5, arrow=False)
edge([(970, 490), (1016, 490)], "green", w=5, arrow=False)
edge([(1016, 150), (900, 128), (740, 124), (650, 150)], "green", flow=True)
edge([(1016, 330), (986, 380), (986, 470), (956, 520)], "green", dash="10 6")

# ---------------- LOOKUP PATH ----------------
edge([(170, 170), (170, 184)], "red", w=3, flow=True)
edge([(304, 300), (360, 250), (400, 214), (440, 212)], "red", w=3, flow=True)
edge([(640, 272), (800, 296), (840, 330), (830, 376)], "red", w=3, flow=True)
edge([(820, 440), (820, 468)], "red", w=3, flow=True)
edge([(170, 608), (240, 690), (380, 690), (488, 356)], "red", w=3, flow=True)
badge(194, 177, 1); badge(380, 222, 2); badge(870, 322, 3); badge(842, 454, 4); badge(372, 610, 5)

box(20, 736, 374, 172, "red", "red-bg", r=14)
text(36, 764, "How st1.blob.core.windows.net resolves", "h", 21, "red")
for i, t in enumerate(["① client asks enterprise DNS", "② forwarder blob.core.windows.net → 10.0.0.4",
                       "③ resolver asks Azure DNS · CNAME → privatelink", "④ hub-linked zone answers 10.0.1.x",
                       "⑤ traffic rides ER to the private endpoint"]):
    text(36, 790 + i * 21, t, size=13.5)

# ---------------- GOVERNANCE ----------------
box(20, 926, 1360, 60, "soft", "board", dash=True, sw=2)
icon("mg", 34, 938, 34)
text(76, 963, "Governance (MG)", "h", 22)
icon("policy", 248, 939, 32); text(288, 961, "DINE: PE → central zone group", size=14)
icon("policy", 580, 939, 32); text(620, 961, "Deny privatelink.* in landing zones", size=14)
icon("mi", 948, 939, 32); text(988, 961, "MI: Network + Private DNS Zone Contributor", size=14)

W, H = 1400, 1000

# =============== SVG render ===============
def esc(s): return html.escape(s, quote=True)
def col(c): return "var(--ink-soft)" if c == "soft" else (f"var(--{c})" if c in HEX else c)

def svg_render():
    used = sorted({a["k"] for t, a in E if t == "icon"} | {a["ic"] for t, a in E if t == "pill" and a["ic"]})
    defs = []
    for k in used:
        raw = (WEBAPP / "img/lib/azure2" / ICONS[k]).read_bytes()
        vb = re.search(rb'viewBox="([^"]+)"', raw).group(1).decode().split()
        vw, vh = float(vb[2]), float(vb[3])
        b64 = base64.b64encode(raw).decode()
        defs.append(f'<symbol id="az-{k}" viewBox="0 0 {vw} {vh}"><image href="data:image/svg+xml;base64,{b64}" width="{vw}" height="{vh}"/></symbol>')
    out = []
    for t, a in E:
        if t == "box":
            st = f"fill:{col(a['fill']) if a['fill'] else 'none'};stroke:{col(a['c'])};stroke-width:{a['sw']}"
            if a["dash"]: st += ";stroke-dasharray:7 6"
            cls = ' class="sk"' if a["sk"] and not a["dash"] and a["fill"] and a["fill"].endswith("-bg") else ""
            out.append(f'<rect{cls} x="{a["x"]}" y="{a["y"]}" width="{a["w"]}" height="{a["h"]}" rx="{a["r"]}" style="{st}"/>')
        elif t == "icon":
            out.append(f'<use href="#az-{a["k"]}" x="{a["x"]}" y="{a["y"]}" width="{a["s"]}" height="{a["s"]}"><title>{esc(pathlib.Path(ICONS[a["k"]]).stem.replace("_", " "))}</title></use>')
        elif t == "text":
            st = f"fill:{col(a['c'])}"
            if a["weight"]: st += f";font-weight:{a['weight']}"
            tr = f' transform="rotate({a["rot"]} {a["x"]} {a["y"]})"' if a["rot"] else ""
            anc = f' text-anchor="{a["anchor"]}"' if a["anchor"] != "start" else ""
            dec = ' text-decoration="line-through"' if a["strike"] else ""
            out.append(f'<text class="{a["cls"]}" x="{a["x"]}" y="{a["y"]}" font-size="{a["size"]}"{anc}{tr}{dec} style="{st}">{esc(a["t"])}</text>')
        elif t == "pill":
            x, y, w, h = a["x"], a["y"], a["w"], a["h"]
            out.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{h/2}" style="fill:var(--{a["c"]}-bg);stroke:var(--{a["c"]});stroke-width:1.5"/>')
            tx = x + 10
            if a["ic"]:
                s = h - 8
                out.append(f'<use href="#az-{a["ic"]}" x="{x+6}" y="{y+4}" width="{s}" height="{s}"/>')
                tx = x + 10 + s
            out.append(f'<text class="m" x="{tx}" y="{y + h/2 + 4}" style="font-size:{a["size"]}px;fill:var(--ink)">{esc(a["t"])}</text>')
        elif t == "edge":
            p = a["pts"]
            d = f"M{p[0][0]} {p[0][1]} " + (f"C {p[1][0]} {p[1][1]}, {p[2][0]} {p[2][1]}, {p[3][0]} {p[3][1]}" if len(p) == 4 else " ".join(f"L{x} {y}" for x, y in p[1:]))
            st = f"fill:none;stroke:{col(a['c'])};stroke-width:{a['w']};stroke-linecap:round"
            if a["dash"]: st += f";stroke-dasharray:{a['dash']}"
            if a["w"] >= 5: st += ";opacity:.7"
            mk = f' marker-end="url(#ar-{a["c"]})"' if a["arrow"] else ""
            cls = ' class="flow"' if a["flow"] else ""
            out.append(f'<path{cls} d="{d}" style="{st}"{mk}/>')
        elif t == "badge":
            out.append(f'<circle cx="{a["x"]}" cy="{a["y"]}" r="13" style="fill:var(--red)"/><text class="h" x="{a["x"]}" y="{a["y"]+7}" font-size="21" text-anchor="middle" style="fill:#fff">{a["n"]}</text>')
    markers = "".join(f'<marker id="ar-{c}" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M0,0 L10,5 L0,10 z" style="fill:var(--{c})"/></marker>' for c in ["red", "green", "purple", "blue", "ink"])
    rough = '<filter id="rough" x="-2%" y="-2%" width="104%" height="104%"><feTurbulence type="fractalNoise" baseFrequency="0.02" numOctaves="2" seed="7"/><feDisplacementMap in="SourceGraphic" scale="3"/></filter>'
    return (f'<svg viewBox="0 0 {W} {H}" role="img" aria-label="Target architecture with Azure icons: on-prem DNS forwards public Azure zones over ExpressRoute to the DNS Private Resolver inbound endpoint in the hub; central privatelink zones linked to the hub; AMPLS private endpoint in the hub; workload spokes use the resolver.">'
            f'<defs>{rough}{markers}{"".join(defs)}</defs>' + "\n".join(out) + "</svg>")

# =============== draw.io render ===============
def dio():
    cells, n = [], [2]
    def nid():
        n[0] += 1; return f"c{n[0]}"
    def cell(style, x, y, w, h, value="", edge=False, extra=""):
        i = nid()
        if edge:
            cells.append(f'<mxCell id="{i}" value="" style="{style}" edge="1" parent="1"><mxGeometry relative="1" as="geometry">{extra}</mxGeometry></mxCell>')
        else:
            cells.append(f'<mxCell id="{i}" value="{esc(value)}" style="{style}" vertex="1" parent="1"><mxGeometry x="{x}" y="{y}" width="{w}" height="{h}" as="geometry"/></mxCell>')
    hx = lambda c: HEX.get(c, c)
    for t, a in E:
        if t == "box":
            st = f"rounded=1;arcSize={min(20, int(a['r']*100/min(a['w'],a['h'])))};absoluteArcSize=0;whiteSpace=wrap;html=1;fillColor={hx(a['fill']) if a['fill'] else 'none'};strokeColor={hx(a['c'])};strokeWidth={a['sw']};"
            if a["dash"]: st += "dashed=1;"
            if a["fill"] and a["fill"].endswith("-bg"): st += "sketch=1;curveFitting=1;jiggle=1.5;"
            cell(st, a["x"], a["y"], a["w"], a["h"])
        elif t == "icon":
            cell(f"image;aspect=fixed;html=1;points=[];align=center;verticalLabelPosition=bottom;verticalAlign=top;image=img/lib/azure2/{ICONS[a['k']]};", a["x"], a["y"], a["s"], a["s"])
        elif t == "text":
            size = a["size"]; w = max(20, len(a["t"]) * size * (0.62 if a["cls"] == "m" else 0.5)); h = size * 1.4
            x = a["x"] - (w / 2 if a["anchor"] == "middle" else 0)
            y = a["y"] - size * 1.1
            st = f"text;html=1;align={'center' if a['anchor']=='middle' else 'left'};verticalAlign=middle;spacing=0;fontFamily={FONTS[a['cls']]};fontSize={size};fontColor={hx(a['c'])};"
            if a["weight"] or a["cls"] == "h": st += "fontStyle=1;"
            if a["strike"]: st += "fontStyle=8;"
            if a["rot"]:
                st += f"rotation={a['rot']};"; cx, cy = a["x"], a["y"]; x, y = cx - w / 2 + size / 2, cy + w / 2 - h / 2
            cell(st, round(x, 1), round(y, 1), round(w, 1), round(h, 1), a["t"])
        elif t == "pill":
            x, y, w, h = a["x"], a["y"], a["w"], a["h"]
            cell(f"rounded=1;arcSize=50;html=1;fillColor={hx(a['c']+'-bg')};strokeColor={hx(a['c'])};strokeWidth=1.5;", x, y, w, h)
            tx = x + 8
            if a["ic"]:
                s = h - 8; cell(f"image;aspect=fixed;html=1;image=img/lib/azure2/{ICONS[a['ic']]};", x + 6, y + 4, s, s); tx = x + 10 + s
            cell(f"text;html=1;align=left;verticalAlign=middle;spacing=0;fontFamily=JetBrains Mono;fontSize={a['size']};fontColor={HEX['ink']};", tx, y, w - (tx - x) - 4, h, a["t"])
        elif t == "edge":
            p = a["pts"]
            st = f"html=1;rounded=1;curved={1 if len(p)==4 else 0};strokeColor={hx(a['c'])};strokeWidth={a['w']};endArrow={'block' if a['arrow'] else 'none'};endFill=1;"
            if a["dash"]: st += f"dashed=1;dashPattern={a['dash'].replace(' ', ' ')};"
            if a["flow"]: st += "flowAnimation=1;"
            if a["w"] >= 5: st += "opacity=70;"
            wp = "".join(f'<mxPoint x="{x}" y="{y}"/>' for x, y in p[1:-1])
            extra = f'<mxPoint x="{p[0][0]}" y="{p[0][1]}" as="sourcePoint"/><mxPoint x="{p[-1][0]}" y="{p[-1][1]}" as="targetPoint"/>' + (f'<Array as="points">{wp}</Array>' if wp else "")
            cell(st, 0, 0, 0, 0, edge=True, extra=extra)
        elif t == "badge":
            cell(f"ellipse;html=1;fillColor={HEX['red']};strokeColor=none;fontColor=#ffffff;fontStyle=1;fontSize=15;", a["x"] - 13, a["y"] - 13, 26, 26, str(a["n"]))
    return ('<mxfile host="drawio" type="device"><diagram id="arch" name="Target architecture">'
            f'<mxGraphModel dx="1400" dy="1000" grid="1" gridSize="10" guides="1" page="1" pageWidth="{W+40}" pageHeight="{H+40}" background="#fbfcfd" math="0" shadow="0">'
            '<root><mxCell id="0"/><mxCell id="1" parent="0"/>' + "".join(cells) + "</root></mxGraphModel></diagram></mxfile>")

(OUT / "arch.svg.html").write_text(svg_render())
(OUT / "ampls-dns-architecture.drawio").write_text(dio())
print("ok", len(E), "elements")
