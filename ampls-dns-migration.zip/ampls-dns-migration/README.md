# AMPLS + DNS Private Resolver — central privatelink DNS migration kit

```
config/zone-map.json            groupId -> privatelink zone(s) -> public zone to forward; cutover waves
infra/terraform/                connectivity (resolver, zones, links, ruleset) + management (AMPLS, DCE, PE) + policy
infra/policy/                   DINE zone-group policy, Deny shadow privatelink zones
infra/workload-spoke.tf.example what a workload subscription owns afterwards
scripts/                        inventory -> reconcile -> backfill -> parity -> cutover/rollback -> AMPLS tests
```

## Run order

| # | Where | Script | Gate |
|---|-------|--------|------|
| 0 | Pipeline | `terraform apply` (infra/terraform) — DINE policy in **Audit/DINE**, Deny in **Audit**, AMPLS **Open/Open** | resolver inbound IP answers |
| 1 | Each DNS server (or one DC if AD-integrated) | `01-Export-OnPremPrivatelinkZones.ps1` (BIND/Infoblox: `export-zone-axfr.sh`) | backups exist |
| 2 | Admin box with Az | `02-Get-AzPrivateEndpointInventory.ps1` | — |
| 3 | Admin box | `03-Compare-DnsInventory.ps1` | exit 0 |
| 4 | Admin box | `04-Set-PeDnsZoneGroup.ps1 -WhatIf`, then real. Re-run 2+3 | no `NeedsZoneGroup`/`CentralIpDrift` |
| 5 | Admin box | `05-Import-OrphanRecords.ps1 -Include ...` for confirmed partner/other-tenant names only | no `OrphanOnPrem` you still need |
| 6 | On-prem host | `06-Test-ResolverParity.ps1 -Zone <wave zones>` | exit 0 |
| 7 | DNS server | `07-Invoke-ZoneCutover.ps1 -Zone <wave> -WhatIf`, then with `-AutoRollback` | validated |
| 8 | If needed | `08-Undo-ZoneCutover.ps1 -LogPath <log>` | — |
| 9 | On-prem, spoke VM, ARO node | `09-Test-AmplsConnectivity.ps1` / `test-resolution.sh` | all OK |
| 10 | Admin box | `10-Test-AmplsIngestion.ps1 [-AddMissing]` | no stale heartbeats |

Waves (from `zone-map.json`): 1 Key Vault → 2 databases/messaging → 3 ACR/App Service/file/queue/table/dfs → 4 **blob + AMPLS together**.
Blob is shared: the AMPLS PE writes its solution-pack record into `privatelink.blob.core.windows.net`. If the blob zone
stays on-prem after AMPLS goes live, agents can't fetch solution packs.

After the last wave: Deny policy → `Deny`; AMPLS ingestion → `PrivateOnly` only once `10` shows every workspace/component scoped;
workspace `publicNetworkAccessForIngestion` → Disabled per workspace.

## Known gaps / adjust for your estate
* `namespace` is mapped to Service Bus. Event Hubs PEs (`Microsoft.EventHub/namespaces`) use the same zone — add a second entry if you have them.
* SQL Managed Instance, AKS/ARO API (`privatelink.<region>.azmk8s.io`, ARO-managed zones) and Databricks are not in the map. Don't migrate zones a managed service creates for itself.
* DINE covers auto-approved PEs only. Manual-approval PEs (cross-tenant) need 04 or a team-owned zone group.
* Terraform was written for azurerm 4.x but not planned against a live tenant here — run `terraform validate` + `plan` first.

## Testing the zones and the auto-registration policy
`scripts/11-Test-PrivateDnsPolicy.ps1` (needs only Az.Accounts; `dig` or Windows `Resolve-DnsName` for resolution checks).

* `-Mode Audit` (read-only): zones exist and are locked, hub links healthy with auto-registration off, shadow
  `privatelink.*` zones, one DINE assignment per groupId pointing at the central zones, managed identity roles,
  non-compliant PEs, Deny assignment.
* `-Mode E2E`: deploys a throwaway Key Vault / storage / SQL server with PEs **without** a zone group, waits for
  `deployedByPolicy`, checks the A record = PE NIC IP, resolves via `-ResolverIp`/`-DnsServer`/`-TestVmId`,
  tests Deny/Audit on a shadow zone, deletes the PEs and checks the records disappear, then deletes the RG.
  If the policy has not fired after `-RemediateAfterMinutes` it starts a remediation task and reports a Warn.
* `-Mode All` runs both. JUnit output for pipelines: `pipelines/dns-policy-canary.yml` (nightly audit, weekly E2E).

Expect DINE on create to take 5–20 minutes in a real tenant: keep `-TimeoutMinutes` ≥ 30.

## ADO
`ado/AMPLS-DNS-Private-Resolver-Migration.md` is the wiki page; upload `ado/.attachments/*.png` with it.
`ado/New-AdoBacklog.ps1` creates the backlog from `ado/backlog.json` (Agile/Scrum/CMMI/Basic, idempotent, `-WhatIf`, `-ValidateOnly`).
Edit `workloadSubscriptions` and `waves` in backlog.json before running.
