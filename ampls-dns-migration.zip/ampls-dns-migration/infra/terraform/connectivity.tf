# =====================  NETWORK / CONNECTIVITY SUBSCRIPTION  =====================
locals {
  hub_parts    = split("/", var.hub_vnet_id)
  hub_rg       = local.hub_parts[4]
  hub_vnet     = local.hub_parts[8]
  zone_rg_name = "rg-dns-privatezones"
}

resource "azurerm_subnet" "resolver_inbound" {
  provider             = azurerm.connectivity
  name                 = "snet-dnspr-inbound"
  resource_group_name  = local.hub_rg
  virtual_network_name = local.hub_vnet
  address_prefixes     = [var.resolver_inbound_cidr]
  delegation {
    name = "dnsresolvers"
    service_delegation {
      name    = "Microsoft.Network/dnsResolvers"
      actions = ["Microsoft.Network/virtualNetworks/subnets/join/action"]
    }
  }
}

resource "azurerm_subnet" "resolver_outbound" {
  provider             = azurerm.connectivity
  name                 = "snet-dnspr-outbound"
  resource_group_name  = local.hub_rg
  virtual_network_name = local.hub_vnet
  address_prefixes     = [var.resolver_outbound_cidr]
  delegation {
    name = "dnsresolvers"
    service_delegation {
      name    = "Microsoft.Network/dnsResolvers"
      actions = ["Microsoft.Network/virtualNetworks/subnets/join/action"]
    }
  }
}

resource "azurerm_private_dns_resolver" "hub" {
  provider            = azurerm.connectivity
  name                = "dnspr-hub-${var.location}"
  resource_group_name = local.hub_rg
  location            = var.location
  virtual_network_id  = var.hub_vnet_id
}

resource "azurerm_private_dns_resolver_inbound_endpoint" "in" {
  provider                = azurerm.connectivity
  name                    = "in-${var.location}"
  private_dns_resolver_id = azurerm_private_dns_resolver.hub.id
  location                = var.location
  ip_configurations {
    subnet_id                    = azurerm_subnet.resolver_inbound.id
    private_ip_allocation_method = "Static"
    private_ip_address           = var.resolver_inbound_ip
  }
}

resource "azurerm_private_dns_resolver_outbound_endpoint" "out" {
  provider                = azurerm.connectivity
  name                    = "out-${var.location}"
  private_dns_resolver_id = azurerm_private_dns_resolver.hub.id
  location                = var.location
  subnet_id               = azurerm_subnet.resolver_outbound.id
}

resource "azurerm_private_dns_resolver_dns_forwarding_ruleset" "onprem" {
  provider                                   = azurerm.connectivity
  name                                       = "dnsfrs-onprem-${var.location}"
  resource_group_name                        = local.hub_rg
  location                                   = var.location
  private_dns_resolver_outbound_endpoint_ids = [azurerm_private_dns_resolver_outbound_endpoint.out.id]
}

# Only on-prem namespaces go out. NEVER add Azure public zones (blob.core.windows.net, ...) here:
# on-prem forwards those to us -> we'd forward back -> loop / SERVFAIL.
resource "azurerm_private_dns_resolver_forwarding_rule" "onprem" {
  provider                  = azurerm.connectivity
  for_each                  = var.onprem_forward_domains
  name                      = replace(trimsuffix(each.key, "."), ".", "-")
  dns_forwarding_ruleset_id = azurerm_private_dns_resolver_dns_forwarding_ruleset.onprem.id
  domain_name               = each.key
  enabled                   = true
  dynamic "target_dns_servers" {
    for_each = each.value
    content {
      ip_address = target_dns_servers.value
      port       = 53
    }
  }
}

resource "azurerm_private_dns_resolver_virtual_network_link" "ruleset" {
  provider                  = azurerm.connectivity
  for_each                  = merge({ hub = var.hub_vnet_id }, var.ruleset_link_vnet_ids)
  name                      = "lnk-${each.key}"
  dns_forwarding_ruleset_id = azurerm_private_dns_resolver_dns_forwarding_ruleset.onprem.id
  virtual_network_id        = each.value
}

# ---- central privatelink zones (one copy per tenant/environment, global resources) ----
resource "azurerm_resource_group" "zones" {
  provider = azurerm.connectivity
  name     = local.zone_rg_name
  location = var.location
}

resource "azurerm_management_lock" "zones" {
  provider   = azurerm.connectivity
  name       = "no-delete-central-dns"
  scope      = azurerm_resource_group.zones.id
  lock_level = "CanNotDelete"
  notes      = "Deleting a privatelink zone breaks resolution for every PE in the tenant."
}

resource "azurerm_private_dns_zone" "pl" {
  provider            = azurerm.connectivity
  for_each            = toset(var.private_dns_zones)
  name                = each.value
  resource_group_name = azurerm_resource_group.zones.name
}

locals {
  zone_links = merge([
    for z in var.private_dns_zones : merge(
      { "${z}|hub" = { zone = z, vnet = var.hub_vnet_id } },
      { for k, v in var.additional_zone_link_vnet_ids : "${z}|${k}" => { zone = z, vnet = v } }
    )
  ]...)
}

# Link to the RESOLVER's VNet (hub). Spokes resolve through the inbound endpoint, so they need no links.
resource "azurerm_private_dns_zone_virtual_network_link" "pl" {
  provider              = azurerm.connectivity
  for_each              = local.zone_links
  name                  = "lnk-${split("|", each.key)[1]}"
  resource_group_name   = azurerm_resource_group.zones.name
  private_dns_zone_name = azurerm_private_dns_zone.pl[each.value.zone].name
  virtual_network_id    = each.value.vnet
  registration_enabled  = false
  resolution_policy     = "Default" # set "NxDomainRedirect" per zone if you need public fallback for names without a PE
}
