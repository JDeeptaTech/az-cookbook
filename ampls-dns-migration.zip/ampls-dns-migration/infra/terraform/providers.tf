terraform {
  required_version = ">= 1.6"
  required_providers {
    azurerm = { source = "hashicorp/azurerm", version = "~> 4.0" }
  }
}

# Network / connectivity subscription: hub VNet, DNS Private Resolver, central privatelink zones.
provider "azurerm" {
  alias           = "connectivity"
  subscription_id = var.connectivity_subscription_id
  features {}
}

# Shared production (management) subscription: Log Analytics, AMPLS, DCEs, AMPLS private endpoint resource.
provider "azurerm" {
  alias           = "management"
  subscription_id = var.management_subscription_id
  features {}
}

# Default provider: used for management-group scoped policy. Any subscription the pipeline SP can read.
provider "azurerm" {
  subscription_id = var.management_subscription_id
  features {}
}
