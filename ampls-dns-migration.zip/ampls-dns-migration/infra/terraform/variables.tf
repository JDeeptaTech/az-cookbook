variable "connectivity_subscription_id" { type = string }
variable "management_subscription_id" { type = string }
variable "location" {
  type    = string
  default = "uksouth"
}

# ---------- connectivity ----------
variable "hub_vnet_id" {
  description = "Existing hub VNet (connectivity sub). Resolver subnets and the AMPLS PE subnet live here."
  type        = string
}
variable "resolver_inbound_cidr" {
  type    = string
  default = "10.0.0.0/28"
}
variable "resolver_inbound_ip" {
  description = "Static inbound endpoint IP. Pin it - on-prem forwarders and spoke VNet DNS settings point here."
  type        = string
  default     = "10.0.0.4"
}
variable "resolver_outbound_cidr" {
  type    = string
  default = "10.0.0.16/28"
}
variable "pe_subnet_id" {
  description = "Hub subnet for shared private endpoints (AMPLS)."
  type        = string
}
variable "onprem_forward_domains" {
  description = "Outbound ruleset: on-prem domains Azure must forward to enterprise DNS. Trailing dot required."
  type        = map(list(string))
  default = {
    "corp.contoso.com." = ["10.10.0.10", "10.10.0.11"]
    "10.in-addr.arpa."  = ["10.10.0.10", "10.10.0.11"]
  }
}
variable "additional_zone_link_vnet_ids" {
  description = "Other VNets to link the central zones to (DR hub in paired region). Spokes are NOT linked - they use the resolver."
  type        = map(string)
  default     = {}
}
variable "ruleset_link_vnet_ids" {
  description = "VNets that get the outbound forwarding ruleset (hub always; add DR hub). Only needed for VNets on Azure-provided DNS."
  type        = map(string)
  default     = {}
}
variable "private_dns_zones" {
  type = list(string)
  default = [
    "privatelink.vaultcore.azure.net",
    "privatelink.database.windows.net",
    "privatelink.postgres.database.azure.com",
    "privatelink.documents.azure.com",
    "privatelink.servicebus.windows.net",
    "privatelink.azurecr.io",
    "privatelink.azurewebsites.net",
    "privatelink.blob.core.windows.net",
    "privatelink.file.core.windows.net",
    "privatelink.queue.core.windows.net",
    "privatelink.table.core.windows.net",
    "privatelink.dfs.core.windows.net",
    # Azure Monitor / AMPLS
    "privatelink.monitor.azure.com",
    "privatelink.oms.opinsights.azure.com",
    "privatelink.ods.opinsights.azure.com",
    "privatelink.agentsvc.azure-automation.net",
  ]
}

# ---------- management / shared prod ----------
variable "log_analytics_workspace_ids" {
  description = "Workspaces to scope into the AMPLS (any subscription)."
  type        = map(string)
  default     = {}
}
variable "app_insights_ids" {
  type    = map(string)
  default = {}
}
variable "ampls_ingestion_access_mode" {
  description = "Start Open. Flip to PrivateOnly only once EVERY workspace/component reachable from this DNS is scoped."
  type        = string
  default     = "Open"
  validation {
    condition     = contains(["Open", "PrivateOnly"], var.ampls_ingestion_access_mode)
    error_message = "Open or PrivateOnly."
  }
}
variable "ampls_query_access_mode" {
  type    = string
  default = "Open"
}

# ---------- policy ----------
variable "policy_definition_mg_id" {
  description = "MG that holds the definitions, e.g. /providers/Microsoft.Management/managementGroups/contoso"
  type        = string
}
variable "landing_zones_mg_id" {
  description = "MG holding workload subscriptions (DINE + Deny assigned here)."
  type        = string
}
