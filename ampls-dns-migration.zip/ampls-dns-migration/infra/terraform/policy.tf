# =====================  GOVERNANCE (management-group scope)  =====================
# New PEs in workload subscriptions get their zone group from policy; scripts/04 backfills existing ones.
locals {
  dine_def = jsondecode(file("${path.module}/../policy/dine-pe-dns-zonegroup.json"))
  deny_def = jsondecode(file("${path.module}/../policy/deny-privatelink-zones.json"))
  zone_map = jsondecode(file("${path.module}/../../config/zone-map.json")).services

  # AMPLS is centrally owned (Terraform above) - no policy needed for it.
  dine_assignments = {
    for s in local.zone_map : "${s.groupId}-${substr(md5(s.resourceType), 0, 4)}" => s
    if s.groupId != "azuremonitor"
  }
}

resource "azurerm_policy_definition" "dine_pe_dns" {
  name                = "dine-pe-central-dns"
  policy_type         = "Custom"
  mode                = local.dine_def.mode
  display_name        = local.dine_def.displayName
  description         = local.dine_def.description
  management_group_id = var.policy_definition_mg_id
  metadata            = jsonencode(local.dine_def.metadata)
  parameters          = jsonencode(local.dine_def.parameters)
  policy_rule         = jsonencode(local.dine_def.policyRule)
}

resource "azurerm_policy_definition" "deny_pl_zones" {
  name                = "deny-privatelink-zones"
  policy_type         = "Custom"
  mode                = local.deny_def.mode
  display_name        = local.deny_def.displayName
  description         = local.deny_def.description
  management_group_id = var.policy_definition_mg_id
  metadata            = jsonencode(local.deny_def.metadata)
  parameters          = jsonencode(local.deny_def.parameters)
  policy_rule         = jsonencode(local.deny_def.policyRule)
}

resource "azurerm_management_group_policy_assignment" "dine_pe_dns" {
  for_each             = local.dine_assignments
  name                 = substr("pedns-${each.key}", 0, 24) # MG assignment names max 24 chars
  display_name         = "PE DNS -> central zone: ${each.value.name}"
  management_group_id  = var.landing_zones_mg_id
  policy_definition_id = azurerm_policy_definition.dine_pe_dns.id
  location             = var.location
  identity { type = "SystemAssigned" }
  parameters = jsonencode({
    groupId           = { value = each.value.groupId }
    resourceType      = { value = each.value.resourceType }
    privateDnsZoneIds = { value = [for z in each.value.zones : azurerm_private_dns_zone.pl[z].id] }
  })
}

# Identity needs: write zone groups on PEs (Network Contributor at MG) + join the central zones.
resource "azurerm_role_assignment" "dine_network" {
  for_each             = azurerm_management_group_policy_assignment.dine_pe_dns
  scope                = var.landing_zones_mg_id
  role_definition_name = "Network Contributor"
  principal_id         = each.value.identity[0].principal_id
}

resource "azurerm_role_assignment" "dine_zones" {
  for_each             = azurerm_management_group_policy_assignment.dine_pe_dns
  scope                = azurerm_resource_group.zones.id
  role_definition_name = "Private DNS Zone Contributor"
  principal_id         = each.value.identity[0].principal_id
}

resource "azurerm_management_group_policy_assignment" "deny_pl_zones" {
  name                 = "deny-pl-zones"
  display_name         = "Deny privatelink.* zones in landing zones"
  management_group_id  = var.landing_zones_mg_id
  policy_definition_id = azurerm_policy_definition.deny_pl_zones.id
  parameters           = jsonencode({ effect = { value = "Audit" } }) # Audit during migration, Deny after the last wave
}
