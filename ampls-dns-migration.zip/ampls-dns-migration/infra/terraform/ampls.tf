# =====================  SHARED PRODUCTION / MANAGEMENT SUBSCRIPTION  =====================
# ONE AMPLS per DNS namespace. Every network that resolves through this resolver gets these answers,
# so a second AMPLS + PE on the same DNS silently overwrites the first one's records.

resource "azurerm_resource_group" "monitor" {
  provider = azurerm.management
  name     = "rg-monitor-ampls"
  location = var.location
}

resource "azurerm_monitor_private_link_scope" "this" {
  provider              = azurerm.management
  name                  = "ampls-shared"
  resource_group_name   = azurerm_resource_group.monitor.name
  ingestion_access_mode = var.ampls_ingestion_access_mode
  query_access_mode     = var.ampls_query_access_mode
}

resource "azurerm_monitor_data_collection_endpoint" "shared" {
  provider                      = azurerm.management
  name                          = "dce-shared-${var.location}"
  resource_group_name           = azurerm_resource_group.monitor.name
  location                      = var.location
  public_network_access_enabled = true # flip after on-prem/Arc agents are proven over the PE
}

resource "azurerm_monitor_private_link_scoped_service" "law" {
  provider            = azurerm.management
  for_each            = var.log_analytics_workspace_ids
  name                = "law-${each.key}"
  resource_group_name = azurerm_resource_group.monitor.name
  scope_name          = azurerm_monitor_private_link_scope.this.name
  linked_resource_id  = each.value
}

resource "azurerm_monitor_private_link_scoped_service" "appi" {
  provider            = azurerm.management
  for_each            = var.app_insights_ids
  name                = "appi-${each.key}"
  resource_group_name = azurerm_resource_group.monitor.name
  scope_name          = azurerm_monitor_private_link_scope.this.name
  linked_resource_id  = each.value
}

resource "azurerm_monitor_private_link_scoped_service" "dce" {
  provider            = azurerm.management
  name                = "dce-shared"
  resource_group_name = azurerm_resource_group.monitor.name
  scope_name          = azurerm_monitor_private_link_scope.this.name
  linked_resource_id  = azurerm_monitor_data_collection_endpoint.shared.id
}

locals {
  ampls_zones = [
    "privatelink.monitor.azure.com",
    "privatelink.oms.opinsights.azure.com",
    "privatelink.ods.opinsights.azure.com",
    "privatelink.agentsvc.azure-automation.net",
    "privatelink.blob.core.windows.net", # solution-pack storage; SHARED with storage PEs -> migrate blob with AMPLS
  ]
}

# PE resource lives in the management sub; its NIC sits in the hub PE subnet (cross-sub subnet join).
resource "azurerm_private_endpoint" "ampls" {
  provider            = azurerm.management
  name                = "pe-ampls-shared"
  resource_group_name = azurerm_resource_group.monitor.name
  location            = var.location
  subnet_id           = var.pe_subnet_id

  private_service_connection {
    name                           = "ampls"
    private_connection_resource_id = azurerm_monitor_private_link_scope.this.id
    subresource_names              = ["azuremonitor"]
    is_manual_connection           = false
  }

  private_dns_zone_group {
    name                 = "default"
    private_dns_zone_ids = [for z in local.ampls_zones : azurerm_private_dns_zone.pl[z].id]
  }

  # Scope resources first so the initial zone-group write includes the per-workspace records
  # (<wsid>.oms/.ods/.agentsvc). After adding workspaces later, re-run scripts/09 to confirm their records landed.
  depends_on = [
    azurerm_monitor_private_link_scoped_service.law,
    azurerm_monitor_private_link_scoped_service.appi,
    azurerm_monitor_private_link_scoped_service.dce,
  ]
}

output "resolver_inbound_ip" { value = var.resolver_inbound_ip }
output "central_zone_rg_id" { value = azurerm_resource_group.zones.id }
output "ampls_id" { value = azurerm_monitor_private_link_scope.this.id }
output "dce_id" { value = azurerm_monitor_data_collection_endpoint.shared.id }
