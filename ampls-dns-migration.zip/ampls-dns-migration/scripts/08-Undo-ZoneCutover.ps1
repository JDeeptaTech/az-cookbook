#requires -Version 5.1
<#
.SYNOPSIS
  Roll back a 07 cutover from its JSON log: remove only the forwarders 07 added, recreate the privatelink zones
  with their original replication scope, re-add every A/CNAME record, flush caches.
.EXAMPLE
  .\08-Undo-ZoneCutover.ps1 -LogPath .\cutover-logs\cutover-privatelink-vaultcore-azure-net-20261102-210501.json
#>
[CmdletBinding(SupportsShouldProcess, ConfirmImpact = 'High')]
param([Parameter(Mandatory)][string]$LogPath)
$ErrorActionPreference = 'Stop'
Import-Module DnsServer
$log = Get-Content -Raw $LogPath | ConvertFrom-Json
$primary = $log.Servers[0]

foreach ($f in $log.ForwardersAdded) {
    if ((Get-DnsServerZone -ComputerName $f.Server -Name $f.Name -ErrorAction SilentlyContinue) -and
        $PSCmdlet.ShouldProcess($f.Server, "Remove forwarder $($f.Name)")) {
        Remove-DnsServerZone -ComputerName $f.Server -Name $f.Name -Force
    }
}

foreach ($z in $log.Zones) {
    $servers = if ($z.IsDsIntegrated) { @($primary) } else { $log.Servers }
    foreach ($srv in $servers) {
        if (-not (Get-DnsServerZone -ComputerName $srv -Name $z.Zone -ErrorAction SilentlyContinue)) {
            if (-not $PSCmdlet.ShouldProcess($srv, "Recreate zone $($z.Zone)")) { continue }
            if ($z.IsDsIntegrated) { Add-DnsServerPrimaryZone -ComputerName $srv -Name $z.Zone -ReplicationScope $z.ReplicationScope }
            else                   { Add-DnsServerPrimaryZone -ComputerName $srv -Name $z.Zone -ZoneFile "$($z.Zone).dns" }
        }
        foreach ($r in $z.Records) {
            if ($r.Name -eq '@') { continue }
            $ttl = [TimeSpan]::FromSeconds([int]$r.Ttl)
            try {
                if ($r.Type -eq 'A') { Add-DnsServerResourceRecordA -ComputerName $srv -ZoneName $z.Zone -Name $r.Name -IPv4Address $r.Data -TimeToLive $ttl -ErrorAction Stop }
                else                 { Add-DnsServerResourceRecordCName -ComputerName $srv -ZoneName $z.Zone -Name $r.Name -HostNameAlias $r.Data -TimeToLive $ttl -ErrorAction Stop }
            } catch { if ($_.Exception.Message -notmatch 'already exists') { throw } }
        }
        Write-Host "Restored $($z.Zone) on $srv ($(@($z.Records).Count) records)"
    }
}
foreach ($srv in $log.Servers) { Clear-DnsServerCache -ComputerName $srv -Force }
Write-Host 'Rollback complete. If AD-integrated, force replication (repadmin /syncall /AdeP) and flush the other DCs.' -ForegroundColor Yellow
