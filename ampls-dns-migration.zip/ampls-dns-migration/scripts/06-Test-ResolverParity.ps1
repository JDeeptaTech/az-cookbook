#requires -Version 7.2
<#
.SYNOPSIS
  Pre-cutover proof: ask the CURRENT enterprise DNS and the Private Resolver INBOUND endpoint the same question
  (the public FQDN a client would query) and compare answers. Run from an on-prem host that can reach both.
.DESCRIPTION
  Expected after 04/05: Match for everything except StaleOnPrem/NewPrivatePath rows (those are intended changes).
  Also asserts every resolver answer is inside -PrivateCidr, which catches "resolver fell through to public".
  Exit 1 on unexpected mismatch -> use as the go/no-go gate for 07.
.EXAMPLE
  ./06-Test-ResolverParity.ps1 -CurrentDns 10.10.0.10 -ResolverInbound 10.0.0.4,10.64.0.4 -PrivateCidr 10.0.0.0/8 -Zone privatelink.vaultcore.azure.net
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory)][string]$CurrentDns,
    [Parameter(Mandatory)][string[]]$ResolverInbound,
    [Parameter(Mandatory)][string[]]$PrivateCidr,
    [string]$ReconcileCsv = './out/reconcile.csv',
    [string[]]$Zone,
    [int]$Sample = 0   # 0 = all rows
)
$ErrorActionPreference = 'Stop'
Import-Module (Join-Path $PSScriptRoot 'DnsMigration.psm1') -Force

$rows = Import-Csv $ReconcileCsv | Where-Object { -not $Zone -or $_.Zone -in $Zone } | Where-Object Status -ne 'OrphanCentral'
if ($Sample -gt 0) { $rows = $rows | Get-Random -Count ([math]::Min($Sample, @($rows).Count)) }

$modPath = Join-Path $PSScriptRoot 'DnsMigration.psm1'
$res = $rows | ForEach-Object -ThrottleLimit 16 -Parallel {
    Import-Module $using:modPath
    $r = $_
    $cur = @(Resolve-ARecord -Name $r.PublicFqdn -Server $using:CurrentDns)
    $answers = @{}
    foreach ($s in $using:ResolverInbound) { $answers[$s] = (@(Resolve-ARecord -Name $r.PublicFqdn -Server $s)) -join ',' }
    $new = @(Resolve-ARecord -Name $r.PublicFqdn -Server ($using:ResolverInbound)[0])
    $resolversAgree = @($answers.Values | Sort-Object -Unique).Count -eq 1
    $cidr = $using:PrivateCidr
    $allPrivate = $new.Count -gt 0 -and -not ($new | Where-Object { -not (Test-IpInCidr -Ip $_ -Cidr $cidr) })
    $verdict = if (-not $new)                    { 'FAIL-NoAnswerFromResolver' }
               elseif (-not $resolversAgree)     { 'FAIL-ResolversDisagree' }
               elseif (-not $allPrivate)         { 'FAIL-ResolverReturnedPublic' }
               elseif (($cur -join ',') -eq ($new -join ',')) { 'Match' }
               elseif ($r.Status -in 'StaleOnPrem', 'NewPrivatePath') { "ExpectedChange-$($r.Status)" }
               else                              { 'FAIL-Mismatch' }
    [pscustomobject]@{ Verdict = $verdict; Fqdn = $r.PublicFqdn; Current = $cur -join ';'; Resolver = $new -join ';'; Zone = $r.Zone }
}
$res | Sort-Object Verdict, Fqdn | Export-Csv './out/parity.csv' -NoTypeInformation
$res | Group-Object Verdict | Sort-Object Name | Format-Table Name, Count -AutoSize | Out-String -Width 200 | Write-Host
$fail = $res | Where-Object Verdict -like 'FAIL*'
if ($fail) { $fail | Select-Object -First 15 | Format-Table -AutoSize | Out-String -Width 200 | Write-Host; Write-Error "$(@($fail).Count) parity failures - DO NOT cut over." ; exit 1 }
Write-Host 'Parity OK - safe to run 07-Invoke-ZoneCutover for these zones.' -ForegroundColor Green
