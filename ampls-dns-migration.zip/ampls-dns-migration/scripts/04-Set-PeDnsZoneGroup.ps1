#requires -Version 7.2
#requires -Modules Az.Accounts, Az.Network
<#
.SYNOPSIS
  Point existing private endpoints (any subscription) at the CENTRAL privatelink zones via a DNS zone group.
  The zone group then owns the A records - no manual records, IP changes self-heal.
.DESCRIPTION
  Idempotent. Drives off reconcile.csv (Status NeedsZoneGroup / CentralIpDrift) or an explicit -PeId list.
  -ReplaceNonCentral swaps zone groups that point at duplicate zones in workload subscriptions.
  Long term the DINE policy (infra/terraform/policy.tf) does this for new PEs; this script backfills existing ones.
  Needs: Network Contributor on the PE + Microsoft.Network/privateDnsZones/join/action on the central zones.
.EXAMPLE
  ./04-Set-PeDnsZoneGroup.ps1 -ReconcileCsv ./out/reconcile.csv -CentralZoneRgId /subscriptions/<conn>/resourceGroups/rg-dns-privatezones -WhatIf
#>
[CmdletBinding(SupportsShouldProcess, ConfirmImpact = 'Medium')]
param(
    [string]$ReconcileCsv = './out/reconcile.csv',
    [string[]]$PeId,
    [Parameter(Mandatory)][string]$CentralZoneRgId,
    [switch]$ReplaceNonCentral
)
$ErrorActionPreference = 'Stop'
Import-Module (Join-Path $PSScriptRoot 'DnsMigration.psm1') -Force
$zoneMap = Get-ZoneMap

$targets = if ($PeId) { $PeId | ForEach-Object { [pscustomobject]@{ PeId = $_.ToLower(); GroupId = $null } } }
           else { Import-Csv $ReconcileCsv | Where-Object { $_.Status -in 'NeedsZoneGroup', 'CentralIpDrift' -and $_.PeId } |
                  Select-Object PeId, GroupId -Unique }
$targets = $targets | Sort-Object PeId -Unique
Write-Host "Private endpoints to process: $(@($targets).Count)"

$results = foreach ($t in $targets) {
    # /subscriptions/{s}/resourceGroups/{rg}/providers/Microsoft.Network/privateEndpoints/{name}
    $p = $t.PeId -split '/'
    $sub, $rg, $name = $p[2], $p[4], $p[8]
    try {
        $null = Set-AzContext -Subscription $sub -WarningAction SilentlyContinue
        $pe = Get-AzPrivateEndpoint -ResourceGroupName $rg -Name $name
        $conn = @($pe.PrivateLinkServiceConnections) + @($pe.ManualPrivateLinkServiceConnections) | Select-Object -First 1
        $groupId = $conn.GroupIds[0]
        $svc = $zoneMap | Where-Object { $_.groupId -eq $groupId -and $conn.PrivateLinkServiceId -match [regex]::Escape($_.resourceType) } | Select-Object -First 1
        if (-not $svc) { $svc = $zoneMap | Where-Object groupId -eq $groupId | Select-Object -First 1 }
        if (-not $svc) { [pscustomobject]@{ PeId = $t.PeId; Result = "Skipped: groupId '$groupId' not in zone-map" }; continue }

        $wantIds = $svc.zones | ForEach-Object { "$CentralZoneRgId/providers/Microsoft.Network/privateDnsZones/$_".ToLower() }
        $existing = Get-AzPrivateDnsZoneGroup -ResourceGroupName $rg -PrivateEndpointName $name -ErrorAction SilentlyContinue
        if ($existing) {
            $haveIds = $existing.PrivateDnsZoneConfigs.PrivateDnsZoneId | ForEach-Object { $_.ToLower() }
            if (-not (Compare-Object $haveIds $wantIds)) { [pscustomobject]@{ PeId = $t.PeId; Result = 'Already central' }; continue }
            if (-not $ReplaceNonCentral) { [pscustomobject]@{ PeId = $t.PeId; Result = "Skipped: zone group points elsewhere ($($haveIds -join ', ')). Use -ReplaceNonCentral" }; continue }
            if ($PSCmdlet.ShouldProcess($t.PeId, "Remove zone group '$($existing.Name)' (non-central)")) {
                Remove-AzPrivateDnsZoneGroup -ResourceGroupName $rg -PrivateEndpointName $name -Name $existing.Name -Force
            }
        }
        $configs = foreach ($id in $wantIds) {
            New-AzPrivateDnsZoneConfig -Name (($id -split '/')[-1] -replace '\.', '-') -PrivateDnsZoneId $id
        }
        if ($PSCmdlet.ShouldProcess($t.PeId, "Create zone group 'default' -> $($svc.zones -join ', ')")) {
            $null = New-AzPrivateDnsZoneGroup -ResourceGroupName $rg -PrivateEndpointName $name -Name 'default' -PrivateDnsZoneConfig $configs -Force
            [pscustomobject]@{ PeId = $t.PeId; Result = 'Created' }
        } else { [pscustomobject]@{ PeId = $t.PeId; Result = 'WhatIf' } }
    } catch {
        [pscustomobject]@{ PeId = $t.PeId; Result = "ERROR: $($_.Exception.Message)" }
    }
}
$results | Group-Object { ($_.Result -split ':')[0] } | Format-Table Name, Count -AutoSize | Out-String -Width 200 | Write-Host
$results | Export-Csv './out/zonegroup-results.csv' -NoTypeInformation
Write-Host 'Re-run 02 + 03 to confirm the central zones now hold every PE record.'
