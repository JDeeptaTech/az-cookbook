#requires -Version 7.2
<#
.SYNOPSIS
  Client-side AMPLS check: every Azure Monitor endpoint an agent/SDK touches resolves to the AMPLS PE subnet
  and TCP/443 connects. Run from: an on-prem server, a spoke VM, and an ARO/AKS node (oc debug / kubectl debug).
.EXAMPLE
  ./09-Test-AmplsConnectivity.ps1 -WorkspaceId 1b2c...,9f8e... -Region uksouth -DceName dce-shared-uks `
     -PeSubnetCidr 10.0.1.0/24 -DnsServer 10.10.0.10
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory)][string[]]$WorkspaceId,
    [Parameter(Mandatory)][string]$Region,
    [Parameter(Mandatory)][string[]]$PeSubnetCidr,
    [string[]]$DceName,                 # DCE resource names - AMA with DCRs that use a DCE
    [string[]]$AppInsightsIngestion,   # host from connection string, e.g. uksouth-1.in.applicationinsights.azure.com
    [string]$DnsServer                  # omit to use the OS resolver (what the agent actually uses)
)
$ErrorActionPreference = 'Stop'
Import-Module (Join-Path $PSScriptRoot 'DnsMigration.psm1') -Force

$names = [System.Collections.Generic.List[string]]::new()
'api.monitor.azure.com', 'global.in.ai.monitor.azure.com', 'live.monitor.azure.com', 'profiler.monitor.azure.com',
'snapshot.monitor.azure.com', 'global.handler.control.monitor.azure.com', "$Region.handler.control.monitor.azure.com",
'scadvisorcontentpl.blob.core.windows.net' | ForEach-Object { $names.Add($_) }
foreach ($w in $WorkspaceId) { "$w.ods.opinsights.azure.com", "$w.oms.opinsights.azure.com", "$w.agentsvc.azure-automation.net" | ForEach-Object { $names.Add($_) } }
foreach ($d in $DceName) { "$d.$Region-1.ingest.monitor.azure.com", "$d.$Region-1.handler.control.monitor.azure.com" | ForEach-Object { $names.Add($_) } }
foreach ($a in $AppInsightsIngestion) { $names.Add($a) }

function Test-Tcp([string]$ip, [int]$port = 443, [int]$ms = 2500) {
    $c = [System.Net.Sockets.TcpClient]::new()
    try { $c.ConnectAsync($ip, $port).Wait($ms) -and $c.Connected } catch { $false } finally { $c.Dispose() }
}

$res = foreach ($n in $names) {
    $ips = if ($DnsServer) { Resolve-ARecord -Name $n -Server $DnsServer }
           else { try { [System.Net.Dns]::GetHostAddresses($n) | Where-Object AddressFamily -eq 'InterNetwork' | ForEach-Object IPAddressToString } catch { @() } }
    $ip = @($ips)[0]
    $private = $ip -and (Test-IpInCidr -Ip $ip -Cidr $PeSubnetCidr)
    [pscustomobject]@{
        Endpoint = $n; Ip = ($ips -join ';')
        Private  = [bool]$private
        Tcp443   = [bool]($ip -and (Test-Tcp $ip))
        Verdict  = if (-not $ip) { 'FAIL-NXDOMAIN' } elseif (-not $private) { 'FAIL-PublicIP' } elseif (-not (Test-Tcp $ip)) { 'FAIL-NoRoute' } else { 'OK' }
    }
}
$res | Format-Table -AutoSize | Out-String -Width 200 | Write-Host
$res | Export-Csv './out/ampls-connectivity.csv' -NoTypeInformation
if ($res.Verdict -like 'FAIL*') {
    Write-Host @'
FAIL-PublicIP  -> this client's DNS path doesn't reach the central zones (forwarder missing / spoke VNet DNS not set / zone not linked).
FAIL-NXDOMAIN  -> zone exists but record missing: workspace/DCE/component not added to the AMPLS, or AMPLS PE zone group not on central zones.
FAIL-NoRoute   -> DNS fine, network isn't: UDR/NVA/NSG/ExpressRoute route to the PE subnet.
'@ -ForegroundColor Yellow
    exit 1
}
