#requires -Version 5.1
<#
.SYNOPSIS
  Cut a privatelink zone over from "hosted on Windows DNS" to "conditional forwarder -> DNS Private Resolver inbound".
.DESCRIPTION
  Per zone:
    1. Preflight  - resolver inbound IPs answer; no conflicting local zone/forwarder for the public name.
    2. Backup     - zone file export + full record dump to a JSON cutover log (08-Undo consumes it).
    3. Forwarder  - add conditional forwarder for the PUBLIC zone(s) (blob.core.windows.net, vault.azure.net ...).
                    This is the actual cutover moment for client lookups.
    4. Remove     - delete the local privatelink.* zone so direct/legacy lookups stop hitting stale data.
    5. Flush      - clear server cache on every listed DNS server.
    6. Validate   - every backed-up record name resolves via THIS server to the same IP the resolver returns.
  AD-integrated: forwarder is created AD-integrated with -ReplicationScope; run against ONE DC then force
  replication (repadmin /syncall /AdeP) and flush caches on the rest (-ComputerName lists them all).
  File-backed / standalone servers: forwarder + removal are applied on every -ComputerName.
.EXAMPLE
  # Wave 1 dry run, then real
  .\07-Invoke-ZoneCutover.ps1 -Zone privatelink.vaultcore.azure.net -InboundIp 10.0.0.4,10.64.0.4 -ComputerName dc01,dc02 -WhatIf
  .\07-Invoke-ZoneCutover.ps1 -Zone privatelink.vaultcore.azure.net -InboundIp 10.0.0.4,10.64.0.4 -ComputerName dc01,dc02 -AutoRollback
#>
[CmdletBinding(SupportsShouldProcess, ConfirmImpact = 'High')]
param(
    [Parameter(Mandatory)][string[]]$Zone,
    [Parameter(Mandatory)][string[]]$InboundIp,
    [string[]]$ComputerName = @($env:COMPUTERNAME),
    [ValidateSet('Forest', 'Domain', 'Legacy', 'None')][string]$ReplicationScope = 'Forest',
    [string]$LogDir = '.\cutover-logs',
    [string]$ResolverProbeFqdn = 'management.azure.com',
    [switch]$KeepLocalZone,
    [switch]$AutoRollback
)
$ErrorActionPreference = 'Stop'
Import-Module DnsServer
Import-Module (Join-Path $PSScriptRoot 'DnsMigration.psm1') -Force
$zoneMap = Get-ZoneMap
$sfx = Get-SuffixIndex -ZoneMap $zoneMap
$primary = $ComputerName[0]
New-Item -ItemType Directory -Force -Path $LogDir | Out-Null
$logPath = Join-Path $LogDir ("cutover-{0}-{1}.json" -f ($Zone[0] -replace '[^a-z0-9]', '-'), (Get-Date -Format 'yyyyMMdd-HHmmss'))

# --- which public zones do we forward for the requested privatelink zones? ---
$forwarders = @($sfx.Keys | Where-Object { $_ -notlike 'privatelink.*' -and $sfx[$_] -in $Zone }) | Sort-Object -Unique
if (-not $forwarders) { throw "No public suffixes in zone-map for: $($Zone -join ', ')" }
Write-Host "Zones: $($Zone -join ', ')`nForwarders to add: $($forwarders -join ', ') -> $($InboundIp -join ', ')"

# --- 1. preflight ---
foreach ($ip in $InboundIp) {
    if (-not (Resolve-ARecord -Name $ResolverProbeFqdn -Server $ip)) { throw "Resolver inbound $ip did not answer for $ResolverProbeFqdn (UDP/TCP 53 from $env:COMPUTERNAME blocked?)" }
}
$existingZones = Get-DnsServerZone -ComputerName $primary
foreach ($f in $forwarders) {
    $hit = $existingZones | Where-Object ZoneName -eq $f
    if ($hit -and $hit.ZoneType -ne 'Forwarder') { throw "$f exists as a $($hit.ZoneType) zone on $primary - it would shadow the forwarder. Resolve manually." }
    if ($hit) {
        $m = ($hit.MasterServers.IPAddressToString | Sort-Object) -join ','
        if ($m -ne (($InboundIp | Sort-Object) -join ',')) { throw "Forwarder $f already exists -> $m. Refusing to overwrite." }
    }
    $parent = $existingZones | Where-Object { $_.ZoneType -eq 'Forwarder' -and $f.EndsWith(".$($_.ZoneName)") }
    if ($parent) { Write-Warning "Parent forwarder(s) $($parent.ZoneName -join ',') exist; the more specific $f will take precedence." }
}
$missing = $Zone | Where-Object { $_ -notin $existingZones.ZoneName }
if ($missing) { Write-Warning "Not hosted on ${primary} (nothing to remove): $($missing -join ', ')" }

# --- 2. backup ---
$log = [ordered]@{ Started = (Get-Date).ToString('o'); Servers = $ComputerName; InboundIp = $InboundIp; ReplicationScope = $ReplicationScope; Zones = @(); ForwardersAdded = @() }
foreach ($z in ($Zone | Where-Object { $_ -in $existingZones.ZoneName })) {
    $meta = $existingZones | Where-Object ZoneName -eq $z
    $bak = "$z.precutover.$(Get-Date -Format 'yyyyMMddHHmmss').bak"
    Export-DnsServerZone -ComputerName $primary -Name $z -FileName $bak
    $recs = Get-DnsServerResourceRecord -ComputerName $primary -ZoneName $z | Where-Object RecordType -in 'A', 'CNAME' | ForEach-Object {
        @{ Name = $_.HostName; Type = "$($_.RecordType)"; Ttl = [int]$_.TimeToLive.TotalSeconds
           Data = $(if ($_.RecordType -eq 'A') { $_.RecordData.IPv4Address.IPAddressToString } else { $_.RecordData.HostNameAlias }) }
    }
    $log.Zones += @{ Zone = $z; IsDsIntegrated = [bool]$meta.IsDsIntegrated; ReplicationScope = "$($meta.ReplicationScope)"; BackupFile = $bak; Records = @($recs) }
}
$log | ConvertTo-Json -Depth 6 | Set-Content $logPath
Write-Host "Backup + log: $logPath"

function Save-Log { $log | ConvertTo-Json -Depth 6 | Set-Content $logPath }

try {
    # --- 3. forwarders ---
    $targets = if ($ReplicationScope -ne 'None') { @($primary) } else { $ComputerName }
    foreach ($f in $forwarders) {
        foreach ($srv in $targets) {
            if (Get-DnsServerZone -ComputerName $srv -Name $f -ErrorAction SilentlyContinue) { continue }
            if ($PSCmdlet.ShouldProcess("$srv", "Add conditional forwarder $f -> $($InboundIp -join ',')")) {
                if ($ReplicationScope -ne 'None') {
                    Add-DnsServerConditionalForwarderZone -ComputerName $srv -Name $f -MasterServers $InboundIp -ReplicationScope $ReplicationScope -ForwarderTimeout 3
                } else {
                    Add-DnsServerConditionalForwarderZone -ComputerName $srv -Name $f -MasterServers $InboundIp -ForwarderTimeout 3
                }
                $log.ForwardersAdded += @{ Name = $f; Server = $srv }; Save-Log
            }
        }
    }
    # --- 4. remove local privatelink zones ---
    if (-not $KeepLocalZone) {
        foreach ($zb in $log.Zones) {
            $zTargets = if ($zb.IsDsIntegrated) { @($primary) } else { $ComputerName }
            foreach ($srv in $zTargets) {
                if ($PSCmdlet.ShouldProcess("$srv", "Remove zone $($zb.Zone)")) {
                    Remove-DnsServerZone -ComputerName $srv -Name $zb.Zone -Force
                    $zb.Removed = $true; Save-Log
                }
            }
        }
    }
    # --- 5. flush ---
    if ($PSCmdlet.ShouldProcess(($ComputerName -join ','), 'Clear DNS server cache')) {
        foreach ($srv in $ComputerName) { Clear-DnsServerCache -ComputerName $srv -Force }
    }
    if ($WhatIfPreference) { return }
    if ($ReplicationScope -ne 'None' -and $ComputerName.Count -gt 1) {
        Write-Warning "AD-integrated change made on $primary. Force replication now (repadmin /syncall /AdeP) and re-flush the others before validating them."
    }

    # --- 6. validate via the primary server against the resolver ---
    $bad = @()
    foreach ($zb in $log.Zones) {
        foreach ($r in ($zb.Records | Where-Object { $_.Type -eq 'A' -and $_.Name -ne '@' })) {
            $key = "$($r.Name)|$($zb.Zone)"
            $fq = Get-PublicFqdn -Key $key -ZoneMap $zoneMap
            $viaServer   = (Resolve-ARecord -Name $fq -Server $primary) -join ','
            $viaResolver = (Resolve-ARecord -Name $fq -Server $InboundIp[0]) -join ','
            if (-not $viaServer -or $viaServer -ne $viaResolver) { $bad += [pscustomobject]@{ Fqdn = $fq; Server = $viaServer; Resolver = $viaResolver; WasOnPrem = $r.Data } }
        }
    }
    $log.Validation = @{ Checked = ($log.Zones.Records | Measure-Object).Count; Failed = $bad.Count }; Save-Log
    if ($bad) {
        $bad | Format-Table -AutoSize | Out-String -Width 200 | Write-Host
        throw "$($bad.Count) names do not resolve identically via $primary and the resolver."
    }
    Write-Host "Cutover complete and validated. Log: $logPath" -ForegroundColor Green
}
catch {
    Write-Error $_
    if ($AutoRollback -and -not $WhatIfPreference) {
        Write-Warning 'AutoRollback: restoring from log'
        & (Join-Path $PSScriptRoot '08-Undo-ZoneCutover.ps1') -LogPath $logPath -Confirm:$false
    } else { Write-Warning "Rollback: .\08-Undo-ZoneCutover.ps1 -LogPath $logPath" }
    exit 1
}
