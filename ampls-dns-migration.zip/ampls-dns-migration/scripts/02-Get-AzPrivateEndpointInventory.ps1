#requires -Version 7.2
#requires -Modules Az.Accounts, Az.ResourceGraph, Az.PrivateDns
<#
.SYNOPSIS
  Ground truth from Azure: every private endpoint FQDN/IP (from the PE NIC, which is populated whether or not a
  zone group exists) plus every record currently in the central privatelink zones.
.OUTPUTS
  out/azure-pe.csv            peId, subscription, groupId, fqdn, ip, targetId, connState, isManual
  out/central-records.csv     zone, name, ip  (what the resolver will answer after cutover)
.EXAMPLE
  ./02-Get-AzPrivateEndpointInventory.ps1 -ManagementGroup mg-root -DnsZoneSubscriptionId <conn-sub> -DnsZoneResourceGroup rg-dns-privatezones
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory)][string]$ManagementGroup,
    [Parameter(Mandatory)][string]$DnsZoneSubscriptionId,
    [Parameter(Mandatory)][string]$DnsZoneResourceGroup,
    [string]$OutDir = './out'
)
$ErrorActionPreference = 'Stop'
Import-Module (Join-Path $PSScriptRoot 'DnsMigration.psm1') -Force
New-Item -ItemType Directory -Force -Path $OutDir | Out-Null

$kql = @'
resources
| where type =~ 'microsoft.network/networkinterfaces' and isnotempty(properties.privateEndpoint.id)
| mv-expand ipc = properties.ipConfigurations
| extend ip = tostring(ipc.properties.privateIPAddress),
         groupId = tostring(ipc.properties.privateLinkConnectionProperties.groupId)
| mv-expand fqdn = ipc.properties.privateLinkConnectionProperties.fqdns
| project peId = tolower(tostring(properties.privateEndpoint.id)), ip, groupId, fqdn = tolower(tostring(fqdn))
| join kind=leftouter (
    resources
    | where type =~ 'microsoft.network/privateendpoints'
    | extend isManual = array_length(properties.manualPrivateLinkServiceConnections) > 0
    | extend conn = iff(isManual, properties.manualPrivateLinkServiceConnections[0], properties.privateLinkServiceConnections[0])
    | project peId = tolower(id), peName = name, subscriptionId, resourceGroup, location, isManual,
              subnetId = tostring(properties.subnet.id),
              targetId = tostring(conn.properties.privateLinkServiceId),
              connState = tostring(conn.properties.privateLinkServiceConnectionState.status)
  ) on peId
| project-away peId1
'@

# ARG pages at 1000; loop with skip token so large estates are complete.
$results = [System.Collections.Generic.List[object]]::new()
$skip = $null
do {
    $page = if ($skip) { Search-AzGraph -Query $kql -ManagementGroup $ManagementGroup -First 1000 -SkipToken $skip }
            else       { Search-AzGraph -Query $kql -ManagementGroup $ManagementGroup -First 1000 }
    $results.AddRange([object[]]$page.Data)
    $skip = $page.SkipToken
} while ($skip)

$results | Select-Object subscriptionId, resourceGroup, peName, peId, location, groupId, fqdn, ip, targetId, connState, isManual, subnetId |
    Export-Csv (Join-Path $OutDir 'azure-pe.csv') -NoTypeInformation

# What's in the central zones right now
$zoneMap = Get-ZoneMap
$null = Set-AzContext -Subscription $DnsZoneSubscriptionId
$central = foreach ($zone in ($zoneMap.zones | Sort-Object -Unique)) {
    $z = Get-AzPrivateDnsZone -ResourceGroupName $DnsZoneResourceGroup -Name $zone -ErrorAction SilentlyContinue
    if (-not $z) { Write-Warning "Central zone missing: $zone (deploy infra/terraform first)"; continue }
    Get-AzPrivateDnsRecordSet -ResourceGroupName $DnsZoneResourceGroup -ZoneName $zone -RecordType A |
        ForEach-Object { $rs = $_; $rs.Records | ForEach-Object { [pscustomobject]@{ Zone = $zone; Name = $rs.Name.ToLower(); Ip = $_.Ipv4Address; Ttl = $rs.Ttl } } }
}
$central | Export-Csv (Join-Path $OutDir 'central-records.csv') -NoTypeInformation

$notApproved = $results | Where-Object connState -ne 'Approved'
if ($notApproved) { Write-Warning "$(@($notApproved).Count) PE connections not Approved (pending/rejected/disconnected) - exclude from cutover sign-off." }
Write-Host "PE FQDN rows: $($results.Count)  | central zone A records: $(@($central).Count)"
