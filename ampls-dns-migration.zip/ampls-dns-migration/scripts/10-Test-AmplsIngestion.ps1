#requires -Version 7.2
#requires -Modules Az.Accounts, Az.Monitor, Az.OperationalInsights, Az.ResourceGraph
<#
.SYNOPSIS
  Server-side AMPLS check: AMPLS scope membership vs every workspace/App Insights/DCE in the estate, access
  modes, workspace network isolation, and whether agents are actually landing data (Heartbeat freshness).
  -AddMissing adds unscoped workspaces/components to the AMPLS (Open mode makes this safe to do in bulk).
#>
[CmdletBinding(SupportsShouldProcess)]
param(
    [Parameter(Mandatory)][string]$AmplsId,
    [Parameter(Mandatory)][string]$ManagementGroup,
    [string]$HeartbeatWorkspaceId,     # workspace GUID to query
    [int]$StaleMinutes = 15,
    [switch]$AddMissing
)
$ErrorActionPreference = 'Stop'
$p = $AmplsId -split '/'; $sub, $rg, $scopeName = $p[2], $p[4], $p[8]
$null = Set-AzContext -Subscription $sub
$scope = Get-AzInsightsPrivateLinkScope -ResourceGroupName $rg -Name $scopeName
$scoped = Get-AzInsightsPrivateLinkScopedResource -ResourceGroupName $rg -ScopeName $scopeName
$scopedIds = $scoped.LinkedResourceId | ForEach-Object { $_.ToLower() }

Write-Host "AMPLS $scopeName  ingestion=$($scope.AccessModeSettingIngestionAccessMode) query=$($scope.AccessModeSettingQueryAccessMode)  scoped=$($scopedIds.Count)  PEs=$(@($scope.PrivateEndpointConnection).Count)/10"

$kql = @'
resources
| where type in~ ('microsoft.operationalinsights/workspaces','microsoft.insights/components','microsoft.insights/datacollectionendpoints')
| project id = tolower(id), name, type, subscriptionId,
          ingest = tostring(coalesce(properties.publicNetworkAccessForIngestion, properties.networkAcls.publicNetworkAccess)),
          query  = tostring(properties.publicNetworkAccessForQuery)
'@
$all = (Search-AzGraph -Query $kql -ManagementGroup $ManagementGroup -First 1000).Data
$missing = $all | Where-Object { $_.id -notin $scopedIds }
$all | ForEach-Object { $_ | Add-Member InAmpls ($_.id -in $scopedIds) -PassThru } |
    Sort-Object InAmpls, type | Format-Table name, type, InAmpls, ingest, query -AutoSize | Out-String -Width 200 | Write-Host

if ($scope.AccessModeSettingIngestionAccessMode -eq 'PrivateOnly' -and $missing) {
    Write-Warning "PrivateOnly mode with $(@($missing).Count) resources OUTSIDE the AMPLS: every network on this DNS is blocked from them."
}
if ($AddMissing) {
    foreach ($m in ($missing | Where-Object type -ne 'microsoft.insights/datacollectionendpoints')) {
        $nm = ("{0}-{1}" -f $m.name, $m.subscriptionId.Substring(0, 8)) -replace '[^A-Za-z0-9\-_]', '-'
        if ($PSCmdlet.ShouldProcess($m.id, "Add to $scopeName")) {
            $null = New-AzInsightsPrivateLinkScopedResource -ResourceGroupName $rg -ScopeName $scopeName -Name $nm -LinkedResourceId $m.id
        }
    }
    Write-Host 'DCEs are scoped the same way but are usually Terraform-owned - add them in ampls.tf, not here.'
}

if ($HeartbeatWorkspaceId) {
    $q = "Heartbeat | where TimeGenerated > ago(1d) | summarize Last = max(TimeGenerated) by Computer, Category, OSType | extend AgeMin = datetime_diff('minute', now(), Last) | order by AgeMin desc"
    $hb = (Invoke-AzOperationalInsightsQuery -WorkspaceId $HeartbeatWorkspaceId -Query $q).Results
    $stale = $hb | Where-Object { [int]$_.AgeMin -gt $StaleMinutes }
    Write-Host "Agents reporting: $(@($hb).Count)  stale (>$StaleMinutes min): $(@($stale).Count)"
    $stale | Select-Object -First 25 | Format-Table Computer, Category, OSType, Last, AgeMin -AutoSize | Out-String -Width 200 | Write-Host
    if ($stale) { exit 1 }
}
