#requires -Version 7.2
<#
.SYNOPSIS
  Three-way reconcile: on-prem zone records  vs  Azure PE truth  vs  central private DNS zones.
.DESCRIPTION
  Status values (one row per <relative-name, privatelink-zone>):
    OK                 on-prem IP == PE IP == central IP. Cutover is a no-op for clients.
    NeedsZoneGroup     PE exists, central zone has no record. Fix with 04-Set-PeDnsZoneGroup.ps1 BEFORE cutover.
    CentralIpDrift     central record IP != PE IP (stale manual record). Fix before cutover.
    StaleOnPrem        on-prem IP != PE IP. Clients are broken today; cutover FIXES them (expect behaviour change).
    OrphanOnPrem       on-prem record with no PE in Azure. Deleted resource, other tenant, or 3rd-party PLS.
                       Will STOP resolving after cutover unless you add it to the central zone (05-Import).
    NewPrivatePath     PE exists but on-prem had no record -> clients reach the PUBLIC endpoint today and will
                       switch to the PRIVATE IP after cutover. Check routing/NSG/firewall to the PE subnet.
  Exit code 1 if anything other than OK/StaleOnPrem/NewPrivatePath exists (use as a pipeline gate).
#>
[CmdletBinding()]
param(
    [string]$OnPremCsv  = './out/onprem-records.csv',
    [string]$AzurePeCsv = './out/azure-pe.csv',
    [string]$CentralCsv = './out/central-records.csv',
    [string]$OutCsv     = './out/reconcile.csv',
    [string[]]$OnlyZones
)
$ErrorActionPreference = 'Stop'
Import-Module (Join-Path $PSScriptRoot 'DnsMigration.psm1') -Force
$zoneMap = Get-ZoneMap
$sfx = Get-SuffixIndex -ZoneMap $zoneMap

$table = @{}
function Get-Row([string]$key) {
    if (-not $table.ContainsKey($key)) {
        $rel, $zone = $key -split '\|', 2
        $table[$key] = [ordered]@{ Key = $key; Zone = $zone; Name = $rel; OnPremIp = @(); PeIp = @(); CentralIp = @(); PeId = $null; GroupId = $null; ConnState = $null; Status = $null }
    }
    $table[$key]
}

foreach ($r in (Import-Csv $OnPremCsv | Where-Object RecordType -eq 'A')) {
    $k = ConvertTo-ZoneKey -Fqdn $r.Fqdn -SuffixIndex $sfx
    if ($k) { (Get-Row $k).OnPremIp += $r.Data } else { Write-Verbose "Unmapped on-prem zone record: $($r.Fqdn)" }
}
foreach ($r in (Import-Csv $AzurePeCsv)) {
    if (-not $r.fqdn) { continue }
    $k = ConvertTo-ZoneKey -Fqdn $r.fqdn -SuffixIndex $sfx
    if (-not $k) { Write-Verbose "PE FQDN outside zone-map: $($r.fqdn) ($($r.groupId))"; continue }
    $row = Get-Row $k
    $row.PeIp += $r.ip; $row.PeId = $r.peId; $row.GroupId = $r.groupId; $row.ConnState = $r.connState
}
foreach ($r in (Import-Csv $CentralCsv)) {
    (Get-Row "$($r.Name)|$($r.Zone)").CentralIp += $r.Ip
}

$eq = { param($a, $b) (@($a | Sort-Object -Unique) -join ',') -eq (@($b | Sort-Object -Unique) -join ',') }
$out = foreach ($row in $table.Values) {
    if ($OnlyZones -and $row.Zone -notin $OnlyZones) { continue }
    $hasOn = $row.OnPremIp.Count -gt 0; $hasPe = $row.PeIp.Count -gt 0; $hasC = $row.CentralIp.Count -gt 0
    $row.Status = switch ($true) {
        { $hasPe -and -not $hasC }                         { 'NeedsZoneGroup'; break }
        { $hasPe -and -not (& $eq $row.PeIp $row.CentralIp) } { 'CentralIpDrift'; break }
        { -not $hasPe -and $hasOn -and -not $hasC }       { 'OrphanOnPrem'; break }
        { -not $hasPe -and $hasC }                         { 'OrphanCentral'; break }
        { $hasPe -and -not $hasOn }                        { 'NewPrivatePath'; break }
        { -not (& $eq $row.OnPremIp $row.PeIp) }           { 'StaleOnPrem'; break }
        default                                            { 'OK' }
    }
    [pscustomobject]@{
        Status = $row.Status; Zone = $row.Zone; Name = $row.Name
        PublicFqdn = Get-PublicFqdn -Key $row.Key -ZoneMap $zoneMap
        OnPremIp = $row.OnPremIp -join ';'; PeIp = $row.PeIp -join ';'; CentralIp = $row.CentralIp -join ';'
        GroupId = $row.GroupId; ConnState = $row.ConnState; PeId = $row.PeId
    }
}
$out | Sort-Object Zone, Status, Name | Export-Csv $OutCsv -NoTypeInformation
$out | Group-Object Zone, Status | Sort-Object Name | Format-Table @{n = 'Zone, Status'; e = { $_.Name } }, Count -AutoSize | Out-String -Width 200 | Write-Host

$blocking = $out | Where-Object Status -in 'NeedsZoneGroup', 'CentralIpDrift', 'OrphanOnPrem'
if ($blocking) { Write-Warning "$(@($blocking).Count) blocking rows -> $OutCsv"; exit 1 }
Write-Host 'No blocking differences. Ready for parity test (06).' -ForegroundColor Green
