#requires -Version 7.2
#requires -Modules Az.Accounts, Az.PrivateDns
<#
.SYNOPSIS
  Copy OrphanOnPrem records (no PE in this tenant: partner PLS, other-tenant PEs, Databricks/Snowflake etc.)
  into the central zone as STATIC records, tagged so they're visibly unmanaged.
.DESCRIPTION
  Do not use this for anything that has a PE you can see - that's what zone groups are for.
  Review reconcile.csv first and pass only the names you have confirmed are still in use (-Include).
#>
[CmdletBinding(SupportsShouldProcess)]
param(
    [string]$ReconcileCsv = './out/reconcile.csv',
    [Parameter(Mandatory)][string]$DnsZoneSubscriptionId,
    [Parameter(Mandatory)][string]$DnsZoneResourceGroup,
    [Parameter(Mandatory)][string[]]$Include,   # wildcard on PublicFqdn, e.g. 'partnerx*'
    [int]$Ttl = 300
)
$ErrorActionPreference = 'Stop'
$null = Set-AzContext -Subscription $DnsZoneSubscriptionId
$rows = Import-Csv $ReconcileCsv | Where-Object { $r = $_; $r.Status -eq 'OrphanOnPrem' -and ($Include | Where-Object { $r.PublicFqdn -like $_ }) }
foreach ($r in $rows) {
    $existing = Get-AzPrivateDnsRecordSet -ResourceGroupName $DnsZoneResourceGroup -ZoneName $r.Zone -Name $r.Name -RecordType A -ErrorAction SilentlyContinue
    if ($existing) { Write-Host "exists  $($r.Name).$($r.Zone)"; continue }
    if ($PSCmdlet.ShouldProcess("$($r.Name).$($r.Zone)", "Create A $($r.OnPremIp)")) {
        $recs = $r.OnPremIp -split ';' | ForEach-Object { New-AzPrivateDnsRecordConfig -Ipv4Address $_ }
        $null = New-AzPrivateDnsRecordSet -ResourceGroupName $DnsZoneResourceGroup -ZoneName $r.Zone -Name $r.Name -RecordType A -Ttl $Ttl `
            -PrivateDnsRecords $recs -Metadata @{ source = 'onprem-migration'; managedBy = 'manual'; migrated = (Get-Date -Format 'yyyy-MM-dd') }
        Write-Host "created $($r.Name).$($r.Zone) -> $($r.OnPremIp)"
    }
}
