#!/usr/bin/env bash
# Non-Windows DNS (BIND / Infoblox / BlueCat): pull privatelink zones by AXFR and emit the same CSV as 01-Export.
# Requires zone-transfer permission for the host you run this from.
# Usage: ./export-zone-axfr.sh <dns-server-ip> out/onprem-records.csv privatelink.blob.core.windows.net privatelink.vaultcore.azure.net ...
set -euo pipefail
server="$1"; out="$2"; shift 2
mkdir -p "$(dirname "$out")"
echo '"Zone","Name","Fqdn","RecordType","Data","TtlSeconds","Timestamp"' > "$out"
for zone in "$@"; do
  dig +noall +answer "@${server}" "${zone}" AXFR > "${out%.csv}.${zone}.axfr"   # raw backup
  awk -v z="${zone}" 'BEGIN{OFS=","}
    $4=="A"||$4=="AAAA"||$4=="CNAME" {
      fq=tolower($1); sub(/\.$/,"",fq); d=$5; sub(/\.$/,"",d)
      name=(fq==z)?"@":substr(fq,1,length(fq)-length(z)-1)
      printf "\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"\"\n", z, name, fq, $4, d, $2
    }' "${out%.csv}.${zone}.axfr" >> "$out"
done
echo "Wrote $(($(wc -l < "$out") - 1)) records to $out"
