<#
.SYNOPSIS
  Inventory + backup every privatelink.* zone hosted directly on Windows DNS (the thing we're migrating away from).
.DESCRIPTION
  Run on (or against) a Windows DNS server with the DnsServer RSAT module. Read-only apart from writing zone backups
  to %windir%\System32\dns on the target server and CSV/JSON to -OutDir.
  Outputs:
    onprem-records.csv      one row per A/AAAA/CNAME record (input to 03-Compare)
    onprem-zones.json       zone metadata incl. AD replication scope (input to 08-Undo)
    onprem-forwarders.csv   existing conditional forwarders (collision check for 07-Cutover)
  For BIND/Infoblox, use export-zone-axfr.sh instead - it writes the same CSV shape.
.EXAMPLE
  .\01-Export-OnPremPrivatelinkZones.ps1 -DnsServer dc01.corp.local -OutDir .\out
#>
[CmdletBinding()]
param(
    [string]$DnsServer = $env:COMPUTERNAME,
    [string[]]$ZoneFilter = @('privatelink.*'),
    [string]$OutDir = '.\out'
)
$ErrorActionPreference = 'Stop'
Import-Module DnsServer
New-Item -ItemType Directory -Force -Path $OutDir | Out-Null
$stamp = Get-Date -Format 'yyyyMMdd-HHmmss'

$allZones = Get-DnsServerZone -ComputerName $DnsServer
$zones = $allZones | Where-Object {
    $z = $_; -not $z.IsReverseLookupZone -and $z.ZoneType -eq 'Primary' -and ($ZoneFilter | Where-Object { $z.ZoneName -like $_ })
}
if (-not $zones) { Write-Warning "No zones matching $($ZoneFilter -join ',') on $DnsServer"; return }

$zoneMeta = @()
$rows = foreach ($z in $zones) {
    $backup = "$($z.ZoneName).$stamp.bak"
    Export-DnsServerZone -ComputerName $DnsServer -Name $z.ZoneName -FileName $backup
    $zoneMeta += [pscustomobject]@{
        Zone = $z.ZoneName; IsDsIntegrated = $z.IsDsIntegrated; ReplicationScope = "$($z.ReplicationScope)"
        DynamicUpdate = "$($z.DynamicUpdate)"; BackupFile = $backup; Server = $DnsServer
    }
    Get-DnsServerResourceRecord -ComputerName $DnsServer -ZoneName $z.ZoneName |
        Where-Object RecordType -in 'A', 'AAAA', 'CNAME' |
        ForEach-Object {
            $data = switch ($_.RecordType) {
                'A'     { $_.RecordData.IPv4Address.IPAddressToString }
                'AAAA'  { $_.RecordData.IPv6Address.IPAddressToString }
                'CNAME' { $_.RecordData.HostNameAlias.TrimEnd('.') }
            }
            [pscustomobject]@{
                Zone       = $z.ZoneName.ToLower()
                Name       = $_.HostName.ToLower()
                Fqdn       = if ($_.HostName -eq '@') { $z.ZoneName.ToLower() } else { "$($_.HostName).$($z.ZoneName)".ToLower() }
                RecordType = $_.RecordType
                Data       = $data
                TtlSeconds = [int]$_.TimeToLive.TotalSeconds
                Timestamp  = $_.Timestamp   # non-null = dynamic/aging record, worth a look
            }
        }
}

$rows     | Export-Csv (Join-Path $OutDir 'onprem-records.csv') -NoTypeInformation
$zoneMeta | ConvertTo-Json -Depth 4 | Set-Content (Join-Path $OutDir 'onprem-zones.json')
$allZones | Where-Object ZoneType -eq 'Forwarder' |
    Select-Object ZoneName, @{n = 'MasterServers'; e = { ($_.MasterServers.IPAddressToString) -join ';' } }, IsDsIntegrated, ReplicationScope |
    Export-Csv (Join-Path $OutDir 'onprem-forwarders.csv') -NoTypeInformation

# Things that silently break the migration - surface them now.
$dupes = $rows | Group-Object Fqdn | Where-Object Count -gt 1
if ($dupes) { Write-Warning "$($dupes.Count) FQDNs have multiple records (round-robin/stale). Review before cutover:"; $dupes.Name | Select-Object -First 20 | ForEach-Object { "  $_" } }
$nonPl = $allZones | Where-Object { $_.ZoneType -eq 'Primary' -and $_.ZoneName -match '(core\.windows\.net|azure\.net|azure\.com|azurecr\.io|azurewebsites\.net)$' -and $_.ZoneName -notlike 'privatelink.*' }
if ($nonPl) { Write-Warning "Non-privatelink Azure zones hosted locally (these will shadow the new forwarders): $($nonPl.ZoneName -join ', ')" }

Write-Host ("Exported {0} records from {1} zones -> {2}" -f @($rows).Count, @($zones).Count, (Resolve-Path $OutDir))
