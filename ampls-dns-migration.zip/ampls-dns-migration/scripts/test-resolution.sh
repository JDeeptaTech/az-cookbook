#!/usr/bin/env bash
# Quick resolution matrix for Linux hosts, spoke VMs and OpenShift/ARO nodes.
#   ./test-resolution.sh <dns-server|system> <cidr-prefix> fqdn [fqdn...]
#   ./test-resolution.sh system 10.0.1. kv-prod-01.vault.azure.net stprod01.blob.core.windows.net api.monitor.azure.com
# ARO/OpenShift: oc debug node/<node> -- chroot /host bash -c "$(cat test-resolution.sh)" _ system 10.0.1. <fqdns>
#   (cluster DNS forwards to the node's upstream = the VNet DNS setting, so nodes are the right place to test)
set -uo pipefail
server="$1"; prefix="$2"; shift 2
fail=0
printf '%-60s %-16s %s\n' FQDN IP VERDICT
for n in "$@"; do
  if [[ "$server" == "system" ]]; then ip=$(getent ahostsv4 "$n" | awk 'NR==1{print $1}')
  else ip=$(dig +short +time=2 +tries=1 "@$server" "$n" A | grep -E '^[0-9.]+$' | head -1); fi
  if   [[ -z "$ip" ]];            then v="FAIL-NXDOMAIN"; fail=1
  elif [[ "$ip" != $prefix* ]];   then v="FAIL-PUBLIC";   fail=1
  elif timeout 3 bash -c "</dev/tcp/$ip/443" 2>/dev/null; then v="OK"
  else v="FAIL-TCP443"; fail=1; fi
  printf '%-60s %-16s %s\n' "$n" "${ip:--}" "$v"
done
exit $fail
