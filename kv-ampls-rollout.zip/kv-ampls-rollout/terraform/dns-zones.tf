# Central private DNS zones in p0004ss, linked ONLY to the transit hub VNet (where the resolver inbound endpoint is).
# No client impact on its own: on-prem keeps answering from its local zones until the forwarders are switched.

data "azurerm_virtual_network" "hub" {
  provider            = azurerm.production
  name                = var.hub_vnet_name
  resource_group_name = var.hub_vnet_resource_group
}

resource "azurerm_resource_group" "zones" {
  name     = var.zones_resource_group
  location = var.location
  tags     = var.tags
}

# OFF by default: a CanNotDelete lock is inherited by record sets, so the A-record clean-up that runs when a
# private endpoint (zone group) is deleted can fail with ScopeLocked and leave stale records. Protect the zones
# instead with the pipeline's no-delete plan guard, tight RBAC on this RG, and a denyAction (DELETE) policy on
# Microsoft.Network/privateDnsZones (policy CR). Enable only after testing PE delete with the lock in place.
resource "azurerm_management_lock" "zones" {
  count      = var.enable_zone_delete_lock ? 1 : 0
  name       = "no-delete-central-privatelink-dns"
  scope      = azurerm_resource_group.zones.id
  lock_level = "CanNotDelete"
  notes      = "Deleting a privatelink zone breaks name resolution for every private endpoint in the tenant."
}

resource "azurerm_private_dns_zone" "this" {
  for_each            = toset(var.private_dns_zones)
  name                = each.value
  resource_group_name = azurerm_resource_group.zones.name
  tags                = var.tags
}

# Cross-subscription link: the identity running this needs virtualNetworks/join/action on the hub VNet
# (Network Contributor on the VNet, or a custom role).
# Only zones in var.hub_link_zones are linked. A linked but still-empty zone answers NXDOMAIN for every
# PE-enabled resource of that type to anyone resolving through the hub/resolver, so hold a zone back
# until its zone groups are backfilled if the resolver already serves clients.
resource "azurerm_private_dns_zone_virtual_network_link" "hub" {
  for_each              = { for k, z in azurerm_private_dns_zone.this : k => z if contains(coalesce(var.hub_link_zones, var.private_dns_zones), k) }
  name                  = "lnk-${var.hub_vnet_name}"
  resource_group_name   = azurerm_resource_group.zones.name
  private_dns_zone_name = each.value.name
  virtual_network_id    = data.azurerm_virtual_network.hub.id
  registration_enabled  = false
  tags                  = var.tags
}

output "private_dns_zone_ids" {
  value = { for k, z in azurerm_private_dns_zone.this : k => z.id }
}
