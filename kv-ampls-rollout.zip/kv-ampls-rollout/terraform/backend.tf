# Partial config: values come from the pipeline (-backend-config) so the same code runs against any state account.
# Auth is Entra ID (OIDC from the ADO service connection): no storage keys. The pipeline identity needs
# Storage Blob Data Contributor on the state container.
terraform {
  backend "azurerm" {
    use_azuread_auth = true
    use_oidc         = true
  }
}
