# AMPLS in p0004ss, its private endpoint in a new subnet of the transit hub (Production Subscription).
# Safe to deploy before the AMPLS DNS wave: on-prem still answers monitor names publicly until the
# monitor.azure.com / opinsights / agentsvc / applicationinsights forwarders are switched.

resource "azurerm_resource_group" "monitor" {
  name     = var.monitor_resource_group
  location = var.location
  tags     = var.tags
}

resource "azurerm_monitor_private_link_scope" "this" {
  name                  = "ampls-iep-prd-shd"
  resource_group_name   = azurerm_resource_group.monitor.name
  ingestion_access_mode = var.ampls_ingestion_access_mode
  query_access_mode     = var.ampls_query_access_mode
  tags                  = var.tags
}

resource "azurerm_monitor_private_link_scoped_service" "this" {
  for_each            = var.ampls_scoped_resource_ids
  name                = substr(replace(each.key, "/[^A-Za-z0-9-]/", "-"), 0, 64)
  resource_group_name = azurerm_resource_group.monitor.name
  scope_name          = azurerm_monitor_private_link_scope.this.name
  linked_resource_id  = each.value
}

# Subnet in the hub VNet. If the hub VNet is managed by another Terraform state with inline subnets,
# add the subnet THERE instead, or the two states will fight over it.
resource "azurerm_subnet" "ampls_pe" {
  provider                          = azurerm.production
  name                              = "snet-iep-prd-pe"
  resource_group_name               = var.hub_vnet_resource_group
  virtual_network_name              = var.hub_vnet_name
  address_prefixes                  = [var.pe_subnet_prefix]
  private_endpoint_network_policies = "Enabled" # lets the NSG / route table apply to the PE
}

# ALZ-style policies often DENY subnets without an NSG. Associate the hub's PE NSG (and route table if the hub
# forces traffic through a firewall) so the subnet create is not refused mid-apply.
resource "azurerm_subnet_network_security_group_association" "ampls_pe" {
  count                     = var.pe_subnet_nsg_id == null ? 0 : 1
  provider                  = azurerm.production
  subnet_id                 = azurerm_subnet.ampls_pe.id
  network_security_group_id = var.pe_subnet_nsg_id
}
resource "azurerm_subnet_route_table_association" "ampls_pe" {
  count          = var.pe_subnet_route_table_id == null ? 0 : 1
  provider       = azurerm.production
  subnet_id      = azurerm_subnet.ampls_pe.id
  route_table_id = var.pe_subnet_route_table_id
}

resource "azurerm_private_endpoint" "ampls" {
  name                = "pe-ampls-iep-prd-shd"
  location            = var.location # must match the hub VNet region
  resource_group_name = azurerm_resource_group.monitor.name
  subnet_id           = azurerm_subnet.ampls_pe.id
  tags                = var.tags

  private_service_connection {
    name                           = "ampls"
    private_connection_resource_id = azurerm_monitor_private_link_scope.this.id
    subresource_names              = ["azuremonitor"]
    is_manual_connection           = false
  }

  # Blob zone is added in the blob wave (it also carries the agent solution-pack record).
  private_dns_zone_group {
    name = "default"
    private_dns_zone_ids = [for z in [
      "privatelink.monitor.azure.com",
      "privatelink.oms.opinsights.azure.com",
      "privatelink.ods.opinsights.azure.com",
      "privatelink.agentsvc.azure-automation.net",
    ] : azurerm_private_dns_zone.this[z].id]
  }

  depends_on = [azurerm_monitor_private_link_scoped_service.this, azurerm_private_dns_zone_virtual_network_link.hub]
}

output "ampls_id" { value = azurerm_monitor_private_link_scope.this.id }
output "ampls_pe_ips" { value = azurerm_private_endpoint.ampls.custom_dns_configs }
