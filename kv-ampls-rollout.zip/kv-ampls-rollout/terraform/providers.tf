terraform {
  required_version = ">= 1.6"
  required_providers {
    azurerm = { source = "hashicorp/azurerm", version = "~> 4.0" }
  }
}

# p0004ss: resolver, central private DNS zones, AMPLS, AMPLS private endpoint resource
provider "azurerm" {
  subscription_id = var.shared_subscription_id
  features {}
}

# Production Subscription: owns the transit hub VNet (subnet for the AMPLS private endpoint)
provider "azurerm" {
  alias           = "production"
  subscription_id = var.production_subscription_id
  features {}
}
