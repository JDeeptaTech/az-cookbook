variable "shared_subscription_id" {
  description = "p0004ss"
  type        = string
  default     = "20be150d-f08a-4594-9260-958582967ba0"
}
variable "production_subscription_id" {
  description = "Production Subscription (owns the transit hub VNet)"
  type        = string
}
variable "location" {
  type    = string
  default = "westeurope"
}
variable "hub_vnet_name" {
  type    = string
  default = "p-prod-ccoe-brz8-transit-vnet-weu-1"
}
variable "hub_vnet_resource_group" {
  description = "Resource group of the transit hub VNet in the Production Subscription"
  type        = string
}
variable "zones_resource_group" {
  type    = string
  default = "rg-iep-prd-pdnsz-shd"
}
variable "monitor_resource_group" {
  type    = string
  default = "rg-iep-prd-mon-shd"
}
variable "pe_subnet_nsg_id" {
  description = "NSG to associate with snet-iep-prd-pe (required if a policy denies subnets without NSG)"
  type        = string
  default     = null
}
variable "pe_subnet_route_table_id" {
  description = "Route table for snet-iep-prd-pe, if the hub forces traffic through a firewall"
  type        = string
  default     = null
}
variable "pe_subnet_prefix" {
  description = "AMPLS private endpoint subnet in the hub. /27 is the minimum Microsoft supports for AMPLS. Check the VNet address space first."
  type        = string
  default     = "10.250.192.160/27"
}

# Zones are added wave by wave. Wave 1 = Key Vault. The four monitor zones come with AMPLS.
# privatelink.blob.core.windows.net is deliberately NOT here: it moves with the blob wave, because
# creating it now would take over blob resolution for every client that already uses the resolver.
variable "private_dns_zones" {
  type = list(string)
  default = [
    "privatelink.vaultcore.azure.net",
    "privatelink.monitor.azure.com",
    "privatelink.oms.opinsights.azure.com",
    "privatelink.ods.opinsights.azure.com",
    "privatelink.agentsvc.azure-automation.net",
  ]
}

variable "enable_zone_delete_lock" {
  type    = bool
  default = false
}
variable "hub_link_zones" {
  description = "Zones to link to the hub VNet now. null = all. Set to the 4 monitor zones to hold vaultcore back for CR-2."
  type        = list(string)
  default     = null
}

variable "ampls_ingestion_access_mode" {
  description = "Start Open. Switch to PrivateOnly only after every workspace / App Insights in the tenant is scoped."
  type        = string
  default     = "Open"
}
variable "ampls_query_access_mode" {
  description = "Target PrivateOnly. Start Open until portal users and tools are confirmed on the private network."
  type        = string
  default     = "Open"
}
variable "ampls_scoped_resource_ids" {
  description = "Log Analytics workspaces, App Insights components and DCEs to scope into the AMPLS: name => resource ID"
  type        = map(string)
  default     = {}
}
variable "tags" {
  type = map(string)
  default = {
    TerraformRepo         = "PlatformShared.IaC"
    "bd-costcentre"       = "1206 Infrastructure"
    "bd-responsibleteam"  = "1206 Infrastructure"
    "bd-service"          = "Infrastructure Automation Services"
  }
}
