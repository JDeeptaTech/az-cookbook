# Sourced inside AzureCLI@2 (addSpnToEnvironment: true): hand the service connection's federated token to
# the azurerm provider and backend. No client secret anywhere.
# The token is short-lived; if a long apply fails with AADSTS700024, switch to
# ARM_OIDC_AZURE_SERVICE_CONNECTION_ID + SYSTEM_ACCESSTOKEN (azurerm 4.x refreshes the token itself).
export ARM_CLIENT_ID="$servicePrincipalId"
export ARM_TENANT_ID="$tenantId"
export ARM_OIDC_TOKEN="$idToken"
export ARM_USE_OIDC=true
export ARM_USE_AZUREAD=true
export TF_IN_AUTOMATION=true
