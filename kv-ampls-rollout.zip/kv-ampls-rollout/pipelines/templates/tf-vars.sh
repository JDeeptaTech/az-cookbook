# Builds TF_ARGS from variable-group values (ADO exposes non-secret variables as env vars).
# Variables that are not defined in the group are simply absent and fall back to the Terraform defaults.
TF_ARGS=()
declare -A MAP=(
  [PRODUCTION_SUBSCRIPTION_ID]=production_subscription_id
  [HUB_VNET_RG]=hub_vnet_resource_group
  [SHARED_SUBSCRIPTION_ID]=shared_subscription_id
  [HUB_VNET_NAME]=hub_vnet_name
  [PE_SUBNET_PREFIX]=pe_subnet_prefix
  [ZONES_RG]=zones_resource_group
  [MONITOR_RG]=monitor_resource_group
  [PE_SUBNET_NSG_ID]=pe_subnet_nsg_id
  [HUB_LINK_ZONES]=hub_link_zones
)
for envname in "${!MAP[@]}"; do
  val="${!envname:-}"
  [[ -z "$val" || "$val" == '$('* ]] && continue
  TF_ARGS+=(-var "${MAP[$envname]}=$val")
done
printf 'Terraform vars from variable group: %s\n' "${!MAP[*]}" >/dev/null
