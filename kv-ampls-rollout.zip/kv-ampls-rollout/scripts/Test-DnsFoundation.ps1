#requires -Version 7.2
<#
.SYNOPSIS  Post-deployment checks for the Private Link DNS foundation (CR-1). az CLI only; exit 1 on any failure.
.EXAMPLE   ./Test-DnsFoundation.ps1 -ProductionSubscriptionId <id> -HubVnetResourceGroup <rg>
#>
param(
    # Defaults come from the pipeline variable group (exposed as env vars); pass explicitly when run by hand.
    [string]$ProductionSubscriptionId = $env:PRODUCTION_SUBSCRIPTION_ID,
    [string]$HubVnetResourceGroup = $env:HUB_VNET_RG,
    [string]$SharedSubscriptionId = ($env:SHARED_SUBSCRIPTION_ID ?? '20be150d-f08a-4594-9260-958582967ba0'),
    [string]$ZonesRg = ($env:ZONES_RG ?? 'rg-iep-prd-pdnsz-shd'),
    [string]$MonitorRg = ($env:MONITOR_RG ?? 'rg-iep-prd-mon-shd'),
    [string]$HubVnet = ($env:HUB_VNET_NAME ?? 'p-prod-ccoe-brz8-transit-vnet-weu-1'),
    [string]$PeSubnetPrefix = ($env:PE_SUBNET_PREFIX ?? '10.250.192.160/27'),
    [string[]]$Zones = @('privatelink.vaultcore.azure.net', 'privatelink.monitor.azure.com', 'privatelink.oms.opinsights.azure.com',
                         'privatelink.ods.opinsights.azure.com', 'privatelink.agentsvc.azure-automation.net'),
    [string]$HubLinkZonesJson = $env:HUB_LINK_ZONES,   # empty = all zones linked
    [string]$ExpectedIngestion = 'Open',
    [string]$ExpectedQuery = 'Open'
)
if (-not $ProductionSubscriptionId -or -not $HubVnetResourceGroup) { throw 'ProductionSubscriptionId and HubVnetResourceGroup are required (or PRODUCTION_SUBSCRIPTION_ID / HUB_VNET_RG env vars).' }
function Test-InCidr([string]$Ip, [string]$Cidr) {
    $net, $bits = $Cidr -split '/'
    $toInt = { param($a) $b = ([Net.IPAddress]::Parse($a)).GetAddressBytes(); [array]::Reverse($b); [BitConverter]::ToUInt32($b, 0) }
    $mask = if ([int]$bits -eq 0) { [uint32]0 } else { [uint32](([uint64]4294967295 -shl (32 - [int]$bits)) -band [uint64]4294967295) }
    ((& $toInt $Ip) -band $mask) -eq ((& $toInt $net) -band $mask)
}
$ErrorActionPreference = 'Stop'
Import-Module (Join-Path $PSScriptRoot 'AzCliHelpers.psm1') -Force
$results = [System.Collections.Generic.List[object]]::new()
function Check([string]$Name, [scriptblock]$Test) {
    try { $d = & $Test; $ok = [bool]$d.ok; $detail = $d.detail } catch { $ok = $false; $detail = $_.Exception.Message }
    $results.Add([pscustomobject]@{ Check = $Name; Result = if ($ok) { 'PASS' } else { 'FAIL' }; Detail = $detail })
}
$hubId = (Invoke-AzJson @('network', 'vnet', 'show', '-g', $HubVnetResourceGroup, '-n', $HubVnet, '--subscription', $ProductionSubscriptionId)).id

$linked = if ($HubLinkZonesJson -and $HubLinkZonesJson -notmatch '^\$\(') { @($HubLinkZonesJson | ConvertFrom-Json) } else { $Zones }
foreach ($z in $Zones) {
    if ($z -notin $linked) {
        Check "zone $z (created, link held for CR-2)" {
            $zz = Invoke-AzJson @('network', 'private-dns', 'zone', 'show', '-g', $ZonesRg, '-n', $z, '--subscription', $SharedSubscriptionId)
            $n = @(Invoke-AzJson @('network', 'private-dns', 'link', 'vnet', 'list', '-g', $ZonesRg, '-z', $z, '--subscription', $SharedSubscriptionId)).Count
            @{ ok = ([bool]$zz -and $n -eq 0); detail = "links=$n (expected 0)" }
        }
        continue
    }
    Check "zone $z" {
        $links = @(Invoke-AzJson @('network', 'private-dns', 'link', 'vnet', 'list', '-g', $ZonesRg, '-z', $z, '--subscription', $SharedSubscriptionId))
        $hub = $links | Where-Object { (Get-AzProp (Get-AzProp $_ 'virtualNetwork') 'id') -eq $hubId }
        $bad = $links | Where-Object { (Get-AzProp $_ 'registrationEnabled') }
        @{ ok = ($hub -and (Get-AzProp $hub 'virtualNetworkLinkState') -eq 'Completed' -and -not $bad)
           detail = "links=$($links.Count) hubLink=$([bool]$hub) registration=$([bool]$bad)" }
    }
}
Check 'No CanNotDelete lock on zones RG (blocks PE record clean-up)' {
    $l = @(Invoke-AzJson @('lock', 'list', '-g', $ZonesRg, '--subscription', $SharedSubscriptionId)) | Where-Object { $_.level -eq 'CanNotDelete' }
    @{ ok = -not $l; detail = if ($l) { "locks: $($l.name -join ',')" } else { 'none' } }
}
Check 'AMPLS access modes' {
    $a = Invoke-AzJson @('monitor', 'private-link-scope', 'show', '-g', $MonitorRg, '-n', 'ampls-iep-prd-shd', '--subscription', $SharedSubscriptionId)
    $m = Get-AzProp $a 'accessModeSettings'
    $i = Get-AzProp $m 'ingestionAccessMode'; $q = Get-AzProp $m 'queryAccessMode'
    @{ ok = ($i -eq $ExpectedIngestion -and $q -eq $ExpectedQuery); detail = "ingestion=$i query=$q" }
}
$pe = Invoke-AzJson @('network', 'private-endpoint', 'show', '-g', $MonitorRg, '-n', 'pe-ampls-iep-prd-shd', '--subscription', $SharedSubscriptionId)
Check 'AMPLS PE connection approved' {
    $s = (Get-AzProp (Get-AzProp (Get-AzProp $pe 'privateLinkServiceConnections')[0] 'privateLinkServiceConnectionState') 'status')
    @{ ok = ($s -eq 'Approved' -and (Get-AzProp $pe 'provisioningState') -eq 'Succeeded'); detail = "state=$s" }
}
Check 'AMPLS PE in snet-iep-prd-pe' {
    $sn = (Get-AzProp (Get-AzProp $pe 'subnet') 'id')
    @{ ok = $sn -match '/subnets/snet-iep-prd-pe$'; detail = $sn }
}
Check 'AMPLS PE zone group registered records' {
    $zg = @(Invoke-AzJson @('network', 'private-endpoint', 'dns-zone-group', 'list', '-g', $MonitorRg, '--endpoint-name', 'pe-ampls-iep-prd-shd', '--subscription', $SharedSubscriptionId))
    $cfg = @($zg | ForEach-Object { Get-AzProp $_ 'privateDnsZoneConfigs' })
    $recs = @($cfg | ForEach-Object { Get-AzProp $_ 'recordSets' }).Count
    @{ ok = ($cfg.Count -ge 4 -and $recs -ge 8); detail = "zoneConfigs=$($cfg.Count) records=$recs" }
}
Check 'monitor zone has api record' {
    $r = Invoke-AzJson @('network', 'private-dns', 'record-set', 'a', 'show', '-g', $ZonesRg, '-z', 'privatelink.monitor.azure.com', '-n', 'api', '--subscription', $SharedSubscriptionId) -AllowNotFound
    $ips = @((Get-AzProp $r 'aRecords').ipv4Address)
    @{ ok = ([bool]$r -and ($ips | Where-Object { Test-InCidr $_ $PeSubnetPrefix })); detail = "$($ips -join ',') in $PeSubnetPrefix" }
}
Check 'vaultcore zone has no hand-made records yet' {
    $r = @(Invoke-AzJson @('network', 'private-dns', 'record-set', 'a', 'list', '-g', $ZonesRg, '-z', 'privatelink.vaultcore.azure.net', '--subscription', $SharedSubscriptionId))
    @{ ok = $true; detail = "A records=$($r.Count) (zone-group registrations land here in CR-2 prep)" }
}
$results | Format-Table -AutoSize | Out-String -Width 220 | Write-Host
if ($results.Result -contains 'FAIL') { Write-Host '##vso[task.logissue type=error]Foundation verification failed'; exit 1 }
