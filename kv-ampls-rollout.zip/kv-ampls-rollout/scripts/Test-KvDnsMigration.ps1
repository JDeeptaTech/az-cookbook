#requires -Version 7.2
<#
.SYNOPSIS
  Key Vault wave: reconcile the on-prem privatelink.vaultcore.azure.net list against Azure and test resolution,
  before (-Stage Pre) and after (-Stage Post) the DNS cutover. Azure CLI + PowerShell 7.

.DESCRIPTION
  Input: whatever you exported from the on-prem DNS server:
    - Export-DnsServerZone file, dnscmd /enumrecords output or a plain text list ("kv-app1  A  10.1.2.3"), or
    - CSV with a name column (HostName / Name / Fqdn) and optionally an IP column (IPv4Address / Data / RecordData / IP), or
    - one vault name or FQDN per line.
  For every vault it finds the private endpoint IP in Azure (Resource Graph over all subscriptions you can read),
  the record in the central zone in p0004ss, and the answers from the on-prem DNS server and the resolver.

  Status per vault:
    Ready              central zone record = PE IP (and the resolver answers it)
    NeedsZoneGroup     PE exists but has no record in the central zone   -> run with -FixZoneGroups
    ZoneGroupElsewhere PE registers in another privatelink zone (spoke)  -> -FixZoneGroups -ReplaceExisting
    CentralIpDrift     central record differs from the PE IP              -> fix before cutover
    NoPrivateEndpoint  vault exists, no PE: after cutover it resolves PUBLIC (fails if public access is off)
    VaultNotFound      record for a vault that no longer exists           -> drop with owner sign-off
  plus OnPremStale (on-prem IP differs from PE: clients are already broken, cutover fixes them) and, for
  -Stage Post, OnPremNotSwitched (on-prem DNS still returns the old answer).

  Exit 1 if anything blocks the stage. Output: kv-dns-<stage>-<timestamp>.csv.

.EXAMPLE
  # from an admin box that can reach the DC and 10.250.192.132; az login first
  ./Test-KvDnsMigration.ps1 -InputPath .\privatelink.vaultcore.txt -OnPremDns 10.10.0.10 -Stage Pre
  ./Test-KvDnsMigration.ps1 -InputPath .\privatelink.vaultcore.txt -OnPremDns 10.10.0.10 -Stage Pre -FixZoneGroups -WhatIf
  ./Test-KvDnsMigration.ps1 -InputPath .\privatelink.vaultcore.txt -OnPremDns 10.10.0.10 -Stage Post
#>
[CmdletBinding(SupportsShouldProcess)]
param(
    [Parameter(Mandatory)][string]$InputPath,
    [string]$OnPremDns,
    [string]$ResolverIp = '10.250.192.132',
    [string]$ZoneSubscriptionId = '20be150d-f08a-4594-9260-958582967ba0',
    [string]$ZoneResourceGroup = 'rg-iep-prd-pdnsz-shd',
    [ValidateSet('Pre', 'Post')][string]$Stage = 'Pre',
    [switch]$FixZoneGroups,
    [switch]$ReplaceExisting,
    [string]$OutDir = '.'
)
$ErrorActionPreference = 'Stop'
Import-Module (Join-Path $PSScriptRoot 'AzCliHelpers.psm1') -Force
$Zone = 'privatelink.vaultcore.azure.net'
$zoneId = "/subscriptions/$ZoneSubscriptionId/resourceGroups/$ZoneResourceGroup/providers/Microsoft.Network/privateDnsZones/$Zone"

function Resolve-A([string]$Name, [string]$Server) {
    if (-not $Server) { return @() }
    if (Get-Command Resolve-DnsName -ErrorAction SilentlyContinue) {
        try { @(Resolve-DnsName -Name $Name -Server $Server -Type A -DnsOnly -NoHostsFile -QuickTimeout -ErrorAction Stop | Where-Object Type -eq 'A' | ForEach-Object IPAddress | Sort-Object -Unique) } catch { @() }
    } elseif (Get-Command dig -ErrorAction SilentlyContinue) {
        @(& dig +short +time=2 +tries=1 "@$Server" $Name A 2>$null | Where-Object { $_ -match '^\d{1,3}(\.\d{1,3}){3}$' } | Sort-Object -Unique)
    } else { throw 'Needs Resolve-DnsName (Windows) or dig.' }
}
function ConvertTo-VaultName([string]$s) {
    $n = $s.Trim().TrimEnd('.').ToLower()
    $n = $n -replace '\.(privatelink\.)?vaultcore\.azure\.net$', '' -replace '\.vault\.azure\.net$', ''
    if ($n -match '^[a-z0-9-]{3,24}$') { $n } else { $null }   # Key Vault name rules
}

# ---------------- parse the on-prem list ----------------
$onprem = [ordered]@{}
$raw = Get-Content -Raw $InputPath
if ($InputPath -match '\.csv$') {
    $rows = $raw | ConvertFrom-Csv
    $nameCol = @('HostName', 'Name', 'Fqdn', 'RecordName') | Where-Object { $rows[0].PSObject.Properties[$_] } | Select-Object -First 1
    $ipCol = @('IPv4Address', 'Data', 'RecordData', 'IP', 'IPAddress') | Where-Object { $rows[0].PSObject.Properties[$_] } | Select-Object -First 1
    if (-not $nameCol) { throw "CSV needs a HostName/Name/Fqdn column; found: $($rows[0].PSObject.Properties.Name -join ', ')" }
    foreach ($r in $rows) { $v = ConvertTo-VaultName $r.$nameCol; if ($v) { $onprem[$v] = if ($ipCol) { "$($r.$ipCol)".Trim() } else { '' } } }
} else {
    foreach ($line in ($raw -split "`r?`n")) {
        $l = $line.Trim(); if (-not $l -or $l -match '^(;|#)' -or $l -match '\b(SOA|NS)\b') { continue }
        $tok = $l -split '\s+'
        $v = ConvertTo-VaultName $tok[0]; if (-not $v) { continue }
        $ip = ($tok | Where-Object { $_ -match '^\d{1,3}(\.\d{1,3}){3}$' } | Select-Object -First 1)
        $onprem[$v] = "$ip"
    }
}
if (-not $onprem.Count) { throw "No vault names recognised in $InputPath" }
Write-Host "Vaults in on-prem list: $($onprem.Count)" -ForegroundColor Cyan

# ---------------- Azure: PEs, vaults, central zone ----------------
$subs = @(Invoke-AzJson @('account', 'list', '--query', "[?state=='Enabled'].id"))
$pes = Get-AzArgRows -Subscriptions $subs -Query @'
resources
| where type =~ 'microsoft.network/networkinterfaces' and isnotempty(properties.privateEndpoint.id)
| mv-expand ipc = properties.ipConfigurations
| where tostring(ipc.properties.privateLinkConnectionProperties.groupId) =~ 'vault'
| mv-expand fqdn = ipc.properties.privateLinkConnectionProperties.fqdns
| project fqdn = tolower(tostring(fqdn)), ip = tostring(ipc.properties.privateIPAddress), peId = tostring(properties.privateEndpoint.id)
'@
$vaults = Get-AzArgRows -Subscriptions $subs -Query "resources | where type =~ 'microsoft.keyvault/vaults' | project name = tolower(name), id, publicNetworkAccess = tostring(properties.publicNetworkAccess)"
$peByVault = @{}; foreach ($p in $pes) { $v = ConvertTo-VaultName $p.fqdn; if ($v) { $peByVault[$v] = $p } }
$vaultByName = @{}; foreach ($v in $vaults) { $vaultByName[$v.name] = $v }
$central = @{}
$recs = Invoke-AzJson @('network', 'private-dns', 'record-set', 'a', 'list', '-g', $ZoneResourceGroup, '-z', $Zone, '--subscription', $ZoneSubscriptionId) -AllowNotFound
if ($null -eq $recs) { Write-Warning "Central zone $Zone not found in ${ZoneResourceGroup}: run the Terraform first." }
foreach ($r in @($recs)) { if ($r) { $central[$r.name.ToLower()] = @((Get-AzProp $r 'aRecords').ipv4Address) } }

# ---------------- evaluate ----------------
$allVaults = @($onprem.Keys) + @($peByVault.Keys | Where-Object { -not $onprem.Contains($_) })
$out = foreach ($v in $allVaults) {
    $pe = $peByVault[$v]; $kv = $vaultByName[$v]
    $peIp = $pe.ip; $cIp = @($central[$v]) -join ';'
    $fqdn = "$v.vault.azure.net"
    $resAns = (Resolve-A $fqdn $ResolverIp) -join ';'
    $opAns = (Resolve-A $fqdn $OnPremDns) -join ';'
    $status = if (-not $pe -and -not $kv) { 'VaultNotFound' }
              elseif (-not $pe) { 'NoPrivateEndpoint' }
              elseif (-not $cIp) { 'NeedsZoneGroup' }
              elseif ($peIp -notin @($central[$v])) { 'CentralIpDrift' }
              else { 'Ready' }
    $notes = @()
    if ($onprem[$v] -and $peIp -and $onprem[$v] -ne $peIp) { $notes += 'OnPremStale' }
    if (-not $onprem.Contains($v)) { $notes += 'NotInOnPremList (NewPrivatePath: resolves public today)' }
    if ($status -eq 'Ready' -and $ResolverIp -and $resAns -ne $peIp) { $notes += "ResolverMismatch ($resAns)" }
    if ($Stage -eq 'Post' -and $OnPremDns -and $peIp -and $opAns -ne $peIp) { $notes += "OnPremNotSwitched ($opAns)" }
    if ($status -eq 'NoPrivateEndpoint' -and $kv.publicNetworkAccess -eq 'Disabled') { $notes += 'PUBLIC ACCESS DISABLED: will break' }
    [pscustomobject]@{ Vault = $v; Status = $status; Notes = ($notes -join '; '); PeIp = $peIp; OnPremListIp = $onprem[$v]
        CentralIp = $cIp; ResolverAnswer = $resAns; OnPremDnsAnswer = $opAns; PrivateEndpointId = $pe.peId }
}
$out = @($out)

# ---------------- optional: add zone groups ----------------
if ($FixZoneGroups) {
    foreach ($r in $out | Where-Object Status -eq 'NeedsZoneGroup') {
        $p = $r.PrivateEndpointId -split '/'; $sub, $rg, $pe = $p[2], $p[4], $p[8]
        $zg = @(Invoke-AzJson @('network', 'private-endpoint', 'dns-zone-group', 'list', '-g', $rg, '--endpoint-name', $pe, '--subscription', $sub))
        $elsewhere = $zg | Where-Object { @((Get-AzProp $_ 'privateDnsZoneConfigs') | ForEach-Object { (Get-AzProp $_ 'privateDnsZoneId').ToLower() }) -notcontains $zoneId.ToLower() }
        $present = $zg | Where-Object { $_ -notin @($elsewhere) }
        if ($present) { $r.Notes += '; zone group to central zone exists but record missing: recreate it'; continue }
        if ($elsewhere -and -not $ReplaceExisting) { $r.Status = 'ZoneGroupElsewhere'; $r.Notes += "; zone group '$($elsewhere[0].name)' points to another zone"; continue }
        if ($PSCmdlet.ShouldProcess("$pe ($sub/$rg)", "zone group -> $Zone (p0004ss)")) {
            foreach ($e in $elsewhere) { $null = Invoke-AzJson @('network', 'private-endpoint', 'dns-zone-group', 'delete', '-g', $rg, '--endpoint-name', $pe, '--name', $e.name, '--subscription', $sub) }
            $null = Invoke-AzJson @('network', 'private-endpoint', 'dns-zone-group', 'create', '-g', $rg, '--endpoint-name', $pe, '--name', 'default',
                    '--private-dns-zone', $zoneId, '--zone-name', 'vaultcore', '--subscription', $sub)
            $r.Status = 'ZoneGroupAdded'; Write-Host "  zone group added: $pe" -ForegroundColor Green
        }
    }
}

# ---------------- report ----------------
New-Item -ItemType Directory -Force -Path $OutDir | Out-Null
$csv = Join-Path $OutDir ("kv-dns-{0}-{1}.csv" -f $Stage.ToLower(), (Get-Date -Format 'yyyyMMdd-HHmmss'))
$out | Sort-Object Status, Vault | Export-Csv $csv -NoTypeInformation
$out | Sort-Object Status, Vault | Format-Table Vault, Status, PeIp, OnPremListIp, CentralIp, ResolverAnswer, OnPremDnsAnswer, Notes -AutoSize | Out-String -Width 260 | Write-Host
$out | Group-Object Status | Sort-Object Name | ForEach-Object { Write-Host ("  {0,-20} {1}" -f $_.Name, $_.Count) }
Write-Host "Report: $csv"

$block = if ($Stage -eq 'Pre') {
    @($out | Where-Object { $_.Status -in 'NeedsZoneGroup', 'ZoneGroupElsewhere', 'CentralIpDrift' -or $_.Notes -match 'ResolverMismatch|PUBLIC ACCESS DISABLED' })
} else { @($out | Where-Object { $_.Notes -match 'OnPremNotSwitched' -and $_.Status -ne 'VaultNotFound' }) }
if ($block) { Write-Host "$($block.Count) vault(s) block the $Stage stage." -ForegroundColor Red; exit 1 }
Write-Host "$Stage checks passed." -ForegroundColor Green
