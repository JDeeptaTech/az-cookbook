-- Master inventory broken out by country / business_line / environment x lifecycle.
-- Drives the slice/dice panels on the Master Servers dashboard.
select
    coalesce(country_code, 'UNKNOWN')        as country_code,
    coalesce(business_line, '(blank)')       as business_line,
    coalesce(environment, '(blank)')         as environment,
    coalesce(lifecycle_state, '(blank)')     as lifecycle_state,
    count(*)                                 as servers
from {{ ref('stg_master') }}
group by 1,2,3,4
