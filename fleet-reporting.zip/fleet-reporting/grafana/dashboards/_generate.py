"""
Generates five provisioned Grafana dashboards:
  overview.json        - cross-project consolidated report
  master.json          - master servers data report
  connectivity.json    - connectivity project status report
  firmware.json        - firmware project status report
  server_detail.json   - drilldown target (filtered list of servers)

Cross-dashboard navigation: each top-level dashboard exposes the other four as
dashboard-level links (top-right). Drilldowns: panels carry data links into
server_detail.json with the clicked value injected as a template variable.
"""
import json
import os
import uuid

DS = {"type": "postgres", "uid": "reporting-gold"}

# stable UIDs — referenced by data links between dashboards
UID = {
    "overview":     "fleet-overview",
    "master":       "fleet-master",
    "connectivity": "fleet-connectivity",
    "firmware":     "fleet-firmware",
    "detail":       "fleet-server-detail",
}


def sql_panel(pid, title, x, y, w, h, sql, vtype="table", links=None):
    p = {
        "id": pid,
        "title": title,
        "type": vtype,
        "datasource": DS,
        "gridPos": {"x": x, "y": y, "w": w, "h": h},
        "targets": [{"refId": "A", "format": "table", "rawSql": sql}],
    }
    if links:
        # data links live under fieldConfig.defaults.links so they apply to every value
        p["fieldConfig"] = {"defaults": {"links": links}, "overrides": []}
    return p


def stat_panel(pid, title, x, y, w, h, sql):
    return {
        "id": pid, "title": title, "type": "stat", "datasource": DS,
        "gridPos": {"x": x, "y": y, "w": w, "h": h},
        "targets": [{"refId": "A", "format": "table", "rawSql": sql}],
        "options": {"reduceOptions": {"calcs": ["lastNotNull"], "fields": "", "values": False},
                    "textMode": "value_and_name", "colorMode": "value"},
    }


def detail_link(label, var_field):
    """Data link that opens server_detail with the clicked row's value as a var."""
    return [{
        "title": label,
        "url": f"/d/{UID['detail']}?var-{var_field['var']}=${{__data.fields.{var_field['col']}}}&${{__url_time_range}}",
        "targetBlank": False,
    }]


def dashboard(uid, title, panels, variables=None, tags=None):
    # cross-dashboard nav links in the top-right
    nav = []
    for key, slug in [("overview","Overview"),("master","Master Servers"),
                      ("connectivity","Connectivity"),("firmware","Firmware")]:
        if UID[key] == uid:
            continue
        nav.append({
            "title": slug, "type": "link", "icon": "external link",
            "url": f"/d/{UID[key]}", "targetBlank": False,
            "keepTime": True, "includeVars": False,
        })

    return {
        "title": title,
        "uid": uid,
        "schemaVersion": 39,
        "tags": tags or ["fleet"],
        "time": {"from": "now-30d", "to": "now"},
        "timezone": "browser",
        "links": nav,
        "templating": {"list": variables or []},
        "panels": panels,
        "refresh": "",
    }


# ---------------------------------------------------------------------------
# 1. OVERVIEW — cross-project consolidated
# ---------------------------------------------------------------------------
overview_panels = [
    stat_panel(1, "Master total", 0, 0, 4, 4,
               "select master_total from gold.fct_project_counts"),
    stat_panel(2, "Firmware total", 4, 0, 4, 4,
               "select firmware_total from gold.fct_project_counts"),
    stat_panel(3, "Connectivity total", 8, 0, 4, 4,
               "select connectivity_total from gold.fct_project_counts"),
    stat_panel(4, "In both projects (fw & conn)", 12, 0, 4, 4,
               "select in_both_projects from gold.fct_project_counts"),
    stat_panel(5, "In all three", 16, 0, 4, 4,
               "select in_all_three from gold.fct_project_counts"),
    stat_panel(6, "Demised but tracked", 20, 0, 4, 4,
               "select sum(demised_tracked_anywhere) from gold.fct_demised_tracked"),

    sql_panel(7, "Project presence matrix (click to drill)",
              0, 4, 12, 9,
              "select segment, servers from gold.fct_project_overlap order by servers desc",
              links=detail_link("Show servers in this segment", {"var": "segment", "col": "segment"})),

    sql_panel(8, "Coverage gaps", 12, 4, 12, 9,
              "select gap, servers from gold.fct_coverage_gaps order by servers desc",
              vtype="bargauge"),

    sql_panel(9, "Demised but still tracked (by country)",
              0, 13, 12, 8,
              "select country_code, demised_in_firmware, demised_in_connectivity, "
              "demised_tracked_anywhere from gold.fct_demised_tracked "
              "order by demised_tracked_anywhere desc",
              links=detail_link("Show demised servers in this country",
                                {"var": "country", "col": "country_code"})),

    sql_panel(10, "Lifecycle disagreement across sources",
              12, 13, 12, 8,
              "select server_key, master_lifecycle_state, fw_lifecycle_state, "
              "conn_lifecycle_state from gold.fct_lifecycle_disagreement limit 100",
              links=detail_link("Open server detail", {"var": "server", "col": "server_key"})),
]
overview = dashboard(UID["overview"], "Fleet — Overview (consolidated)",
                     overview_panels, tags=["fleet","overview"])


# ---------------------------------------------------------------------------
# 2. MASTER SERVERS — single-source view
# ---------------------------------------------------------------------------
master_panels = [
    stat_panel(1, "Total servers (master)", 0, 0, 6, 4,
               "select count(*) from gold.dim_server where in_master"),
    stat_panel(2, "Live", 6, 0, 6, 4,
               "select count(*) from gold.dim_server where in_master and lifecycle_state='Live'"),
    stat_panel(3, "Demised", 12, 0, 6, 4,
               "select count(*) from gold.dim_server where in_master and lifecycle_state='Demised'"),
    stat_panel(4, "Other / blank state", 18, 0, 6, 4,
               "select count(*) from gold.dim_server where in_master and "
               "(lifecycle_state is null or lifecycle_state not in ('Live','Demised'))"),

    sql_panel(5, "By lifecycle state (click to drill)",
              0, 4, 8, 9,
              "select lifecycle_state, servers from gold.fct_master_by_state",
              vtype="piechart",
              links=detail_link("Show servers in this state",
                                {"var": "state", "col": "lifecycle_state"})),

    sql_panel(6, "By country", 8, 4, 8, 9,
              "select country_code, sum(servers) as servers "
              "from gold.fct_master_breakdown group by 1 order by servers desc",
              vtype="bargauge",
              links=detail_link("Show servers in this country",
                                {"var": "country", "col": "country_code"})),

    sql_panel(7, "By environment", 16, 4, 8, 9,
              "select environment, sum(servers) as servers "
              "from gold.fct_master_breakdown group by 1 order by servers desc",
              vtype="piechart",
              links=detail_link("Show servers in this environment",
                                {"var": "environment", "col": "environment"})),

    sql_panel(8, "Country x lifecycle state",
              0, 13, 12, 9,
              "select country_code, lifecycle_state, sum(servers) as servers "
              "from gold.fct_master_breakdown group by 1,2 order by 1, servers desc"),

    sql_panel(9, "Business line breakdown",
              12, 13, 12, 9,
              "select business_line, sum(servers) as servers "
              "from gold.fct_master_breakdown group by 1 order by servers desc",
              links=detail_link("Show servers in this business line",
                                {"var": "business_line", "col": "business_line"})),
]
master = dashboard(UID["master"], "Fleet — Master Servers",
                   master_panels, tags=["fleet","master"])


# ---------------------------------------------------------------------------
# 3. CONNECTIVITY PROJECT
# ---------------------------------------------------------------------------
connectivity_panels = [
    stat_panel(1, "Total hosts (latest)", 0, 0, 6, 4,
               "select count(*) from gold.dim_server where in_connectivity"),
    stat_panel(2, "Not Reachable", 6, 0, 6, 4,
               "select count(*) from gold.dim_server "
               "where in_connectivity and conn_status ilike 'Not Reachable%'"),
    stat_panel(3, "Reachable", 12, 0, 6, 4,
               "select count(*) from gold.dim_server "
               "where in_connectivity and conn_status ilike 'Reachable%'"),
    stat_panel(4, "Demised in master, still tracked here", 18, 0, 6, 4,
               "select count(*) from gold.dim_server "
               "where in_connectivity and lifecycle_state='Demised'"),

    sql_panel(5, "By status (latest snapshot)",
              0, 4, 8, 9,
              "select status, hosts from gold.fct_connectivity_by_status",
              vtype="piechart",
              links=detail_link("Show hosts with this status",
                                {"var": "conn_status", "col": "status"})),

    sql_panel(6, "Unreachable by assignee",
              8, 4, 16, 9,
              "select group_assignee, not_reachable from gold.fct_connectivity_ops "
              "where not_reachable > 0 order by not_reachable desc limit 25",
              vtype="bargauge",
              links=detail_link("Show this assignee's hosts",
                                {"var": "assignee", "col": "group_assignee"})),

    sql_panel(7, "Unreachable by country",
              0, 13, 12, 9,
              "select country_code, sum(not_reachable) as not_reachable, "
              "sum(reachable) as reachable, sum(total) as total "
              "from gold.fct_connectivity_ops group by 1 order by not_reachable desc",
              links=detail_link("Show hosts in this country",
                                {"var": "country", "col": "country_code"})),

    sql_panel(8, "Unreachable by DMZ zone",
              12, 13, 12, 9,
              "select dmz_zone, sum(not_reachable) as not_reachable, sum(total) as total "
              "from gold.fct_connectivity_ops group by 1 order by not_reachable desc"),
]
connectivity = dashboard(UID["connectivity"], "Fleet — Connectivity Project",
                         connectivity_panels, tags=["fleet","connectivity"])


# ---------------------------------------------------------------------------
# 4. FIRMWARE PROJECT
# ---------------------------------------------------------------------------
firmware_panels = [
    stat_panel(1, "Total servers (firmware)", 0, 0, 6, 4,
               "select count(*) from gold.dim_server where in_firmware"),
    stat_panel(2, "In scope", 6, 0, 6, 4,
               "select count(*) from gold.dim_server where in_firmware and m_scope ilike 'In%'"),
    stat_panel(3, "Lookup completed", 12, 0, 6, 4,
               "select count(*) from gold.fct_firmware_progress where lookup_completed ilike 'Completed%'"),
    stat_panel(4, "Demised in master, still tracked here", 18, 0, 6, 4,
               "select count(*) from gold.dim_server "
               "where in_firmware and lifecycle_state='Demised'"),

    sql_panel(5, "By status",
              0, 4, 8, 9,
              "select status, sum(servers) as servers from gold.fct_firmware_by_status "
              "group by 1 order by servers desc",
              vtype="piechart",
              links=detail_link("Show servers with this status",
                                {"var": "fw_status", "col": "status"})),

    sql_panel(6, "By scope (m_scope)",
              8, 4, 8, 9,
              "select m_scope, sum(servers) as servers from gold.fct_firmware_progress "
              "group by 1 order by servers desc",
              vtype="piechart",
              links=detail_link("Show servers with this scope",
                                {"var": "m_scope", "col": "m_scope"})),

    sql_panel(7, "Upgrade type mix",
              16, 4, 8, 9,
              "select upgrade_type, sum(servers) as servers from gold.fct_firmware_progress "
              "group by 1 order by servers desc",
              vtype="piechart"),

    sql_panel(8, "Lookup completion progress",
              0, 13, 12, 9,
              "select lookup_completed, sum(servers) as servers "
              "from gold.fct_firmware_progress group by 1 order by servers desc",
              vtype="bargauge"),

    sql_panel(9, "Status x scope (drill)",
              12, 13, 12, 9,
              "select status, m_scope, sum(servers) as servers "
              "from gold.fct_firmware_by_status group by 1,2 order by servers desc"),
]
firmware = dashboard(UID["firmware"], "Fleet — Firmware Project",
                     firmware_panels, tags=["fleet","firmware"])


# ---------------------------------------------------------------------------
# 5. SERVER DETAIL — drilldown target
# ---------------------------------------------------------------------------
# every filter defaults to '__all' so the dashboard works when opened directly,
# and any data link that sets one or more vars filters accordingly.
def tmpl_var(name, label, default="__all"):
    return {
        "name": name, "label": label, "type": "textbox",
        "current": {"value": default, "text": default}, "query": default,
    }

detail_vars = [
    tmpl_var("state", "Lifecycle state"),
    tmpl_var("segment", "Project segment"),
    tmpl_var("country", "Country"),
    tmpl_var("environment", "Environment"),
    tmpl_var("business_line", "Business line"),
    tmpl_var("conn_status", "Connectivity status"),
    tmpl_var("fw_status", "Firmware status"),
    tmpl_var("m_scope", "Firmware scope"),
    tmpl_var("assignee", "Connectivity assignee"),
    tmpl_var("server", "Server key"),
]

# the where-clause: each filter is a no-op when the var equals '__all'.
# segment derivation matches the case statement in fct_project_overlap.
detail_sql = """
with x as (
  select *,
    case
      when in_master and in_firmware and in_connectivity then 'all_three'
      when in_master and in_firmware                     then 'master+firmware'
      when in_firmware and in_connectivity               then 'firmware+connectivity'
      when in_master and in_connectivity                 then 'master+connectivity (transitive)'
      when in_master                                     then 'master_only'
      when in_firmware                                   then 'firmware_only'
      when in_connectivity                               then 'connectivity_only'
    end as segment
  from gold.dim_server
)
select server_key, lifecycle_state, country_code, environment, business_line,
       in_master, in_firmware, in_connectivity,
       fw_status, m_scope, conn_status, group_assignee,
       master_hostname, firmware_server_hostname, connectivity_host_name
from x
where ('__all' = '$state'         or coalesce(lifecycle_state,'(blank)') = '$state')
  and ('__all' = '$segment'       or segment = '$segment')
  and ('__all' = '$country'       or coalesce(country_code,'UNKNOWN') = '$country')
  and ('__all' = '$environment'   or coalesce(environment,'(blank)') = '$environment')
  and ('__all' = '$business_line' or coalesce(business_line,'(blank)') = '$business_line')
  and ('__all' = '$conn_status'   or coalesce(conn_status,'(blank)') = '$conn_status')
  and ('__all' = '$fw_status'     or coalesce(fw_status,'(blank)') = '$fw_status')
  and ('__all' = '$m_scope'       or coalesce(m_scope,'(blank)') = '$m_scope')
  and ('__all' = '$assignee'      or coalesce(group_assignee,'(unassigned)') = '$assignee')
  and ('__all' = '$server'        or server_key = '$server')
order by server_key
limit 5000
"""

active_filters_sql = """
select 'state' as filter, '$state' as value union all
select 'segment',         '$segment' union all
select 'country',         '$country' union all
select 'environment',     '$environment' union all
select 'business_line',   '$business_line' union all
select 'conn_status',     '$conn_status' union all
select 'fw_status',       '$fw_status' union all
select 'm_scope',         '$m_scope' union all
select 'assignee',        '$assignee' union all
select 'server',          '$server'
"""

detail_panels = [
    sql_panel(1, "Active filters", 0, 0, 8, 8, active_filters_sql),
    stat_panel(2, "Servers matched", 8, 0, 4, 8,
               "select count(*) from (" + detail_sql + ") s"),
    sql_panel(3, "Matched servers", 0, 8, 24, 16, detail_sql),
]
detail = dashboard(UID["detail"], "Fleet — Server Detail (drilldown)",
                   detail_panels, variables=detail_vars,
                   tags=["fleet","detail"])

# ---------------------------------------------------------------------------
out_dir = os.path.dirname(os.path.abspath(__file__))
for name, dash in [("overview", overview), ("master", master),
                   ("connectivity", connectivity), ("firmware", firmware),
                   ("server_detail", detail)]:
    path = os.path.join(out_dir, f"{name}.json")
    with open(path, "w") as f:
        json.dump(dash, f, indent=2)
    print(f"wrote {path}")
