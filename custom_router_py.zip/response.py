"""
Standardised API response envelope.

Every endpoint returns:
{
    "success": true,
    "data": { ... },          # the actual payload
    "error": null,
    "meta": {
        "request_id": "...",
        "timestamp": "...",
        "version": "1.0.0",
        "path": "/api/v1/...",
        "duration_ms": 14.2
    }
}

On error:
{
    "success": false,
    "data": null,
    "error": {
        "code": "VM_NOT_FOUND",
        "message": "VM 'my-vm' not found in dev",
        "field": null,          # set for validation errors
        "details": []           # set for multi-field validation errors
    },
    "meta": { ... }
}
"""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Generic, TypeVar
from pydantic import BaseModel, Field
from pydantic.generics import GenericModel

T = TypeVar("T")


# ─────────────────────────────────────────────────────────────────────────────
# Meta block — always present
# ─────────────────────────────────────────────────────────────────────────────

class ResponseMeta(BaseModel):
    request_id: str
    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    version: str = "1.0.0"
    path: str
    duration_ms: float | None = None


# ─────────────────────────────────────────────────────────────────────────────
# Error block — only present on failure
# ─────────────────────────────────────────────────────────────────────────────

class FieldError(BaseModel):
    field: str
    message: str
    type: str = "validation_error"


class ErrorDetail(BaseModel):
    code: str
    message: str
    field: str | None = None          # single-field errors (e.g. path param)
    details: list[FieldError] = []    # multi-field errors (e.g. Pydantic 422)


# ─────────────────────────────────────────────────────────────────────────────
# Envelope
# ─────────────────────────────────────────────────────────────────────────────

class APIResponse(GenericModel, Generic[T]):
    success: bool
    data: T | None = None
    error: ErrorDetail | None = None
    meta: ResponseMeta

    @classmethod
    def ok(
        cls,
        data: T,
        *,
        request_id: str,
        path: str,
        duration_ms: float | None = None,
    ) -> APIResponse[T]:
        return cls(
            success=True,
            data=data,
            error=None,
            meta=ResponseMeta(
                request_id=request_id,
                path=path,
                duration_ms=duration_ms,
            ),
        )

    @classmethod
    def fail(
        cls,
        code: str,
        message: str,
        *,
        request_id: str,
        path: str,
        duration_ms: float | None = None,
        field: str | None = None,
        details: list[FieldError] | None = None,
    ) -> APIResponse[None]:
        return cls(
            success=False,
            data=None,
            error=ErrorDetail(
                code=code,
                message=message,
                field=field,
                details=details or [],
            ),
            meta=ResponseMeta(
                request_id=request_id,
                path=path,
                duration_ms=duration_ms,
            ),
        )


# ─────────────────────────────────────────────────────────────────────────────
# Typed aliases for common payloads — use these as response_model
# ─────────────────────────────────────────────────────────────────────────────
# e.g. response_model=VMResponse, response_model=VMListResponse

from app.schemas.vm import VMStatus, VMListResponse as _VMListPayload, VMProvisionResponse

VMResponse          = APIResponse[VMStatus]
VMListEnvelope      = APIResponse[_VMListPayload]
VMProvisionEnvelope = APIResponse[VMProvisionResponse]
