"""
VM routes — with standardised response envelope.

Two changes vs the original:
  1. router = APIRouter(route_class=EnvelopedRoute, ...)
  2. Each endpoint just returns its data object directly —
     the route class wraps it in APIResponse.ok() automatically.

For the response_model declaration, wrap the payload type:
  response_model=APIResponse[VMStatus]
"""

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession

from app.schemas.vm import (
    VMProvisionRequest, VMProvisionResponse,
    VMStatus, VMListResponse,
    VMPowerRequest, VMPowerResponse,
    SnapshotCreateRequest, SnapshotResponse,
    ConsoleResponse,
)
from app.core.response import APIResponse
from app.core.routing import EnvelopedRoute
from app.core.security import get_current_user, UserContext
from app.models.database import get_db, VMAuditLog
from app.services import k8s_service as k8s
from app.services.approval_service import ApprovalService
from app.core.config import get_settings
from app.core.logging import get_logger
from datetime import datetime, timezone
import yaml

# ↓ The only change needed on every router
router = APIRouter(
    prefix="/vms",
    tags=["VMs"],
    route_class=EnvelopedRoute,
)

logger = get_logger(__name__)
settings = get_settings()
approval_service = ApprovalService()


# ── Provision ──────────────────────────────────────────────────────────────────
# response_model declares the *inner* type; EnvelopedRoute wraps it in APIResponse

@router.post("/", response_model=APIResponse[VMProvisionResponse], status_code=202)
async def provision_vm(
    req: VMProvisionRequest,
    user: UserContext = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    current_count = k8s.count_user_vms(user.username, req.environment.value)
    if current_count >= settings.MAX_VMS_PER_USER:
        raise HTTPException(
            status_code=429,
            detail={
                "code": "QUOTA_EXCEEDED",
                "message": f"You have {current_count}/{settings.MAX_VMS_PER_USER} VMs in {req.environment.value}",
            },
        )

    existing = k8s.get_vm(req.name, req.environment.value)
    if existing:
        raise HTTPException(
            status_code=409,
            detail={
                "code": "VM_ALREADY_EXISTS",
                "message": f"VM '{req.name}' already exists in {req.environment.value}",
            },
        )

    result = await approval_service.submit_provision_request(req, user.username, db)

    # ↓ Return the data object directly — EnvelopedRoute wraps it
    return VMProvisionResponse(**result)


# ── List ───────────────────────────────────────────────────────────────────────

@router.get("/", response_model=APIResponse[VMListResponse])
async def list_vms(
    environment: str = Query(None),
    team: str = Query(None),
    mine: bool = Query(False),
    user: UserContext = Depends(get_current_user),
):
    owner_filter = user.username if (mine or not user.is_admin) else None
    vms_raw = k8s.list_vms(environment=environment, owner=owner_filter, team=team)

    items = []
    for vm_dict in vms_raw:
        vm_name = vm_dict.get("metadata", {}).get("name")
        env = vm_dict.get("metadata", {}).get("labels", {}).get("vm.selfservice/environment", "")
        vmi = k8s.get_vmi(vm_name, env) if vm_name else None
        items.append(VMStatus(**k8s.build_vm_status_dict(vm_dict, vmi)))

    return VMListResponse(items=items, total=len(items))


# ── Get single VM ──────────────────────────────────────────────────────────────

@router.get("/{name}", response_model=APIResponse[VMStatus])
async def get_vm(
    name: str,
    environment: str = Query(...),
    user: UserContext = Depends(get_current_user),
):
    vm = k8s.get_vm(name, environment)
    if not vm:
        raise HTTPException(
            status_code=404,
            detail={"code": "VM_NOT_FOUND", "message": f"VM '{name}' not found in {environment}"},
        )

    owner = vm.get("metadata", {}).get("labels", {}).get("vm.selfservice/owner")
    if not user.is_admin and owner != user.username:
        raise HTTPException(status_code=403, detail="Access denied")

    vmi = k8s.get_vmi(name, environment)
    return VMStatus(**k8s.build_vm_status_dict(vm, vmi))


# ── Power ──────────────────────────────────────────────────────────────────────

@router.put("/{name}/power", response_model=APIResponse[VMPowerResponse])
async def set_power(
    name: str,
    req: VMPowerRequest,
    environment: str = Query(...),
    user: UserContext = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    vm = k8s.get_vm(name, environment)
    if not vm:
        raise HTTPException(
            status_code=404,
            detail={"code": "VM_NOT_FOUND", "message": f"VM '{name}' not found in {environment}"},
        )

    owner = vm.get("metadata", {}).get("labels", {}).get("vm.selfservice/owner")
    if not user.is_admin and owner != user.username:
        raise HTTPException(status_code=403, detail="Access denied")

    k8s.set_vm_power(name, environment, req.action.value)

    db.add(VMAuditLog(vm_name=name, environment=environment,
                       action=f"power_{req.action.value}", performed_by=user.username, detail={}))
    await db.commit()

    return VMPowerResponse(
        name=name,
        action=req.action.value,
        status="accepted",
        message=f"Power action '{req.action.value}' initiated",
    )


# ── Deprovision ────────────────────────────────────────────────────────────────

@router.delete("/{name}", status_code=202, response_model=APIResponse[dict])
async def deprovision_vm(
    name: str,
    environment: str = Query(...),
    user: UserContext = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    if environment == "prod" and not user.is_admin:
        raise HTTPException(status_code=403, detail="Only admins can deprovision prod VMs")

    vm = k8s.get_vm(name, environment)
    if not vm:
        raise HTTPException(
            status_code=404,
            detail={"code": "VM_NOT_FOUND", "message": f"VM '{name}' not found in {environment}"},
        )

    from app.services.git_service import GitService
    sha = GitService().delete_vm_manifest(name, environment, user.username)

    db.add(VMAuditLog(vm_name=name, environment=environment, action="deprovisioned",
                       performed_by=user.username, detail={"sha": sha}))
    await db.commit()

    return {"name": name, "environment": environment, "commit_sha": sha}


# ── Console ────────────────────────────────────────────────────────────────────

@router.get("/{name}/console", response_model=APIResponse[ConsoleResponse])
async def get_console(
    name: str,
    environment: str = Query(...),
    user: UserContext = Depends(get_current_user),
):
    vm = k8s.get_vm(name, environment)
    if not vm:
        raise HTTPException(
            status_code=404,
            detail={"code": "VM_NOT_FOUND", "message": f"VM '{name}' not found in {environment}"},
        )

    owner = vm.get("metadata", {}).get("labels", {}).get("vm.selfservice/owner")
    if not user.is_admin and owner != user.username:
        raise HTTPException(status_code=403, detail="Access denied")

    return ConsoleResponse(**k8s.get_console_url(name, environment))
