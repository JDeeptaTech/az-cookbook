"""
Custom APIRoute that:
  - Injects request_id (from X-Request-ID header or generated)
  - Times every request
  - Wraps the return value in APIResponse.ok() automatically
  - Intercepts all exceptions and wraps them in APIResponse.fail()

Mount this as router_class on every APIRouter — routes need no changes.
"""

from __future__ import annotations

import time
import uuid
from typing import Any, Callable

from fastapi import Request, Response
from fastapi.responses import JSONResponse
from fastapi.routing import APIRoute
from fastapi.exceptions import RequestValidationError
from starlette.exceptions import HTTPException as StarletteHTTPException

from app.core.response import APIResponse, FieldError
from app.core.logging import get_logger

logger = get_logger(__name__)


# ── Error code mapping ────────────────────────────────────────────────────────
# Maps HTTP status → a stable machine-readable code for clients

_STATUS_CODE_MAP: dict[int, str] = {
    400: "BAD_REQUEST",
    401: "UNAUTHORIZED",
    403: "FORBIDDEN",
    404: "NOT_FOUND",
    405: "METHOD_NOT_ALLOWED",
    409: "CONFLICT",
    422: "VALIDATION_ERROR",
    429: "QUOTA_EXCEEDED",
    500: "INTERNAL_ERROR",
    503: "SERVICE_UNAVAILABLE",
}


def _code_for(status: int, detail: Any) -> str:
    """
    Prefer an explicit code embedded in the detail dict.
    Falls back to the status-code map, then 'UNKNOWN_ERROR'.
    """
    if isinstance(detail, dict) and "code" in detail:
        return detail["code"]
    return _STATUS_CODE_MAP.get(status, "UNKNOWN_ERROR")


def _message_for(detail: Any) -> str:
    if isinstance(detail, str):
        return detail
    if isinstance(detail, dict):
        return detail.get("message", str(detail))
    if isinstance(detail, list) and detail:
        first = detail[0]
        return first.get("msg", str(first)) if isinstance(first, dict) else str(first)
    return "An unexpected error occurred"


# ── Custom route class ────────────────────────────────────────────────────────

class EnvelopedRoute(APIRoute):
    """
    Drop-in replacement for APIRoute.
    Wraps handler return values and all exceptions in the standard envelope.
    """

    def get_route_handler(self) -> Callable:
        original = super().get_route_handler()

        async def enveloped_handler(request: Request) -> Response:
            # Attach request_id to every request
            request_id = (
                request.headers.get("X-Request-ID") or
                str(uuid.uuid4())
            )
            start = time.perf_counter()
            path  = request.url.path

            try:
                response: Response = await original(request)

                # If the handler already returned a raw Response (e.g. StreamingResponse)
                # or a pre-wrapped envelope, pass it through untouched.
                if isinstance(response, Response) and not _is_plain_json(response):
                    return response

                # Unwrap JSONResponse to get the Python dict, then re-wrap
                data = response.body  # bytes
                import json
                payload = json.loads(data)

                # If the handler already returned an envelope (success key present),
                # just inject the meta fields and pass through.
                if isinstance(payload, dict) and "success" in payload:
                    payload.setdefault("meta", {})
                    payload["meta"]["request_id"] = request_id
                    payload["meta"]["duration_ms"] = _elapsed(start)
                    return JSONResponse(content=payload, status_code=response.status_code)

                envelope = APIResponse.ok(
                    data=payload,
                    request_id=request_id,
                    path=path,
                    duration_ms=_elapsed(start),
                )
                return JSONResponse(
                    content=envelope.model_dump(mode="json"),
                    status_code=response.status_code,
                    headers={"X-Request-ID": request_id},
                )

            except StarletteHTTPException as exc:
                logger.warning(
                    "http_exception",
                    status=exc.status_code,
                    detail=exc.detail,
                    path=path,
                    request_id=request_id,
                )
                envelope = APIResponse.fail(
                    code=_code_for(exc.status_code, exc.detail),
                    message=_message_for(exc.detail),
                    request_id=request_id,
                    path=path,
                    duration_ms=_elapsed(start),
                )
                return JSONResponse(
                    content=envelope.model_dump(mode="json"),
                    status_code=exc.status_code,
                    headers={"X-Request-ID": request_id},
                )

            except RequestValidationError as exc:
                # Pydantic / FastAPI validation errors — unpack all field errors
                field_errors = [
                    FieldError(
                        field=".".join(str(l) for l in e["loc"] if l != "body"),
                        message=e["msg"],
                        type=e["type"],
                    )
                    for e in exc.errors()
                ]
                logger.info(
                    "validation_error",
                    errors=[f.model_dump() for f in field_errors],
                    path=path,
                    request_id=request_id,
                )
                envelope = APIResponse.fail(
                    code="VALIDATION_ERROR",
                    message=f"{len(field_errors)} validation error(s)",
                    request_id=request_id,
                    path=path,
                    duration_ms=_elapsed(start),
                    details=field_errors,
                )
                return JSONResponse(
                    content=envelope.model_dump(mode="json"),
                    status_code=422,
                    headers={"X-Request-ID": request_id},
                )

            except Exception as exc:
                logger.error(
                    "unhandled_exception",
                    error=str(exc),
                    path=path,
                    request_id=request_id,
                    exc_info=True,
                )
                envelope = APIResponse.fail(
                    code="INTERNAL_ERROR",
                    message="An unexpected error occurred",
                    request_id=request_id,
                    path=path,
                    duration_ms=_elapsed(start),
                )
                return JSONResponse(
                    content=envelope.model_dump(mode="json"),
                    status_code=500,
                    headers={"X-Request-ID": request_id},
                )

        return enveloped_handler


def _elapsed(start: float) -> float:
    return round((time.perf_counter() - start) * 1000, 2)


def _is_plain_json(response: Response) -> bool:
    ct = response.headers.get("content-type", "")
    return "application/json" in ct
