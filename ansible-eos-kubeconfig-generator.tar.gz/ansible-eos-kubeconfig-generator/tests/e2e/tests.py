"""End-to-end tests for ansible-eos-kubeconfig-generator against real kube-apiservers."""
import base64, copy, datetime as dt, json, os, re, subprocess, sys, time, yaml
from cryptography import x509
from cryptography.x509.oid import NameOID, ExtendedKeyUsageOID
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec

T = os.environ.get("BGT_DIR", "/var/tmp/bgt"); REPO = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
KUBECTL = os.environ.get("KUBECTL", "kubectl")
ENV = dict(os.environ, VAULT_TOKEN="root-vault-token", ANSIBLE_FORCE_COLOR="0")
RESULTS = []


def check(name, ok, detail=""):
    RESULTS.append((name, ok, detail))
    print(f"{'PASS' if ok else 'FAIL'}  {name}" + (f"  [{detail}]" if detail else ""), flush=True)


def play(pb, user, *extra, log=None):
    cmd = ["ansible-playbook", "-i", f"{T}/test-inventory.yml", f"playbooks/{pb}", "-e", f"@{T}/test-vars.yml", *extra]
    r = subprocess.run(cmd, cwd=REPO, env=dict(ENV, USER=user), capture_output=True, text=True, timeout=600)
    out = r.stdout + r.stderr
    if log: open(f"{T}/{log}", "w").write(out)
    return r.returncode, out


def generate(user, cluster="lab-1", account="eos-cluster-admin", *extra, log=None):
    return play("generate_kubeconfig.yml", user, "-e", f"target_cluster={cluster}", "-e", f"breakglass_account={account}",
                "-e", "breakglass_ticket=INC0012345", "-e", "breakglass_reason='incident drill for breakglass test'", *extra, log=log)


def kc(path, *args):
    r = subprocess.run([KUBECTL, "--kubeconfig", path, *args], capture_output=True, text=True, timeout=30)
    err = "\n".join(l for l in r.stderr.splitlines() if not l.startswith("Warning:"))
    return r.returncode, (r.stdout + err).strip()


def admin(cluster, *args):
    return kc(f"{T}/{cluster}/admin.kubeconfig", *args)


def load(p): return yaml.safe_load(open(p))


def save(cfg, name):
    p = f"{T}/tamper/{name}.kubeconfig"
    os.makedirs(f"{T}/tamper", exist_ok=True)
    yaml.safe_dump(cfg, open(p, "w")); os.chmod(p, 0o600); return p


def whoami(path):
    rc, out = kc(path, "auth", "whoami", "-o", "json")
    return json.loads(out)["status"]["userInfo"] if rc == 0 else out


def pem_of(cfg, key): return base64.b64decode(cfg["users"][0]["user"][key])


RUN = str(int(time.time()))[-6:]


def hub_cr(name, cn, orgs, duration, token="issuer-sa-token", ns="eos-breakglass", issuer="eos-breakglass-lab-1"):
    """Create a CertificateRequest directly (bypassing the playbook) and wait for a decision."""
    pk = ec.generate_private_key(ec.SECP256R1())
    subj = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, cn)] + [x509.NameAttribute(NameOID.ORGANIZATION_NAME, o) for o in orgs])
    csr = x509.CertificateSigningRequestBuilder().subject_name(subj).sign(pk, hashes.SHA256())
    body = {"apiVersion": "cert-manager.io/v1", "kind": "CertificateRequest", "metadata": {"name": f"{name}-{RUN}", "namespace": ns},
            "spec": {"request": base64.b64encode(csr.public_bytes(serialization.Encoding.PEM)).decode(), "duration": duration,
                     "usages": ["client auth", "digital signature"], "issuerRef": {"group": "cert-manager.io", "kind": "ClusterIssuer", "name": issuer}}}
    kcfg = load(f"{T}/hub/admin.kubeconfig"); kcfg["users"][0]["user"]["token"] = token
    p = save(kcfg, f"hub-{token}")
    rc, out = kc(p, "create", "-f", "-") if False else (None, None)
    r = subprocess.run([KUBECTL, "--kubeconfig", p, "create", "-f", "-"], input=json.dumps(body), capture_output=True, text=True)
    if r.returncode != 0:
        return "forbidden", r.stderr.strip(), None, None
    for _ in range(40):
        rc, out = admin("hub", "-n", ns, "get", "certificaterequest", f"{name}-{RUN}", "-o", "json")
        st = json.loads(out).get("status", {})
        conds = {c["type"]: c for c in st.get("conditions", [])}
        if "Denied" in conds: return "denied", conds["Denied"]["message"], None, None
        if conds.get("Ready", {}).get("status") == "True": return "issued", "", base64.b64decode(st["certificate"]), pk
        time.sleep(0.5)
    return "timeout", "", None, None


def kubeconfig_from(cert_pem, key, cluster="lab-1", name="x"):
    cfg = copy.deepcopy(ALICE)
    cfg["users"][0]["user"]["client-certificate-data"] = base64.b64encode(cert_pem).decode()
    cfg["users"][0]["user"]["client-key-data"] = base64.b64encode(key.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8, serialization.NoEncryption())).decode()
    return save(cfg, name)


# ====================================================================== 1. the legitimate path
print("\n== Legitimate use")
ALICE_PATH = f"{T}/out/lab-1-eos-cluster-admin-alice.smith.kubeconfig"
ALICE = load(ALICE_PATH)
u = whoami(ALICE_PATH)
check("alice's kubeconfig authenticates as alice", isinstance(u, dict) and u["username"] == "eos-breakglass:eos-cluster-admin:alice.smith", str(u)[:120])
rc, out = kc(ALICE_PATH, "auth", "can-i", "*", "*", "--all-namespaces")
check("alice has the admin role on lab-1", out == "yes", out)
cert = x509.load_pem_x509_certificate(pem_of(ALICE, "client-certificate-data"))
life = cert.not_valid_after_utc - cert.not_valid_before_utc
check("certificate lives 2h (the default request)", abs(life.total_seconds() - 7200) < 120, str(life))
st = os.stat(ALICE_PATH)
check("delivered file is 0600", oct(st.st_mode & 0o777) == "0o600", oct(st.st_mode & 0o777))

# ====================================================================== 2. tampering
print("\n== Tampering")
c = copy.deepcopy(ALICE); c["users"][0]["name"] = "bob.jones"; c["contexts"][0]["context"]["user"] = "bob.jones"
u = whoami(save(c, "renamed-user"))
check("renaming the user in the kubeconfig does not change identity", isinstance(u, dict) and u["username"].endswith(":alice.smith"), str(u)[:100])

der = cert.public_bytes(serialization.Encoding.DER)
tampered = der.replace(b"alice.smith", b"bob.jone.sx")      # same length, so the DER stays well-formed
assert tampered != der
c = copy.deepcopy(ALICE)
c["users"][0]["user"]["client-certificate-data"] = base64.b64encode(
    b"-----BEGIN CERTIFICATE-----\n" + base64.encodebytes(tampered) + b"-----END CERTIFICATE-----\n").decode()
rc, out = kc(save(c, "edited-cn"), "auth", "whoami")
check("editing the name inside the certificate is rejected", rc != 0 and ("Unauthorized" in out or "tls" in out.lower()), out[-110:])

rc, bob_log = generate("bob.jones", log="run-bob.log")
BOB = load(f"{T}/out/lab-1-eos-cluster-admin-bob.jones.kubeconfig")
c = copy.deepcopy(ALICE); c["users"][0]["user"]["client-certificate-data"] = BOB["users"][0]["user"]["client-certificate-data"]
rc, out = kc(save(c, "bob-cert-alice-key"), "auth", "whoami")
check("bob's certificate with alice's key is refused", rc != 0 and "private key does not match" in out, out[-90:])

forged_key = ec.generate_private_key(ec.SECP256R1())
forged = (x509.CertificateBuilder().subject_name(cert.subject).issuer_name(cert.issuer).public_key(forged_key.public_key())
          .serial_number(x509.random_serial_number()).not_valid_before(dt.datetime.now(dt.timezone.utc))
          .not_valid_after(dt.datetime.now(dt.timezone.utc) + dt.timedelta(hours=1))
          .add_extension(x509.ExtendedKeyUsage([ExtendedKeyUsageOID.CLIENT_AUTH]), critical=False)
          .sign(forged_key, hashes.SHA256()).public_bytes(serialization.Encoding.PEM))
rc, out = kc(kubeconfig_from(forged, forged_key, name="forged"), "auth", "whoami")
check("a self-made certificate with alice's name and the CA's name is rejected", rc != 0 and "Unauthorized" in out, out[-60:])

c = copy.deepcopy(ALICE)
c["clusters"][0]["cluster"]["server"] = "https://127.0.0.1:6445"
c["clusters"][0]["cluster"]["certificate-authority-data"] = base64.b64encode(open(f"{T}/lab-2/certs/apiserver.crt", "rb").read()).decode()
rc, out = kc(save(c, "other-cluster"), "auth", "whoami")
check("alice's lab-1 certificate is rejected by lab-2", rc != 0 and "Unauthorized" in out, out[-60:])

# expired / not-yet-valid: sign with the real lab-1 CA (test harness reads the CA key as hub admin)
rc, out = admin("hub", "-n", "cert-manager", "get", "secret", "eos-breakglass-ca-lab-1", "-o", "json")
sec = json.loads(out)["data"]
ca_key = serialization.load_pem_private_key(base64.b64decode(sec["tls.key"]), None)
ca_cert = x509.load_pem_x509_certificate(base64.b64decode(sec["tls.crt"]))
for label, nb, na in (("expired", -5, -1), ("not yet valid", 1, 3)):
    k = ec.generate_private_key(ec.SECP256R1()); n = dt.datetime.now(dt.timezone.utc)
    crt = (x509.CertificateBuilder().subject_name(cert.subject).issuer_name(ca_cert.subject).public_key(k.public_key())
           .serial_number(x509.random_serial_number()).not_valid_before(n + dt.timedelta(hours=nb)).not_valid_after(n + dt.timedelta(hours=na))
           .add_extension(x509.ExtendedKeyUsage([ExtendedKeyUsageOID.CLIENT_AUTH]), critical=False)
           .sign(ca_key, hashes.SHA384()).public_bytes(serialization.Encoding.PEM))
    rc, out = kc(kubeconfig_from(crt, k, name=label.replace(" ", "-")), "auth", "whoami")
    check(f"a genuinely signed but {label} certificate is rejected", rc != 0 and "Unauthorized" in out, out[-60:])

# ====================================================================== 3. the 4-hour cap
print("\n== 4-hour cap")
rc, out = generate("alice.smith", "lab-1", "eos-cluster-admin", "-e", "breakglass_duration_hours=5")
check("playbook refuses 5h", rc != 0 and "Invalid request" in out, "")
rc, out = generate("alice.smith", "lab-1", "eos-cluster-reader", "-e", "breakglass_duration_hours=4", log="run-4h.log")
c4 = load(f"{T}/out/lab-1-eos-cluster-reader-alice.smith.kubeconfig")
cert4 = x509.load_pem_x509_certificate(pem_of(c4, "client-certificate-data"))
life = cert4.not_valid_after_utc - cert4.not_valid_before_utc
check("4h is accepted and the certificate lives exactly 4h", rc == 0 and abs(life.total_seconds() - 14400) < 120, str(life))
res, msg, _, _ = hub_cr("bypass-5h", "eos-breakglass:eos-cluster-admin:alice.smith", ["eos-breakglass:eos-cluster-admin"], "5h")
check("5h asked for directly on the hub (bypassing the playbook) is denied by policy", res == "denied" and "maxDuration" in msg, msg[-80:])
res, msg, _, _ = hub_cr("bypass-90d", "eos-breakglass:eos-cluster-admin:alice.smith", ["eos-breakglass:eos-cluster-admin"], "2160h")
check("90 days asked for directly is denied by policy", res == "denied" and "maxDuration" in msg, "")

# ====================================================================== 4. bound to one person
print("\n== Bound to one person")
rc, out = generate("carol.white", "lab-1", "eos-cluster-admin")
check("carol (not on the admin list) cannot get an admin kubeconfig", rc != 0 and "not allowed" in out, "")
rc, out = generate("alice.smith", "lab-1", "eos-cluster-admin", "-e", "breakglass_recipient=bob.jones")
check("alice cannot issue one for bob (no delegation)", rc != 0 and "not allowed" in out, "")
res, msg, crt, k = hub_cr("minted-dave", "eos-breakglass:eos-cluster-admin:dave.evil", ["eos-breakglass:eos-cluster-admin"], "1h")
if res == "issued":
    p = kubeconfig_from(crt, k, name="dave")
    u = whoami(p); rc, out = kc(p, "get", "namespaces")
    check("a certificate minted for an unlisted person authenticates but has no access",
          isinstance(u, dict) and u["username"].endswith(":dave.evil") and rc != 0 and "forbidden" in out.lower(), out[-70:])
else:
    check("a certificate minted for an unlisted person authenticates but has no access", False, res + " " + msg[:80])
res, msg, _, _ = hub_cr("masters", "kube-admin", ["system:masters"], "1h")
check("a request for system:masters is denied by policy", res == "denied" and "commonName" in msg and "organizations" in msg, msg[-90:])
res, msg, _, _ = hub_cr("admin-sa-try", "eos-breakglass:eos-cluster-admin:alice.smith", ["eos-breakglass:eos-cluster-admin"], "1h", token="admin-sa-token")
check("the bootstrap service account cannot request client certificates", res == "forbidden", msg[-80:])
res, msg, _, _ = hub_cr("hub-admin-try", "eos-breakglass:eos-cluster-admin:alice.smith", ["eos-breakglass:eos-cluster-admin"], "1h", token="hub-admin-token")
audit = [json.loads(l) for l in open(f"{T}/hub/audit.log") if f"hub-admin-try-{RUN}" in l]
who = {e["user"]["username"] for e in audit if e.get("verb") == "create"}
check("FINDING: a hub cluster-admin can mint a cert in alice's name, but it is attributable in the hub audit log",
      res == "issued" and who == {"hub-admin"}, f"result={res}, audit user={who}")

# ====================================================================== 5. revocation
print("\n== Revocation")
BOB_PATH = f"{T}/out/lab-1-eos-cluster-admin-bob.jones.kubeconfig"
rc, out = kc(BOB_PATH, "auth", "can-i", "delete", "nodes")
before = out
accounts = {"eos-cluster-admin": {"description": "x", "cluster_role": "cluster-admin", "max_duration_hours": 4, "allowed_operators": ["alice.smith"]},
            "eos-cluster-reader": {"description": "x", "cluster_role": "cluster-reader", "max_duration_hours": 4, "allowed_operators": ["alice.smith", "bob.jones", "carol.white"]}}
json.dump({"breakglass_accounts": accounts}, open(f"{T}/no-bob.json", "w"))
rc, out = play("bootstrap_cluster.yml", "ops", "-e", "target_cluster=lab-1", "-e", f"@{T}/no-bob.json")
time.sleep(2)
rc2, after = kc(BOB_PATH, "auth", "can-i", "delete", "nodes")
rc3, alice_after = kc(ALICE_PATH, "auth", "can-i", "delete", "nodes")
check("removing bob revokes his live kubeconfig at once; alice keeps access", before == "yes" and after == "no" and alice_after == "yes",
      f"bob {before}->{after}, alice {alice_after}")
rc, out = play("bootstrap_cluster.yml", "ops", "-e", "target_cluster=lab-1", "-e", "breakglass_enabled=false")
time.sleep(2)
rc2, out2 = kc(ALICE_PATH, "get", "namespaces")
check("breakglass_enabled=false removes all access", rc == 0 and rc2 != 0 and "forbidden" in out2.lower(), out2[-60:])
rc, out = admin("lab-1", "get", "apiserver", "cluster", "-o", "jsonpath={.spec.clientCA.name}")
check("disabling keeps the cluster's clientCA setting (orphaned, not deleted)", out == "eos-breakglass-client-ca", out)
play("bootstrap_cluster.yml", "ops", "-e", "target_cluster=lab-1"); time.sleep(2)
rc, out = kc(ALICE_PATH, "auth", "can-i", "*", "*")
check("re-enabling restores alice", out == "yes", out)

# ====================================================================== 6. secrets handling
print("\n== Secrets handling")
rc, out = admin("hub", "-n", "eos-breakglass", "get", "certificaterequests", "-o", "json")
check("no private key is stored on the hub", "PRIVATE KEY" not in out and "UFJJVkFURSBLRVk" not in out)
logs = open(f"{T}/run-alice.log").read() + open(f"{T}/run-bob.log").read() + open(f"{T}/run-4h.log").read()
key_b64 = ALICE["users"][0]["user"]["client-key-data"]
check("playbook output never shows a key or token", "PRIVATE KEY" not in logs and key_b64[:40] not in logs and "issuer-sa-token" not in logs and "root-vault-token" not in logs)
check("temporary key directory is removed", not [d for d in os.listdir("/tmp") if d.startswith("breakglass.")])
rc, out = admin("hub", "-n", "eos-breakglass", "get", "certificaterequests", "-l", "eos.breakglass/account=eos-cluster-admin",
                "-o", "jsonpath={range .items[*]}{.metadata.annotations.eos\\.breakglass/ticket} {.metadata.annotations.eos\\.breakglass/fingerprint-sha256}{'\\n'}{end}")
fp = cert.fingerprint(hashes.SHA256()).hex()
check("each issuance is recorded on the hub with ticket and certificate fingerprint",
      "INC0012345" in out and fp[:16] in out.replace(":", "").lower(), out.splitlines()[0][:60] if out else "")

# ====================================================================== 7. the output file and oc-style use
print("\n== Output file and use")
d = os.stat(os.path.dirname(ALICE_PATH))
check("kubeconfig is written 0600 in a 0700 directory", oct(os.stat(ALICE_PATH).st_mode & 0o777) == "0o600" and oct(d.st_mode & 0o777) == "0o700")
check("file name identifies cluster, account and person", os.path.basename(ALICE_PATH) == "lab-1-eos-cluster-admin-alice.smith.kubeconfig")
r = subprocess.run([KUBECTL, "auth", "whoami", "-o", "jsonpath={.status.userInfo.username}"], env=dict(os.environ, KUBECONFIG=ALICE_PATH), capture_output=True, text=True)
check("works via KUBECONFIG=<file> (no login step)", r.returncode == 0 and r.stdout.endswith(":alice.smith"), r.stdout or r.stderr[-80:])
rc, out = kc(ALICE_PATH, "config", "current-context")
check("current context is set, so no --context is needed", out == "breakglass-lab-1", out)
rc, out = generate("alice.smith", "lab-2", "eos-cluster-reader")
p = f"{T}/out/lab-2-eos-cluster-reader-alice.smith.kubeconfig"
u = whoami(p) if rc == 0 else out[-120:]
rc2, out2 = kc(p, "auth", "can-i", "delete", "pods")
check("lab-2 reader kubeconfig works on lab-2 and is read-only", isinstance(u, dict) and out2 == "no", out2)

print(f"\n{sum(ok for _, ok, _ in RESULTS)}/{len(RESULTS)} passed")
json.dump([{"test": n, "pass": ok, "detail": d} for n, ok, d in RESULTS], open(f"{T}/results.json", "w"), indent=1)
sys.exit(0 if all(ok for _, ok, _ in RESULTS) else 1)
