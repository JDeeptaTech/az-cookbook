#!/usr/bin/env bash
# Bootstrap both lab clusters, issue alice.smith's admin kubeconfig, then run the test suite.
# Run start-env.sh first.
set -euo pipefail
HERE=$(cd "$(dirname "$0")" && pwd); REPO=$(cd "$HERE/../.." && pwd)
T=${BGT_DIR:-/var/tmp/bgt}
export KUBECTL=${KUBECTL:-${ENVTEST_BIN:+$ENVTEST_BIN/kubectl}}; KUBECTL=${KUBECTL:-kubectl}
export VAULT_TOKEN=root-vault-token BGT_DIR=$T
cd "$REPO"
for c in lab-1 lab-2; do
  echo "==> bootstrap $c"
  ansible-playbook -i "$T/test-inventory.yml" playbooks/bootstrap_cluster.yml -e "@$T/test-vars.yml" -e "target_cluster=$c" > "$T/bootstrap-$c.log"
done
sleep 3
echo "==> issue alice.smith / eos-cluster-admin / lab-1"
USER=alice.smith ansible-playbook -i "$T/test-inventory.yml" playbooks/generate_kubeconfig.yml -e "@$T/test-vars.yml" \
  -e target_cluster=lab-1 -e breakglass_account=eos-cluster-admin -e breakglass_ticket=INC0012345 \
  -e "breakglass_reason='OAuth down, need to fix identity provider'" > "$T/run-alice.log"
echo "==> tests"
python3 "$HERE/tests.py"
