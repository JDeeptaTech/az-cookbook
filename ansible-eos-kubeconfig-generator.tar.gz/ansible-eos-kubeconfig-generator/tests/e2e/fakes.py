"""
Stand-ins for components that need container images (test only):
  cert-manager       Certificates, ClusterIssuers (selfSigned, ca), CertificateRequests
  approver-policy    evaluates CertificateRequestPolicy for the real requester, taken from the
                     hub's audit log, with a SubjectAccessReview for the "use" verb
  work agent         applies ManifestWorks to lab-1 / lab-2 with server-side apply, honours
                     fieldManager/force, orphaning rules, removal of dropped manifests
  OpenShift operator turns APIServer spec.clientCA into the kube-apiserver --client-ca-file
  Vault              KV v2 + token lookup-self on http://127.0.0.1:18200
"""
import base64, datetime as dt, fnmatch, json, re, threading, time, traceback, os
import http.server
import requests, yaml
from cryptography import x509
from cryptography.x509.oid import NameOID, ExtendedKeyUsageOID
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec, rsa

T = os.environ.get("BGT_DIR", "/var/tmp/bgt")
API = {"hub": ("https://127.0.0.1:6443", "hub-admin-token"), "lab-1": ("https://127.0.0.1:6444", "cluster-admin-token"),
       "lab-2": ("https://127.0.0.1:6445", "cluster-admin-token")}
CM_TOKEN = "cm-sa-token"


def kreq(cluster, method, path, body=None, token=None, ctype="application/json", params=None):
    url, tok = API[cluster]
    h = {"Authorization": f"Bearer {token or tok}", "Content-Type": ctype}
    data = body if isinstance(body, (str, bytes)) or body is None else json.dumps(body)
    r = requests.request(method, url + path, headers=h, data=data, params=params, verify=f"{T}/{cluster}/certs/apiserver.crt", timeout=10)
    return r


def get(cluster, path):
    r = kreq(cluster, "GET", path)
    return r.json() if r.status_code == 200 else None


def b64(b): return base64.b64encode(b).decode()
def now(): return dt.datetime.now(dt.timezone.utc)
def ts(): return now().strftime("%Y-%m-%dT%H:%M:%SZ")


def dur(s):
    m = re.fullmatch(r"(?:(\d+)h)?(?:(\d+)m)?(?:(\d+)s)?", s or "")
    if not m or not s: return dt.timedelta(days=90)
    h, mi, se = (int(x or 0) for x in m.groups())
    return dt.timedelta(hours=h, minutes=mi, seconds=se)


def cond(obj, typ):
    return next((c for c in (obj.get("status") or {}).get("conditions") or [] if c["type"] == typ), None)


def set_status(cluster, path, status):
    r = kreq(cluster, "PATCH", path + "/status", {"status": status}, ctype="application/merge-patch+json")
    if r.status_code >= 300: print("status patch failed", path, r.status_code, r.text[:200], flush=True)


# ------------------------------------------------------------------ cert-manager
KEYS = {}   # "<ns>/<cr name>" -> private key for Certificates we requested


def issuer_ready():
    for ci in (get("hub", "/apis/cert-manager.io/v1/clusterissuers") or {}).get("items", []):
        spec, name = ci["spec"], ci["metadata"]["name"]
        ok = "selfSigned" in spec or ("ca" in spec and get("hub", f"/api/v1/namespaces/cert-manager/secrets/{spec['ca']['secretName']}"))
        c = cond(ci, "Ready")
        want = "True" if ok else "False"
        if not c or c["status"] != want:
            set_status("hub", f"/apis/cert-manager.io/v1/clusterissuers/{name}",
                       {"conditions": [{"type": "Ready", "status": want, "reason": "KeyPairVerified" if ok else "SecretNotFound",
                                        "message": "ok" if ok else "secret missing", "lastTransitionTime": ts()}]})


def certificates():
    for c in (get("hub", "/apis/cert-manager.io/v1/namespaces/cert-manager/certificates") or {}).get("items", []):
        name, st, spec = c["metadata"]["name"], c.get("status") or {}, c["spec"]
        rev = st.get("revision", 0)
        ready = cond(c, "Ready")
        if ready and ready["status"] == "True":
            continue
        crname = f"{name}-{rev + 1}"
        key_id = f"cert-manager/{crname}"
        cr = get("hub", f"/apis/cert-manager.io/v1/namespaces/cert-manager/certificaterequests/{crname}")
        if not cr:
            pk = ec.generate_private_key(ec.SECP384R1()) if (spec.get("privateKey") or {}).get("algorithm") == "ECDSA" else rsa.generate_private_key(65537, 2048)
            KEYS[key_id] = pk
            subj = [x509.NameAttribute(NameOID.COMMON_NAME, spec["commonName"])] + \
                   [x509.NameAttribute(NameOID.ORGANIZATION_NAME, o) for o in (spec.get("subject") or {}).get("organizations", [])]
            csr = x509.CertificateSigningRequestBuilder().subject_name(x509.Name(subj)).sign(pk, hashes.SHA256())
            body = {"apiVersion": "cert-manager.io/v1", "kind": "CertificateRequest",
                    "metadata": {"name": crname, "namespace": "cert-manager",
                                 "annotations": {"cert-manager.io/certificate-name": name, "cert-manager.io/certificate-revision": str(rev + 1),
                                                 "cert-manager.io/private-key-secret-name": spec["secretName"]}},
                    "spec": {"request": b64(csr.public_bytes(serialization.Encoding.PEM)), "isCA": spec.get("isCA", False),
                             "duration": spec.get("duration"), "usages": spec.get("usages"), "issuerRef": spec["issuerRef"]}}
            r = kreq("hub", "POST", "/apis/cert-manager.io/v1/namespaces/cert-manager/certificaterequests", body, token=CM_TOKEN)
            if r.status_code >= 300: print("cert CR create failed", r.text[:200], flush=True)
            continue
        if cond(cr, "Ready") and cond(cr, "Ready")["status"] == "True" and key_id in KEYS:
            pk = KEYS.pop(key_id)
            crt = base64.b64decode(cr["status"]["certificate"])
            secret = {"apiVersion": "v1", "kind": "Secret", "type": "kubernetes.io/tls",
                      "metadata": {"name": spec["secretName"], "namespace": "cert-manager"},
                      "data": {"tls.crt": b64(crt), "ca.crt": cr["status"].get("ca", b64(crt)),
                               "tls.key": b64(pk.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8, serialization.NoEncryption()))}}
            kreq("hub", "DELETE", f"/api/v1/namespaces/cert-manager/secrets/{spec['secretName']}")
            kreq("hub", "POST", "/api/v1/namespaces/cert-manager/secrets", secret)
            cert = x509.load_pem_x509_certificate(crt)
            set_status("hub", f"/apis/cert-manager.io/v1/namespaces/cert-manager/certificates/{name}",
                       {"revision": rev + 1, "notAfter": cert.not_valid_after_utc.strftime("%Y-%m-%dT%H:%M:%SZ"),
                        "conditions": [{"type": "Ready", "status": "True", "reason": "Ready", "message": "Certificate is up to date", "lastTransitionTime": ts()}]})


def requester(ns, name):
    try:
        for line in open(f"{T}/hub/audit.log"):
            e = json.loads(line)
            o = e.get("objectRef") or {}
            if e.get("verb") == "create" and o.get("resource") == "certificaterequests" and o.get("namespace") == ns \
               and e.get("stage") == "ResponseComplete" and (o.get("name") == name or (e.get("responseStatus") or {}).get("code") == 201 and o.get("name") is None):
                if o.get("name") == name: return e["user"]["username"]
    except FileNotFoundError:
        pass
    return None


def can_use(user, groups, policy):
    sar = {"apiVersion": "authorization.k8s.io/v1", "kind": "SubjectAccessReview",
           "spec": {"user": user, "groups": groups, "resourceAttributes": {"group": "policy.cert-manager.io", "resource": "certificaterequestpolicies", "verb": "use", "name": policy}}}
    r = kreq("hub", "POST", "/apis/authorization.k8s.io/v1/subjectaccessreviews", sar)
    return r.json()["status"].get("allowed", False)


def evaluate(policy, cr, csr):
    a, cons, v = policy["spec"].get("allowed", {}), policy["spec"].get("constraints", {}), []
    cn = [x.value for x in csr.subject.get_attributes_for_oid(NameOID.COMMON_NAME)]
    orgs = [x.value for x in csr.subject.get_attributes_for_oid(NameOID.ORGANIZATION_NAME)]
    if "commonName" in a:
        if a["commonName"].get("required") and not cn: v.append("spec.allowed.commonName.required: Required value")
        for x in cn:
            if not fnmatch.fnmatchcase(x, a["commonName"].get("value", "")): v.append(f"spec.allowed.commonName.value: Invalid value: \"{x}\"")
    elif cn: v.append("spec.allowed.commonName: not allowed")
    ov = ((a.get("subject") or {}).get("organizations") or {})
    if ov.get("required") and not orgs: v.append("spec.allowed.subject.organizations.required: Required value")
    for o in orgs:
        if not any(fnmatch.fnmatchcase(o, p) for p in ov.get("values", [])): v.append(f"spec.allowed.subject.organizations.values: Invalid value: \"{o}\"")
    for u in cr["spec"].get("usages") or []:
        if u not in (a.get("usages") or []): v.append(f"spec.allowed.usages: Invalid value: \"{u}\"")
    if cr["spec"].get("isCA") and not a.get("isCA"): v.append("spec.allowed.isCA: Invalid value: true")
    if "maxDuration" in cons and dur(cr["spec"].get("duration")) > dur(cons["maxDuration"]):
        v.append(f"spec.constraints.maxDuration: Invalid value: \"{cr['spec'].get('duration')}\": {cons['maxDuration']}")
    alg = (cons.get("privateKey") or {}).get("algorithm")
    if alg:
        got = "ECDSA" if isinstance(csr.public_key(), ec.EllipticCurvePublicKey) else "RSA"
        if got != alg: v.append(f"spec.constraints.privateKey.algorithm: Invalid value: \"{got}\": {alg}")
    return v


def approve(ns, cr):
    name = cr["metadata"]["name"]
    user = requester(ns, name)
    if not user: return
    groups = {"system:serviceaccount:eos-automation:eos-breakglass-issuer": ["system:serviceaccounts", "system:serviceaccounts:eos-automation"],
              "system:serviceaccount:eos-automation:eos-breakglass-admin": ["system:serviceaccounts", "system:serviceaccounts:eos-automation"],
              "system:serviceaccount:cert-manager:cert-manager": ["system:serviceaccounts", "system:serviceaccounts:cert-manager"]}.get(user, ["system:masters"] if user == "hub-admin" else [])
    csr = x509.load_pem_x509_csr(base64.b64decode(cr["spec"]["request"]))
    ref = cr["spec"]["issuerRef"]
    matching = [p for p in (get("hub", "/apis/policy.cert-manager.io/v1alpha1/certificaterequestpolicies") or {}).get("items", [])
                if fnmatch.fnmatchcase(ref.get("name", ""), p["spec"]["selector"].get("issuerRef", {}).get("name", "*"))
                and ref.get("kind", "Issuer") == p["spec"]["selector"].get("issuerRef", {}).get("kind", ref.get("kind"))
                and (not p["spec"]["selector"].get("namespace") or ns in p["spec"]["selector"]["namespace"].get("matchNames", [ns]))]
    usable = [p for p in matching if can_use(user, groups, p["metadata"]["name"])]
    conds = [c for c in (cr.get("status") or {}).get("conditions") or []]
    if not usable:
        conds.append({"type": "Denied", "status": "True", "reason": "policy.cert-manager.io",
                      "message": "No policy approved this request: [No CertificateRequestPolicies bound or applicable]", "lastTransitionTime": ts()})
    else:
        results = {p["metadata"]["name"]: evaluate(p, cr, csr) for p in usable}
        ok = [n for n, v in results.items() if not v]
        if ok:
            conds.append({"type": "Approved", "status": "True", "reason": "policy.cert-manager.io",
                          "message": f"Approved request by policy: {ok[0]}", "lastTransitionTime": ts()})
        else:
            msg = "; ".join(f"[{n}: {', '.join(v)}]" for n, v in results.items())
            conds.append({"type": "Denied", "status": "True", "reason": "policy.cert-manager.io",
                          "message": f"No policy approved this request: {msg}", "lastTransitionTime": ts()})
    set_status("hub", f"/apis/cert-manager.io/v1/namespaces/{ns}/certificaterequests/{name}", {"conditions": conds})
    print(f"[approver] {ns}/{name} by {user}: {conds[-1]['type']} {conds[-1]['message'][:160]}", flush=True)


KU = {"digital signature": "digital_signature", "cert sign": "key_cert_sign", "crl sign": "crl_sign", "key encipherment": "key_encipherment"}


def sign(ns, cr):
    name, spec = cr["metadata"]["name"], cr["spec"]
    csr = x509.load_pem_x509_csr(base64.b64decode(spec["request"]))
    assert csr.is_signature_valid
    ci = get("hub", f"/apis/cert-manager.io/v1/clusterissuers/{spec['issuerRef']['name']}")
    if "selfSigned" in ci["spec"]:
        key = KEYS.get(f"{ns}/{name}"); issuer_name = csr.subject; ca_pem = None
    else:
        sec = get("hub", f"/api/v1/namespaces/cert-manager/secrets/{ci['spec']['ca']['secretName']}")
        key = serialization.load_pem_private_key(base64.b64decode(sec["data"]["tls.key"]), None)
        ca_pem = base64.b64decode(sec["data"]["tls.crt"]); issuer_name = x509.load_pem_x509_certificate(ca_pem).subject
    usages = spec.get("usages") or []
    kus = {v: (k in usages) for k, v in KU.items()}
    b = (x509.CertificateBuilder().subject_name(csr.subject).issuer_name(issuer_name).public_key(csr.public_key())
         .serial_number(x509.random_serial_number()).not_valid_before(now()).not_valid_after(now() + dur(spec.get("duration")))
         .add_extension(x509.BasicConstraints(ca=bool(spec.get("isCA")), path_length=None), critical=True)
         .add_extension(x509.KeyUsage(content_commitment=False, data_encipherment=False, key_agreement=False, encipher_only=False, decipher_only=False, **kus), critical=True))
    if "client auth" in usages:
        b = b.add_extension(x509.ExtendedKeyUsage([ExtendedKeyUsageOID.CLIENT_AUTH]), critical=False)
    crt = b.sign(key, hashes.SHA384() if isinstance(key, ec.EllipticCurvePrivateKey) else hashes.SHA256()).public_bytes(serialization.Encoding.PEM)
    conds = (cr.get("status") or {}).get("conditions") or []
    conds = [c for c in conds if c["type"] != "Ready"] + [{"type": "Ready", "status": "True", "reason": "Issued", "message": "Certificate fetched from issuer successfully", "lastTransitionTime": ts()}]
    set_status("hub", f"/apis/cert-manager.io/v1/namespaces/{ns}/certificaterequests/{name}",
               {"certificate": b64(crt), "ca": b64(ca_pem or crt), "conditions": conds})


def certificaterequests():
    for cr in (get("hub", "/apis/cert-manager.io/v1/certificaterequests") or {}).get("items", []):
        ns = cr["metadata"]["namespace"]
        if cond(cr, "Ready") and cond(cr, "Ready")["status"] == "True": continue
        if cond(cr, "Denied"):
            if not cond(cr, "Ready"):
                set_status("hub", f"/apis/cert-manager.io/v1/namespaces/{ns}/certificaterequests/{cr['metadata']['name']}",
                           {"conditions": cr["status"]["conditions"] + [{"type": "Ready", "status": "False", "reason": "Denied", "message": "The CertificateRequest was denied by an approval controller", "lastTransitionTime": ts()}]})
            continue
        if not cond(cr, "Approved"): approve(ns, cr); continue
        sign(ns, cr)


# ------------------------------------------------------------------ ACM work agent + OpenShift operator
RES = {("", "ConfigMap"): ("/api/v1", "configmaps", True), ("config.openshift.io", "APIServer"): ("/apis/config.openshift.io/v1", "apiservers", False),
       ("rbac.authorization.k8s.io", "ClusterRoleBinding"): ("/apis/rbac.authorization.k8s.io/v1", "clusterrolebindings", False)}


def rpath(m):
    g = m["apiVersion"].split("/")[0] if "/" in m["apiVersion"] else ""
    base, plural, nsd = RES[(g, m["kind"])]
    ns = m["metadata"].get("namespace")
    return g, plural, (f"{base}/namespaces/{ns}/{plural}" if nsd else f"{base}/{plural}") + f"/{m['metadata']['name']}"


APPLIED = {}   # (cluster, work) -> {path: meta}


def works():
    for cluster in ("lab-1", "lab-2"):
        for w in (get("hub", f"/apis/work.open-cluster-management.io/v1/namespaces/{cluster}/manifestworks") or {}).get("items", []):
            gen, name = w["metadata"]["generation"], w["metadata"]["name"]
            ap = cond(w, "Applied")
            if ap and ap.get("observedGeneration") == gen: continue
            cfgs = w["spec"].get("manifestConfigs") or []
            orphans = ((w["spec"].get("deleteOption") or {}).get("selectivelyOrphans") or {}).get("orphaningRules") or []
            results, all_ok, now_applied, feedback = [], True, {}, []
            for i, m in enumerate(w["spec"]["workload"]["manifests"]):
                g, plural, path = rpath(m)
                cfg = next((c for c in cfgs if c["resourceIdentifier"].get("resource") == plural and c["resourceIdentifier"].get("name") == m["metadata"]["name"]), None)
                ssa = (cfg or {}).get("updateStrategy", {}).get("serverSideApply", {})
                fm, force = ssa.get("fieldManager", "work-agent"), ssa.get("force", True)
                r = kreq(cluster, "PATCH", path, yaml.safe_dump(m), ctype="application/apply-patch+yaml",
                         params={"fieldManager": fm, "force": "true" if force else "false"})
                ok = r.status_code < 300
                all_ok &= ok
                now_applied[path] = {"group": g, "resource": plural, "name": m["metadata"]["name"], "namespace": m["metadata"].get("namespace", "")}
                c = {"type": "Applied", "status": "True" if ok else "False", "reason": "AppliedManifestComplete" if ok else "AppliedManifestFailed",
                     "message": "Apply manifest complete" if ok else r.json().get("message", r.text)[:300], "lastTransitionTime": ts()}
                entry = {"resourceMeta": {"ordinal": i, "group": g, "version": "v1", "kind": m["kind"], "resource": plural,
                                          "name": m["metadata"]["name"], "namespace": m["metadata"].get("namespace", "")}, "conditions": [c]}
                if ok and cfg and cfg.get("feedbackRules"):
                    live = r.json()
                    entry["statusFeedback"] = {"values": [{"name": "clientCA", "fieldValue": {"type": "String", "string": ((live.get("spec") or {}).get("clientCA") or {}).get("name", "")}}]}
                results.append(entry)
            for path, meta in APPLIED.get((cluster, name), {}).items():   # dropped from the work -> delete unless orphaned
                if path in now_applied: continue
                if any(o.get("resource") == meta["resource"] and o.get("name") == meta["name"] and o.get("namespace", "") == meta["namespace"] for o in orphans): continue
                kreq(cluster, "DELETE", path)
                print(f"[work-agent] {cluster}: deleted {meta['resource']}/{meta['name']}", flush=True)
            APPLIED[(cluster, name)] = now_applied
            st = "True" if all_ok else "False"
            set_status("hub", f"/apis/work.open-cluster-management.io/v1/namespaces/{cluster}/manifestworks/{name}", {
                "conditions": [{"type": t, "status": st, "reason": t + ("" if all_ok else "Failed"), "message": "All resources applied" if all_ok else "Failed to apply manifest",
                                "observedGeneration": gen, "lastTransitionTime": ts()} for t in ("Applied", "Available")],
                "resourceStatus": {"manifests": results}})
            print(f"[work-agent] {cluster}/{name} gen {gen}: Applied={st}", flush=True)


def openshift_operator():
    for cluster in ("lab-1", "lab-2"):
        api = get(cluster, "/apis/config.openshift.io/v1/apiservers/cluster") or {}
        name = ((api.get("spec") or {}).get("clientCA") or {}).get("name")
        bundle = open(f"{T}/placeholder-ca.crt").read()
        if name:
            cm = get(cluster, f"/api/v1/namespaces/openshift-config/configmaps/{name}")
            if cm and (cm.get("data") or {}).get("ca-bundle.crt"): bundle = cm["data"]["ca-bundle.crt"]
        f = f"{T}/{cluster}/client-ca.crt"
        if open(f).read() != bundle:
            with open(f, "r+") as fh:
                fh.seek(0); fh.write(bundle); fh.truncate()
            print(f"[openshift-operator] {cluster}: client CA bundle now has {bundle.count('BEGIN CERTIFICATE')} CA(s)", flush=True)


# ------------------------------------------------------------------ Vault
VAULT = {"eos/acm-hub/sa/eos-breakglass-issuer": {"token": "issuer-sa-token"},
         "eos/acm-hub/sa/eos-breakglass-admin": {"token": "admin-sa-token"}}
VAULT_TOKEN = "root-vault-token"


class Vault(http.server.BaseHTTPRequestHandler):
    def _send(self, code, body):
        b = json.dumps(body).encode(); self.send_response(code); self.send_header("Content-Type", "application/json"); self.end_headers(); self.wfile.write(b)

    def _auth(self):
        if self.headers.get("X-Vault-Token") != VAULT_TOKEN: self._send(403, {"errors": ["permission denied"]}); return False
        return True

    def do_GET(self):
        if not self._auth(): return
        if self.path.startswith("/v1/auth/token/lookup-self"): return self._send(200, {"data": {"id": "x", "policies": ["root"], "ttl": 0}})
        m = re.match(r"/v1/secret/data/(.+?)(\?.*)?$", self.path)
        if m and m.group(1) in VAULT: return self._send(200, {"data": {"data": VAULT[m.group(1)], "metadata": {"version": 1}}})
        self._send(404, {"errors": []})

    def do_POST(self):
        if not self._auth(): return
        m = re.match(r"/v1/secret/data/(.+)$", self.path)
        body = json.loads(self.rfile.read(int(self.headers.get("Content-Length", 0))) or b"{}")
        if m:
            VAULT[m.group(1)] = body.get("data", {}); json.dump(VAULT, open(f"{T}/vault-dump.json", "w"))
            return self._send(200, {"data": {"version": 1}})
        self._send(404, {"errors": []})
    do_PUT = do_POST

    def log_message(self, *a): pass


def loop():
    while True:
        for f in (issuer_ready, certificates, certificaterequests, works, openshift_operator):
            try: f()
            except Exception: traceback.print_exc()
        time.sleep(0.5)


if __name__ == "__main__":
    threading.Thread(target=http.server.ThreadingHTTPServer(("127.0.0.1", 18200), Vault).serve_forever, daemon=True).start()
    print("fakes up", flush=True)
    loop()
