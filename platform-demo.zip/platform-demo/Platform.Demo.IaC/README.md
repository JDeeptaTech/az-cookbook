# Platform.Demo.IaC

Versioned Terraform module + reusable Azure DevOps deploy template.

## Release flow
1. PR: bump `VERSION` (semver). CI fails if that tag already exists.
2. CI runs `fmt`, `validate`, `terraform test` (mocked providers, `tests/fixture.tfvars`),
   then a read-only `plan` against the reference consumer's dev vars.
3. Merge to `main` -> CI tags `vX.Y.Z` and moves floating `vX`.

## One-time setup
- Generate and commit the provider lock file (CI uses `-lockfile=readonly`):
  `terraform providers lock -platform=linux_amd64 -platform=windows_amd64 -platform=darwin_arm64`
- Build Service identity: **Contribute** + **Create tag** on this repo.
- Variable group `platform-demo-iac-ci`: `serviceConnectionId`, `clientId`, `tenantId`
  (WIF service connection with Reader + state-blob read only).
- Consumers' pipelines need permission to use this repo as a resource
  (Project settings -> Repositories -> Pipeline permissions).

## Consuming
```yaml
resources:
  repositories:
    - repository: iac
      type: git
      name: Platform_Demo/Platform.Demo.IaC
      ref: refs/tags/v1.0.0
extends:
  template: .azdo/templates/terraform-deploy.yml@iac
```
