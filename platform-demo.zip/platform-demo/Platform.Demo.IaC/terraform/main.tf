# Stable per-environment suffix. Lives in state, so it survives re-runs on
# ephemeral agents (unlike a local marker file, which disappears with the agent).
resource "random_id" "environment" {
  byte_length = 3

  keepers = {
    workload    = var.workload_name
    environment = var.environment_name
  }
}

locals {
  environment_id = random_id.environment.hex
  name_prefix    = "${var.workload_name}-${var.environment_name}-${local.environment_id}"

  mandatory_tags = {
    environment = var.environment_name
    workload    = var.workload_name
    managed_by  = "terraform"
    iac_module  = "platform-demo-iac"
  }

  # Mandatory tags win: consumers can add tags but not overwrite governance ones.
  tags = merge(var.tags, local.mandatory_tags)
}

resource "azurerm_resource_group" "this" {
  name     = "rg-${local.name_prefix}"
  location = var.location
  tags     = local.tags
}
