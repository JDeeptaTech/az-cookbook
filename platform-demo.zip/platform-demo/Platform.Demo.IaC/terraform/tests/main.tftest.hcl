# Run: terraform init -backend=false && terraform test -var-file=tests/fixture.tfvars
mock_provider "azurerm" {}
mock_provider "random" {
  mock_resource "random_id" {
    defaults = { hex = "a1b2c3" }
  }
}

run "naming_and_tags" {
  command = plan

  assert {
    condition     = azurerm_resource_group.this.name == "rg-demo-dev-a1b2c3"
    error_message = "Resource group naming convention broken."
  }

  assert {
    condition     = azurerm_resource_group.this.tags["managed_by"] == "terraform"
    error_message = "Mandatory tags missing."
  }
}

run "consumer_cannot_override_mandatory_tags" {
  command = plan

  variables {
    tags = { environment = "hijacked" }
  }

  assert {
    condition     = azurerm_resource_group.this.tags["environment"] == "dev"
    error_message = "Consumer tags overrode a mandatory tag."
  }
}

run "rejects_bad_environment" {
  command = plan

  variables {
    environment_name = "production"
  }

  expect_failures = [var.environment_name]
}
