# Contract fixture: the IaC repo's own canonical consumer input.
# CI tests against this with mocked providers - no Azure creds needed.
subscription_id  = "00000000-0000-0000-0000-000000000000"
environment_name = "dev"
workload_name    = "demo"
location         = "uksouth"
tags = {
  owner = "platform-team"
}
