output "environment_name" {
  description = "Name of the created environment"
  value       = var.environment_name
}

output "environment_id" {
  description = "Unique id generated for this environment (persisted in state)"
  value       = local.environment_id
}

output "resource_group_name" {
  description = "Resource group that marks the environment as created"
  value       = azurerm_resource_group.this.name
}

output "resource_group_id" {
  description = "Resource ID of the environment resource group"
  value       = azurerm_resource_group.this.id
}
