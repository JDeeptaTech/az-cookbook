variable "subscription_id" {
  description = "Target subscription. Supplied by the consumer's tfvars."
  type        = string

  validation {
    condition     = can(regex("^[0-9a-fA-F-]{36}$", var.subscription_id))
    error_message = "subscription_id must be a GUID."
  }
}

variable "environment_name" {
  description = "Logical environment name, e.g. dev, test, prod."
  type        = string

  validation {
    condition     = contains(["dev", "test", "uat", "prod"], var.environment_name)
    error_message = "environment_name must be one of dev, test, uat, prod."
  }
}

variable "workload_name" {
  description = "Short workload/app name used in resource naming."
  type        = string

  validation {
    condition     = can(regex("^[a-z0-9]{2,12}$", var.workload_name))
    error_message = "workload_name must be 2-12 lowercase alphanumerics."
  }
}

variable "location" {
  description = "Azure region."
  type        = string
  default     = "uksouth"
}

variable "tags" {
  description = "Extra tags merged over the module's mandatory tags."
  type        = map(string)
  default     = {}
}
