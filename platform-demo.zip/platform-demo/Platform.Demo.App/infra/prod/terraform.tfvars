subscription_id  = "00000000-0000-0000-0000-0000000000bb"
environment_name = "prod"
workload_name    = "demo"
location         = "uksouth"
tags = {
  owner       = "app-team"
  cost_center = "cc-1234"
}
