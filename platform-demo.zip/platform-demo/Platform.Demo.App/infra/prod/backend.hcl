resource_group_name  = "rg-tfstate-prod"
storage_account_name = "sttfstateprod001"
container_name       = "tfstate"
# One state per app per env. Never share a key across consumers.
key                  = "platform-demo-app/prod.tfstate"
