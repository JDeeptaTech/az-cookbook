resource_group_name  = "rg-tfstate-dev"
storage_account_name = "sttfstatedev001"
container_name       = "tfstate"
# One state per app per env. Never share a key across consumers.
key                  = "platform-demo-app/dev.tfstate"
