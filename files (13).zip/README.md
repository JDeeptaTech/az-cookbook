# VirtualMachine audit pipeline (Path A)

Captures every KubeVirt `VirtualMachine` create / update / delete on the cluster
and stores it in PostgreSQL within seconds, with no duplicates and no silent
loss. Built on the kube-apiserver audit log, so it records every change
authoritatively — not a best-effort watch.

---

## For non-engineers (the 60-second version)

Think of it like the cluster's own **security camera footage** for virtual
machines. Every time someone creates, changes, or deletes a VM, OpenShift
already writes that action into its tamper-evident activity log. This pipeline
taps that log, ships each action through a durable queue, and files it into a
database — usually within a couple of seconds of it happening.

Why this matters in plain terms:

- **Nothing is missed.** We read the cluster's authoritative record of what
  happened, not a secondhand feed that can drop events.
- **Nothing is double-counted.** Each action has a unique ID; if the system
  retries after a hiccup, the database ignores the repeat.
- **It survives outages.** If the database is briefly down, actions wait safely
  in the queue and load in when it's back — no data lost.
- **It's near-real-time.** From "VM changed" to "row in the database" is
  typically a few seconds.

The trade-off to be aware of: turning on this level of detailed logging adds
some volume to the cluster's logging system. We filter aggressively so only
VM-related actions reach the database.

---

## Architecture

```
VM create/update/delete
        |
        v
kube-apiserver audit log     (records every request; managed control plane)
        |
        v
Vector collector             (openshift-logging; DaemonSet, one per node)
        |
        v
Kafka topic: vm-audit-raw    (amq namespace; durable buffer)
        |
        v
audit-sink (3 replicas)      (vm-events namespace; filter -> batch -> write)
        |
        v
PostgreSQL: vm_audit_events  (db namespace; append-only, idempotent)
```

Each stage does exactly one job. Kafka is the buffer that decouples capture from
storage, so a database outage never loses events — they wait in the topic.

### Where each piece lives, and who owns it

| Component | Namespace | You deploy it? |
|---|---|---|
| Audit profile | control plane | Config only (`APIServer` CR) |
| Vector collector | `openshift-logging` | No — Logging operator manages it |
| `ClusterLogForwarder` | `openshift-logging` | Config only |
| Kafka + topic | `amq` | No — AMQ Streams operator; you apply the `KafkaTopic` |
| **audit-sink** | `vm-events` | **Yes — this is the only code you run** |
| PostgreSQL | `db` (or external) | Yes, or use a managed DB |

The only workload you build and ship is the sink. Everything upstream is
declarative configuration of platform components.

---

## Latency

End-to-end means: the moment a VM change completes on the API server, to the
moment the row is committed in Postgres.

| Stage | Typical added latency | Notes |
|---|---|---|
| apiserver writes audit event | < 10 ms | at `ResponseComplete` stage |
| Vector collect + forward | 0.5 - 3 s | **dominant factor**; depends on Logging config |
| Kafka produce + consumer fetch | < 0.5 s | bounded by `KAFKA_MAX_WAIT` (500 ms) |
| Sink batch flush | <= `MAX_BATCH_DELAY` (500 ms) | sooner if the batch fills under load |
| Postgres batch insert | 10 - 50 ms | one round trip per batch |
| **End-to-end** | **~1 - 4 s typical** | Vector collection is the swing factor |

The sink itself contributes under ~1 second. The largest and least-controllable
piece is Vector's audit-log collection interval, set by the Logging operator —
if you need to push end-to-end latency down, tune the collector flush there.

These are design-budget estimates from the configured parameters, **not measured
benchmarks** — validate on your cluster under representative load.

---

## Performance and scale

| Aspect | Expected behaviour | Why |
|---|---|---|
| Pre-filter discard | ~GB/s, negligible CPU | a cheap byte scan rejects the non-VM majority before any JSON parse |
| Throughput per replica | thousands of VM events/s | bounded by the batched Postgres insert, not by realistic VM churn |
| Horizontal scaling | linear, up to partition count | Kafka consumer group splits partitions across replicas |
| Hard parallelism ceiling | = topic partition count (6) | one active consumer per partition; extra replicas idle |

On a heavy-load cluster the **audit firehose** (all resources, not just VMs) is
large — which is exactly why the sink filters cheaply and early. Actual VM
mutation rate is normally far below the throughput ceiling; the design headroom
is for traffic spikes, not steady state.

To scale: raise `KafkaTopic.spec.partitions` and the sink `replicas` together.
Three replicas against a one-partition topic leaves two pods idle.

---

## Tuning knobs

All on the sink Deployment as env vars.

| Variable | Default | Effect |
|---|---|---|
| `MAX_BATCH` | `2000` | Higher = more throughput per DB round trip; lower = tighter latency |
| `MAX_BATCH_DELAY` | `500ms` | Worst-case latency added when the cluster is quiet |
| `KAFKA_MAX_WAIT` | `500ms` | Caps how long a fetch blocks waiting for a message |
| `PG_MAX_CONNS` | `8` | Postgres write concurrency per replica |
| `replicas` (deploy) | `3` | Parallelism; keep <= topic partition count |

Latency vs throughput is the core trade-off: lowering `MAX_BATCH_DELAY` and
`MAX_BATCH` cuts latency at the cost of more, smaller DB writes.

---

## Reliability guarantees

- **At-least-once delivery, idempotent storage.** Every layer may redeliver; the
  `vm_audit_events` primary key is `audit_id` (unique per apiserver request), so
  a redelivered event is a no-op (`ON CONFLICT DO NOTHING`).
- **Persist-then-commit.** Kafka offsets are committed only after the database
  transaction commits. A crash mid-batch replays the whole batch safely.
- **Outage tolerance.** Postgres down -> events wait in Kafka up to the topic
  retention (7 days). Kafka down -> Vector buffers; sustained loss only if the
  cluster's logging buffer also exhausts.
- **Only successful mutations recorded.** Events are filtered to
  `stage=ResponseComplete` and HTTP `< 300`; a failed create is not a state
  change. Drop the status filter if you want failed attempts in the trail too.

---

## Deploy order

1. `oc apply -f 02-audit-fidelity.yaml` — audit profile (triggers a controlled
   apiserver rollout) + `ClusterLogForwarder`. Check your Logging operator
   version and adjust the CR apiVersion if on Logging 5.x.
2. `oc apply -f kafkatopic.yaml` — creates `vm-audit-raw` with 6 partitions.
3. Apply `schema-audit.sql` to Postgres (via `psql`, not `oc`).
4. Build and push the sink image (`Dockerfile`); `go mod tidy` first to generate
   `go.sum`.
5. `oc apply -f audit-sink-deployment.yaml`
6. `oc apply -f networkpolicy.yaml` — egress lock-down (DNS + Kafka + PG).

### Verify

- Pull one message off the topic and confirm the audit JSON shape matches the
  parser's expectations (the `message`-envelope unwrap assumption):
  `oc exec` into a broker pod and run `kafka-console-consumer`.
- Create a test VM and confirm a row lands in `vm_audit_events` within seconds.

---

## Known caveats

- **Audit profile is cluster-wide.** OpenShift sets audit detail by *profile*,
  not per-resource. `WriteRequestBodies` increases audit volume for **all**
  resources, not just VMs. Weigh this on a busy cluster.
- **Collector message framing varies.** How Logging 6.x / Vector wraps the
  forwarded audit record depends on config; verify the real shape before trusting
  it in production (the parser has a one-level unwrap fallback).
- **Not yet load-tested.** Latency/throughput figures are design estimates.
