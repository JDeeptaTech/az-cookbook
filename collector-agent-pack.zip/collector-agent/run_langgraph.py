#!/usr/bin/env python3
"""collector-agent local runner (mock mode - no external APIs).

  python run_langgraph.py scenarios/happy.json
  python run_langgraph.py scenarios/happy.json --sink file:///tmp/evidence
"""
import argparse, json
from pathlib import Path

from workflow.lg_graph import build_graph
from tools.mock.redhat import MockRedhat
from tools.mock.nexus import MockNexus
from tools.skyline_api import SkylinePush


class Ctx:
    def __init__(self, scenario, sink):
        self.scenario = scenario
        self.redhat = MockRedhat(scenario)
        self.nexus = MockNexus(scenario)
        self.push = SkylinePush(sink)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("scenario")
    ap.add_argument("--sink", default="file:///tmp/skyline-evidence")
    args = ap.parse_args()

    scenario = json.loads(Path(args.scenario).read_text())
    graph = build_graph(Ctx(scenario, args.sink))
    out = graph.invoke({"log": []})

    for line in out.get("log", []):
        print(line)

    rep = out.get("report")
    if out.get("escalate"):
        print("\nRESULT: escalated - sources contradict, nothing published")
    elif rep and rep["valid"]:
        print(f"\nRESULT: published {rep['published']} (sink: {args.sink})")
    else:
        print(f"\nRESULT: invalid collection, nothing published - issues: {rep['issues']}")


if __name__ == "__main__":
    main()
