"""collector-agent LangGraph workflow.

            +-> collect_redhat --+
  intake ---+                    +--> validate --+--> publish --> report -> END
            +-> collect_nexus ---+               +--> END (invalid: nothing published)
                                                 +--> END (contradictory: escalate)

Parallel fan-out/fan-in (pack feature): both sources collected concurrently;
each branch writes its own state key, so no reducer conflicts. Deterministic
validation gates publishing - invalid or contradictory evidence never reaches
the API.
"""
import operator
from typing import Annotated, TypedDict

from langgraph.graph import StateGraph, START, END

from rules.validate import validate_collection
from contracts.payloads import RedhatPayload, NexusPayload


class CollectorState(TypedDict, total=False):
    redhat: dict
    nexus: dict
    report: dict
    escalate: bool
    log: Annotated[list, operator.add]


def build_graph(ctx, checkpointer=None):

    def intake(state):
        chans = ctx.scenario["trigger"].get("channels", [])
        return {"log": [f"[intake] collect: channels={chans} sources=redhat,nexus"]}

    def collect_redhat(state):
        p = ctx.redhat.collect()
        return {"redhat": p.model_dump(),
                "log": [f"[collect_redhat] {len(p.channels)} channel(s) from {p.source}"]}

    def collect_nexus(state):
        p = ctx.nexus.collect()
        return {"nexus": p.model_dump(),
                "log": [f"[collect_nexus] {len(p.digests)} digest(s) from {p.source}"]}

    def validate(state):
        rh = RedhatPayload(**state["redhat"])
        nx = NexusPayload(**state["nexus"])
        report = validate_collection(rh, nx)
        if report is None:
            return {"escalate": True,
                    "log": ["[validate] CONTRADICTORY: nexus and upstream digest sets "
                            "are fully disjoint - escalate for human triage "
                            "(only branch that may consult the approved AI API)"]}
        return {"report": report.model_dump(),
                "log": [f"[validate] {report.rule_id} valid={report.valid} "
                        f"issues={report.issues}"]}

    def route_after_validate(state):
        if state.get("escalate"):
            return "escalate"
        return "publish" if state["report"]["valid"] else "invalid"

    def publish(state):
        rh = RedhatPayload(**state["redhat"])
        nx = NexusPayload(**state["nexus"])
        pub = {"redhat": ctx.push.publish("redhat", rh.model_dump_json(indent=2)),
               "nexus": ctx.push.publish("nexus", nx.model_dump_json(indent=2))}
        report = dict(state["report"]); report["published"] = pub
        return {"report": report,
                "log": [f"[publish] snapshots: {pub}"]}

    g = StateGraph(CollectorState)
    for name, fn in [("intake", intake), ("collect_redhat", collect_redhat),
                     ("collect_nexus", collect_nexus), ("validate", validate),
                     ("publish", publish)]:
        g.add_node(name, fn)

    g.add_edge(START, "intake")
    g.add_edge("intake", "collect_redhat")   # fan-out
    g.add_edge("intake", "collect_nexus")
    g.add_edge("collect_redhat", "validate") # fan-in
    g.add_edge("collect_nexus", "validate")
    g.add_conditional_edges("validate", route_after_validate,
                            {"publish": "publish", "invalid": END, "escalate": END})
    g.add_edge("publish", END)

    return g.compile(checkpointer=checkpointer)
