"""Pydantic contracts for collected evidence and the agent's structured output."""
from datetime import datetime, timezone

from pydantic import BaseModel, Field


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


class ChannelGraph(BaseModel):
    channel: str
    releases: list[dict]                 # {version, payload_digest}
    edges: list[list[str]]               # [from_version, to_version]


class RedhatPayload(BaseModel):
    source: str = Field(min_length=1)
    channels: list[ChannelGraph]
    collected_at: str = Field(default_factory=_now)


class NexusPayload(BaseModel):
    source: str = Field(min_length=1)
    digests: list[str]
    collected_at: str = Field(default_factory=_now)


class CollectionReport(BaseModel):
    valid: bool
    issues: list[str] = Field(default_factory=list)
    confidence: float = Field(ge=0.0, le=1.0)
    rule_id: str
    published: dict = Field(default_factory=dict)   # kind -> snapshot_id
