import json, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from workflow.lg_graph import build_graph
from tools.mock.redhat import MockRedhat
from tools.mock.nexus import MockNexus
from tools.skyline_api import SkylinePush

ROOT = Path(__file__).resolve().parents[1]


class Ctx:
    def __init__(self, scenario, sink):
        self.scenario = scenario
        self.redhat = MockRedhat(scenario)
        self.nexus = MockNexus(scenario)
        self.push = SkylinePush(sink)


def _run(name, tmp_path):
    s = json.loads((ROOT / "scenarios" / name).read_text())
    g = build_graph(Ctx(s, f"file://{tmp_path}"))
    return g.invoke({"log": []}), tmp_path


def test_happy_path_collects_in_parallel_and_publishes(tmp_path):
    out, sink = _run("happy.json", tmp_path)
    assert out["report"]["valid"] is True
    assert set(out["report"]["published"]) == {"redhat", "nexus"}
    files = list(sink.glob("*.json"))
    assert len(files) == 2
    # published JSON honors the pydantic contract incl. provenance
    payload = json.loads(next(f for f in files if f.name.startswith("redhat")).read_text())
    assert payload["source"] and payload["collected_at"]
    assert payload["channels"][0]["channel"] == "stable-4.18"


def test_invalid_collection_publishes_nothing(tmp_path):
    out, sink = _run("empty_nexus.json", tmp_path)
    assert out["report"]["valid"] is False
    assert any("empty inventory" in i for i in out["report"]["issues"])
    assert list(sink.glob("*.json")) == []


def test_contradictory_sources_escalate_and_publish_nothing(tmp_path):
    out, sink = _run("contradictory_sources.json", tmp_path)
    assert out.get("escalate") is True and "report" not in out
    assert list(sink.glob("*.json")) == []


def test_both_collect_nodes_ran():
    s = json.loads((ROOT / "scenarios" / "happy.json").read_text())
    out = build_graph(Ctx(s, "file:///tmp/x")).invoke({"log": []})
    joined = "\n".join(out["log"])
    assert "[collect_redhat]" in joined and "[collect_nexus]" in joined
