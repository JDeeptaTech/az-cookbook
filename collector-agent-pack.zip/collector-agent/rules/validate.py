"""Deterministic collection-validation rule (COLLECT-VAL-001).

Zero-token: schema + cross-source sanity checks. Returns a CollectionReport
(valid or not) - or None when evidence is contradictory in a way rules can't
resolve, which is the only branch that may escalate to the approved AI API
in production (in practice: human triage)."""
import re

from contracts.payloads import CollectionReport

DIGEST_RE = re.compile(r"^sha256:[0-9a-f]{6,64}$")


def validate_collection(redhat, nexus):
    issues = []

    if not redhat.channels:
        issues.append("redhat: zero channels collected")
    for ch in redhat.channels:
        if not ch.releases:
            issues.append(f"redhat: channel {ch.channel} has no releases")
        bad = [r["version"] for r in ch.releases
               if not DIGEST_RE.match(r.get("payload_digest", ""))]
        if bad:
            issues.append(f"redhat: malformed digests in {ch.channel}: {bad}")

    if not nexus.digests:
        issues.append("nexus: empty inventory (registry unreachable or repo wrong?)")
    bad = [d for d in nexus.digests if not DIGEST_RE.match(d)]
    if bad:
        issues.append(f"nexus: {len(bad)} malformed digest(s)")

    # cross-source sanity: nexus digests that exist upstream nowhere at all
    upstream = {r["payload_digest"] for ch in redhat.channels for r in ch.releases}
    orphans = [d for d in nexus.digests if upstream and d not in upstream]
    if upstream and len(orphans) == len(nexus.digests) and nexus.digests:
        return None  # total disjoint sets: sources contradict -> escalate

    return CollectionReport(valid=not issues, issues=issues,
                            confidence=1.0, rule_id="COLLECT-VAL-001")
