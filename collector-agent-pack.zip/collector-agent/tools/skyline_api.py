"""Publish sink: file:// dir (local/mock) or https:// REST endpoint (real)."""
import time
from pathlib import Path


class SkylinePush:
    def __init__(self, sink="file:///tmp/skyline-evidence"):
        self.sink = sink

    def publish(self, kind: str, payload_json: str) -> str:
        if self.sink.startswith("file://"):
            d = Path(self.sink[7:]); d.mkdir(parents=True, exist_ok=True)
            sid = f"{kind}-{int(time.time()*1000)}"
            (d / f"{sid}.json").write_text(payload_json)
            return sid
        import requests
        r = requests.post(f"{self.sink}/api/v1/evidence/{kind}", data=payload_json,
                          headers={"Content-Type": "application/json"}, timeout=60)
        r.raise_for_status()
        return r.json()["snapshot_id"]
