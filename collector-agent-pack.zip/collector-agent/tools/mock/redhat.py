"""Mock Red Hat adapter - scenario-fed, same signatures as the real one."""
from contracts.payloads import ChannelGraph, RedhatPayload


class MockRedhat:
    def __init__(self, scenario):
        self.s = scenario

    def collect(self) -> RedhatPayload:
        return RedhatPayload(
            source="mock://cincinnati",
            channels=[ChannelGraph(**c) for c in self.s["redhat"]["channels"]])
