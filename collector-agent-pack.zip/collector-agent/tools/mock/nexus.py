"""Mock Nexus adapter for the collector - scenario-fed."""
from contracts.payloads import NexusPayload


class MockNexus:
    def __init__(self, scenario):
        self.s = scenario

    def collect(self) -> NexusPayload:
        return NexusPayload(source="mock://nexus/ocp4/ocp-release",
                            digests=self.s["nexus"]["digests"])
