"""Red Hat (Cincinnati) extractor - real adapter.
Same signatures as tools/mock/redhat.py."""
import requests

from contracts.payloads import ChannelGraph, RedhatPayload

OSUS = "https://api.openshift.com/api/upgrades_info"


class RedhatExtractor:
    def __init__(self, channels, arch="amd64"):
        self.channels, self.arch = channels, arch

    def get_channel_graph(self, channel) -> ChannelGraph:
        r = requests.get(f"{OSUS}/v1/graph",
                         params={"channel": channel, "arch": self.arch},
                         headers={"Accept": "application/json"}, timeout=60)
        r.raise_for_status()
        g = r.json()
        nodes = g.get("nodes", [])
        return ChannelGraph(
            channel=channel,
            releases=[{"version": n["version"],
                       "payload_digest": n.get("payload", "").split("@")[-1]}
                      for n in nodes],
            edges=[[nodes[a]["version"], nodes[b]["version"]]
                   for a, b in g.get("edges", [])])

    def collect(self) -> RedhatPayload:
        return RedhatPayload(source=OSUS,
                             channels=[self.get_channel_graph(c) for c in self.channels])
