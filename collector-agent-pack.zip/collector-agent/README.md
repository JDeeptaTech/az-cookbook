# collector-agent (Cortex Domain Agent Pack)

Extracts evidence from Red Hat (Cincinnati update graph) and Nexus (digest
inventory), validates it deterministically, and publishes JSON to a file
sink or REST API. Read-only sources; single write action: skyline.publish.

## Workflow (LangGraph)
              +-> collect_redhat --+
    intake ---+  (parallel fan-out) +--> validate --+--> publish -> END
              +-> collect_nexus ---+   (fan-in)     +--> END invalid  (nothing published)
                                                    +--> END escalate (sources contradict)

- Parallel fan-out/fan-in: both sources collected concurrently (pack feature).
- COLLECT-VAL-001 (deterministic): schema, digest format, emptiness,
  cross-source sanity. Invalid or contradictory evidence NEVER reaches the API.
- No interrupt: nothing here needs human approval, so no checkpointer either.

## Run
    make setup && make test
    python run_langgraph.py scenarios/happy.json
    python run_langgraph.py scenarios/happy.json --sink file:///tmp/evidence
    python run_langgraph.py scenarios/empty_nexus.json           # invalid -> no publish
    python run_langgraph.py scenarios/contradictory_sources.json # escalate

## Real mode
Swap tools/mock/* for tools/redhat.py + a real Nexus adapter (same signatures)
and point --sink at https://<skyline-api>. requests is the only extra dep.
