"""
VNC gateway: browser (noVNC) <-> FastAPI WS <-> KubeVirt VNC subresource.

Users never get cluster credentials. This service holds a narrowly-scoped
ServiceAccount token and is therefore THE authorization boundary.
"""
import asyncio
import json
import logging
import os
import re
import secrets
import ssl
import time
from dataclasses import dataclass

import jwt
from fastapi import Depends, FastAPI, HTTPException, WebSocket, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from fastapi.staticfiles import StaticFiles
from websockets.asyncio.client import connect
from websockets.exceptions import ConnectionClosed

log = logging.getLogger("vnc-gateway")
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")

# --- config -----------------------------------------------------------------
API_SERVER = os.environ["K8S_API_SERVER"].rstrip("/")          # https://api.ocp.example:6443
WS_BASE = API_SERVER.replace("https://", "wss://", 1)
SA_TOKEN_PATH = os.environ.get("SA_TOKEN_PATH", "/secrets/sa/token")
K8S_CA_PATH = os.environ.get("K8S_CA_PATH", "/secrets/sa/ca.crt")
OIDC_JWKS_URL = os.environ["OIDC_JWKS_URL"]
OIDC_ISSUER = os.environ["OIDC_ISSUER"]
OIDC_AUDIENCE = os.environ["OIDC_AUDIENCE"]
ACL_PATH = os.environ.get("ACL_PATH", "/config/acl.json")
ALLOWED_ORIGINS = {o.strip() for o in os.environ["ALLOWED_ORIGINS"].split(",")}
TICKET_TTL_S = int(os.environ.get("TICKET_TTL_S", "30"))
MAX_SESSION_S = int(os.environ.get("MAX_SESSION_S", "3600"))

DNS1123 = re.compile(r"^[a-z0-9]([-a-z0-9]{0,61}[a-z0-9])?$")

ssl_ctx = ssl.create_default_context(cafile=K8S_CA_PATH)       # never verify=False
jwks = jwt.PyJWKClient(OIDC_JWKS_URL, cache_keys=True)

with open(ACL_PATH) as f:
    # {"group-name": ["namespace/vm-name", "namespace/*"]}
    ACL: dict[str, list[str]] = json.load(f)

app = FastAPI(docs_url=None, redoc_url=None)
bearer = HTTPBearer()


# --- authn / authz ------------------------------------------------------------
@dataclass(frozen=True)
class User:
    sub: str
    groups: tuple[str, ...]


def current_user(creds: HTTPAuthorizationCredentials = Depends(bearer)) -> User:
    try:
        key = jwks.get_signing_key_from_jwt(creds.credentials).key
        c = jwt.decode(creds.credentials, key, algorithms=["RS256"],
                       audience=OIDC_AUDIENCE, issuer=OIDC_ISSUER)
    except jwt.PyJWTError:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "invalid token")
    return User(sub=c["sub"], groups=tuple(c.get("groups", [])))


def authorized(user: User, ns: str, vm: str) -> bool:
    for g in user.groups:
        for rule in ACL.get(g, []):
            r_ns, r_vm = rule.split("/", 1)
            if r_ns == ns and r_vm in ("*", vm):
                return True
    return False


# --- one-time tickets (browsers can't set headers on WebSocket) ---------------
@dataclass
class Ticket:
    user: User
    ns: str
    vm: str
    expires: float


_tickets: dict[str, Ticket] = {}   # single replica only; use Redis GETDEL for HA


def _gc_tickets() -> None:
    now = time.monotonic()
    for k in [k for k, t in _tickets.items() if t.expires < now]:
        _tickets.pop(k, None)


@app.post("/api/vms/{ns}/{vm}/console-ticket")
def issue_ticket(ns: str, vm: str, user: User = Depends(current_user)):
    if not (DNS1123.match(ns) and DNS1123.match(vm)):
        raise HTTPException(400, "invalid name")          # blocks path injection upstream
    if not authorized(user, ns, vm):
        log.warning("deny user=%s vm=%s/%s", user.sub, ns, vm)
        raise HTTPException(403, "forbidden")
    _gc_tickets()
    tid = secrets.token_urlsafe(32)
    _tickets[tid] = Ticket(user, ns, vm, time.monotonic() + TICKET_TTL_S)
    return {"ticket": tid, "ws_path": f"/ws/console?ticket={tid}"}


# --- the proxy ----------------------------------------------------------------
def _sa_token() -> str:
    # re-read every session so a rotated/projected token is picked up
    with open(SA_TOKEN_PATH) as f:
        return f.read().strip()


@app.websocket("/ws/console")
async def console(ws: WebSocket, ticket: str):
    t = _tickets.pop(ticket, None)                         # one-time use
    if t is None or t.expires < time.monotonic():
        await ws.close(code=4401)
        return
    if ws.headers.get("origin") not in ALLOWED_ORIGINS:   # CSWSH protection
        await ws.close(code=4403)
        return

    offered = ws.scope.get("subprotocols", [])
    await ws.accept(subprotocol="binary" if "binary" in offered else None)

    url = (f"{WS_BASE}/apis/subresources.kubevirt.io/v1/namespaces/"
           f"{t.ns}/virtualmachineinstances/{t.vm}/vnc")
    started, tx, rx = time.monotonic(), 0, 0
    log.info("open user=%s vm=%s/%s", t.user.sub, t.ns, t.vm)

    try:
        async with asyncio.timeout(MAX_SESSION_S):
            async with connect(
                url,
                additional_headers={"Authorization": f"Bearer {_sa_token()}"},
                subprotocols=["plain.kubevirt.io"],
                ssl=ssl_ctx,
                max_size=None,
                ping_interval=20,
                open_timeout=10,
            ) as up:

                async def client_to_upstream():
                    nonlocal tx
                    while True:
                        msg = await ws.receive()
                        if msg["type"] == "websocket.disconnect":
                            return
                        data = msg.get("bytes") or (msg.get("text") or "").encode()
                        tx += len(data)
                        await up.send(data)

                async def upstream_to_client():
                    nonlocal rx
                    async for data in up:
                        b = data if isinstance(data, bytes) else data.encode()
                        rx += len(b)
                        await ws.send_bytes(b)

                tasks = {asyncio.create_task(client_to_upstream()),
                         asyncio.create_task(upstream_to_client())}
                done, pending = await asyncio.wait(tasks, return_when=asyncio.FIRST_COMPLETED)
                for p in pending:
                    p.cancel()
                await asyncio.gather(*pending, return_exceptions=True)
                for d in done:
                    if (e := d.exception()) and not isinstance(e, ConnectionClosed):
                        raise e
    except TimeoutError:
        log.info("session limit reached user=%s", t.user.sub)
    except Exception as e:  # upstream 403/404, TLS, VMI not running, ...
        log.error("proxy error user=%s vm=%s/%s: %r", t.user.sub, t.ns, t.vm, e)
    finally:
        log.info("close user=%s vm=%s/%s dur=%.0fs tx=%d rx=%d",
                 t.user.sub, t.ns, t.vm, time.monotonic() - started, tx, rx)
        try:
            await ws.close()
        except RuntimeError:
            pass


app.mount("/novnc", StaticFiles(directory="/opt/novnc"), name="novnc")
app.mount("/", StaticFiles(directory=os.path.join(os.path.dirname(__file__), "static"), html=True))
