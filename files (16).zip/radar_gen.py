#!/usr/bin/env python3
"""
radar_gen.py (v2) — build-time drift-health radars from three version sources,
with explicit identity resolution and channel filtering.

Pipeline:
    data/current.json   (deployed/desired versions, per cluster)
    data/upstream.json  (Red Hat upstream available versions, per app, per channel)
    data/nexus.json     (Nexus-mirrored available versions, per app)
    app_map.yaml        (identity + channel contract)
        -> resolve identity, filter upstream to subscribed channel
        -> per-app status (CURRENT|UPDATE_AVAILABLE|BLOCKED|UNPARSEABLE|UNMAPPED)
        -> per-cluster axis scores (0..5)
        -> docs/clusters/<cluster>/radar.svg
        -> docs/data/merged.json
        -> docs/clusters/_fleet_radar.svg

Deps: packaging, PyYAML.
Edit the ACCESSORS block to match your REST pull's exact JSON shape.
"""
from __future__ import annotations

import json
import math
import re
import sys
import datetime as dt
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional, Iterable

try:
    from packaging.version import Version, InvalidVersion
except ImportError:
    sys.exit("pip install packaging")
try:
    import yaml
except ImportError:
    sys.exit("pip install pyyaml")

# --------------------------------------------------------------------------- #
# Config
# --------------------------------------------------------------------------- #
DATA_DIR = Path("data")
OUT_CLUSTERS = Path("docs/clusters")
OUT_DATA = Path("docs/data")
APP_MAP_PATH = Path("app_map.yaml")

MAX_STALE_DAYS = 7
LAG_CAP = 6
FAIL_ON_UNMAPPED = False   # break build if any app resolves to UNMAPPED
STRICT_MAP = False         # break build if any app falls back to fuzzy identity

AXES = ["Currency", "Upstream lag", "Mirror coverage",
        "Determinism", "Mapping coverage", "Patch freshness"]

# --------------------------------------------------------------------------- #
# ACCESSORS — the only block to touch when your JSON shape differs.
# --------------------------------------------------------------------------- #
def parse_current(raw: dict) -> dict[str, list["ClusterApp"]]:
    out: dict[str, list[ClusterApp]] = {}
    for cluster in raw["clusters"]:
        out[cluster["name"]] = [
            ClusterApp(name=a["name"], current_raw=a["version"])
            for a in cluster["applications"]
        ]
    return out


def parse_upstream(raw: dict) -> dict[str, dict[str, list[str]]]:
    """
    upstream.json -> {upstream_key: {channel: [version_str, ...]}}
    Expected shape:
      {"apps":[{"name":"openshift-cert-manager-operator",
                "channels":{"stable-v1":["v1.14.2","v1.15.0"],
                            "tech-preview":["v1.16.0"]}}]}
    If your pull is flat (no channels), wrap it: {"_all": [...]} and set
    channel: _all in app_map.yaml.
    """
    out: dict[str, dict[str, list[str]]] = {}
    for a in raw["apps"]:
        chans = a.get("channels")
        if chans is None:  # flat fallback
            chans = {"_all": list(a.get("available", []))}
        out[a["name"]] = {c: list(v) for c, v in chans.items()}
    return out


def parse_nexus(raw: dict) -> dict[str, list[str]]:
    """nexus.json -> {nexus_key: [version_str, ...]}"""
    return {a["name"]: list(a.get("available", [])) for a in raw["apps"]}


# --------------------------------------------------------------------------- #
# Version normalization
# --------------------------------------------------------------------------- #
_SEMVER_RE = re.compile(r"(\d+)\.(\d+)(?:\.(\d+))?")


def extract_semver(raw: str) -> Optional[Version]:
    if not raw:
        return None
    m = _SEMVER_RE.search(raw)
    if not m:
        return None
    try:
        return Version(f"{m.group(1)}.{m.group(2)}.{m.group(3) or '0'}")
    except InvalidVersion:
        return None


def newer_than(current: Version, candidates: Iterable[str]) -> list[Version]:
    return sorted(v for v in (extract_semver(c) for c in candidates)
                  if v is not None and v > current)


def same_minor_patches(current: Version, candidates: Iterable[str]) -> list[Version]:
    return sorted(v for v in (extract_semver(c) for c in candidates)
                  if v is not None and (v.major, v.minor) == (current.major, current.minor))


# --------------------------------------------------------------------------- #
# Identity resolution
# --------------------------------------------------------------------------- #
@dataclass
class MapEntry:
    upstream_key: str
    nexus_key: str
    channel: str
    kind: str = "app"


def load_app_map() -> dict[str, MapEntry]:
    if not APP_MAP_PATH.exists():
        print(f"WARNING: {APP_MAP_PATH} absent — all apps resolve by fuzzy identity",
              file=sys.stderr)
        return {}
    raw = yaml.safe_load(APP_MAP_PATH.read_text()) or {}
    return {
        k: MapEntry(v["upstream_key"], v["nexus_key"],
                    v.get("channel", "_all"), v.get("kind", "app"))
        for k, v in raw.items()
    }


def resolve(app_name: str, amap: dict[str, MapEntry]) -> tuple[MapEntry, str]:
    """Returns (entry, resolution) where resolution in {explicit, fuzzy}."""
    if app_name in amap:
        return amap[app_name], "explicit"
    return MapEntry(app_name, app_name, "_all"), "fuzzy"


# --------------------------------------------------------------------------- #
# Data model
# --------------------------------------------------------------------------- #
@dataclass
class ClusterApp:
    name: str
    current_raw: str
    current: Optional[Version] = field(init=False, default=None)

    def __post_init__(self):
        self.current = extract_semver(self.current_raw)


@dataclass
class AppStatus:
    name: str
    current_raw: str
    resolution: str
    channel: str
    parseable: bool
    mapped: bool
    lag_upstream: int
    lag_nexus: int
    blocked: bool
    on_latest_nexus: bool
    on_latest_patch: bool
    status: str

    def to_row(self) -> dict:
        return {"app": self.name, "current": self.current_raw,
                "channel": self.channel, "resolution": self.resolution,
                "lag_upstream": self.lag_upstream, "lag_nexus": self.lag_nexus,
                "status": self.status}


def evaluate(app: ClusterApp,
             amap: dict[str, MapEntry],
             upstream: dict[str, dict[str, list[str]]],
             nexus: dict[str, list[str]]) -> AppStatus:
    entry, resolution = resolve(app.name, amap)

    up_channels = upstream.get(entry.upstream_key)
    nx_list = nexus.get(entry.nexus_key)
    mapped = up_channels is not None and nx_list is not None

    if up_channels is not None:
        if entry.channel in up_channels:
            up_list = up_channels[entry.channel]
        elif "_all" in up_channels:
            up_list = up_channels["_all"]
        else:
            up_list = []
    else:
        up_list = []
    nx_list = nx_list or []

    if app.current is None:
        return AppStatus(app.name, app.current_raw, resolution, entry.channel,
                         False, mapped, 0, 0, False, False, False, "UNPARSEABLE")
    if not mapped:
        return AppStatus(app.name, app.current_raw, resolution, entry.channel,
                         True, False, 0, 0, False, False, False, "UNMAPPED")

    lag_up = len(newer_than(app.current, up_list))
    lag_nx = len(newer_than(app.current, nx_list))
    up_max = max(newer_than(app.current, up_list), default=None)
    nx_max = max(newer_than(app.current, nx_list), default=None)
    blocked = up_max is not None and (nx_max is None or up_max > nx_max)

    patches = same_minor_patches(app.current, nx_list)
    on_latest_patch = bool(patches) and app.current >= max(patches)
    on_latest_nexus = lag_nx == 0

    if lag_up == 0 and lag_nx == 0:
        status = "CURRENT"
    elif blocked and lag_nx == 0:
        status = "BLOCKED"
    else:
        status = "UPDATE_AVAILABLE"

    return AppStatus(app.name, app.current_raw, resolution, entry.channel,
                     True, True, lag_up, lag_nx, blocked,
                     on_latest_nexus, on_latest_patch, status)


# --------------------------------------------------------------------------- #
# Scoring
# --------------------------------------------------------------------------- #
def score_cluster(statuses: list[AppStatus]) -> dict[str, float]:
    total = len(statuses)
    if total == 0:
        return {ax: 0.0 for ax in AXES}
    scored = [s for s in statuses if s.parseable and s.mapped]
    n = len(scored) or 1

    def frac(pred) -> float:
        return sum(1 for s in scored if pred(s)) / n

    lag_norm = sum(min(s.lag_upstream, LAG_CAP) / LAG_CAP for s in scored) / n
    return {
        "Currency": round(5 * frac(lambda s: s.on_latest_nexus), 2),
        "Upstream lag": round(5 * (1 - lag_norm), 2),
        "Mirror coverage": round(5 * (1 - frac(lambda s: s.blocked)), 2),
        "Determinism": round(5 * sum(1 for s in statuses if s.parseable) / total, 2),
        "Mapping coverage": round(5 * sum(1 for s in statuses if s.mapped) / total, 2),
        "Patch freshness": round(5 * frac(lambda s: s.on_latest_patch), 2),
    }


# --------------------------------------------------------------------------- #
# SVG radar
# --------------------------------------------------------------------------- #
_PALETTE = ["#f97316", "#3b82f6", "#a855f7", "#eab308", "#22c55e", "#38bdf8"]
_BG, _GRID, _SPOKE = "#0d1117", "#252b34", "#333a44"


def _polar(cx, cy, r, deg):
    a = math.radians(deg)
    return cx + r * math.cos(a), cy + r * math.sin(a)


def _band(v: float) -> str:
    return "#22c55e" if v >= 4 else "#eab308" if v >= 2.5 else "#f97316"


def _esc(s: str) -> str:
    return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def render_radar(scores: dict[str, float], title: str,
                 subtitle: str = "", blocked: int = 0) -> str:
    axes, n = AXES, len(AXES)
    # wider than tall: horizontal axis labels need room on both flanks;
    # cy shifted below centre to clear the header/subtitle band.
    W, H = 560, 500
    cx, cy = 280, 262
    R, label_r, maxs = 132, 158, 5
    angles = [-90 + i * 360 / n for i in range(n)]

    p = [f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W} {H}" '
         f'font-family="ui-monospace,Menlo,monospace">',
         f'<rect width="{W}" height="{H}" rx="14" fill="{_BG}"/>']

    for ring in range(1, maxs + 1):
        pts = " ".join(f"{x:.1f},{y:.1f}" for x, y in
                       (_polar(cx, cy, R * ring / maxs, a) for a in angles))
        p.append(f'<polygon points="{pts}" fill="none" stroke="{_GRID}" stroke-width="1"/>')

    worst_axis = min(scores, key=scores.get) if scores else ""
    for i, a in enumerate(angles):
        ex, ey = _polar(cx, cy, R, a)
        p.append(f'<line x1="{cx}" y1="{cy}" x2="{ex:.1f}" y2="{ey:.1f}" '
                 f'stroke="{_SPOKE}" stroke-width="1"/>')
        lx, ly = _polar(cx, cy, label_r, a)
        anchor = "start" if lx > cx + 4 else "end" if lx < cx - 4 else "middle"
        # highlight the worst axis label so the eye lands on the problem
        fill = _band(scores.get(axes[i], 0.0)) if axes[i] == worst_axis else "#8b949e"
        weight = "700" if axes[i] == worst_axis else "400"
        p.append(f'<text x="{lx:.1f}" y="{ly:.1f}" fill="{fill}" font-size="11" '
                 f'font-weight="{weight}" text-anchor="{anchor}" '
                 f'dominant-baseline="middle">{axes[i]}</text>')

    dpts = [_polar(cx, cy, R * max(0.0, min(maxs, scores.get(axes[i], 0.0))) / maxs, a)
            for i, a in enumerate(angles)]
    poly = " ".join(f"{x:.1f},{y:.1f}" for x, y in dpts)
    p.append(f'<polygon points="{poly}" fill="#38bdf8" fill-opacity="0.16" '
             f'stroke="#38bdf8" stroke-width="2"/>')
    for i, (x, y) in enumerate(dpts):
        p.append(f'<circle cx="{x:.1f}" cy="{y:.1f}" r="3.5" fill="{_PALETTE[i % len(_PALETTE)]}"/>')

    # centre = WORST axis, not the mean. An averaged score launders a single
    # red axis (e.g. an unpatched BLOCKED app) into a healthy-looking number.
    worst = min(scores.values()) if scores else 0.0
    mean = sum(scores.values()) / len(scores) if scores else 0.0
    p.append(f'<text x="{cx}" y="{cy - 2}" fill="{_band(worst)}" font-size="34" '
             f'font-weight="700" text-anchor="middle">{worst:.1f}</text>')
    p.append(f'<text x="{cx}" y="{cy + 18}" fill="#6e7681" font-size="9.5" '
             f'text-anchor="middle">worst / 5 · avg {mean:.1f}</text>')

    p.append(f'<text x="20" y="30" fill="#e6edf3" font-size="15" font-weight="700">'
             f'{_esc(title)}</text>')
    if subtitle:
        p.append(f'<text x="20" y="49" fill="#8b949e" font-size="10">{_esc(subtitle)}</text>')

    # BLOCKED badge: upstream shipped, Nexus hasn't mirrored — the audit-relevant state
    if blocked > 0:
        bw = 92
        p.append(f'<rect x="{W - bw - 16}" y="16" width="{bw}" height="22" rx="11" '
                 f'fill="#f9731622" stroke="#f97316" stroke-width="1"/>')
        p.append(f'<text x="{W - bw/2 - 16}" y="31" fill="#f97316" font-size="11" '
                 f'font-weight="700" text-anchor="middle">⛔ {blocked} BLOCKED</text>')

    p.append("</svg>")
    return "\n".join(p)


# --------------------------------------------------------------------------- #
# Loading + freshness
# --------------------------------------------------------------------------- #
def load_source(name: str) -> dict:
    path = DATA_DIR / name
    if not path.exists():
        sys.exit(f"missing required source: {path}")
    age = (dt.datetime.now().timestamp() - path.stat().st_mtime) / 86400
    if age > MAX_STALE_DAYS:
        print(f"WARNING: {path} is {age:.1f}d old (> {MAX_STALE_DAYS}d)", file=sys.stderr)
    return json.loads(path.read_text())


def source_stamp() -> str:
    out = []
    for name in ("current.json", "upstream.json", "nexus.json"):
        p = DATA_DIR / name
        if p.exists():
            ts = dt.datetime.fromtimestamp(p.stat().st_mtime, dt.timezone.utc)
            out.append(f"{name} {ts:%Y-%m-%d %H:%MZ}")
    return " | ".join(out)


# --------------------------------------------------------------------------- #
# Main
# --------------------------------------------------------------------------- #
def main() -> int:
    amap = load_app_map()
    current = parse_current(load_source("current.json"))
    upstream = parse_upstream(load_source("upstream.json"))
    nexus = parse_nexus(load_source("nexus.json"))

    OUT_CLUSTERS.mkdir(parents=True, exist_ok=True)
    OUT_DATA.mkdir(parents=True, exist_ok=True)

    merged: dict[str, dict] = {}
    fleet: list[dict[str, float]] = []
    unmapped = fuzzy = fleet_blocked = 0
    stamp = source_stamp()

    for cluster, apps in current.items():
        statuses = [evaluate(a, amap, upstream, nexus) for a in apps]
        unmapped += sum(1 for s in statuses if s.status == "UNMAPPED")
        fuzzy += sum(1 for s in statuses if s.resolution == "fuzzy")

        scores = score_cluster(statuses)
        fleet.append(scores)

        cdir = OUT_CLUSTERS / cluster
        cdir.mkdir(parents=True, exist_ok=True)
        blocked = sum(1 for s in statuses if s.status == "BLOCKED")
        fleet_blocked += blocked
        (cdir / "radar.svg").write_text(
            render_radar(scores, cluster,
                         f"{len(apps)} apps · {blocked} blocked · {stamp}",
                         blocked=blocked))

        merged[cluster] = {
            "scores": scores,
            "generated": dt.datetime.now(dt.timezone.utc).isoformat(),
            "sources": stamp,
            "apps": [s.to_row() for s in statuses],
        }

    if fleet:
        favg = {ax: round(sum(s[ax] for s in fleet) / len(fleet), 2) for ax in AXES}
        (OUT_CLUSTERS / "_fleet_radar.svg").write_text(
            render_radar(favg, "Fleet",
                         f"{len(fleet)} clusters · {fleet_blocked} blocked · {stamp}",
                         blocked=fleet_blocked))
        merged["_fleet"] = {"scores": favg, "clusters": len(fleet)}

    (OUT_DATA / "merged.json").write_text(json.dumps(merged, indent=2))

    print(f"clusters: {len(current)}  unmapped: {unmapped}  fuzzy-resolved: {fuzzy}")
    if fuzzy and STRICT_MAP:
        sys.exit(f"{fuzzy} apps fell back to fuzzy identity — add them to app_map.yaml")
    if unmapped and FAIL_ON_UNMAPPED:
        sys.exit(f"{unmapped} unmapped apps")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
