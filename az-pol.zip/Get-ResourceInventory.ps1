#Requires -Modules Az.Accounts, Az.Resources
<#
.SYNOPSIS
    Inventories resources of a given type across one or more subscriptions.
.EXAMPLE
    ./Get-ResourceInventory.ps1 -SubscriptionId "xxxx-xxxx" -ResourceType "Microsoft.Storage/storageAccounts" -OutputCsv ./storage-inventory.csv
.EXAMPLE
    # multiple types in one pass, tagged by policy area
    ./Get-ResourceInventory.ps1 -SubscriptionId "xxxx-xxxx" -ResourceType @(
        "Microsoft.Storage/storageAccounts",
        "Microsoft.Cache/redis",
        "Microsoft.Insights/components",
        "Microsoft.KeyVault/vaults",
        "Microsoft.Sql/servers",
        "Microsoft.Network/networkSecurityGroups"
    ) -OutputCsv ./full-inventory.csv
#>
param(
    [Parameter(Mandatory)]
    [string]$SubscriptionId,

    [Parameter(Mandatory)]
    [string[]]$ResourceType,

    [string]$OutputCsv = "./resource-inventory.csv",

    # tag filter, e.g. -Tag @{Environment='Prod'}
    [hashtable]$Tag,

    [switch]$IncludeExtendedProperties
)

$ErrorActionPreference = 'Stop'

$ctx = Get-AzContext
if (-not $ctx -or $ctx.Subscription.Id -ne $SubscriptionId) {
    Set-AzContext -SubscriptionId $SubscriptionId | Out-Null
}

$results = foreach ($type in $ResourceType) {
    Write-Verbose "Querying $type in $SubscriptionId"
    $params = @{ ResourceType = $type }
    if ($Tag) { $params['Tag'] = $Tag }

    Get-AzResource @params -ExpandProperties:$IncludeExtendedProperties | ForEach-Object {
        [PSCustomObject]@{
            Name              = $_.Name
            ResourceGroup     = $_.ResourceGroupName
            ResourceType      = $_.ResourceType
            Location          = $_.Location
            SubscriptionId    = $SubscriptionId
            Environment       = $_.Tags['Environment']  # adjust to your tagging taxonomy
            ResourceId        = $_.ResourceId
            Properties        = if ($IncludeExtendedProperties) { ($_.Properties | ConvertTo-Json -Compress -Depth 5) } else { $null }
        }
    }
}

$results | Export-Csv -Path $OutputCsv -NoTypeInformation -Encoding UTF8
Write-Host "Exported $($results.Count) resources to $OutputCsv" -ForegroundColor Green
$results
