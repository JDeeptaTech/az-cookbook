#Requires -Modules Az.Accounts, Az.Resources, Az.Storage, Az.RedisCache, Az.KeyVault, Az.Sql, Az.Network, Az.ApplicationInsights
<#
.SYNOPSIS
    Applies remediation for known policy violations (SC-AZURE-*) against a list of resources.
.DESCRIPTION
    Consumes the CSV from Get-ResourceInventory.ps1, filters to a PolicyId's target resource type,
    and applies the fix. Defaults to -WhatIf. Pass -Apply to actually execute.
.EXAMPLE
    ./Invoke-PolicyRemediation.ps1 -PolicyId SC-AZURE-STORAGE-004 -InputCsv ./storage-inventory.csv
    ./Invoke-PolicyRemediation.ps1 -PolicyId SC-AZURE-STORAGE-004 -InputCsv ./storage-inventory.csv -Apply
#>
param(
    [Parameter(Mandatory)]
    [ValidateSet(
        'SC-AZURE-APPINSIGHTS-001',
        'SC-AZURE-REDIS-008',
        'SC-AZURE-REDIS-009',
        'SC-AZURE-STORAGE-004',
        'SC-AZURE-STORAGE-006',
        'SC-AZURE-STORAGE-021',
        'SC-AZURE-STORAGE-016',
        'SC-AZURE-STORAGE-023',
        'SC-AZURE-AKV-002',
        'SC-AZURE-SQL-025',
        'SC-AZURE-SQL-032',
        'SC-AZURE-NSG-001',
        'SC-AZURE-NSG-002',
        'SC-AZURE-STORAGE-002'
    )]
    [string]$PolicyId,

    [Parameter(Mandatory)]
    [string]$InputCsv,

    [switch]$Apply,   # if not set, runs -WhatIf and only reports what WOULD change

    # required for AKV-002 / STORAGE-004 style rules that need an allow-list instead of hard deny
    [string[]]$AllowedSubnetIds,
    [string[]]$AllowedIpRanges
)

$ErrorActionPreference = 'Stop'
$WhatIfPreference = -not $Apply.IsPresent

$resources = Import-Csv -Path $InputCsv

# ---- remediation function library, keyed by PolicyId --------------------

function Remediate-AppInsightsPublicAccess {
    param($r)
    Update-AzApplicationInsights -ResourceGroupName $r.ResourceGroup -Name $r.Name `
        -PublicNetworkAccessForIngestion Disabled -PublicNetworkAccessForQuery Disabled -WhatIf:$WhatIfPreference
}

function Remediate-RedisPublicNetworkAccess {
    param($r)
    Set-AzRedisCache -ResourceGroupName $r.ResourceGroup -Name $r.Name `
        -PublicNetworkAccess Disabled -WhatIf:$WhatIfPreference
}

function Remediate-RedisEntraAuth {
    param($r)
    # RedisConfiguration flag; requires AAD-enabled Redis config
    Set-AzRedisCache -ResourceGroupName $r.ResourceGroup -Name $r.Name `
        -RedisConfiguration @{ 'aad-enabled' = 'true' } -WhatIf:$WhatIfPreference
}

function Remediate-StorageDefaultDeny {
    param($r)
    $params = @{
        ResourceGroupName    = $r.ResourceGroup
        Name                 = $r.Name
        NetworkRuleSet       = @{
            DefaultAction = 'Deny'
            Bypass        = 'AzureServices'
        }
    }
    if ($AllowedIpRanges) { $params.NetworkRuleSet['IPRules'] = $AllowedIpRanges | ForEach-Object { @{ IPAddressOrRange = $_; Action = 'Allow' } } }
    Update-AzStorageAccountNetworkRuleSet @params -WhatIf:$WhatIfPreference
}

function Remediate-StorageContainerPublicAccess {
    param($r)
    Set-AzStorageAccount -ResourceGroupName $r.ResourceGroup -Name $r.Name `
        -AllowBlobPublicAccess $false -WhatIf:$WhatIfPreference
}

function Remediate-StorageAccessKeyRotation {
    param($r)
    # Rotate both keys; downstream consumers using key auth MUST be migrated to Entra/SAS first
    if ($Apply) {
        New-AzStorageAccountKey -ResourceGroupName $r.ResourceGroup -Name $r.Name -KeyName key1 | Out-Null
        New-AzStorageAccountKey -ResourceGroupName $r.ResourceGroup -Name $r.Name -KeyName key2 | Out-Null
        Write-Host "Rotated keys for $($r.Name)" -ForegroundColor Yellow
    } else {
        Write-Host "[WhatIf] Would rotate access keys for $($r.Name)" -ForegroundColor Cyan
    }
}

function Remediate-StorageLocalUsersDisabled {
    param($r)
    Set-AzStorageAccount -ResourceGroupName $r.ResourceGroup -Name $r.Name `
        -EnableLocalUser $false -WhatIf:$WhatIfPreference
}

function Remediate-KeyVaultPrivateEndpointOnly {
    param($r)
    if (-not $AllowedSubnetIds) {
        Write-Warning "AKV-002 requires -AllowedSubnetIds to avoid locking out legitimate traffic. Skipping $($r.Name)."
        return
    }
    Update-AzKeyVaultNetworkRuleSet -ResourceGroupName $r.ResourceGroup -VaultName $r.Name `
        -DefaultAction Deny -Bypass AzureServices -WhatIf:$WhatIfPreference
    foreach ($subnet in $AllowedSubnetIds) {
        Add-AzKeyVaultNetworkRule -ResourceGroupName $r.ResourceGroup -VaultName $r.Name `
            -VirtualNetworkResourceId $subnet -WhatIf:$WhatIfPreference
    }
}

function Remediate-SqlPublicNetworkAccess {
    param($r)
    Set-AzSqlServer -ResourceGroupName $r.ResourceGroup -ServerName $r.Name `
        -PublicNetworkAccess "Disabled" -WhatIf:$WhatIfPreference
}

function Remediate-SqlAadOnlyAuth {
    param($r)
    # BREAKING: kills SQL-auth logins. Confirm AAD admin is set and app connection strings migrated first.
    Set-AzSqlServerActiveDirectoryOnlyAuthentication -ResourceGroupName $r.ResourceGroup `
        -ServerName $r.Name -WhatIf:$WhatIfPreference
}

function Remediate-NsgWideOpenInbound {
    param($r)
    $nsg = Get-AzNetworkSecurityGroup -ResourceGroupName $r.ResourceGroup -Name $r.Name
    $offenders = $nsg.SecurityRules | Where-Object {
        $_.Direction -eq 'Inbound' -and $_.Access -eq 'Allow' -and
        ($_.SourceAddressPrefix -in @('*','0.0.0.0/0','Internet'))
    }
    foreach ($rule in $offenders) {
        Write-Host "[WhatIf:$WhatIfPreference] Would tighten/remove inbound rule '$($rule.Name)' on $($r.Name)" -ForegroundColor Yellow
        if ($Apply) {
            $nsg | Remove-AzNetworkSecurityRuleConfig -Name $rule.Name | Set-AzNetworkSecurityGroup
        }
    }
}

function Remediate-NsgWideOpenOutbound {
    param($r)
    $nsg = Get-AzNetworkSecurityGroup -ResourceGroupName $r.ResourceGroup -Name $r.Name
    $offenders = $nsg.SecurityRules | Where-Object {
        $_.Direction -eq 'Outbound' -and $_.Access -eq 'Allow' -and
        ($_.DestinationAddressPrefix -in @('*','0.0.0.0/0','Internet'))
    }
    foreach ($rule in $offenders) {
        Write-Host "[WhatIf:$WhatIfPreference] Would tighten/remove outbound rule '$($rule.Name)' on $($r.Name)" -ForegroundColor Yellow
        if ($Apply) {
            $nsg | Remove-AzNetworkSecurityRuleConfig -Name $rule.Name | Set-AzNetworkSecurityGroup
        }
    }
}

function Remediate-StorageEnterpriseIpOnly {
    param($r)
    if (-not $AllowedIpRanges) {
        Write-Warning "STORAGE-002 requires -AllowedIpRanges. Skipping $($r.Name)."
        return
    }
    $rules = $AllowedIpRanges | ForEach-Object { @{ IPAddressOrRange = $_; Action = 'Allow' } }
    Update-AzStorageAccountNetworkRuleSet -ResourceGroupName $r.ResourceGroup -Name $r.Name `
        -NetworkRuleSet @{ DefaultAction = 'Deny'; IPRules = $rules } -WhatIf:$WhatIfPreference
}

# ---- dispatch table -------------------------------------------------------

$map = @{
    'SC-AZURE-APPINSIGHTS-001' = @{ Fn = 'Remediate-AppInsightsPublicAccess';    Type = 'Microsoft.Insights/components' }
    'SC-AZURE-REDIS-008'       = @{ Fn = 'Remediate-RedisPublicNetworkAccess';   Type = 'Microsoft.Cache/redis' }
    'SC-AZURE-REDIS-009'       = @{ Fn = 'Remediate-RedisEntraAuth';            Type = 'Microsoft.Cache/redis' }
    'SC-AZURE-STORAGE-004'     = @{ Fn = 'Remediate-StorageDefaultDeny';        Type = 'Microsoft.Storage/storageAccounts' }
    'SC-AZURE-STORAGE-006'     = @{ Fn = 'Remediate-StorageContainerPublicAccess'; Type = 'Microsoft.Storage/storageAccounts' }
    'SC-AZURE-STORAGE-021'     = @{ Fn = 'Remediate-StorageDefaultDeny';        Type = 'Microsoft.Storage/storageAccounts' } # "remove unrestricted access" = same fix as 004
    'SC-AZURE-STORAGE-016'     = @{ Fn = 'Remediate-StorageAccessKeyRotation';  Type = 'Microsoft.Storage/storageAccounts' }
    'SC-AZURE-STORAGE-023'     = @{ Fn = 'Remediate-StorageLocalUsersDisabled'; Type = 'Microsoft.Storage/storageAccounts' }
    'SC-AZURE-STORAGE-002'     = @{ Fn = 'Remediate-StorageEnterpriseIpOnly';   Type = 'Microsoft.Storage/storageAccounts' }
    'SC-AZURE-AKV-002'         = @{ Fn = 'Remediate-KeyVaultPrivateEndpointOnly'; Type = 'Microsoft.KeyVault/vaults' }
    'SC-AZURE-SQL-025'         = @{ Fn = 'Remediate-SqlPublicNetworkAccess';    Type = 'Microsoft.Sql/servers' }
    'SC-AZURE-SQL-032'         = @{ Fn = 'Remediate-SqlAadOnlyAuth';            Type = 'Microsoft.Sql/servers' }
    'SC-AZURE-NSG-001'         = @{ Fn = 'Remediate-NsgWideOpenInbound';        Type = 'Microsoft.Network/networkSecurityGroups' }
    'SC-AZURE-NSG-002'         = @{ Fn = 'Remediate-NsgWideOpenOutbound';       Type = 'Microsoft.Network/networkSecurityGroups' }
}

$entry = $map[$PolicyId]
$targets = $resources | Where-Object { $_.ResourceType -eq $entry.Type }

if (-not $targets) {
    Write-Warning "No resources of type $($entry.Type) found in $InputCsv for policy $PolicyId"
    return
}

Write-Host "PolicyId: $PolicyId | Target type: $($entry.Type) | Mode: $(if($Apply){'APPLY'}else{'WHATIF (dry run)'}) | Count: $($targets.Count)" -ForegroundColor Cyan

$log = foreach ($r in $targets) {
    try {
        & $entry.Fn $r
        [PSCustomObject]@{ Resource = $r.Name; ResourceGroup = $r.ResourceGroup; PolicyId = $PolicyId; Status = if($Apply){'Remediated'}else{'WhatIf-OK'}; Error = $null }
    } catch {
        [PSCustomObject]@{ Resource = $r.Name; ResourceGroup = $r.ResourceGroup; PolicyId = $PolicyId; Status = 'Failed'; Error = $_.Exception.Message }
    }
}

$logPath = "./remediation-log-$PolicyId-$(Get-Date -Format yyyyMMdd-HHmmss).csv"
$log | Export-Csv -Path $logPath -NoTypeInformation
Write-Host "Log written to $logPath" -ForegroundColor Green
$log | Format-Table -AutoSize
