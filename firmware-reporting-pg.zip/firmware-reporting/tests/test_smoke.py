"""Smoke tests — run without Postgres or any data."""
from __future__ import annotations

from firmware_reporting.ingest import SOURCES, get_source
from firmware_reporting.settings import get_settings


def test_settings_loads():
    s = get_settings()
    assert "postgresql" in s.postgres_url
    assert s.schedule_cron.count(" ") == 4   # 5-field cron


def test_pg_components_parsed():
    s = get_settings()
    pg = s.pg
    assert "PGHOST" in pg
    assert "PGDATABASE" in pg
    assert pg["PGDATABASE"] == "reporting"


def test_sources_registered():
    names = [s.name for s in SOURCES]
    assert "server_inventory" in names
    assert "ssl_cert_venafi" in names


def test_get_source_unknown():
    import pytest
    with pytest.raises(KeyError):
        get_source("does_not_exist")


def test_source_specs_have_pattern():
    for s in SOURCES:
        assert "*" in s.pattern, f"{s.name} pattern looks wrong"
