"""Centralised configuration. All paths and toggles live here."""
from __future__ import annotations

from functools import lru_cache
from pathlib import Path
from urllib.parse import urlparse

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


def _find_project_root() -> Path:
    cwd = Path.cwd().resolve()
    for parent in [cwd, *cwd.parents]:
        if (parent / "pyproject.toml").exists():
            return parent
    return cwd


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        env_prefix="FWR_",
        extra="ignore",
    )

    project_root: Path = Field(default_factory=_find_project_root)

    data_raw_dir: Path = Path("data/raw")
    data_archive_dir: Path = Path("data/archive")
    dbt_project_dir: Path = Path("dbt_project")
    logs_dir: Path = Path("logs")

    # PostgreSQL — single store; default targets docker-compose Postgres
    postgres_url: str = "postgresql://grafana:grafana_secret@localhost:5432/reporting"

    # Scheduler
    schedule_cron: str = "0 6 * * *"
    scheduler_timezone: str = "Europe/London"

    # Ingestion
    archive_after_load: bool = True
    fail_fast: bool = False

    # Grafana
    grafana_port: int = 3000

    # Logging
    log_level: str = "INFO"
    log_json: bool = False

    def resolve(self, p: Path) -> Path:
        return p if p.is_absolute() else (self.project_root / p).resolve()

    @property
    def raw_dir(self) -> Path:
        return self.resolve(self.data_raw_dir)

    @property
    def archive_dir(self) -> Path:
        return self.resolve(self.data_archive_dir)

    @property
    def dbt_dir(self) -> Path:
        return self.resolve(self.dbt_project_dir)

    @property
    def log_dir(self) -> Path:
        return self.resolve(self.logs_dir)

    @property
    def pg(self) -> dict[str, str]:
        """PG connection components as env vars for dbt subprocess."""
        p = urlparse(self.postgres_url)
        return {
            "PGHOST":     p.hostname or "localhost",
            "PGPORT":     str(p.port or 5432),
            "PGDATABASE": (p.path or "/reporting").lstrip("/"),
            "PGUSER":     p.username or "grafana",
            "PGPASSWORD": p.password or "",
        }


@lru_cache
def get_settings() -> Settings:
    return Settings()
