"""
`fwr` CLI — operator entrypoint for everything.

Usage:
    fwr ingest                         # bronze ingestion only
    fwr transform                      # dbt silver + gold only
    fwr etl                            # full pipeline
    fwr etl --source server_inventory  # subset
    fwr etl --full-refresh
    fwr scheduler                      # run cron scheduler in foreground
    fwr grafana up|down|logs|open      # manage the Grafana+Postgres stack
    fwr db                             # open psql on the reporting database
    fwr sources                        # list configured sources
    fwr status                         # last N ETL run summaries
    fwr deps                           # install dbt packages
"""
from __future__ import annotations

import json
import os
import subprocess
from pathlib import Path

import typer
from rich.console import Console
from rich.table import Table

from firmware_reporting.ingest import SOURCES, run_ingest
from firmware_reporting.orchestrator import run_etl
from firmware_reporting.settings import get_settings
from firmware_reporting.transform import dbt_deps, run_transform
from firmware_reporting.utils.logging import configure_logging

app = typer.Typer(
    name="fwr",
    help="Firmware Upgrade Programme reporting platform.",
    no_args_is_help=True,
    add_completion=False,
)
console = Console()


@app.callback()
def _bootstrap() -> None:
    configure_logging()


@app.command()
def ingest(
    source: list[str] = typer.Option(None, "--source", "-s"),
) -> None:
    """Run bronze ingestion only (CSV -> Postgres bronze schema)."""
    summary = run_ingest(source_names=source or None)
    console.print_json(json.dumps(summary, default=str))
    raise typer.Exit(0 if summary.get("status") in ("success", "no_op") else 1)


@app.command()
def transform(
    select: str | None = typer.Option(None, "--select"),
    full_refresh: bool = typer.Option(False, "--full-refresh"),
    no_tests: bool = typer.Option(False, "--no-tests"),
) -> None:
    """Run dbt silver + gold transformations only."""
    summary = run_transform(select=select, full_refresh=full_refresh, run_tests=not no_tests)
    console.print_json(json.dumps(summary, default=str))
    raise typer.Exit(0 if summary.get("status") == "success" else 1)


@app.command()
def etl(
    source: list[str] = typer.Option(None, "--source", "-s"),
    skip_transform: bool = typer.Option(False, "--skip-transform"),
    full_refresh: bool = typer.Option(False, "--full-refresh"),
    no_tests: bool = typer.Option(False, "--no-tests"),
    select: str | None = typer.Option(None, "--select"),
) -> None:
    """Run full ETL on demand: CSV -> bronze -> silver -> gold (all in Postgres)."""
    summary = run_etl(
        sources=source or None,
        skip_transform=skip_transform,
        full_refresh=full_refresh,
        run_tests=not no_tests,
        dbt_select=select,
    )
    console.print_json(json.dumps(summary, default=str))
    raise typer.Exit(0 if summary.get("status") == "success" else 1)


@app.command()
def scheduler() -> None:
    """Run the cron scheduler in the foreground."""
    from firmware_reporting.scheduler import start_blocking
    start_blocking()


@app.command()
def grafana(
    action: str = typer.Argument("up", help="up | down | logs | open"),
) -> None:
    """Manage the Grafana + Postgres stack via docker compose."""
    settings = get_settings()
    root = str(settings.project_root)
    if action == "open":
        import webbrowser
        url = f"http://localhost:{settings.grafana_port}"
        console.print(f"Opening {url}")
        webbrowser.open(url)
        return
    cmds = {
        "up":   ["docker", "compose", "up", "-d", "--build"],
        "down": ["docker", "compose", "down"],
        "logs": ["docker", "compose", "logs", "-f", "grafana"],
    }
    if action not in cmds:
        console.print(f"[red]Unknown action {action!r}. Use: up | down | logs | open[/red]")
        raise typer.Exit(1)
    subprocess.run(cmds[action], cwd=root, check=True)


@app.command()
def db() -> None:
    """Open a psql session on the reporting database."""
    settings = get_settings()
    pg = settings.pg
    env = {**os.environ, **pg}
    os.execvpe(
        "psql",
        ["psql", "-h", pg["PGHOST"], "-p", pg["PGPORT"],
         "-U", pg["PGUSER"], "-d", pg["PGDATABASE"]],
        env,
    )


@app.command()
def deps() -> None:
    """Install dbt packages declared in packages.yml."""
    raise typer.Exit(dbt_deps())


@app.command()
def sources() -> None:
    """List configured CSV sources."""
    table = Table(title="Configured Sources")
    table.add_column("Name")
    table.add_column("Bronze table (PG)")
    table.add_column("File pattern")
    table.add_column("PK")
    table.add_column("Disposition")
    for s in SOURCES:
        table.add_row(
            s.name,
            f"bronze.{s.table_name}",
            s.pattern,
            ",".join(s.primary_key) or "-",
            s.write_disposition,
        )
    console.print(table)


@app.command()
def status(limit: int = 5) -> None:
    """Show recent ETL run summaries from logs/."""
    settings = get_settings()
    runs = sorted(settings.log_dir.glob("etl_run_*.json"), reverse=True)[:limit]
    if not runs:
        console.print("[yellow]No runs recorded yet.[/yellow]")
        return
    table = Table(title=f"Last {len(runs)} ETL runs")
    table.add_column("Run ID")
    table.add_column("Status")
    table.add_column("Started")
    table.add_column("Finished")
    for r in runs:
        data = json.loads(r.read_text())
        table.add_row(
            data.get("run_id", "?"),
            data.get("status", "?"),
            data.get("started_at", "?"),
            data.get("finished_at", "?"),
        )
    console.print(table)


if __name__ == "__main__":
    app()
