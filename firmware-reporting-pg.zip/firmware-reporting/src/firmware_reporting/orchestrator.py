"""
ETL job orchestrator.

Three stages: ingest (CSV -> bronze PG) -> transform (dbt: silver + gold PG)
That's it — no DuckDB, no sync step.
"""
from __future__ import annotations

import json
from datetime import datetime, timezone
from typing import Any

from firmware_reporting.ingest import run_ingest
from firmware_reporting.settings import get_settings
from firmware_reporting.transform import run_transform
from firmware_reporting.utils.logging import get_logger

log = get_logger(__name__)


def run_etl(
    sources: list[str] | None = None,
    skip_transform: bool = False,
    full_refresh: bool = False,
    run_tests: bool = True,
    dbt_select: str | None = None,
) -> dict[str, Any]:
    """
    Run the full ETL pipeline:
        CSV files -> dlt -> bronze (PG) -> dbt -> silver (PG) -> gold (PG)

    Grafana reads directly from gold.* — no sync step needed.
    """
    settings = get_settings()
    run_id = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    log.info("etl_start", run_id=run_id, sources=sources)

    summary: dict[str, Any] = {
        "run_id": run_id,
        "started_at": datetime.now(timezone.utc).isoformat(),
        "stages": {},
    }

    # Stage 1: Bronze ingestion
    ingest_summary = run_ingest(source_names=sources)
    summary["stages"]["ingest"] = ingest_summary
    if ingest_summary.get("status") == "failed":
        summary["status"] = "ingest_failed"
        _persist(summary)
        return summary

    # Stage 2: Silver + Gold via dbt
    if not skip_transform:
        transform_summary = run_transform(
            select=dbt_select,
            full_refresh=full_refresh,
            run_tests=run_tests,
        )
        summary["stages"]["transform"] = transform_summary
        summary["status"] = transform_summary.get("status", "unknown")
    else:
        summary["status"] = ingest_summary.get("status", "unknown")

    summary["finished_at"] = datetime.now(timezone.utc).isoformat()
    _persist(summary)
    log.info("etl_finished", run_id=run_id, status=summary["status"])
    return summary


def _persist(summary: dict[str, Any]) -> None:
    settings = get_settings()
    out = settings.log_dir / f"etl_run_{summary['run_id']}.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(summary, indent=2, default=str))
