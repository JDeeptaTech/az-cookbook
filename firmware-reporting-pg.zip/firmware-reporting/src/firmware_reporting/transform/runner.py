"""
Run dbt as a subprocess against PostgreSQL.

PG connection details are injected as PGHOST/PGPORT/... env vars so the
profiles.yml stays secret-free and works in any environment.
"""
from __future__ import annotations

import os
import subprocess
from datetime import datetime, timezone
from typing import Any

from firmware_reporting.settings import get_settings
from firmware_reporting.utils.logging import get_logger

log = get_logger(__name__)


def _run(cmd: list[str], cwd: str, extra_env: dict[str, str] | None = None) -> subprocess.CompletedProcess:
    log.info("dbt_exec", cmd=" ".join(cmd))
    env = {**os.environ, **(extra_env or {})}
    proc = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True, env=env)
    if proc.returncode != 0:
        log.error("dbt_failed", stdout=proc.stdout[-3000:], stderr=proc.stderr[-1000:])
    else:
        log.info("dbt_ok", stdout_tail=proc.stdout[-500:])
    return proc


def run_transform(
    select: str | None = None,
    full_refresh: bool = False,
    run_tests: bool = True,
) -> dict[str, Any]:
    settings = get_settings()
    cwd = str(settings.dbt_dir)
    pg_env = settings.pg          # PGHOST, PGPORT, PGDATABASE, PGUSER, PGPASSWORD

    summary: dict[str, Any] = {
        "started_at": datetime.now(timezone.utc).isoformat(),
        "select": select,
        "full_refresh": full_refresh,
    }

    run_cmd = ["dbt", "run", "--profiles-dir", cwd]
    if select:
        run_cmd += ["--select", select]
    if full_refresh:
        run_cmd.append("--full-refresh")

    proc = _run(run_cmd, cwd, pg_env)
    summary["run_returncode"] = proc.returncode
    summary["run_stdout_tail"] = proc.stdout[-2000:]

    if proc.returncode != 0:
        summary["status"] = "run_failed"
        return summary

    if run_tests:
        test_cmd = ["dbt", "test", "--profiles-dir", cwd]
        if select:
            test_cmd += ["--select", select]
        tproc = _run(test_cmd, cwd, pg_env)
        summary["test_returncode"] = tproc.returncode
        summary["test_stdout_tail"] = tproc.stdout[-2000:]
        summary["status"] = "success" if tproc.returncode == 0 else "tests_failed"
    else:
        summary["status"] = "success"

    summary["finished_at"] = datetime.now(timezone.utc).isoformat()
    return summary


def dbt_deps() -> int:
    settings = get_settings()
    proc = _run(
        ["dbt", "deps", "--profiles-dir", str(settings.dbt_dir)],
        str(settings.dbt_dir),
        settings.pg,
    )
    return proc.returncode
