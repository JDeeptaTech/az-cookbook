#!/usr/bin/env bash
# OWNER: Vault team        RUN: from 02-onboard-cluster.sh, and again whenever an account is added
#                               or its maximum lifetime changes. Safe to re-run (every write overwrites).
# For each breakglass account, on one cluster's PKI mount:
#   role        breakglass-<account>      signs ONLY "eos-breakglass:<account>:*", for at most <ttl>
#   policy      eos-breakglass-sign-<cluster>-<account>   may use that one role
#   auth role   eos-breakglass-<cluster>-<account>        only cert-manager's signer token, minted for
#                                                         the hub Issuer eos-breakglass-<cluster>-<account>
# Because each role is pinned to its account's name prefix, an admin certificate can only come out
# of the admin role, with the admin cap, whoever asks and through whichever hub Issuer.
#
# Usage: CLUSTER=ocp-prod-01 ACCOUNTS="eos-cluster-admin=1h eos-cluster-reader=4h" ./04-account-roles.sh
set -euo pipefail
: "${CLUSTER:?set CLUSTER to the ACM managed cluster name}"
: "${ACCOUNTS:?set ACCOUNTS, e.g. ACCOUNTS=\"eos-cluster-admin=1h eos-cluster-reader=4h\"}"
VAULT_K8S_AUTH_MOUNT=${VAULT_K8S_AUTH_MOUNT:-kubernetes-acm-hub}
MOUNT="pki-eos-breakglass-$CLUSTER"
# Absolute ceiling for any account. Raising it is a security decision, not a config change.
CEILING_HOURS=4

for entry in $ACCOUNTS; do
  if [[ ! $entry =~ ^([a-z0-9]([a-z0-9-]*[a-z0-9])?)=([0-9]+)h$ ]]; then
    echo "bad ACCOUNTS entry '$entry' (want <account>=<hours>h)" >&2; exit 1
  fi
  ACCOUNT=${BASH_REMATCH[1]}; HOURS=${BASH_REMATCH[3]}
  if (( HOURS < 1 || HOURS > CEILING_HOURS )); then
    echo "$ACCOUNT: ${HOURS}h is outside 1..${CEILING_HOURS}h" >&2; exit 1
  fi
  ROLE="breakglass-$ACCOUNT"
  NAME="eos-breakglass-$CLUSTER-$ACCOUNT"

  vault write "$MOUNT/roles/$ROLE" \
    max_ttl="${HOURS}h" ttl="${HOURS}h" not_before_duration=30s \
    allowed_domains="eos-breakglass:$ACCOUNT:*" allow_glob_domains=true \
    allow_any_name=false allow_bare_domains=false allow_subdomains=false \
    allow_localhost=false allow_wildcard_certificates=false allow_ip_sans=false \
    allowed_uri_sans="" allowed_other_sans="" \
    enforce_hostnames=false cn_validations=disabled require_cn=true \
    use_csr_common_name=true use_csr_sans=false \
    organization="eos-breakglass" \
    key_type=ec key_bits=256 \
    key_usage=DigitalSignature ext_key_usage="" \
    client_flag=true server_flag=false code_signing_flag=false email_protection_flag=false \
    no_store=false >/dev/null

  vault policy write "eos-breakglass-sign-$CLUSTER-$ACCOUNT" - >/dev/null <<POLICY
path "$MOUNT/sign/$ROLE" {
  capabilities = ["create", "update"]
}
POLICY

  # cert-manager sets the token audience to vault://<namespace>/<issuer name>
  vault write "auth/$VAULT_K8S_AUTH_MOUNT/role/$NAME" \
    bound_service_account_names=eos-breakglass-vault-signer \
    bound_service_account_namespaces=eos-breakglass \
    audience="vault://eos-breakglass/$NAME" \
    token_policies="eos-breakglass-sign-$CLUSTER-$ACCOUNT" \
    token_ttl=1m token_max_ttl=5m >/dev/null

  echo "$CLUSTER/$ACCOUNT: role $MOUNT/roles/$ROLE (max ${HOURS}h), auth role $NAME"
done
