# OWNER: Vault team        APPLY: once
# Read access to the hub tokens from hub/07. Attach to the AAP AppRole (or identity) that runs
# each playbook, not to individual users: whoever can read the issuer token can request
# breakglass certificates.
#   vault policy write eos-breakglass-issuer   <(sed -n '/^# --- issuer/,/^# --- admin/p' 03-automation-policies.hcl)
#   vault policy write eos-breakglass-bootstrap <(sed -n '/^# --- admin/,$p' 03-automation-policies.hcl)

# --- issuer: generate_kubeconfig.yml
path "secret/data/eos/acm-hub/sa/eos-breakglass-issuer" {
  capabilities = ["read"]
}

# --- admin: bootstrap_cluster.yml (reads the hub token; the CA certificate is public)
path "secret/data/eos/acm-hub/sa/eos-breakglass-admin" {
  capabilities = ["read"]
}

# bootstrap also reads each per-account signing role (config only: TTL and allowed names, no keys)
# to check it matches the account catalogue before trusting the cluster's CA.
path "+/roles/breakglass-*" {
  capabilities = ["read"]
}
