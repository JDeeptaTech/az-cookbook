#!/usr/bin/env bash
# OWNER: Vault team        RUN: once per managed cluster, before the hub admin applies hub/04
# One PKI mount per managed cluster, so a certificate for one cluster is useless on another.
# The CA key is generated inside Vault and never leaves it. The per-account signing roles
# (the security control: lifetime cap and allowed names) are created by 04-account-roles.sh,
# which this script runs at the end and which can be re-run on its own later.
#
# Usage: CLUSTER=ocp-prod-01 ACCOUNTS="eos-cluster-admin=1h eos-cluster-reader=4h" ./02-onboard-cluster.sh
#        ACCOUNTS must match breakglass_accounts / max_duration_hours in playbooks/group_vars/all/main.yml
set -euo pipefail
: "${CLUSTER:?set CLUSTER to the ACM managed cluster name}"
: "${ACCOUNTS:?set ACCOUNTS, e.g. ACCOUNTS=\"eos-cluster-admin=1h eos-cluster-reader=4h\"}"
MOUNT="pki-eos-breakglass-$CLUSTER"

# PKI mount and the cluster's breakglass CA (EC P-384, 5 years, key generated in Vault).
# Not idempotent on purpose: re-running would add a second CA. Use 04-account-roles.sh to change roles.
vault secrets enable -path="$MOUNT" -max-lease-ttl=43800h pki
vault write "$MOUNT/root/generate/internal" \
  common_name="EOS breakglass CA $CLUSTER" \
  organization="EOS breakglass" \
  key_type=ec key_bits=384 \
  ttl=43800h \
  issuer_name=breakglass-ca >/dev/null

"$(dirname "$0")/04-account-roles.sh"
echo "Onboarded $CLUSTER: PKI mount $MOUNT"
