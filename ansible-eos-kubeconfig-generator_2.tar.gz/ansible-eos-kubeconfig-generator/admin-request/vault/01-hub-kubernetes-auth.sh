#!/usr/bin/env bash
# OWNER: Vault team        RUN: once
# Kubernetes auth mount for the ACM hub, so cert-manager on the hub can log in to Vault.
# Skip if a Kubernetes auth mount for this hub already exists; then set VAULT_K8S_AUTH_MOUNT
# to its path when running 02.
#
# Inputs: HUB_API_URL, HUB_CA_FILE (CA of the hub API), REVIEWER_JWT_FILE (token from
#         hub/06: oc -n eos-automation get secret vault-token-reviewer-token -o jsonpath='{.data.token}' | base64 -d)
set -euo pipefail
: "${HUB_API_URL:?}" "${HUB_CA_FILE:?}" "${REVIEWER_JWT_FILE:?}"
VAULT_K8S_AUTH_MOUNT=${VAULT_K8S_AUTH_MOUNT:-kubernetes-acm-hub}

vault auth enable -path="$VAULT_K8S_AUTH_MOUNT" kubernetes
vault write "auth/$VAULT_K8S_AUTH_MOUNT/config" \
  kubernetes_host="$HUB_API_URL" \
  kubernetes_ca_cert=@"$HUB_CA_FILE" \
  token_reviewer_jwt=@"$REVIEWER_JWT_FILE" \
  disable_local_ca_jwt=true
