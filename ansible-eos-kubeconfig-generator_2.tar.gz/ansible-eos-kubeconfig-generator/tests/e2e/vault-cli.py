#!/usr/bin/env python3
"""Minimal `vault` CLI for the test rig: just enough to run admin-request/vault/*.sh unchanged
against the stand-in Vault. Supports: auth enable, secrets enable, write, policy write, kv put."""
import json, os, sys, urllib.request

ADDR = os.environ.get("VAULT_ADDR", "http://127.0.0.1:18200").rstrip("/")
TOKEN = os.environ.get("VAULT_TOKEN", "")


def call(method, path, body=None):
    req = urllib.request.Request(f"{ADDR}/v1/{path}", method=method, data=json.dumps(body or {}).encode(),
                                 headers={"X-Vault-Token": TOKEN, "Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req) as r:
            out = r.read()
            return json.loads(out) if out else {}
    except urllib.error.HTTPError as e:
        sys.exit(f"Error writing data to {path}: Code: {e.code}. Errors: {e.read().decode()[:300]}")


def value(v):
    if v.startswith("@"): return open(v[1:]).read()
    if v == "-": return sys.stdin.read()
    return v


def flags(args):
    f, rest = {}, []
    for a in args:
        if a.startswith("-") and "=" in a: k, v = a.lstrip("-").split("=", 1); f[k] = v
        else: rest.append(a)
    return f, rest


a = sys.argv[1:]
if a[:2] == ["auth", "enable"]:
    f, rest = flags(a[2:]); call("POST", f"sys/auth/{f.get('path', rest[0])}", {"type": rest[0]})
elif a[:2] == ["secrets", "enable"]:
    f, rest = flags(a[2:]); call("POST", f"sys/mounts/{f.get('path', rest[0])}", {"type": rest[0], "config": {"max_lease_ttl": f.get("max-lease-ttl", "768h")}})
elif a[:2] == ["policy", "write"]:
    call("PUT", f"sys/policies/acl/{a[2]}", {"policy": value(a[3])})
elif a[:2] == ["kv", "put"]:
    path = a[2].split("/", 1); data = dict(x.split("=", 1) for x in a[3:])
    call("POST", f"{path[0]}/data/{path[1]}", {"data": {k: value(v) for k, v in data.items()}})
elif a[0] == "write":
    body = {}
    for kv in a[2:]:
        k, v = kv.split("=", 1); body[k] = value(v)
    out = call("POST", a[1], body)
    if out: print(json.dumps(out.get("data", {}))[:200])
else:
    sys.exit(f"vault-cli shim: unsupported command {' '.join(a)}")
