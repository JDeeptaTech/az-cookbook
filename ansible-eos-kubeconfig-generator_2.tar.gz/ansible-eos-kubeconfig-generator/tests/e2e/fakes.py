"""
Stand-ins for components that need container images or binaries (test only):

  cert-manager   built-in approver ON (approves everything, as in the Red Hat operator).
                 Namespaced Vault Issuers: requests a token for spec.vault.auth.kubernetes
                 .serviceAccountRef with audience vault://<ns>/<issuer> (real TokenRequest,
                 real RBAC), logs in to Vault, calls <path> with the CSR and ttl.
  Vault          KV v2, sys/mounts, sys/auth, ACL policies, Kubernetes auth (real TokenReview
                 against the hub with the reviewer JWT), PKI root/generate/internal, roles,
                 sign/<role> and ca/pem. The PKI role checks follow the Vault API docs
                 (allowed_domains + glob, cn_validations, key_type/key_bits, use_csr_sans,
                 organization from the role, ttl capped at max_ttl, not_before_duration,
                 client/server flags). It is an emulation, not Vault.
  work agent     applies ManifestWorks to lab-1 / lab-2 with server-side apply.
  OpenShift op.  turns APIServer spec.clientCA into the kube-apiserver --client-ca-file.
"""
import base64, datetime as dt, fnmatch, json, os, re, secrets, threading, time, traceback
import http.server
import requests, yaml
from cryptography import x509
from cryptography.x509.oid import NameOID, ExtendedKeyUsageOID
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec

T = os.environ.get("BGT_DIR", "/var/tmp/bgt")
API = {"hub": ("https://127.0.0.1:6443", "hub-admin-token"), "lab-1": ("https://127.0.0.1:6444", "cluster-admin-token"),
       "lab-2": ("https://127.0.0.1:6445", "cluster-admin-token")}
CM_TOKEN = "cm-sa-token"          # cert-manager's controller identity on the hub
VAULT_ROOT = "root-vault-token"


def kreq(cluster, method, path, body=None, token=None, ctype="application/json", params=None):
    url, tok = API[cluster]
    h = {"Authorization": f"Bearer {token or tok}", "Content-Type": ctype}
    data = body if isinstance(body, (str, bytes)) or body is None else json.dumps(body)
    return requests.request(method, url + path, headers=h, data=data, params=params,
                            verify=f"{T}/{cluster}/certs/apiserver.crt", timeout=10)


def get(cluster, path):
    r = kreq(cluster, "GET", path)
    return r.json() if r.status_code == 200 else None


def b64(b): return base64.b64encode(b).decode()
def now(): return dt.datetime.now(dt.timezone.utc)
def ts(): return now().strftime("%Y-%m-%dT%H:%M:%SZ")


def godur(s):
    """Go/Vault durations: 4h, 2h0m0s, 30s, 43800h, 90m."""
    if not s: return dt.timedelta(0)
    if re.fullmatch(r"\d+", str(s)): return dt.timedelta(seconds=int(s))
    total = dt.timedelta(0)
    for n, u in re.findall(r"(\d+(?:\.\d+)?)(h|m|s)", s):
        total += {"h": dt.timedelta(hours=float(n)), "m": dt.timedelta(minutes=float(n)), "s": dt.timedelta(seconds=float(n))}[u]
    return total


def cond(obj, typ):
    return next((c for c in (obj.get("status") or {}).get("conditions") or [] if c["type"] == typ), None)


def set_status(cluster, path, status):
    r = kreq(cluster, "PATCH", path + "/status", {"status": status}, ctype="application/merge-patch+json")
    if r.status_code >= 300: print("status patch failed", path, r.status_code, r.text[:200], flush=True)


# ====================================================================== cert-manager
def issuers():
    for iss in (get("hub", "/apis/cert-manager.io/v1/issuers") or {}).get("items", []):
        ok = "vault" in iss["spec"] and iss["spec"]["vault"].get("server") and iss["spec"]["vault"].get("path")
        c = cond(iss, "Ready")
        want = "True" if ok else "False"
        if not c or c["status"] != want:
            ns, name = iss["metadata"]["namespace"], iss["metadata"]["name"]
            set_status("hub", f"/apis/cert-manager.io/v1/namespaces/{ns}/issuers/{name}",
                       {"conditions": [{"type": "Ready", "status": want, "reason": "VaultVerified" if ok else "VaultError",
                                        "message": "Vault verified" if ok else "invalid vault config", "lastTransitionTime": ts()}]})


def vault_sign(ns, cr, iss):
    v = iss["spec"]["vault"]
    k = v["auth"]["kubernetes"]
    sa = k["serviceAccountRef"]["name"]
    aud = f"vault://{ns}/{iss['metadata']['name']}"
    tr = {"apiVersion": "authentication.k8s.io/v1", "kind": "TokenRequest", "spec": {"audiences": [aud], "expirationSeconds": 600}}
    r = kreq("hub", "POST", f"/api/v1/namespaces/{ns}/serviceaccounts/{sa}/token", tr, token=CM_TOKEN)
    if r.status_code >= 300:
        raise RuntimeError(f"error requesting token for serviceaccount {sa}: {r.json().get('message', r.text)[:200]}")
    jwt = r.json()["status"]["token"]
    login = requests.post(v["server"] + k["mountPath"] + "/login", json={"role": k["role"], "jwt": jwt}, timeout=10)
    if login.status_code >= 300:
        raise RuntimeError(f"error logging in to Vault: {login.text[:200]}")
    vtoken = login.json()["auth"]["client_token"]
    resp = requests.post(f"{v['server']}/v1/{v['path']}", headers={"X-Vault-Token": vtoken}, timeout=10,
                         json={"csr": base64.b64decode(cr["spec"]["request"]).decode(), "ttl": str(godur(cr["spec"].get("duration", "")).total_seconds()).split(".")[0] + "s",
                               "exclude_cn_from_sans": True})
    if resp.status_code >= 300:
        raise RuntimeError(f"failed to sign certificate by vault: {resp.text[:300]}")
    d = resp.json()["data"]
    return d["certificate"].encode(), d["issuing_ca"].encode()


def certificaterequests():
    for cr in (get("hub", "/apis/cert-manager.io/v1/certificaterequests") or {}).get("items", []):
        ns, name = cr["metadata"]["namespace"], cr["metadata"]["name"]
        path = f"/apis/cert-manager.io/v1/namespaces/{ns}/certificaterequests/{name}"
        ready = cond(cr, "Ready")
        if ready and (ready["status"] == "True" or ready.get("reason") in ("Failed", "Denied")): continue
        conds = (cr.get("status") or {}).get("conditions") or []
        if not cond(cr, "Approved"):       # cert-manager's built-in approver: approves everything
            conds = conds + [{"type": "Approved", "status": "True", "reason": "cert-manager.io",
                              "message": "Certificate request has been approved by cert-manager.io", "lastTransitionTime": ts()}]
            set_status("hub", path, {"conditions": conds}); continue
        ref = cr["spec"]["issuerRef"]
        iss = get("hub", f"/apis/cert-manager.io/v1/namespaces/{ns}/issuers/{ref['name']}") if ref.get("kind", "Issuer") == "Issuer" else None
        if not iss:
            if not ready:
                set_status("hub", path, {"conditions": conds + [{"type": "Ready", "status": "False", "reason": "Pending",
                           "message": f"Referenced \"Issuer\" not found: issuer.cert-manager.io \"{ref['name']}\" not found", "lastTransitionTime": ts()}]})
                print(f"[cert-manager] {ns}/{name}: issuer {ref['name']} not found in {ns}", flush=True)
            continue
        try:
            crt, ca = vault_sign(ns, cr, iss)
            conds = [c for c in conds if c["type"] != "Ready"] + [{"type": "Ready", "status": "True", "reason": "Issued",
                     "message": "Certificate fetched from issuer successfully", "lastTransitionTime": ts()}]
            set_status("hub", path, {"certificate": b64(crt), "ca": b64(ca), "conditions": conds})
            print(f"[cert-manager] {ns}/{name}: issued via {iss['spec']['vault']['path']}", flush=True)
        except Exception as e:
            conds = [c for c in conds if c["type"] != "Ready"] + [{"type": "Ready", "status": "False", "reason": "Failed",
                     "message": str(e)[:500], "lastTransitionTime": ts()}]
            set_status("hub", path, {"conditions": conds, "failureTime": ts()})
            print(f"[cert-manager] {ns}/{name}: FAILED {str(e)[:200]}", flush=True)


# ====================================================================== ACM work agent + OpenShift operator
RES = {("", "ConfigMap"): ("/api/v1", "configmaps", True), ("config.openshift.io", "APIServer"): ("/apis/config.openshift.io/v1", "apiservers", False),
       ("rbac.authorization.k8s.io", "ClusterRoleBinding"): ("/apis/rbac.authorization.k8s.io/v1", "clusterrolebindings", False)}
APPLIED = {}


def rpath(m):
    g = m["apiVersion"].split("/")[0] if "/" in m["apiVersion"] else ""
    base, plural, nsd = RES[(g, m["kind"])]
    ns = m["metadata"].get("namespace")
    return g, plural, (f"{base}/namespaces/{ns}/{plural}" if nsd else f"{base}/{plural}") + f"/{m['metadata']['name']}"


def works():
    for cluster in ("lab-1", "lab-2"):
        for w in (get("hub", f"/apis/work.open-cluster-management.io/v1/namespaces/{cluster}/manifestworks") or {}).get("items", []):
            gen, name = w["metadata"]["generation"], w["metadata"]["name"]
            ap = cond(w, "Applied")
            if ap and ap.get("observedGeneration") == gen: continue
            cfgs = w["spec"].get("manifestConfigs") or []
            orphans = ((w["spec"].get("deleteOption") or {}).get("selectivelyOrphans") or {}).get("orphaningRules") or []
            results, all_ok, now_applied = [], True, {}
            for i, m in enumerate(w["spec"]["workload"]["manifests"]):
                g, plural, path = rpath(m)
                cfg = next((c for c in cfgs if c["resourceIdentifier"].get("resource") == plural and c["resourceIdentifier"].get("name") == m["metadata"]["name"]), None)
                ssa = (cfg or {}).get("updateStrategy", {}).get("serverSideApply", {})
                r = kreq(cluster, "PATCH", path, yaml.safe_dump(m), ctype="application/apply-patch+yaml",
                         params={"fieldManager": ssa.get("fieldManager", "work-agent"), "force": "true" if ssa.get("force", True) else "false"})
                ok = r.status_code < 300
                all_ok &= ok
                now_applied[path] = {"group": g, "resource": plural, "name": m["metadata"]["name"], "namespace": m["metadata"].get("namespace", "")}
                results.append({"resourceMeta": {"ordinal": i, "group": g, "version": "v1", "kind": m["kind"], "resource": plural,
                                                 "name": m["metadata"]["name"], "namespace": m["metadata"].get("namespace", "")},
                                "conditions": [{"type": "Applied", "status": "True" if ok else "False",
                                                "reason": "AppliedManifestComplete" if ok else "AppliedManifestFailed",
                                                "message": "Apply manifest complete" if ok else r.json().get("message", r.text)[:300], "lastTransitionTime": ts()}]})
            for path, meta in APPLIED.get((cluster, name), {}).items():
                if path in now_applied: continue
                if any(o.get("resource") == meta["resource"] and o.get("name") == meta["name"] and o.get("namespace", "") == meta["namespace"] for o in orphans): continue
                kreq(cluster, "DELETE", path)
                print(f"[work-agent] {cluster}: deleted {meta['resource']}/{meta['name']}", flush=True)
            APPLIED[(cluster, name)] = now_applied
            st = "True" if all_ok else "False"
            set_status("hub", f"/apis/work.open-cluster-management.io/v1/namespaces/{cluster}/manifestworks/{name}", {
                "conditions": [{"type": t, "status": st, "reason": t + ("" if all_ok else "Failed"), "message": "All resources applied" if all_ok else "Failed to apply manifest",
                                "observedGeneration": gen, "lastTransitionTime": ts()} for t in ("Applied", "Available")],
                "resourceStatus": {"manifests": results}})
            print(f"[work-agent] {cluster}/{name} gen {gen}: Applied={st}", flush=True)


def openshift_operator():
    for cluster in ("lab-1", "lab-2"):
        api = get(cluster, "/apis/config.openshift.io/v1/apiservers/cluster") or {}
        name = ((api.get("spec") or {}).get("clientCA") or {}).get("name")
        bundle = open(f"{T}/placeholder-ca.crt").read()
        if name:
            cm = get(cluster, f"/api/v1/namespaces/openshift-config/configmaps/{name}")
            if cm and (cm.get("data") or {}).get("ca-bundle.crt"): bundle = cm["data"]["ca-bundle.crt"]
        f = f"{T}/{cluster}/client-ca.crt"
        if open(f).read() != bundle:
            with open(f, "r+") as fh:
                fh.seek(0); fh.write(bundle); fh.truncate()
            print(f"[openshift-operator] {cluster}: client CA bundle now has {bundle.count('BEGIN CERTIFICATE')} CA(s)", flush=True)


# ====================================================================== Vault
V = {"kv": {"eos/acm-hub/sa/eos-breakglass-issuer": {"token": "issuer-sa-token"},
            "eos/acm-hub/sa/eos-breakglass-admin": {"token": "admin-sa-token"}},
     "mounts": {}, "auth": {}, "policies": {}, "tokens": {VAULT_ROOT: {"policies": ["root"], "expires": None}}}
LOCK = threading.Lock()


def tobool(v): return str(v).lower() in ("true", "1", "yes")
def tolist(v): return [x.strip() for x in v.split(",") if x.strip()] if isinstance(v, str) else list(v or [])


def acl_allows(token, path, cap):
    t = V["tokens"].get(token)
    if not t or (t["expires"] and t["expires"] < time.time()): return False
    if "root" in t["policies"]: return True
    for p in t["policies"]:
        for pat, caps in V["policies"].get(p, []):
            rx = "^" + re.escape(pat).replace(r"\+", "[^/]+").replace(r"\*", ".*") + "$"
            if re.match(rx, path):
                if cap in caps: return True
    return False


def parse_policy(hcl):
    return [(m.group(1), re.findall(r'"([a-z]+)"', m.group(2))) for m in re.finditer(r'path\s+"([^"]+)"\s*\{\s*capabilities\s*=\s*\[([^\]]*)\]', hcl)]


HOSTNAME = re.compile(r"^(\*\.)?[A-Za-z0-9]([A-Za-z0-9-]{0,61}[A-Za-z0-9])?(\.[A-Za-z0-9]([A-Za-z0-9-]{0,61}[A-Za-z0-9])?)*$")


def pki_sign(mount, role_name, body):
    m = V["mounts"][mount]
    role = m["roles"].get(role_name)
    if not role: return 400, {"errors": [f"unknown role: {role_name}"]}
    try:
        csr = x509.load_pem_x509_csr(body["csr"].encode())
    except Exception:
        return 400, {"errors": ["certificate request could not be parsed"]}
    # key type
    pub = csr.public_key()
    kt, kb = role.get("key_type", "rsa"), int(role.get("key_bits", 0) or 0)
    if kt != "any":
        got = "ec" if isinstance(pub, ec.EllipticCurvePublicKey) else "rsa"
        if got != kt: return 400, {"errors": [f"role requires keys of type {kt}"]}
        if kt == "ec" and kb and pub.curve.key_size != kb: return 400, {"errors": [f"role requires ec keys of {kb} bits; got {pub.curve.key_size}"]}
    # common name
    cns = [a.value for a in csr.subject.get_attributes_for_oid(NameOID.COMMON_NAME)]
    cn = cns[0] if cns and tobool(role.get("use_csr_common_name", "true")) else body.get("common_name", "")
    if not cn and tobool(role.get("require_cn", "true")): return 400, {"errors": ["the common_name field is required"]}
    cnv = tolist(role.get("cn_validations", "email,hostname"))
    if cnv != ["disabled"]:
        ok = ("email" in cnv and "@" in cn) or ("hostname" in cnv and HOSTNAME.match(cn))
        if not ok: return 400, {"errors": [f"common name {cn} not allowed by this role: failed cn_validations {cnv}"]}
    if not tobool(role.get("allow_any_name", "false")):
        allowed = False
        for d in tolist(role.get("allowed_domains", "")):
            if tobool(role.get("allow_glob_domains", "false")) and "*" in d and fnmatch.fnmatchcase(cn, d): allowed = True
            elif tobool(role.get("allow_bare_domains", "false")) and cn == d: allowed = True
            elif tobool(role.get("allow_subdomains", "false")) and cn.endswith("." + d): allowed = True
        if not allowed: return 400, {"errors": [f"common name {cn} not allowed by this role"]}
    # ttl
    warnings = []
    max_ttl = godur(role.get("max_ttl", "")) or godur(m["max_lease_ttl"])
    ttl = godur(body.get("ttl", "")) or godur(role.get("ttl", "")) or max_ttl
    if ttl > max_ttl:
        warnings.append(f"TTL \"{body.get('ttl')}\" is longer than permitted maxTTL \"{role.get('max_ttl')}\", so maxTTL is being used")
        ttl = max_ttl
    ca_cert, ca_key = m["ca_cert"], m["ca_key"]
    nb = now() - godur(role.get("not_before_duration", "30s"))
    na = now() + ttl
    if na > ca_cert.not_valid_after_utc: return 400, {"errors": ["cannot satisfy request, as TTL would result in notAfter beyond the CA's NotAfter"]}
    subj = [x509.NameAttribute(NameOID.COMMON_NAME, cn)]
    if role.get("organization"): subj.append(x509.NameAttribute(NameOID.ORGANIZATION_NAME, role["organization"]))
    kus = {x.lower() for x in tolist(role.get("key_usage", "DigitalSignature,KeyAgreement,KeyEncipherment"))}
    b = (x509.CertificateBuilder().subject_name(x509.Name(subj)).issuer_name(ca_cert.subject).public_key(pub)
         .serial_number(x509.random_serial_number()).not_valid_before(nb).not_valid_after(na)
         .add_extension(x509.KeyUsage(digital_signature="digitalsignature" in kus, content_commitment=False,
                                      key_encipherment="keyencipherment" in kus, data_encipherment=False,
                                      key_agreement="keyagreement" in kus, key_cert_sign=False, crl_sign=False,
                                      encipher_only=False, decipher_only=False), critical=True))
    ekus = ([ExtendedKeyUsageOID.CLIENT_AUTH] if tobool(role.get("client_flag", "true")) else []) + \
           ([ExtendedKeyUsageOID.SERVER_AUTH] if tobool(role.get("server_flag", "true")) else [])
    if ekus: b = b.add_extension(x509.ExtendedKeyUsage(ekus), critical=False)
    crt = b.sign(ca_key, hashes.SHA384()).public_bytes(serialization.Encoding.PEM).decode()
    ca_pem = ca_cert.public_bytes(serialization.Encoding.PEM).decode()
    return 200, {"data": {"certificate": crt, "issuing_ca": ca_pem, "ca_chain": [ca_pem]}, "warnings": warnings or None}


class Vault(http.server.BaseHTTPRequestHandler):
    def _send(self, code, body=None):
        b = json.dumps(body).encode() if body is not None else b""
        self.send_response(code); self.send_header("Content-Type", "application/json"); self.end_headers(); self.wfile.write(b)

    def _body(self):
        n = int(self.headers.get("Content-Length", 0) or 0)
        return json.loads(self.rfile.read(n) or b"{}") if n else {}

    def do_GET(self):
        p = self.path.split("?")[0][len("/v1/"):]
        mount = p.split("/")[0]
        if mount in V["mounts"] and p == f"{mount}/ca/pem":           # unauthenticated, as in Vault
            ca = V["mounts"][mount].get("ca_cert")
            if not ca: return self._send(400, {"errors": ["no default issuer"]})
            b = ca.public_bytes(serialization.Encoding.PEM)
            self.send_response(200); self.send_header("Content-Type", "application/pem-certificate-chain"); self.end_headers(); self.wfile.write(b); return
        tok = self.headers.get("X-Vault-Token")
        if p == "auth/token/lookup-self":
            return self._send(200, {"data": {"id": "x", "policies": V["tokens"].get(tok, {}).get("policies", [])}}) if tok in V["tokens"] else self._send(403, {"errors": ["permission denied"]})
        m = re.match(r"([^/]+)/roles/(.+)$", p)
        if m and m.group(1) in V["mounts"]:                          # role read, typed as real Vault returns it
            if not acl_allows(tok, p, "read"): return self._send(403, {"errors": ["permission denied"]})
            r = V["mounts"][m.group(1)]["roles"].get(m.group(2))
            if r is None: return self._send(404, {"errors": []})
            out = dict(r, max_ttl=int(godur(r.get("max_ttl", "")).total_seconds()), ttl=int(godur(r.get("ttl", "")).total_seconds()),
                       allowed_domains=tolist(r.get("allowed_domains", "")))
            return self._send(200, {"data": out})
        m = re.match(r"secret/data/(.+)$", p)
        if m:
            if not acl_allows(tok, p, "read"): return self._send(403, {"errors": ["permission denied"]})
            if m.group(1) in V["kv"]: return self._send(200, {"data": {"data": V["kv"][m.group(1)], "metadata": {"version": 1}}})
        self._send(404, {"errors": []})

    def do_POST(self):
        p = self.path.split("?")[0][len("/v1/"):]
        body = self._body()
        tok = self.headers.get("X-Vault-Token")
        with LOCK:
            m = re.match(r"auth/([^/]+)/login$", p)
            if m: return self._k8s_login(m.group(1), body)
            m = re.match(r"([^/]+)/sign/([^/]+)$", p)
            if m and m.group(1) in V["mounts"]:
                if not acl_allows(tok, p, "update") and not acl_allows(tok, p, "create"): return self._send(403, {"errors": ["permission denied"]})
                code, resp = pki_sign(m.group(1), m.group(2), body)
                return self._send(code, resp)
            if not acl_allows(tok, p, "update") and not acl_allows(tok, p, "create"): return self._send(403, {"errors": ["permission denied"]})
            if (m := re.match(r"sys/mounts/(.+)$", p)):
                V["mounts"][m.group(1)] = {"type": body.get("type"), "max_lease_ttl": (body.get("config") or {}).get("max_lease_ttl", "768h"), "roles": {}}
                return self._send(204)
            if (m := re.match(r"sys/auth/(.+)$", p)):
                V["auth"][m.group(1)] = {"type": body.get("type"), "config": {}, "roles": {}}; return self._send(204)
            if (m := re.match(r"sys/policies/acl/(.+)$", p)):
                V["policies"][m.group(1)] = parse_policy(body.get("policy", "")); return self._send(204)
            if (m := re.match(r"auth/([^/]+)/config$", p)):
                V["auth"][m.group(1)]["config"] = body; return self._send(204)
            if (m := re.match(r"auth/([^/]+)/role/(.+)$", p)):
                V["auth"][m.group(1)]["roles"][m.group(2)] = body; return self._send(204)
            if (m := re.match(r"([^/]+)/root/generate/internal$", p)) and m.group(1) in V["mounts"]:
                mt = V["mounts"][m.group(1)]
                key = ec.generate_private_key(ec.SECP384R1() if str(body.get("key_bits")) == "384" else ec.SECP256R1())
                subj = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, body["common_name"])] +
                                 ([x509.NameAttribute(NameOID.ORGANIZATION_NAME, body["organization"])] if body.get("organization") else []))
                ttl = godur(body.get("ttl", "")) or godur(mt["max_lease_ttl"])
                ca = (x509.CertificateBuilder().subject_name(subj).issuer_name(subj).public_key(key.public_key())
                      .serial_number(x509.random_serial_number()).not_valid_before(now() - dt.timedelta(seconds=30)).not_valid_after(now() + ttl)
                      .add_extension(x509.BasicConstraints(ca=True, path_length=None), critical=True)
                      .add_extension(x509.KeyUsage(digital_signature=False, content_commitment=False, key_encipherment=False, data_encipherment=False,
                                                   key_agreement=False, key_cert_sign=True, crl_sign=True, encipher_only=False, decipher_only=False), critical=True)
                      .sign(key, hashes.SHA384()))
                mt["ca_cert"], mt["ca_key"] = ca, key
                os.makedirs(f"{T}/vault-ca-keys", exist_ok=True)     # test-only escape hatch for crafting bad certs
                open(f"{T}/vault-ca-keys/{m.group(1)}.key", "wb").write(key.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8, serialization.NoEncryption()))
                return self._send(200, {"data": {"certificate": ca.public_bytes(serialization.Encoding.PEM).decode()}})
            if (m := re.match(r"([^/]+)/roles/(.+)$", p)) and m.group(1) in V["mounts"]:
                V["mounts"][m.group(1)]["roles"][m.group(2)] = body; return self._send(204)
            if (m := re.match(r"secret/data/(.+)$", p)):
                V["kv"][m.group(1)] = body.get("data", {}); return self._send(200, {"data": {"version": 1}})
        self._send(404, {"errors": [f"no handler for {p}"]})
    do_PUT = do_POST

    def _k8s_login(self, mount, body):
        a = V["auth"].get(mount)
        role = (a or {}).get("roles", {}).get(body.get("role", ""))
        if not role: return self._send(400, {"errors": [f"invalid role name \"{body.get('role')}\""]})
        cfg = a["config"]
        aud = role.get("audience")
        tr = {"apiVersion": "authentication.k8s.io/v1", "kind": "TokenReview", "spec": {"token": body.get("jwt", ""), "audiences": [aud] if aud else []}}
        ca_file = f"{T}/vault-k8s-auth-{mount}-ca.crt"
        open(ca_file, "w").write(cfg["kubernetes_ca_cert"])          # as configured by vault/01-hub-kubernetes-auth.sh
        r = requests.post(cfg["kubernetes_host"] + "/apis/authentication.k8s.io/v1/tokenreviews", json=tr, timeout=10,
                          headers={"Authorization": f"Bearer {cfg['token_reviewer_jwt'].strip()}"}, verify=ca_file)
        if r.status_code >= 300: return self._send(403, {"errors": [f"token review failed: {r.text[:150]}"]})
        st = r.json().get("status", {})
        if not st.get("authenticated"): return self._send(403, {"errors": ["permission denied: " + st.get("error", "not authenticated")]})
        user = st["user"]["username"]                     # system:serviceaccount:<ns>:<name>
        _, _, sa_ns, sa_name = user.split(":")
        if sa_name not in tolist(role.get("bound_service_account_names", "")) or sa_ns not in tolist(role.get("bound_service_account_namespaces", "")):
            return self._send(403, {"errors": [f"service account {sa_ns}/{sa_name} not authorized for this role"]})
        tok = "hvs." + secrets.token_hex(12)
        V["tokens"][tok] = {"policies": tolist(role.get("token_policies", "")), "expires": time.time() + godur(role.get("token_ttl", "1m")).total_seconds()}
        return self._send(200, {"auth": {"client_token": tok, "policies": V["tokens"][tok]["policies"]}})

    def log_message(self, *a): pass


def loop():
    while True:
        for f in (issuers, certificaterequests, works, openshift_operator):
            try: f()
            except Exception: traceback.print_exc()
        time.sleep(0.5)


if __name__ == "__main__":
    threading.Thread(target=http.server.ThreadingHTTPServer(("127.0.0.1", 18200), Vault).serve_forever, daemon=True).start()
    print("fakes up", flush=True)
    loop()
