#!/usr/bin/env bash
# Local test rig: three real kube-apiservers (hub, lab-1, lab-2) on one etcd, real CRDs
# (cert-manager, OCM ManagedCluster/ManifestWork, OpenShift APIServer), and stand-ins for
# cert-manager (Vault issuer, built-in approver on), Vault (PKI + Kubernetes auth), the
# klusterlet work agent and OpenShift's kube-apiserver operator (fakes.py).
# The admin-request files are applied exactly as delivered: hub/*.yaml with kubectl, and
# vault/*.sh through a vault CLI shim. No container runtime or OpenShift needed.
#
# Needs: git, openssl, curl, python3 with kubernetes/cryptography/requests/pyyaml, and
#   ENVTEST_BIN: directory with etcd, kube-apiserver, kubectl (v1.31), e.g. from
#   https://github.com/kubernetes-sigs/controller-tools/releases/download/envtest-v1.31.0/envtest-v1.31.0-linux-amd64.tar.gz
set -euo pipefail
HERE=$(cd "$(dirname "$0")" && pwd)
REQ=$(cd "$HERE/../../admin-request" && pwd)
T=${BGT_DIR:-/var/tmp/bgt}
B=${ENVTEST_BIN:?set ENVTEST_BIN to the directory holding etcd, kube-apiserver and kubectl}
SRC=$T/src
CERT_MANAGER=v1.15.3 OCM_API=v0.15.0 OCP_API=release-4.16

pkill -f "[k]ube-apiserver --etcd-servers http://127.0.0.1:2379" || true
pkill -f "[e]tcd --data-dir .*--listen-client-urls http://127.0.0.1:2379" || true
pkill -f "[f]akes.py" || true
for _ in $(seq 1 20); do ss -ltn 2>/dev/null | grep -qE ":(2379|6443|6444|6445|18200) " || break; sleep 1; done
rm -rf "$T"; mkdir -p "$T" "$SRC" "$T/bin"; cd "$T"

echo "==> CRD sources"
curl -fsSL -o "$SRC/cert-manager.yaml" "https://github.com/cert-manager/cert-manager/releases/download/$CERT_MANAGER/cert-manager.yaml"
git clone -q --depth 1 --branch "$OCM_API" https://github.com/open-cluster-management-io/api.git "$SRC/ocm-api" 2>/dev/null
git clone -q --depth 1 --filter=blob:none --sparse --branch "$OCP_API" https://github.com/openshift/api.git "$SRC/ocp-api" 2>/dev/null
git -C "$SRC/ocp-api" sparse-checkout set config/v1/zz_generated.crd-manifests

echo "==> keys, tokens, audit policy"
openssl genrsa -out sa.key 2048 2>/dev/null; openssl rsa -in sa.key -pubout -out sa.pub 2>/dev/null
openssl req -x509 -newkey ec -pkeyopt ec_paramgen_curve:prime256v1 -nodes -keyout ph.key -out placeholder-ca.crt -days 2 -subj "/CN=placeholder" 2>/dev/null
cat > audit-policy.yaml <<'AUDIT'
apiVersion: audit.k8s.io/v1
kind: Policy
rules:
  - level: Metadata
    resources: [{ group: cert-manager.io, resources: [certificaterequests] }]
    verbs: [create]
  - level: None
AUDIT
# Static identities. The SA names match the ServiceAccounts in admin-request/hub/01, so the
# RBAC in hub/02-05 is what authorises them.
cat > hub-tokens.csv <<'TOKENS'
hub-admin-token,hub-admin,hub-admin,"system:masters"
issuer-sa-token,system:serviceaccount:eos-automation:eos-breakglass-issuer,u-issuer,"system:serviceaccounts,system:serviceaccounts:eos-automation"
admin-sa-token,system:serviceaccount:eos-automation:eos-breakglass-admin,u-admin,"system:serviceaccounts,system:serviceaccounts:eos-automation"
cm-sa-token,system:serviceaccount:cert-manager:cert-manager,u-cm,"system:serviceaccounts,system:serviceaccounts:cert-manager"
appteam-token,app-developer,u-app,"app-developers"
TOKENS
echo 'cluster-admin-token,kube-admin,kube-admin,"system:masters"' > cluster-tokens.csv

echo "==> etcd + kube-apiservers"
nohup "$B/etcd" --data-dir "$T/etcd" --listen-client-urls http://127.0.0.1:2379 --advertise-client-urls http://127.0.0.1:2379 \
  --listen-peer-urls http://127.0.0.1:2380 > etcd.log 2>&1 &
sleep 2
start() {
  local n=$1 p=$2 tok=$3; shift 3; mkdir -p "$T/$n/certs"; cp "$T/placeholder-ca.crt" "$T/$n/client-ca.crt"
  nohup "$B/kube-apiserver" --etcd-servers http://127.0.0.1:2379 --etcd-prefix "/$n" --secure-port "$p" --bind-address 127.0.0.1 \
    --cert-dir "$T/$n/certs" --token-auth-file "$T/$tok" --client-ca-file "$T/$n/client-ca.crt" --authorization-mode RBAC \
    --service-account-issuer https://kubernetes.default.svc --service-account-key-file "$T/sa.pub" \
    --service-account-signing-key-file "$T/sa.key" --service-cluster-ip-range 10.96.0.0/12 "$@" > "$T/$n/apiserver.log" 2>&1 &
}
start hub 6443 hub-tokens.csv --audit-policy-file "$T/audit-policy.yaml" --audit-log-path "$T/hub/audit.log"
start lab-1 6444 cluster-tokens.csv
start lab-2 6445 cluster-tokens.csv
for spec in hub:6443:hub-admin-token lab-1:6444:cluster-admin-token lab-2:6445:cluster-admin-token; do
  IFS=: read -r name port tok <<< "$spec"
  for _ in $(seq 1 90); do [[ -s "$T/$name/certs/apiserver.crt" ]] && break; sleep 1; done
  cat > "$T/$name/admin.kubeconfig" <<KCFG
apiVersion: v1
kind: Config
clusters: [{name: $name, cluster: {server: "https://127.0.0.1:$port", certificate-authority: $T/$name/certs/apiserver.crt}}]
users: [{name: admin, user: {token: $tok}}]
contexts: [{name: $name, context: {cluster: $name, user: admin}}]
current-context: $name
KCFG
  for _ in $(seq 1 90); do "$B/kubectl" --kubeconfig "$T/$name/admin.kubeconfig" get --raw /readyz >/dev/null 2>&1 && break; sleep 1; done
  echo "    $name ready"
done
K() { "$B/kubectl" --kubeconfig "$T/$1/admin.kubeconfig" "${@:2}"; }

echo "==> hub CRDs"
python3 - "$SRC" "$T/hub-crds.yaml" <<'PY'
import sys, yaml
src, out_path = sys.argv[1], sys.argv[2]
out = [d for d in yaml.safe_load_all(open(f"{src}/cert-manager.yaml")) if d and d.get("kind") == "CustomResourceDefinition"]
for d in out:
    if (d["spec"].get("conversion") or {}).get("strategy") == "Webhook":
        d["spec"]["conversion"] = {"strategy": "None"}
for f in ("cluster/v1/0000_00_clusters.open-cluster-management.io_managedclusters.crd.yaml",
          "work/v1/0000_00_work.open-cluster-management.io_manifestworks.crd.yaml"):
    out += [d for d in yaml.safe_load_all(open(f"{src}/ocm-api/{f}")) if d]
yaml.safe_dump_all(out, open(out_path, "w"))
PY
K hub apply --server-side -f "$T/hub-crds.yaml" >/dev/null
K hub wait crd --all --for=condition=Established --timeout=120s >/dev/null
K hub create ns cert-manager --dry-run=client -o yaml | K hub apply -f - >/dev/null

echo "==> admin-request/hub (as the hub admin would apply it)"
for f in "$REQ"/hub/01-*.yaml "$REQ"/hub/02-*.yaml "$REQ"/hub/03-*.yaml "$REQ"/hub/05-*.yaml "$REQ"/hub/06-*.yaml "$REQ"/hub/07-*.yaml; do
  K hub apply -f "$f" >/dev/null; echo "    applied $(basename "$f")"
done
# An app team with ordinary rights in its own namespace on the hub (cert-manager aggregates
# certificaterequest create into the standard edit role).
K hub create ns app-team --dry-run=client -o yaml | K hub apply -f - >/dev/null
printf 'apiVersion: rbac.authorization.k8s.io/v1\nkind: ClusterRole\nmetadata: {name: cert-manager-edit}\nrules: [{apiGroups: [cert-manager.io], resources: [certificates, certificaterequests, issuers], verbs: [create, get, list, patch, update, delete]}]\n' | K hub apply -f - >/dev/null
K hub -n app-team create rolebinding app-developers-certs --clusterrole=cert-manager-edit --group=app-developers --dry-run=client -o yaml | K hub apply -f - >/dev/null

echo "==> managed clusters"
for c in lab-1:6444 lab-2:6445 lab-3:6446; do
  IFS=: read -r n p <<< "$c"
  K hub create ns "$n" --dry-run=client -o yaml | K hub apply -f - >/dev/null
  if [[ $n == lab-3 ]]; then CA_FILE="$T/hub/certs/apiserver.crt"; else CA_FILE="$T/$n/certs/apiserver.crt"; fi
  cat <<MC | K hub apply -f - >/dev/null
apiVersion: cluster.open-cluster-management.io/v1
kind: ManagedCluster
metadata: {name: $n}
spec:
  hubAcceptsClient: true
  managedClusterClientConfigs:
    - url: https://127.0.0.1:$p
      caBundle: $(base64 -w0 "$CA_FILE")
MC
  if [[ $n == lab-3 ]]; then echo "    lab-3 registered but NOT onboarded (no hub/04 RoleBinding)"; continue; fi
  sed "s/CLUSTER_NAME/$n/g" "$REQ/hub/04-onboard-cluster-TEMPLATE.yaml" | K hub apply -f - >/dev/null
  K "$n" apply --server-side -f "$SRC/ocp-api/config/v1/zz_generated.crd-manifests/0000_10_config-operator_01_apiservers.crd.yaml" >/dev/null
  K "$n" wait crd apiservers.config.openshift.io --for=condition=Established --timeout=60s >/dev/null
  printf 'apiVersion: config.openshift.io/v1\nkind: APIServer\nmetadata: {name: cluster}\nspec: {audit: {profile: Default}}\n' | K "$n" apply -f - >/dev/null
  K "$n" create ns openshift-config --dry-run=client -o yaml | K "$n" apply -f - >/dev/null
  printf 'apiVersion: rbac.authorization.k8s.io/v1\nkind: ClusterRole\nmetadata: {name: cluster-reader}\nrules: [{apiGroups: ["*"], resources: ["*"], verbs: [get, list, watch]}]\n' | K "$n" apply -f - >/dev/null
  echo "    $n registered and onboarded (hub/04 applied)"
done

echo "==> stand-ins (cert-manager, Vault, work agent, OpenShift operator)"
BGT_DIR=$T nohup python3 "$HERE/fakes.py" > "$T/fakes.log" 2>&1 &
sleep 2

echo "==> admin-request/vault (as the Vault team would run it, via the CLI shim)"
chmod +x "$HERE/vault-cli.py"; ln -sf "$HERE/vault-cli.py" "$T/bin/vault"
export PATH="$T/bin:$PATH" VAULT_ADDR=http://127.0.0.1:18200 VAULT_TOKEN=root-vault-token
# On a real hub this is the token in hub/06's Secret; there is no token controller here.
K hub -n eos-automation create token vault-token-reviewer --duration=24h > "$T/reviewer.jwt"
HUB_API_URL=https://127.0.0.1:6443 HUB_CA_FILE="$T/hub/certs/apiserver.crt" REVIEWER_JWT_FILE="$T/reviewer.jwt" \
  "$REQ/vault/01-hub-kubernetes-auth.sh" >/dev/null
echo "    ran 01-hub-kubernetes-auth.sh"
export ACCOUNTS="eos-cluster-admin=1h eos-cluster-reader=4h"   # = breakglass_accounts in group_vars
for n in lab-1 lab-2 lab-3; do CLUSTER=$n "$REQ/vault/02-onboard-cluster.sh" | sed 's/^/    /'; done

cat > "$T/test-vars.yml" <<VARS
hub_api_url: https://127.0.0.1:6443
hub_ca_cert_path: $T/hub/certs/apiserver.crt
vault_url: http://127.0.0.1:18200
breakglass_output_dir: $T/out
VARS
PY=$(command -v python3)
cat > "$T/test-inventory.yml" <<INV
all:
  hosts:
    localhost: { ansible_connection: local, ansible_python_interpreter: $PY }
INV
echo "Ready. Run tests/e2e/run.sh"
