"""End-to-end tests for ansible-eos-kubeconfig-generator (Vault PKI design) against real kube-apiservers."""
import base64, copy, datetime as dt, json, os, subprocess, sys, time, yaml
from cryptography import x509
from cryptography.x509.oid import NameOID, ExtendedKeyUsageOID
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec, rsa

T = os.environ.get("BGT_DIR", "/var/tmp/bgt"); REPO = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
KUBECTL = os.environ.get("KUBECTL", "kubectl")
ENV = dict(os.environ, VAULT_TOKEN="root-vault-token", ANSIBLE_FORCE_COLOR="0")
RESULTS = []
RUN = str(int(time.time()))[-6:]


def check(name, ok, detail=""):
    RESULTS.append((name, ok, detail))
    print(f"{'PASS' if ok else 'FAIL'}  {name}" + (f"  [{detail}]" if detail else ""), flush=True)


def play(pb, user, *extra, log=None):
    cmd = ["ansible-playbook", "-i", f"{T}/test-inventory.yml", f"playbooks/{pb}", "-e", f"@{T}/test-vars.yml", *extra]
    r = subprocess.run(cmd, cwd=REPO, env=dict(ENV, USER=user), capture_output=True, text=True, timeout=600)
    out = r.stdout + r.stderr
    if log: open(f"{T}/{log}", "w").write(out)
    return r.returncode, out


def generate(user, cluster="lab-1", account="eos-cluster-admin", *extra, log=None):
    return play("generate_kubeconfig.yml", user, "-e", f"target_cluster={cluster}", "-e", f"breakglass_account={account}",
                "-e", "breakglass_ticket=INC0012345", "-e", "breakglass_reason='incident drill for breakglass test'", *extra, log=log)


def kc(path, *args, stdin=None):
    r = subprocess.run([KUBECTL, "--kubeconfig", path, *args], capture_output=True, text=True, timeout=30, input=stdin)
    err = "\n".join(l for l in r.stderr.splitlines() if not l.startswith("Warning:"))
    return r.returncode, (r.stdout + err).strip()


def admin(cluster, *args): return kc(f"{T}/{cluster}/admin.kubeconfig", *args)
def load(p): return yaml.safe_load(open(p))


def save(cfg, name):
    os.makedirs(f"{T}/tamper", exist_ok=True)
    p = f"{T}/tamper/{name}.kubeconfig"
    yaml.safe_dump(cfg, open(p, "w")); os.chmod(p, 0o600); return p


def hub_as(token):
    c = load(f"{T}/hub/admin.kubeconfig"); c["users"][0]["user"]["token"] = token
    return save(c, f"hub-{token}")


def whoami(path):
    rc, out = kc(path, "auth", "whoami", "-o", "json")
    return json.loads(out)["status"]["userInfo"] if rc == 0 else out


def pem_of(cfg, key): return base64.b64decode(cfg["users"][0]["user"][key])


def hub_cr(name, cn, duration, token="issuer-sa-token", ns="eos-breakglass", issuer="eos-breakglass-lab-1-eos-cluster-admin", key=None, orgs=("eos-breakglass",)):
    """Create a CertificateRequest directly on the hub (bypassing the playbook) and wait for the outcome."""
    pk = key or ec.generate_private_key(ec.SECP256R1())
    subj = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, cn)] + [x509.NameAttribute(NameOID.ORGANIZATION_NAME, o) for o in orgs])
    csr = x509.CertificateSigningRequestBuilder().subject_name(subj).sign(pk, hashes.SHA256())
    body = {"apiVersion": "cert-manager.io/v1", "kind": "CertificateRequest", "metadata": {"name": f"{name}-{RUN}", "namespace": ns},
            "spec": {"request": base64.b64encode(csr.public_bytes(serialization.Encoding.PEM)).decode(), "duration": duration,
                     "usages": ["client auth", "digital signature"], "issuerRef": {"group": "cert-manager.io", "kind": "Issuer", "name": issuer}}}
    rc, out = kc(hub_as(token), "create", "-f", "-", stdin=json.dumps(body))
    if rc != 0: return "forbidden", out, None, None
    for _ in range(40):
        rc, out = admin("hub", "-n", ns, "get", "certificaterequest", f"{name}-{RUN}", "-o", "json")
        st = json.loads(out).get("status", {})
        ready = {c["type"]: c for c in st.get("conditions", [])}.get("Ready", {})
        if ready.get("status") == "True": return "issued", "", base64.b64decode(st["certificate"]), pk
        if ready.get("reason") in ("Failed",) or (ready.get("reason") == "Pending" and "not found" in ready.get("message", "")):
            return "refused", ready.get("message", ""), None, None
        time.sleep(0.5)
    return "timeout", "", None, None


def kubeconfig_from(cert_pem, key, name):
    cfg = copy.deepcopy(ALICE)
    cfg["users"][0]["user"]["client-certificate-data"] = base64.b64encode(cert_pem).decode()
    cfg["users"][0]["user"]["client-key-data"] = base64.b64encode(key.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8, serialization.NoEncryption())).decode()
    return save(cfg, name)


def life(cert_pem):
    c = x509.load_pem_x509_certificate(cert_pem)
    return c.not_valid_after_utc - c.not_valid_before_utc


# ====================================================================== 1. the legitimate path
print("\n== Legitimate use")
ALICE_PATH = f"{T}/out/lab-1-eos-cluster-admin-alice.smith.kubeconfig"
ALICE = load(ALICE_PATH)
u = whoami(ALICE_PATH)
check("alice's kubeconfig authenticates as alice", isinstance(u, dict) and u["username"] == "eos-breakglass:eos-cluster-admin:alice.smith", str(u)[:110])
rc, out = kc(ALICE_PATH, "auth", "can-i", "*", "*", "--all-namespaces")
check("alice has the admin role on lab-1", out == "yes", out)
cert = x509.load_pem_x509_certificate(pem_of(ALICE, "client-certificate-data"))
lt = cert.not_valid_after_utc - cert.not_valid_before_utc
check("admin certificate lives 1h, the admin cap (default 2h lowered; +30s Vault backdating)", abs(lt.total_seconds() - 3630) < 60, str(lt))
check("signed by lab-1's Vault CA, O set by the Vault role", cert.issuer.rfc4514_string() == "O=EOS breakglass,CN=EOS breakglass CA lab-1"
      and [a.value for a in cert.subject.get_attributes_for_oid(NameOID.ORGANIZATION_NAME)] == ["eos-breakglass"], cert.issuer.rfc4514_string())

# ====================================================================== 2. tampering
print("\n== Tampering")
c = copy.deepcopy(ALICE); c["users"][0]["name"] = "bob.jones"; c["contexts"][0]["context"]["user"] = "bob.jones"
u = whoami(save(c, "renamed-user"))
check("renaming the user in the kubeconfig does not change identity", isinstance(u, dict) and u["username"].endswith(":alice.smith"), str(u)[:90])
der = cert.public_bytes(serialization.Encoding.DER)
tampered = der.replace(b"alice.smith", b"bob.jone.sx")
c = copy.deepcopy(ALICE)
c["users"][0]["user"]["client-certificate-data"] = base64.b64encode(b"-----BEGIN CERTIFICATE-----\n" + base64.encodebytes(tampered) + b"-----END CERTIFICATE-----\n").decode()
rc, out = kc(save(c, "edited-cn"), "auth", "whoami")
check("editing the name inside the certificate is rejected", rc != 0 and "Unauthorized" in out, out[-60:])
rc, _ = generate("bob.jones", log="run-bob.log")
BOB_PATH = f"{T}/out/lab-1-eos-cluster-admin-bob.jones.kubeconfig"
BOB = load(BOB_PATH)
c = copy.deepcopy(ALICE); c["users"][0]["user"]["client-certificate-data"] = BOB["users"][0]["user"]["client-certificate-data"]
rc, out = kc(save(c, "bob-cert-alice-key"), "auth", "whoami")
check("bob's certificate with alice's key is refused", rc != 0 and "private key does not match" in out, out[-60:])
fk = ec.generate_private_key(ec.SECP256R1())
forged = (x509.CertificateBuilder().subject_name(cert.subject).issuer_name(cert.issuer).public_key(fk.public_key())
          .serial_number(x509.random_serial_number()).not_valid_before(dt.datetime.now(dt.timezone.utc))
          .not_valid_after(dt.datetime.now(dt.timezone.utc) + dt.timedelta(hours=1))
          .add_extension(x509.ExtendedKeyUsage([ExtendedKeyUsageOID.CLIENT_AUTH]), critical=False)
          .sign(fk, hashes.SHA256()).public_bytes(serialization.Encoding.PEM))
rc, out = kc(kubeconfig_from(forged, fk, "forged"), "auth", "whoami")
check("a self-made certificate with alice's name and the CA's name is rejected", rc != 0 and "Unauthorized" in out, out[-60:])
c = copy.deepcopy(ALICE)
c["clusters"][0]["cluster"]["server"] = "https://127.0.0.1:6445"
c["clusters"][0]["cluster"]["certificate-authority-data"] = base64.b64encode(open(f"{T}/lab-2/certs/apiserver.crt", "rb").read()).decode()
rc, out = kc(save(c, "other-cluster"), "auth", "whoami")
check("alice's lab-1 certificate is rejected by lab-2", rc != 0 and "Unauthorized" in out, out[-60:])
ca_key = serialization.load_pem_private_key(open(f"{T}/vault-ca-keys/pki-eos-breakglass-lab-1.key", "rb").read(), None)
for label, nb, na in (("expired", -5, -1), ("not yet valid", 1, 3)):
    k = ec.generate_private_key(ec.SECP256R1()); n = dt.datetime.now(dt.timezone.utc)
    crt = (x509.CertificateBuilder().subject_name(cert.subject).issuer_name(cert.issuer).public_key(k.public_key())
           .serial_number(x509.random_serial_number()).not_valid_before(n + dt.timedelta(hours=nb)).not_valid_after(n + dt.timedelta(hours=na))
           .add_extension(x509.ExtendedKeyUsage([ExtendedKeyUsageOID.CLIENT_AUTH]), critical=False)
           .sign(ca_key, hashes.SHA384()).public_bytes(serialization.Encoding.PEM))
    rc, out = kc(kubeconfig_from(crt, k, label.replace(" ", "-")), "auth", "whoami")
    check(f"a genuinely signed but {label} certificate is rejected", rc != 0 and "Unauthorized" in out, out[-60:])

# ====================================================================== 3. the 4-hour cap
print("\n== Per-account caps (admin 1h, reader 4h)")
VAULT_ENV = dict(ENV, PATH=f"{T}/bin:" + os.environ["PATH"], VAULT_ADDR="http://127.0.0.1:18200", CLUSTER="lab-1")
def vault_roles(accounts):
    r = subprocess.run([f"{REPO}/admin-request/vault/04-account-roles.sh"], env=dict(VAULT_ENV, ACCOUNTS=accounts), capture_output=True, text=True)
    return r.returncode, r.stdout + r.stderr
rc, out = generate("alice.smith", "lab-1", "eos-cluster-admin", "-e", "breakglass_duration_hours=2")
check("playbook refuses 2h for the admin account", rc != 0 and "Invalid request" in out)
rc, out = generate("alice.smith", "lab-1", "eos-cluster-reader", "-e", "breakglass_duration_hours=4", log="run-4h.log")
lt = life(pem_of(load(f"{T}/out/lab-1-eos-cluster-reader-alice.smith.kubeconfig"), "client-certificate-data"))
check("reader: 4h is accepted and the certificate lives 4h", rc == 0 and abs(lt.total_seconds() - 14430) < 60, str(lt))
rc, out = generate("alice.smith", "lab-1", "eos-cluster-reader", "-e", "breakglass_duration_hours=5")
check("reader: playbook refuses 5h", rc != 0 and "Invalid request" in out)
for label, d in (("4h", "4h"), ("90 days", "2160h")):
    res, msg, crt, _ = hub_cr(f"bypass-admin-{d}", "eos-breakglass:eos-cluster-admin:alice.smith", d)
    lt = life(crt) if crt else None
    check(f"admin: {label} asked for directly on the hub comes back as 1h (Vault admin role)", res == "issued" and abs(lt.total_seconds() - 3630) < 60, f"{res} {lt}")
res, msg, crt, _ = hub_cr("bypass-reader-90d", "eos-breakglass:eos-cluster-reader:alice.smith", "2160h", issuer="eos-breakglass-lab-1-eos-cluster-reader")
lt = life(crt) if crt else None
check("reader: 90 days asked for directly on the hub comes back as 4h", res == "issued" and abs(lt.total_seconds() - 14430) < 60, f"{res} {lt}")
res, msg, _, _ = hub_cr("admin-via-reader", "eos-breakglass:eos-cluster-admin:alice.smith", "4h", issuer="eos-breakglass-lab-1-eos-cluster-reader")
check("an admin name sent through the reader Issuer (to get 4h) is refused by Vault", res == "refused" and "not allowed by this role" in msg, msg[-90:])
rogue = {"apiVersion": "cert-manager.io/v1", "kind": "Issuer", "metadata": {"name": f"rogue-{RUN}", "namespace": "eos-breakglass"},
         "spec": {"vault": {"server": "http://127.0.0.1:18200", "path": "pki-eos-breakglass-lab-1/sign/breakglass-eos-cluster-reader",
                            "auth": {"kubernetes": {"role": "eos-breakglass-lab-1-eos-cluster-reader", "mountPath": "/v1/auth/kubernetes-acm-hub",
                                                    "serviceAccountRef": {"name": "eos-breakglass-vault-signer"}}}}}}
os.makedirs(f"{T}/tamper", exist_ok=True); json.dump(rogue, open(f"{T}/tamper/rogue.json", "w"))
admin("hub", "apply", "-f", f"{T}/tamper/rogue.json"); time.sleep(2)
res, msg, _, _ = hub_cr("rogue-issuer", "eos-breakglass:eos-cluster-reader:alice.smith", "1h", token="hub-admin-token", issuer=f"rogue-{RUN}")
check("a new hub Issuer reusing an account's Vault login is refused (token audience is bound to the Issuer)", res == "refused" and "vault" in msg.lower(), msg[-90:])

rc, out = vault_roles("eos-cluster-admin=4h eos-cluster-reader=4h")
rc2, out2 = play("bootstrap_cluster.yml", "ops", "-e", "target_cluster=lab-1")
check("bootstrap fails when Vault's admin cap is raised above the catalogue", rc == 0 and rc2 != 0 and "eos-cluster-admin: Vault max_ttl 14400s, catalogue 3600s" in out2, out2[-160:].replace("\n", " ") if rc2 == 0 else "")
rc, out = vault_roles("eos-cluster-admin=1h eos-cluster-reader=4h")
over = {"breakglass_accounts": {"eos-cluster-admin": {"cluster_role": "cluster-admin", "max_duration_hours": 2, "allowed_operators": ["alice.smith", "bob.jones"]},
                                "eos-cluster-reader": {"cluster_role": "cluster-reader", "max_duration_hours": 4, "allowed_operators": ["alice.smith", "bob.jones", "carol.white"]}}}
json.dump(over, open(f"{T}/admin-2h.json", "w"))
rc2, out2 = play("bootstrap_cluster.yml", "ops", "-e", "target_cluster=lab-1", "-e", f"@{T}/admin-2h.json")
check("bootstrap fails when the catalogue is raised but Vault is not, and prints the Vault command to run",
      rc2 != 0 and "catalogue 7200s" in out2 and "eos-cluster-admin=2h eos-cluster-reader=4h" in out2, out2[-200:].replace("\n", " "))
rc, out = vault_roles("eos-cluster-admin=5h")
check("04-account-roles.sh refuses more than 4h", rc != 0 and "outside 1..4h" in out, out.strip()[-60:])
legacy = dict(rogue, metadata={"name": "eos-breakglass-lab-2", "namespace": "eos-breakglass", "labels": {"eos.breakglass/cluster": "lab-2"}})
json.dump(legacy, open(f"{T}/tamper/legacy.json", "w")); admin("hub", "apply", "-f", f"{T}/tamper/legacy.json")
rc, out = play("bootstrap_cluster.yml", "ops", "-e", "target_cluster=lab-2")
check("bootstrap warns about the old single-Issuer layout", rc == 0 and "Leftover Issuer(s) eos-breakglass-lab-2" in out, "")
admin("hub", "-n", "eos-breakglass", "delete", "issuer", "eos-breakglass-lab-2", f"rogue-{RUN}")

# ====================================================================== 4. what Vault will and won't sign
print("\n== Vault role rules")
for label, cn, key, orgs in (("kube-admin / system:masters", "kube-admin", None, ("system:masters",)),
                             ("a hostname", "api.ocp-prod-01.example.com", None, ("eos-breakglass",)),
                             ("an RSA key", "eos-breakglass:eos-cluster-admin:alice.smith", rsa.generate_private_key(65537, 2048), ("eos-breakglass",))):
    res, msg, crt, _ = hub_cr("refuse-" + label.split()[0].replace("/", ""), cn, "1h", key=key, orgs=orgs)
    check(f"Vault refuses {label}", res == "refused" and "vault" in msg.lower(), msg[-90:])
res, msg, crt, _ = hub_cr("org-override", "eos-breakglass:eos-cluster-admin:alice.smith", "1h", orgs=("system:masters",))
orgs = [a.value for a in x509.load_pem_x509_certificate(crt).subject.get_attributes_for_oid(NameOID.ORGANIZATION_NAME)] if crt else None
check("an O=system:masters in the CSR is replaced by the role's O", res == "issued" and orgs == ["eos-breakglass"], str(orgs))

# ====================================================================== 5. who can get a certificate signed
print("\n== Who can request")
res, msg, _, _ = hub_cr("appteam", "eos-breakglass:eos-cluster-admin:alice.smith", "1h", token="appteam-token", ns="app-team")
check("an app team on the hub cannot use the breakglass Issuer from its namespace", res == "refused" and "not found" in msg, msg[-80:])
res, msg, _, _ = hub_cr("appteam-into", "eos-breakglass:eos-cluster-admin:alice.smith", "1h", token="appteam-token")
check("an app team cannot create requests in eos-breakglass", res == "forbidden", msg[-70:])
res, msg, _, _ = hub_cr("admin-sa-try", "eos-breakglass:eos-cluster-admin:alice.smith", "1h", token="admin-sa-token")
check("the bootstrap service account cannot request certificates", res == "forbidden", msg[-70:])
rc, out = kc(hub_as("issuer-sa-token"), "-n", "eos-breakglass", "create", "token", "eos-breakglass-vault-signer")
check("the issuer service account cannot mint the Vault signer's token", rc != 0 and "forbidden" in out.lower(), out[-70:])
rc, out = kc(hub_as("appteam-token"), "-n", "eos-breakglass", "create", "token", "eos-breakglass-vault-signer")
check("nor can anyone else except cert-manager", rc != 0 and "forbidden" in out.lower(), out[-50:])
res, msg, crt, k = hub_cr("hub-admin-try", "eos-breakglass:eos-cluster-admin:alice.smith", "1h", token="hub-admin-token")
audit = [json.loads(l) for l in open(f"{T}/hub/audit.log") if f"hub-admin-try-{RUN}" in l]
who = {e["user"]["username"] for e in audit if e.get("verb") == "create"}
check("FINDING: a hub cluster-admin can still get a cert in alice's name; attributable in the hub audit log",
      res == "issued" and who == {"hub-admin"}, f"result={res}, audit user={who}")
res, msg, crt, k = hub_cr("minted-dave", "eos-breakglass:eos-cluster-admin:dave.evil", "1h")
if crt:
    p = kubeconfig_from(crt, k, "dave"); u = whoami(p); rc, out = kc(p, "get", "namespaces")
    check("a certificate for an unlisted person authenticates but has no access", isinstance(u, dict) and rc != 0 and "forbidden" in out.lower(), out[-60:])
else:
    check("a certificate for an unlisted person authenticates but has no access", False, res + msg[:60])

# ====================================================================== 6. bound to one person (playbook)
print("\n== Bound to one person")
rc, out = generate("carol.white", "lab-1", "eos-cluster-admin")
check("carol (not on the admin list) cannot get an admin kubeconfig", rc != 0 and "not allowed" in out)
rc, out = generate("alice.smith", "lab-1", "eos-cluster-admin", "-e", "breakglass_recipient=bob.jones")
check("alice cannot issue one for bob (no delegation)", rc != 0 and "not allowed" in out)

# ====================================================================== 7. onboarding boundaries and revocation
print("\n== Onboarding and revocation")
rc, out = play("bootstrap_cluster.yml", "ops", "-e", "target_cluster=lab-3")
check("bootstrap cannot touch a cluster that was not onboarded (no hub/04 RoleBinding)", rc != 0 and "forbidden" in out.lower(), "")
rc, before = kc(BOB_PATH, "auth", "can-i", "delete", "nodes")
accounts = {"eos-cluster-admin": {"description": "x", "cluster_role": "cluster-admin", "max_duration_hours": 1, "allowed_operators": ["alice.smith"]},
            "eos-cluster-reader": {"description": "x", "cluster_role": "cluster-reader", "max_duration_hours": 4, "allowed_operators": ["alice.smith", "bob.jones", "carol.white"]}}
json.dump({"breakglass_accounts": accounts}, open(f"{T}/no-bob.json", "w"))
play("bootstrap_cluster.yml", "ops", "-e", "target_cluster=lab-1", "-e", f"@{T}/no-bob.json"); time.sleep(2)
rc2, after = kc(BOB_PATH, "auth", "can-i", "delete", "nodes")
rc3, alice_after = kc(ALICE_PATH, "auth", "can-i", "delete", "nodes")
check("removing bob revokes his live kubeconfig at once; alice keeps access", before == "yes" and after == "no" and alice_after == "yes",
      f"bob {before}->{after}, alice {alice_after}")
rc, out = play("bootstrap_cluster.yml", "ops", "-e", "target_cluster=lab-1", "-e", "breakglass_enabled=false"); time.sleep(2)
rc2, out2 = kc(ALICE_PATH, "get", "namespaces")
check("breakglass_enabled=false removes all access", rc == 0 and rc2 != 0 and "forbidden" in out2.lower(), out2[-50:])
rc, out = admin("lab-1", "get", "apiserver", "cluster", "-o", "jsonpath={.spec.clientCA.name}")
check("disabling keeps the cluster's clientCA setting", out == "eos-breakglass-client-ca", out)
play("bootstrap_cluster.yml", "ops", "-e", "target_cluster=lab-1"); time.sleep(2)
rc, out = kc(ALICE_PATH, "auth", "can-i", "*", "*")
check("re-enabling restores alice", out == "yes", out)

# ====================================================================== 8. secrets handling
print("\n== Secrets handling")
rc, out = admin("hub", "get", "certificaterequests,secrets", "-A", "-o", "json")
check("no client private key or CA key is stored on the hub", "PRIVATE KEY" not in out and "UFJJVkFURSBLRVk" not in out)
logs = "".join(open(f"{T}/{f}").read() for f in ("run-alice.log", "run-bob.log", "run-4h.log"))
check("playbook output never shows a key or token",
      "PRIVATE KEY" not in logs and ALICE["users"][0]["user"]["client-key-data"][:40] not in logs and "issuer-sa-token" not in logs and "root-vault-token" not in logs)
check("temporary key directory is removed", not [d for d in os.listdir("/tmp") if d.startswith("breakglass.")])
rc, out = admin("hub", "-n", "eos-breakglass", "get", "certificaterequests", "-l", "eos.breakglass/account=eos-cluster-admin",
                "-o", "jsonpath={range .items[*]}{.metadata.annotations.eos\\.breakglass/ticket} {.metadata.annotations.eos\\.breakglass/fingerprint-sha256}{'\\n'}{end}")
fp = cert.fingerprint(hashes.SHA256()).hex()
check("each issuance is recorded on the hub with ticket and certificate fingerprint", "INC0012345" in out and fp[:16] in out.replace(":", "").lower())

# ====================================================================== 9. the file and oc-style use
print("\n== Output file and use")
d = os.stat(os.path.dirname(ALICE_PATH))
check("kubeconfig is written 0600 in a 0700 directory", oct(os.stat(ALICE_PATH).st_mode & 0o777) == "0o600" and oct(d.st_mode & 0o777) == "0o700")
r = subprocess.run([KUBECTL, "auth", "whoami", "-o", "jsonpath={.status.userInfo.username}"], env=dict(os.environ, KUBECONFIG=ALICE_PATH), capture_output=True, text=True)
check("works via KUBECONFIG=<file> (no login step)", r.returncode == 0 and r.stdout.endswith(":alice.smith"), r.stdout or r.stderr[-80:])
rc, out = generate("alice.smith", "lab-2", "eos-cluster-reader")
p = f"{T}/out/lab-2-eos-cluster-reader-alice.smith.kubeconfig"
u = whoami(p) if rc == 0 else out[-120:]
rc2, out2 = kc(p, "auth", "can-i", "delete", "pods")
check("lab-2 reader kubeconfig works on lab-2 and is read-only", isinstance(u, dict) and out2 == "no", out2)

print(f"\n{sum(ok for _, ok, _ in RESULTS)}/{len(RESULTS)} passed")
json.dump([{"test": n, "pass": ok, "detail": d} for n, ok, d in RESULTS], open(f"{T}/results.json", "w"), indent=1)
sys.exit(0 if all(ok for _, ok, _ in RESULTS) else 1)
