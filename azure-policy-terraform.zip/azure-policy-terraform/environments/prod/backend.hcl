resource_group_name  = "rg-tfstate-platform-uks"
storage_account_name = "sttfstateplatformuks"
container_name       = "policy"
key                  = "prod/policy.tfstate"
use_azuread_auth     = true
use_oidc             = true
