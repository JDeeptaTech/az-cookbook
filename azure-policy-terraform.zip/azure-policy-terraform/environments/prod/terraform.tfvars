# Prod ring. Rollout: audit (enforce=false) -> review compliance -> DINE + remediate -> Deny.
provider_subscription_id = "00000000-0000-0000-0000-000000000000"
definition_root_mg_id    = "/providers/Microsoft.Management/managementGroups/contoso"
landing_zones_mg_id      = "/providers/Microsoft.Management/managementGroups/contoso-landingzones"
central_dns_rg_id        = "/subscriptions/22222222-2222-2222-2222-222222222222/resourceGroups/rg-dns-prod-uks"
location                 = "uksouth"

enforce     = false
dns_effect  = "AuditIfNotExists"
deny_effect = "Audit"

# Region used in {regionName}/{regionCode} zone templates (Backup, Data Explorer, AKS)
dns_zone_region      = "uksouth"
dns_zone_region_code = "uks"

# Per-instance SQL MI zones are linked to this VNet
hub_vnet_id = "/subscriptions/22222222-2222-2222-2222-222222222222/resourceGroups/rg-hub-prod-uks/providers/Microsoft.Network/virtualNetworks/vnet-hub-prod-uks"

# Identity from the bootstrap stack (bootstrap/). Remove to fall back to SystemAssigned.
bootstrap_state = {
  resource_group_name  = "rg-tfstate-platform-uks"
  storage_account_name = "sttfstateplatformuks"
  container_name       = "bootstrap"
  key                  = "prod/identity.tfstate"
}
