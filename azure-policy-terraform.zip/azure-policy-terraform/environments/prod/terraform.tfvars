# Prod ring. Rollout: audit (enforce=false) -> review compliance -> DINE + remediate -> Deny.
provider_subscription_id = "00000000-0000-0000-0000-000000000000"
definition_root_mg_id    = "/providers/Microsoft.Management/managementGroups/contoso"
landing_zones_mg_id      = "/providers/Microsoft.Management/managementGroups/contoso-landingzones"
central_dns_rg_id        = "/subscriptions/22222222-2222-2222-2222-222222222222/resourceGroups/rg-dns-prod-uks"
location                 = "uksouth"

enforce     = false
dns_effect  = "AuditIfNotExists"
deny_effect = "Audit"
