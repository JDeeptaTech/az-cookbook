# Canary ring: a parallel MG hierarchy (e.g. contoso-canary) with sandbox/test subs.
# Effects go live here first.
provider_subscription_id = "00000000-0000-0000-0000-000000000000"
definition_root_mg_id    = "/providers/Microsoft.Management/managementGroups/contoso-canary"
landing_zones_mg_id      = "/providers/Microsoft.Management/managementGroups/contoso-canary-landingzones"
central_dns_rg_id        = "/subscriptions/11111111-1111-1111-1111-111111111111/resourceGroups/rg-dns-canary-uks"
location                 = "uksouth"

enforce     = true
dns_effect  = "DeployIfNotExists"
deny_effect = "Deny"

# Region used in {regionName}/{regionCode} zone templates (Backup, Data Explorer, AKS)
dns_zone_region      = "uksouth"
dns_zone_region_code = "uks"
