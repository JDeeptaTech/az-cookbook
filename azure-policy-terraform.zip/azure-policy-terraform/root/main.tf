############################################
# 1. Custom definitions (from lib/definitions)
############################################
module "definitions" {
  source              = "../modules/policy-definitions"
  management_group_id = var.definition_root_mg_id
  definitions_path    = "${path.module}/../lib/definitions"
}

############################################
# 2. Initiative: Private Link DNS integration
############################################
module "init_private_dns" {
  source              = "../modules/policy-initiative"
  name                = "private-link-dns-integration"
  display_name        = "Private Link DNS integration (central zones)"
  description         = "Registers PE A records in central privatelink zones and blocks shadow privatelink zones in landing zones."
  category            = "Network"
  management_group_id = var.definition_root_mg_id

  parameters = {
    privateDnsZoneMap         = { type = "Object", metadata = { displayName = "groupId key => central zone IDs" } }
    centralDnsResourceGroupId = { type = "String", metadata = { displayName = "Central DNS RG ID" } }
    dnsEffect = {
      type          = "String"
      allowedValues = ["DeployIfNotExists", "AuditIfNotExists", "Disabled"]
      defaultValue  = "AuditIfNotExists"
    }
    denyEffect = {
      type          = "String"
      allowedValues = ["Deny", "Audit", "Disabled"]
      defaultValue  = "Audit"
    }
  }

  references = [
    {
      reference_id         = "peDnsZoneGroup"
      policy_definition_id = module.definitions.ids["deploy-pe-dns-zonegroup-central"]
      parameter_values = {
        privateDnsZoneMap         = { value = "[parameters('privateDnsZoneMap')]" }
        centralDnsResourceGroupId = { value = "[parameters('centralDnsResourceGroupId')]" }
        effect                    = { value = "[parameters('dnsEffect')]" }
      }
    },
    {
      reference_id         = "denyShadowZones"
      policy_definition_id = module.definitions.ids["deny-privatelink-dns-zones-outside-hub"]
      parameter_values = {
        effect = { value = "[parameters('denyEffect')]" }
      }
    },
  ]
}

############################################
# 3. Assignment at the Landing Zones MG
#    (connectivity/platform MG sits outside it, so the hub can own the zones)
############################################
locals {
  private_dns_roles = distinct(flatten([
    module.definitions.role_definition_ids["deploy-pe-dns-zonegroup-central"],
  ]))

  zone_map = {
    for key, zones in var.private_dns_zone_names :
    key => [for z in zones : "${var.central_dns_rg_id}/providers/Microsoft.Network/privateDnsZones/${z}"]
  }
}

module "assign_private_dns" {
  source               = "../modules/policy-assignment"
  name                 = "pl-dns-integration"
  display_name         = "Private Link DNS integration"
  management_group_id  = var.landing_zones_mg_id
  policy_definition_id = module.init_private_dns.id
  location             = var.location
  enforce              = var.enforce

  parameters = {
    privateDnsZoneMap         = local.zone_map
    centralDnsResourceGroupId = var.central_dns_rg_id
    dnsEffect                 = var.dns_effect
    denyEffect                = var.deny_effect
  }

  role_definition_ids    = local.private_dns_roles
  additional_role_scopes = [var.central_dns_rg_id]

  non_compliance_message = "Private endpoints must register in the central privatelink zones; privatelink.* zones are not allowed in landing zones."
}
