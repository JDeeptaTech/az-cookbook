output "private_dns_assignment_id" {
  description = "Consumed by the pipeline remediation step."
  value       = module.assign_private_dns.id
}

output "private_dns_remediation_reference_ids" {
  description = "DINE members of the initiative that need remediation tasks."
  value       = local.dine_reference_ids
}

output "remediation_enabled" {
  description = "Remediation only makes sense when enforced and effect is DINE."
  value       = var.enforce && var.dns_effect == "DeployIfNotExists"
}

output "landing_zones_mg_name" {
  value = basename(var.landing_zones_mg_id)
}

output "required_private_dns_zones" {
  description = "Every zone this assignment points at. Feed to the connectivity repo; DINE fails if a zone does not exist."
  value       = local.required_zones
}

output "assignment_identity_roles" {
  description = "Roles granted to the assignment identity (review: Contributor must not appear unless intended)."
  value       = local.dine_roles
}

output "required_role_bindings" {
  description = "Grants the remediation identity needs. Keep bootstrap remediation_role_bindings in sync with this list."
  value       = module.assign_private_dns.required_role_bindings
}

output "remediation_identity_mode" {
  value = local.remediation_identity_id == null ? "SystemAssigned" : "UserAssigned"
}
