output "private_dns_assignment_id" {
  description = "Consumed by the pipeline remediation step."
  value       = module.assign_private_dns.id
}

output "private_dns_remediation_reference_ids" {
  description = "DINE members of the initiative that need remediation tasks."
  value       = ["peDnsZoneGroup"]
}

output "remediation_enabled" {
  description = "Remediation only makes sense when enforced and effect is DINE."
  value       = var.enforce && var.dns_effect == "DeployIfNotExists"
}

output "landing_zones_mg_name" {
  value = basename(var.landing_zones_mg_id)
}
