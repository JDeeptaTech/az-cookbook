variable "definition_root_mg_id" {
  description = "MG hosting definitions/initiatives (intermediate root of this ring)."
  type        = string
}

variable "landing_zones_mg_id" {
  description = "MG where the initiative is assigned."
  type        = string
}

variable "central_dns_rg_id" {
  description = "Resource ID of the RG holding the central privatelink zones (connectivity sub)."
  type        = string
}

variable "location" {
  type    = string
  default = "uksouth"
}

variable "enforce" {
  description = "Assignment enforcement mode. Start false (DoNotEnforce) and flip per ring."
  type        = bool
  default     = false
}

variable "dns_effect" {
  type    = string
  default = "AuditIfNotExists"
  validation {
    condition     = contains(["DeployIfNotExists", "AuditIfNotExists", "Disabled"], var.dns_effect)
    error_message = "dns_effect must be DeployIfNotExists, AuditIfNotExists or Disabled."
  }
}

variable "deny_effect" {
  type    = string
  default = "Audit"
  validation {
    condition     = contains(["Deny", "Audit", "Disabled"], var.deny_effect)
    error_message = "deny_effect must be Deny, Audit or Disabled."
  }
}

variable "private_dns_zone_names" {
  description = "Key '<provider>/<type>/<groupId>' (lowercase) => list of zone names in the central RG."
  type        = map(list(string))
  default = {
    "microsoft.containerregistry/registries/registry" = ["privatelink.azurecr.io"]
    "microsoft.insights/privatelinkscopes/azuremonitor" = [
      "privatelink.monitor.azure.com",
      "privatelink.oms.opinsights.azure.com",
      "privatelink.ods.opinsights.azure.com",
      "privatelink.agentsvc.azure-automation.net",
      "privatelink.blob.core.windows.net",
    ]
    "microsoft.storage/storageaccounts/blob"            = ["privatelink.blob.core.windows.net"]
    "microsoft.storage/storageaccounts/blob_secondary"  = ["privatelink.blob.core.windows.net"]
    "microsoft.storage/storageaccounts/file"            = ["privatelink.file.core.windows.net"]
    "microsoft.storage/storageaccounts/queue"           = ["privatelink.queue.core.windows.net"]
    "microsoft.storage/storageaccounts/queue_secondary" = ["privatelink.queue.core.windows.net"]
    "microsoft.storage/storageaccounts/table"           = ["privatelink.table.core.windows.net"]
    "microsoft.storage/storageaccounts/table_secondary" = ["privatelink.table.core.windows.net"]
    "microsoft.storage/storageaccounts/dfs"             = ["privatelink.dfs.core.windows.net"]
    "microsoft.storage/storageaccounts/dfs_secondary"   = ["privatelink.dfs.core.windows.net"]
    "microsoft.storage/storageaccounts/web"             = ["privatelink.web.core.windows.net"]
    "microsoft.storage/storageaccounts/web_secondary"   = ["privatelink.web.core.windows.net"]
  }
}
