variable "definition_root_mg_id" {
  description = "MG hosting definitions/initiatives (intermediate root of this ring)."
  type        = string
}

variable "landing_zones_mg_id" {
  description = "MG where the initiative is assigned."
  type        = string
}

variable "central_dns_rg_id" {
  description = "Resource ID of the RG holding the central privatelink zones (connectivity sub)."
  type        = string
}

variable "location" {
  type    = string
  default = "uksouth"
}

variable "enforce" {
  description = "Assignment enforcement mode. Start false (DoNotEnforce) and flip per ring."
  type        = bool
  default     = false
}

variable "dns_effect" {
  type    = string
  default = "AuditIfNotExists"
  validation {
    condition     = contains(["DeployIfNotExists", "AuditIfNotExists", "Disabled"], var.dns_effect)
    error_message = "dns_effect must be DeployIfNotExists, AuditIfNotExists or Disabled."
  }
}

variable "deny_effect" {
  type    = string
  default = "Audit"
  validation {
    condition     = contains(["Deny", "Audit", "Disabled"], var.deny_effect)
    error_message = "deny_effect must be Deny, Audit or Disabled."
  }
}

############################################
# Private DNS: built-ins
############################################
variable "dns_zone_region" {
  description = "Region substituted into {regionName} zone templates (e.g. Data Explorer, AKS)."
  type        = string
  default     = "uksouth"
}

variable "dns_zone_region_code" {
  description = "Short code substituted into {regionCode} zone templates (Backup: privatelink.<code>.backup.windowsazure.com)."
  type        = string
  default     = "uks"
}

variable "exclude_deprecated" {
  description = "Skip built-ins Microsoft has marked deprecated (currently Media Services)."
  type        = bool
  default     = true
}

variable "exclude_preview" {
  description = "Skip preview built-ins (currently Backup and Site Recovery)."
  type        = bool
  default     = false
}

variable "private_dns_builtin_exclude" {
  description = <<-EOT
    Catalog reference IDs to leave out.
    - IoT (4): declare the full Contributor role, which would be granted to the
      assignment identity at the Landing Zones MG. Re-enable only if you run them
      and accept that grant.
    - Storage-Table: matches groupId 'table' with no provider check, so it also
      fires on Cosmos DB Table API endpoints and races Cosmos-Table. Covered by the
      provider-aware custom DINE instead (see private_dns_custom_zones).
    - DataFactory-Portal: matches groupId 'portal' with no provider check, so it
      would register Purview portal endpoints in privatelink.adf.azure.com.
      Covered by the custom DINE instead.
  EOT
  type        = list(string)
  default = [
    "DINE-Private-DNS-Azure-IoT",
    "DINE-Private-DNS-Azure-IoTCentral",
    "DINE-Private-DNS-Azure-IoTDeviceupdate",
    "DINE-Private-DNS-Azure-IoTHubs",
    "DINE-Private-DNS-Azure-Storage-Table",
    "DINE-Private-DNS-Azure-DataFactory-Portal",
  ]
}

############################################
# Private DNS: services with no built-in (custom generic DINE)
############################################
variable "private_dns_custom_zones" {
  description = <<-EOT
    Key '<provider>/<type>/<groupId>' (lowercase) => zone names in the central RG.
    Only for groupIds no enabled built-in handles; the plan fails on overlap.
  EOT
  type        = map(list(string))
  default = {
    # Built-in exists but is unsafe (groupId-only match); see private_dns_builtin_exclude
    "microsoft.storage/storageaccounts/table" = ["privatelink.table.core.windows.net"]
    "microsoft.datafactory/factories/portal"  = ["privatelink.adf.azure.com"]

    # No built-in exists
    "microsoft.sql/servers/sqlserver"                            = ["privatelink.database.windows.net"]
    "microsoft.dbforpostgresql/flexibleservers/postgresqlserver" = ["privatelink.postgres.database.azure.com"]
    "microsoft.dbformysql/flexibleservers/mysqlserver"           = ["privatelink.mysql.database.azure.com"]
    "microsoft.apimanagement/service/gateway"                    = ["privatelink.azure-api.net"]
    "microsoft.purview/accounts/account"                         = ["privatelink.purview.azure.com"]
    "microsoft.purview/accounts/portal"                          = ["privatelink.purviewstudio.azure.com"]
  }
  validation {
    condition     = alltrue([for k in keys(var.private_dns_custom_zones) : length(split("/", k)) == 3 && k == lower(k)])
    error_message = "Keys must be lowercase '<provider>/<type>/<groupId>'."
  }
}
