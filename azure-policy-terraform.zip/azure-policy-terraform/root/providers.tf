terraform {
  required_version = ">= 1.6"

  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "~> 4.0"
    }
  }

  # Values supplied per environment: -backend-config=../environments/<env>/backend.hcl
  backend "azurerm" {}
}

provider "azurerm" {
  features {}
  # Policy/RBAC work is tenant/MG-scoped; this sub is only the provider's "home".
  subscription_id                 = var.provider_subscription_id
  resource_provider_registrations = "none"
  storage_use_azuread             = true
  # Auth: OIDC via ADO workload identity federation (ARM_USE_OIDC etc. set by pipeline).
}

variable "provider_subscription_id" {
  description = "Any subscription the pipeline identity can read (usually management/platform sub)."
  type        = string
}
