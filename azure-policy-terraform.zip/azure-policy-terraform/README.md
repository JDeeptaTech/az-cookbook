# azure-policy-terraform

Policy-as-code for Azure Policy, deployed from Azure DevOps with Terraform.

```
.
├── lib/definitions/<category>/*.json   # custom policy definitions, native Azure JSON shape
├── lib/builtin-private-dns/            # GENERATED catalog of built-in zone-group DINEs (+ .md matrix)
├── modules/
│   ├── policy-definitions/             # loads lib/definitions -> azurerm_policy_definition
│   ├── policy-initiative/              # azurerm_policy_set_definition
│   └── policy-assignment/              # MG assignment + MI + RBAC (incl. out-of-scope RGs)
├── root/                               # single composition: definitions -> initiatives -> assignments
├── environments/
│   ├── canary/{terraform.tfvars,backend.hcl}   # parallel canary MG hierarchy
│   └── prod/{terraform.tfvars,backend.hcl}
└── pipelines/
    ├── azure-pipelines-pr.yml          # fmt, validate, tflint, policy JSON check, checkov, plan x2
    ├── azure-pipelines-cd.yml          # canary -> (approval) -> prod, then remediation
    └── templates/
```

## Rollout model (audit -> remediate -> enforce)

| Phase | `enforce` | `dns_effect` | `deny_effect` |
|---|---|---|---|
| 1. Observe | false | AuditIfNotExists | Audit |
| 2. Remediate | true | DeployIfNotExists | Audit |
| 3. Enforce | true | DeployIfNotExists | Deny |

Each phase lands in canary first. Prod only moves after canary compliance looks right.

## ADO setup

| Item | Name | Notes |
|---|---|---|
| Service connections (WIF) | `sc-policy-canary`, `sc-policy-prod` | Identity needs **Resource Policy Contributor** + **User Access Administrator** (or RBAC Admin constrained to Network Contributor) on the definition root MG, plus RBAC write on the central DNS RG. |
| Variable groups | `tf-policy-common` | `SC_ID_CANARY`, `SC_ID_PROD` (service connection GUIDs) |
| | `tf-policy-canary`, `tf-policy-prod` | `ARM_CLIENT_ID`, `ARM_TENANT_ID` |
| Environments | `policy-canary`, `policy-prod` | Approvals + exclusive lock on prod |
| Branch policy | `main` | Build validation = PR pipeline; min 2 reviewers; CODEOWNERS on `lib/` + `environments/prod/` |
| State | `sttfstateplatformuks` / container `policy` | Entra ID auth only (shared key disabled), versioning + soft delete, private endpoint |

## Adding a policy

1. Drop the JSON into `lib/definitions/<category>/`.
2. Reference it from an initiative in `root/main.tf`. Assign initiatives, not loose definitions.
3. Open a PR. The speculative plan for both rings shows on the PR.

## Private Link DNS initiative

One initiative, assigned at the Landing Zones MG:

| Part | Covers | Source |
|---|---|---|
| 50 built-in DINE policies | ~40 services (Key Vault, Cosmos, Event Hubs, Service Bus, ACR, AMPLS, Storage, Synapse, Databricks, ML, AVD, Arc, ...) | `lib/builtin-private-dns/catalog.json` |
| Custom generic DINE | Services with no built-in (SQL, PostgreSQL, MySQL, APIM, Purview) **and** built-ins that are unsafe to combine (Storage table, Data Factory portal) | `var.private_dns_custom_zones` |
| Custom deny | `privatelink.*` zones created inside landing zones | `lib/definitions/network/` |

Full list with IDs, versions and zones: [`lib/builtin-private-dns/catalog.md`](lib/builtin-private-dns/catalog.md).

### Excluded by default (`private_dns_builtin_exclude`)

| Built-in | Why |
|---|---|
| IoT Hub, IoT DPS, IoT Central, Device Update | Declare **Contributor**; that role would be granted to the assignment identity across Landing Zones |
| Storage table | Matches groupId `table` with no provider check, so it also fires on Cosmos DB Table API endpoints and races the Cosmos built-in |
| Data Factory portal | Matches groupId `portal` with no provider check, so it would register Purview portal endpoints in the ADF zone |
| Media Services (3) | Deprecated (`exclude_deprecated`) |

Plan-time guards fail the build if a catalog regeneration or a tfvars change reintroduces either kind of collision.

### Refreshing the catalog

```bash
git clone --depth 1 --filter=blob:none --sparse https://github.com/Azure/azure-policy.git
git -C azure-policy sparse-checkout set built-in-policies/policyDefinitions
git clone --depth 1 --filter=blob:none --sparse https://github.com/Azure/Azure-Landing-Zones-Library.git
git -C Azure-Landing-Zones-Library sparse-checkout set platform/alz
python3 scripts/generate-private-dns-catalog.py --policy-repo azure-policy --alz-repo Azure-Landing-Zones-Library
```

Review the `catalog.md` diff in the PR. The speculative plan shows any new references, parameters or roles.

### Zones must exist first

`terraform output required_private_dns_zones` lists every zone the assignment points at. Create them, with hub VNet links, in the connectivity repo before switching `dns_effect` to DeployIfNotExists; otherwise remediation deployments fail.
