# azure-policy-terraform

Policy-as-code for Azure Policy, deployed from Azure DevOps with Terraform.

```
.
├── lib/definitions/<category>/*.json   # custom policy definitions, native Azure JSON shape
├── modules/
│   ├── policy-definitions/             # loads lib/definitions -> azurerm_policy_definition
│   ├── policy-initiative/              # azurerm_policy_set_definition
│   └── policy-assignment/              # MG assignment + MI + RBAC (incl. out-of-scope RGs)
├── root/                               # single composition: definitions -> initiatives -> assignments
├── environments/
│   ├── canary/{terraform.tfvars,backend.hcl}   # parallel canary MG hierarchy
│   └── prod/{terraform.tfvars,backend.hcl}
└── pipelines/
    ├── azure-pipelines-pr.yml          # fmt, validate, tflint, policy JSON check, checkov, plan x2
    ├── azure-pipelines-cd.yml          # canary -> (approval) -> prod, then remediation
    └── templates/
```

## Rollout model (audit -> remediate -> enforce)

| Phase | `enforce` | `dns_effect` | `deny_effect` |
|---|---|---|---|
| 1. Observe | false | AuditIfNotExists | Audit |
| 2. Remediate | true | DeployIfNotExists | Audit |
| 3. Enforce | true | DeployIfNotExists | Deny |

Each phase lands in canary first. Prod only moves after canary compliance looks right.

## ADO setup

| Item | Name | Notes |
|---|---|---|
| Service connections (WIF) | `sc-policy-canary`, `sc-policy-prod` | Identity needs **Resource Policy Contributor** + **User Access Administrator** (or RBAC Admin constrained to Network Contributor) on the definition root MG, plus RBAC write on the central DNS RG. |
| Variable groups | `tf-policy-common` | `SC_ID_CANARY`, `SC_ID_PROD` (service connection GUIDs) |
| | `tf-policy-canary`, `tf-policy-prod` | `ARM_CLIENT_ID`, `ARM_TENANT_ID` |
| Environments | `policy-canary`, `policy-prod` | Approvals + exclusive lock on prod |
| Branch policy | `main` | Build validation = PR pipeline; min 2 reviewers; CODEOWNERS on `lib/` + `environments/prod/` |
| State | `sttfstateplatformuks` / container `policy` | Entra ID auth only (shared key disabled), versioning + soft delete, private endpoint |

## Adding a policy

1. Drop the JSON into `lib/definitions/<category>/`.
2. Reference it from an initiative in `root/main.tf`. Assign initiatives, not loose definitions.
3. Open a PR. The speculative plan for both rings shows on the PR.
