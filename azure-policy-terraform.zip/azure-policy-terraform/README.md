# azure-policy-terraform

Policy-as-code for Azure Policy, deployed from Azure DevOps with Terraform.

```
.
├── lib/definitions/<category>/*.json   # custom policy definitions, native Azure JSON shape
├── lib/builtin-private-dns/            # GENERATED catalog of built-in zone-group DINEs (+ .md matrix)
├── modules/
│   ├── policy-definitions/             # loads lib/definitions -> azurerm_policy_definition
│   ├── policy-initiative/              # azurerm_management_group_policy_set_definition
│   └── policy-assignment/              # MG assignment + MI + RBAC (incl. out-of-scope RGs)
├── bootstrap/                          # PRIVILEGED, human via PIM: pipeline + remediation identities, all role grants
├── root/                               # single composition: definitions -> initiatives -> assignments
├── environments/
│   ├── canary/{terraform.tfvars,backend.hcl}   # parallel canary MG hierarchy
│   └── prod/{terraform.tfvars,backend.hcl}
├── scripts/
│   ├── generate-private-dns-catalog.py # rebuilds lib/builtin-private-dns from Microsoft repos
│   └── az-cli/pldns-test.sh            # az CLI end-to-end test: one test sub + DNS in a shared sub (no Terraform)
└── pipelines/
    ├── azure-pipelines-pr.yml          # fmt, validate, tflint, policy JSON check, checkov, plan x2
    ├── azure-pipelines-cd.yml          # canary -> (approval) -> prod, then remediation
    └── templates/
```

## Rollout model (audit -> remediate -> enforce)

| Phase | `enforce` | `dns_effect` | `deny_effect` |
|---|---|---|---|
| 1. Observe | false | AuditIfNotExists | Audit |
| 2. Remediate | true | DeployIfNotExists | Audit |
| 3. Enforce | true | DeployIfNotExists | Deny |

Each phase lands in canary first. Prod only moves after canary compliance looks right.

## ADO setup

| Item | Name | Notes |
|---|---|---|
| Service connections (WIF) | `sc-policy-canary`, `sc-policy-prod` | Backed by the bootstrap's `id-policy-pipeline-<ring>` managed identity, Entra issuer. Roles: see [Identities](#identities). No role-assignment rights. |
| Variable groups | `tf-policy-common` | `SC_ID_CANARY`, `SC_ID_PROD` (service connection GUIDs) |
| | `tf-policy-canary`, `tf-policy-prod` | `ARM_CLIENT_ID` = bootstrap `pipeline_client_id`, `ARM_TENANT_ID` |
| Environments | `policy-canary`, `policy-prod` | Approvals + exclusive lock on prod |
| Branch policy | `main` | Build validation = PR pipeline; min 2 reviewers; CODEOWNERS on `lib/` + `environments/prod/` |
| State | `sttfstateplatformuks` / container `policy` | Entra ID auth only (shared key disabled), versioning + soft delete, private endpoint |

## Identities

Two identities per ring, both user-assigned managed identities created by `bootstrap/`. Neither has a secret.

| | Pipeline identity `id-policy-pipeline-<ring>` | Remediation identity `id-policy-remediation-<ring>` |
|---|---|---|
| Used by | ADO service connection (workload identity federation) | The policy assignment. DeployIfNotExists deployments run as it |
| Does | Creates definitions, initiatives, assignments, exemptions; starts remediation tasks | Writes zone groups, A records, per-instance SQL MI zones and links |
| Roles | Resource Policy Contributor @ ring root MG · Managed Identity Operator @ the remediation identity only · Storage Blob Data Contributor @ policy state container · Storage Blob Data Reader @ bootstrap state container | Exactly `terraform output required_role_bindings` from the policy stack (6 grants today: Network Contributor, Private DNS Zone Contributor, Reader across the Landing Zones MG, the DNS RG and the hub VNet) |
| Cannot | Grant roles, read data, touch workloads | Run outside policy deployments; Owner/Contributor/UAA are blocked by validation |

The pipeline holds no role-assignment rights. A policy change that needs a new grant fails the **plan** with the missing grants listed; a human adds them to `bootstrap/environments/<ring>/terraform.tfvars` and applies the bootstrap through PIM. New permissions always pass a privileged review.

### First-time setup per ring

1. **Draft the service connection.** ADO → Project settings → Service connections → New → Azure Resource Manager → *App registration or Managed identity (manual)* → *Workload identity federation*. Name it `sc-policy-<ring>`, scope Management Group, then **Keep as draft**. Copy the *Issuer* and *Subject identifier*. New connections use the Entra issuer; the `vstoken.dev.azure.com` issuer retires on 2027-07-01 and the bootstrap rejects it.
2. **Fill `bootstrap/environments/<ring>/terraform.tfvars`.** Paste the issuer and subject; set subscription and state container IDs.
3. **Apply the bootstrap** as a human with Owner (or User Access Administrator + Managed Identity Contributor) activated through PIM on the ring's root MG:
   ```bash
   cd bootstrap
   terraform init -backend-config=environments/<ring>/backend.hcl
   terraform apply -var-file=environments/<ring>/terraform.tfvars
   terraform output pipeline_client_id
   ```
4. **Finish the service connection.** Enter the tenant ID and `pipeline_client_id` as *Application (client) ID*, then **Verify and save**. Put the same client ID in `tf-policy-<ring>` as `ARM_CLIENT_ID`.
5. **Run the CD pipeline.** The policy stack reads the remediation identity and its grants from the bootstrap state (`bootstrap_state` in tfvars). Its plan fails if a grant is missing.

### Fallback: SystemAssigned

Remove `bootstrap_state` from the ring's tfvars and the assignment uses a system-assigned identity that the policy stack grants itself. The pipeline then needs `roleAssignments/write`: set `pipeline_can_grant_remediation_roles = true` in the bootstrap, which grants RBAC Administrator on each remediation scope, constrained by an ABAC condition to exactly the remediation roles and to service principals only. This is weaker: a recreated assignment gets a new principal, and the pipeline can grant roles.

## Adding a policy

1. Drop the JSON into `lib/definitions/<category>/`.
2. Reference it from an initiative in `root/main.tf`. Assign initiatives, not loose definitions.
3. Open a PR. The speculative plan for both rings shows on the PR.

## Private Link DNS initiative

One initiative, assigned at the Landing Zones MG:

| Part | Covers | Source |
|---|---|---|
| 50 built-in DINE policies | ~40 services (Key Vault, Cosmos, Event Hubs, Service Bus, ACR, AMPLS, Storage, Synapse, Databricks, ML, AVD, Arc, ...) | `lib/builtin-private-dns/catalog.json` |
| Custom generic DINE | Services with no built-in (SQL, PostgreSQL, MySQL, APIM, Purview) **and** built-ins that are unsafe to combine (Storage table, Data Factory portal) | `var.private_dns_custom_zones` |
| Custom deny | `privatelink.*` zones created inside landing zones | `lib/definitions/network/` |

Full list with IDs, versions and zones: [`lib/builtin-private-dns/catalog.md`](lib/builtin-private-dns/catalog.md).

### Excluded by default (`private_dns_builtin_exclude`)

| Built-in | Why |
|---|---|
| IoT Hub, IoT DPS, IoT Central, Device Update | Declare **Contributor**; that role would be granted to the assignment identity across Landing Zones |
| Storage table | Matches groupId `table` with no provider check, so it also fires on Cosmos DB Table API endpoints and races the Cosmos built-in |
| Data Factory portal | Matches groupId `portal` with no provider check, so it would register Purview portal endpoints in the ADF zone |
| Media Services (3) | Deprecated (`exclude_deprecated`) |

Plan-time guards fail the build if a catalog regeneration or a tfvars change reintroduces either kind of collision.

### Refreshing the catalog

```bash
git clone --depth 1 --filter=blob:none --sparse https://github.com/Azure/azure-policy.git
git -C azure-policy sparse-checkout set built-in-policies/policyDefinitions
git clone --depth 1 --filter=blob:none --sparse https://github.com/Azure/Azure-Landing-Zones-Library.git
git -C Azure-Landing-Zones-Library sparse-checkout set platform/alz
python3 scripts/generate-private-dns-catalog.py --policy-repo azure-policy --alz-repo Azure-Landing-Zones-Library
```

Review the `catalog.md` diff in the PR. The speculative plan shows any new references, parameters or roles.

### Zones must exist first

`terraform output required_private_dns_zones` lists every zone the assignment points at. Create them, with hub VNet links, in the connectivity repo before switching `dns_effect` to DeployIfNotExists; otherwise remediation deployments fail.

### SQL Managed Instance (`lib/definitions/network/deploy-pe-dns-sqlmi.json`)

Managed Instance needs its own policy. Microsoft gives each instance its own zone, `privatelink.<dnsZone>.database.windows.net`, and documents that automatic DNS registration "isn't yet supported". For each MI private endpoint, the policy:

1. Reads the instance's `dnsZone` and subnet with `reference()` at deploy time.
2. Creates the per-instance zone in the central DNS RG and links it to the hub VNet, if missing.
3. Writes the `<instance-name>` A record pointing at the endpoint NIC's IP.
4. Adds a `deployedByPolicy` zone group on the endpoint as the compliance marker.

Grants beyond the shared ones: Reader on the Landing Zones MG, and Network Contributor on the hub VNet (for the zone link).

**Constraints:**
- **Same-VNet endpoints are skipped on purpose.** Microsoft warns that a zone with this name inside the instance's own VNet breaks MI management operations. Those endpoints stay non-compliant, so give them a policy exemption.
- **The instance's own VNet must not resolve through the hub resolver**, or it will pick up these zones. Keep the MI VNet on Azure-provided DNS and add DNS forwarding-ruleset rules for any other zones it needs. Test this before enforcing.
- **The A record outlives the endpoint.** If an endpoint is deleted for good, the record remains; recreating the endpoint overwrites it.
- **The connectivity repo must not manage `privatelink.*.database.windows.net` per-instance zones.** The policy owns them, tagged `managedBy=azure-policy/deploy-pe-dns-sqlmi`.

## Testing without Terraform (`scripts/az-cli/pldns-test.sh`)

Builds the same initiative from `catalog.json` and `lib/definitions`, assigns it to one test subscription, and keeps the zones in a shared subscription. Use it for the POC before the pipeline exists. Needs bash 4+, az and jq (Azure Cloud Shell has all three).

```bash
cd scripts/az-cli
cp pldns-test.env.example pldns-test.env   # set TEST_SUB, SHARED_SUB, names
./pldns-test.sh infra       # zones (shared), VNet, VM, storage + a PRE-EXISTING queue endpoint
./pldns-test.sh identity    # deployer SPN (24h secret) + remediation UAMI + all RBAC
./pldns-test.sh deploy      # runs AS THE SPN: definitions, initiative, assignment
./pldns-test.sh deny-test   # waits until the assignment is live; spoke privatelink zone must be denied
./pldns-test.sh pe          # blob, file, table, Key Vault, ACR, SQL (+ Cosmos Table if listed)
./pldns-test.sh verify      # zone group, central zone, A record = endpoint IP, VM name resolution
./pldns-test.sh remediate   # runs AS THE SPN: scan + remediation fixes the pre-existing queue endpoint
./pldns-test.sh verify      # everything PASS
./pldns-test.sh rbac-check  # SPN and UAMI hold only the expected roles
./pldns-test.sh down        # removes everything it created (zones only with PURGE_DNS=true)
```

Covers acceptance criteria POC-03, POC-05 to POC-09, POC-11, POC-14 and POC-15. Zones are linked straight to the test VNet, so the hub resolver path (POC-17, POC-18) is only exercised if `HUB_VNET_ID` is set and a client resolves through the resolver.
