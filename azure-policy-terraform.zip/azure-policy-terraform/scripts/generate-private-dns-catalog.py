#!/usr/bin/env python3
"""
Build lib/builtin-private-dns/catalog.json: every Microsoft built-in policy that
deploys Microsoft.Network/privateEndpoints/privateDnsZoneGroups, with the zone
each parameter needs.

Sources (both Microsoft-maintained):
  --policy-repo  clone of github.com/Azure/azure-policy        (definition metadata)
  --alz-repo     clone of github.com/Azure/Azure-Landing-Zones-Library
                 (Deploy-Private-DNS-Zones initiative = zone-name mapping)

Re-run when either repo moves; review the diff in a PR like any other change.

  git clone --depth 1 --filter=blob:none --sparse https://github.com/Azure/azure-policy.git
  git -C azure-policy sparse-checkout set built-in-policies/policyDefinitions
  git clone --depth 1 --filter=blob:none --sparse https://github.com/Azure/Azure-Landing-Zones-Library.git
  git -C Azure-Landing-Zones-Library sparse-checkout set platform/alz
  python3 scripts/generate-private-dns-catalog.py --policy-repo azure-policy --alz-repo Azure-Landing-Zones-Library
"""
import argparse
import json
import pathlib
import re
import sys

ZONE_KEY_RE = re.compile(r"parameters\('dnsZoneNames'\)\.(\w+)")
ZONE_GROUP_TYPE = "microsoft.network/privateendpoints/privatednszonegroups"


def load(p):
    with open(p, encoding="utf-8-sig") as f:
        return json.load(f)


def deploys_zone_group(defn):
    rule = defn["properties"].get("policyRule", {})
    details = rule.get("then", {}).get("details", {})
    if not isinstance(details, dict):
        return False
    if str(details.get("type", "")).lower() == ZONE_GROUP_TYPE:
        return True
    tmpl = details.get("deployment", {}).get("properties", {}).get("template", {})
    return ZONE_GROUP_TYPE in json.dumps(tmpl).lower()


def matched_group_ids(defn):
    """Literal groupId values the rule matches on, best effort."""
    ids = set()

    def walk(n):
        if isinstance(n, dict):
            f = str(n.get("field", ""))
            if f.endswith("groupIds[*]"):
                for op in ("equals", "in"):
                    v = n.get(op)
                    if isinstance(v, str) and not v.startswith("["):
                        ids.add(v)
                    elif isinstance(v, list):
                        ids.update(x for x in v if isinstance(x, str))
            for v in n.values():
                walk(v)
        elif isinstance(n, list):
            for v in n:
                walk(v)

    walk(defn["properties"]["policyRule"]["if"])
    return sorted(ids)


def provider_filters(defn):
    """Lowercased 'contains' values on privateLinkServiceId in the if-block.
    Empty => the policy matches on groupId alone and will act on ANY service
    exposing that groupId."""
    out = set()

    def walk(n):
        if isinstance(n, dict):
            if str(n.get("field", "")).endswith("privateLinkServiceId"):
                for op in ("contains", "like", "equals"):
                    v = n.get(op)
                    if isinstance(v, str) and not v.startswith("["):
                        out.add(v.lower().strip("*"))
            for v in n.values():
                walk(v)
        elif isinstance(n, list):
            for v in n:
                walk(v)

    walk(defn["properties"]["policyRule"]["if"])
    return sorted(out)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--policy-repo", required=True)
    ap.add_argument("--alz-repo", required=True)
    ap.add_argument("--out", default=str(pathlib.Path(__file__).resolve().parent.parent / "lib/builtin-private-dns"))
    a = ap.parse_args()

    # 1. Every built-in that deploys a zone group
    builtins = {}
    for p in pathlib.Path(a.policy_repo, "built-in-policies/policyDefinitions").rglob("*.json"):
        try:
            d = load(p)
        except (json.JSONDecodeError, UnicodeDecodeError):
            continue
        if "properties" not in d or not deploys_zone_group(d):
            continue
        props = d["properties"]
        md = props.get("metadata", {})
        builtins[d["name"]] = {
            "definition_id": f"/providers/Microsoft.Authorization/policyDefinitions/{d['name']}",
            "display_name": props["displayName"],
            "category": md.get("category", ""),
            "version": md.get("version", props.get("version", "")),
            "deprecated": bool(md.get("deprecated", False)),
            "preview": bool(md.get("preview", False)),
            "group_ids_matched": matched_group_ids(d),
            "provider_filter": provider_filters(d),
            "role_definition_ids": props["policyRule"]["then"]["details"].get("roleDefinitionIds", []),
            "parameters": sorted(k for k in props.get("parameters", {}) if k != "effect"),
            "source": str(p.relative_to(a.policy_repo)),
        }

    # 2. ALZ mapping: reference -> definition + param wiring + zone name template
    alz = pathlib.Path(a.alz_repo, "platform/alz")
    pset = load(alz / "policy_set_definitions/Deploy-Private-DNS-Zones.alz_policy_set_definition.json")
    zone_names = pset["properties"]["parameters"]["dnsZoneNames"]["defaultValue"]

    references = []
    used = set()
    for ref in pset["properties"]["policyDefinitions"]:
        guid = ref["policyDefinitionId"].rsplit("/", 1)[-1]
        b = builtins.get(guid)
        if b is None:
            print(f"WARN ALZ ref {ref['policyDefinitionReferenceId']} -> {guid} is not a zone-group built-in", file=sys.stderr)
            continue
        used.add(guid)
        zone_params, fixed_params = {}, {}
        for pname, pval in ref.get("parameters", {}).items():
            v = pval.get("value")
            if pname == "effect":
                continue
            if isinstance(v, str) and (m := ZONE_KEY_RE.search(v)):
                zone_params[pname] = {"zone_key": m.group(1), "zone_name": zone_names[m.group(1)]}
            elif isinstance(v, str) and v.startswith("[") and "parameters(" in v:
                print(f"WARN {ref['policyDefinitionReferenceId']}.{pname}: unhandled expression", file=sys.stderr)
            else:
                fixed_params[pname] = v
        references.append({
            "reference_id": ref["policyDefinitionReferenceId"],
            **{k: b[k] for k in ("definition_id", "display_name", "category", "version", "deprecated", "preview", "group_ids_matched", "provider_filter", "role_definition_ids")},
            "zone_parameters": zone_params,
            "fixed_parameters": fixed_params,
        })

    not_in_alz = [
        {"name": g, **{k: v for k, v in b.items() if k in ("display_name", "category", "version", "deprecated", "preview", "parameters", "source")}}
        for g, b in sorted(builtins.items(), key=lambda kv: (kv[1]["category"], kv[1]["display_name"]))
        if g not in used
    ]

    out = pathlib.Path(a.out)
    out.mkdir(parents=True, exist_ok=True)
    catalog = {
        "generated_from": {
            "alz_initiative_version": pset["properties"]["metadata"].get("version"),
            "builtin_zone_group_policies": len(builtins),
        },
        "references": sorted(references, key=lambda r: (r["category"], r["reference_id"])),
        "builtins_not_in_alz": not_in_alz,
    }
    (out / "catalog.json").write_text(json.dumps(catalog, indent=2) + "\n")

    # Human-readable matrix, reviewed in PRs alongside the JSON
    rows = ["| Reference ID | Category | Built-in ID | Ver | Zones | Match | Status |", "|---|---|---|---|---|---|---|"]
    for r in catalog["references"]:
        gids = sorted(set(r["group_ids_matched"]) | {str(x) for k, v in r["fixed_parameters"].items() for x in (v if isinstance(v, list) else [v])})
        if gids:
            match = "groupId " + ",".join(gids) + (" + provider" if r["provider_filter"] else " **(no provider check)**")
        else:
            match = "provider only" if r["provider_filter"] else "parameterised"
        status = "deprecated" if r["deprecated"] else ("preview" if r["preview"] else "")
        zones = "<br>".join(z["zone_name"] for z in r["zone_parameters"].values())
        rows.append(f"| {r['reference_id']} | {r['category']} | `{r['definition_id'].rsplit('/', 1)[-1]}` | {r['version']} | {zones} | {match} | {status} |")
    rows += ["", "## Zone-group built-ins ALZ does not map", "", "| Built-in ID | Category | Name | Parameters |", "|---|---|---|---|"]
    rows += [f"| `{b['name']}` | {b['category']} | {b['display_name']} | {', '.join(b['parameters'])} |" for b in not_in_alz]
    (out / "catalog.md").write_text(f"# Built-in private DNS zone-group policies\n\nGenerated by scripts/generate-private-dns-catalog.py from ALZ Deploy-Private-DNS-Zones v{catalog['generated_from']['alz_initiative_version']}. Do not edit by hand.\n\n" + "\n".join(rows) + "\n")
    print(f"{len(references)} references, {len(builtins)} zone-group built-ins, {len(not_in_alz)} not mapped by ALZ -> {out/'catalog.json'}")


if __name__ == "__main__":
    main()
