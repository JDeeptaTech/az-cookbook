#!/usr/bin/env bash
# Resolve built-in IDs (by displayName, so no stale GUIDs), create custom defs,
# assign at subscription scope, and grant the MI rights on the central DNS RG.
set -euo pipefail

TARGET_SUB="${TARGET_SUB:?spoke subscription id}"
DNS_RG_ID="${DNS_RG_ID:?/subscriptions/<conn-sub>/resourceGroups/rg-dns}"
LOCATION="${LOCATION:-uksouth}"
SCOPE="/subscriptions/${TARGET_SUB}"

echo "== Built-in DINE policies for ACR / AMPLS / Storage =="
az policy definition list --query "[?policyType=='BuiltIn' && (
  displayName=='Configure Container registries to use private DNS zones' ||
  displayName=='Configure Azure Monitor Private Link Scope to use private DNS zones' ||
  starts_with(displayName, 'Configure a private DNS Zone ID for'))]
  .{id:name, name:displayName, params:join(',', keys(parameters))}" -o table

# --- Custom definitions ---
az policy definition create --subscription "$TARGET_SUB" \
  --name deploy-pe-dns-zonegroup-central \
  --display-name "Deploy PE DNS zone group to central zones (ACR/AMPLS/Storage)" \
  --mode Indexed \
  --rules <(jq '.properties.policyRule' custom-pe-dns-zonegroup-dine.json) \
  --params <(jq '.properties.parameters' custom-pe-dns-zonegroup-dine.json)

az policy definition create --subscription "$TARGET_SUB" \
  --name deny-privatelink-dns-zones-outside-hub \
  --display-name "Deny privatelink.* Private DNS zones in spokes" \
  --mode All \
  --rules <(jq '.properties.policyRule' custom-deny-spoke-privatelink-zones.json) \
  --params <(jq '.properties.parameters' custom-deny-spoke-privatelink-zones.json)

# --- Assignments ---
PARAMS=$(jq -n --slurpfile m zone-map.example.json --arg rg "$DNS_RG_ID" \
  '{privateDnsZoneMap:{value:$m[0]}, centralDnsResourceGroupId:{value:$rg}}')

az policy assignment create --name pe-dns-central --scope "$SCOPE" \
  --policy "/subscriptions/${TARGET_SUB}/providers/Microsoft.Authorization/policyDefinitions/deploy-pe-dns-zonegroup-central" \
  --params "$PARAMS" --mi-system-assigned --location "$LOCATION"

az policy assignment create --name deny-spoke-pl-zones --scope "$SCOPE" \
  --policy "/subscriptions/${TARGET_SUB}/providers/Microsoft.Authorization/policyDefinitions/deny-privatelink-dns-zones-outside-hub"

# --- RBAC: MI needs rights on BOTH the PE (spoke) and the zones (hub RG) ---
PRINCIPAL=$(az policy assignment show --name pe-dns-central --scope "$SCOPE" --query identity.principalId -o tsv)
for s in "$SCOPE" "$DNS_RG_ID"; do
  az role assignment create --assignee-object-id "$PRINCIPAL" --assignee-principal-type ServicePrincipal \
    --role "Network Contributor" --scope "$s"
done

# --- Remediate existing PEs ---
az policy remediation create --name pe-dns-central-remediate \
  --policy-assignment "${SCOPE}/providers/Microsoft.Authorization/policyAssignments/pe-dns-central" \
  --resource-discovery-mode ReEvaluateCompliance
