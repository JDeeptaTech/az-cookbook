terraform {
  required_version = ">= 1.6"

  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "~> 4.0"
    }
  }

  # -backend-config=environments/<ring>/backend.hcl
  backend "azurerm" {}
}

# Run interactively: az login as a human with Owner (or User Access Administrator +
# Managed Identity Contributor) activated through PIM on the ring's root MG.
provider "azurerm" {
  features {}
  subscription_id                 = var.subscription_id
  resource_provider_registrations = "none"
  storage_use_azuread             = true
}
