variable "ring" {
  description = "canary | prod"
  type        = string
  validation {
    condition     = contains(["poc", "canary", "prod"], var.ring)
    error_message = "ring must be poc, canary or prod."
  }
}

variable "subscription_id" {
  description = "Subscription that hosts the identities (management/platform subscription)."
  type        = string
}

variable "location" {
  type    = string
  default = "uksouth"
}

variable "location_short" {
  type    = string
  default = "uks"
}

variable "definition_root_mg_id" {
  description = "Ring's root MG; the pipeline gets Resource Policy Contributor here."
  type        = string
}

variable "policy_state_container_id" {
  description = "Resource ID of the blob container holding the policy stack's state: <storage account id>/blobServices/default/containers/<name>."
  type        = string
}

variable "bootstrap_state_container_id" {
  description = "Resource ID of the blob container holding THIS stack's state (pipeline gets read-only access)."
  type        = string
}

variable "ado_service_connection_name" {
  description = "Name of the ADO service connection, used in the federated credential name."
  type        = string
}

variable "ado_issuer" {
  description = "Issuer shown on the draft ADO service connection (Entra issuer, https://login.microsoftonline.com/<tenant>/v2.0)."
  type        = string
  validation {
    condition     = !startswith(var.ado_issuer, "https://vstoken.dev.azure.com")
    error_message = "The vstoken.dev.azure.com issuer is deprecated (retires 2027-07-01). Create the service connection with the Entra issuer."
  }
}

variable "ado_subject" {
  description = "Subject identifier shown on the draft ADO service connection. Copy exactly; do not build it by hand."
  type        = string
}

variable "remediation_role_bindings" {
  description = "Grants for the remediation identity. Source of truth: `terraform output -json required_role_bindings` from the policy stack."
  type = list(object({
    role_definition_id = string
    scope              = string
  }))
  validation {
    # Owner, Contributor, User Access Administrator, RBAC Administrator never go to the remediation identity.
    condition = !anytrue([for b in var.remediation_role_bindings : contains([
      "8e3af657-a8ff-443c-a75c-2fe8c4bcb635",
      "b24988ac-6180-42a0-ab88-20f7382dd24c",
      "18d7d88d-d35e-4fb5-a5c3-7773c20a72d9",
      "f58310d9-a9f6-439a-9e8d-f62e7b41a168",
    ], lower(basename(b.role_definition_id)))])
    error_message = "Owner, Contributor, User Access Administrator and RBAC Administrator are not allowed on the remediation identity."
  }
}

variable "pipeline_can_grant_remediation_roles" {
  description = "Only for SystemAssigned assignments: give the pipeline constrained RBAC Administrator on each remediation scope."
  type        = bool
  default     = false
}
