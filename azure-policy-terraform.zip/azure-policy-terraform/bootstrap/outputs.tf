output "tenant_id" {
  value = azurerm_user_assigned_identity.pipeline.tenant_id
}

output "pipeline_client_id" {
  description = "Enter as Application (client) ID on the ADO service connection and as ARM_CLIENT_ID in the variable group."
  value       = azurerm_user_assigned_identity.pipeline.client_id
}

output "pipeline_principal_id" {
  value = azurerm_user_assigned_identity.pipeline.principal_id
}

output "remediation_identity_id" {
  description = "Read by the policy stack (terraform_remote_state) and attached to the assignment."
  value       = azurerm_user_assigned_identity.remediation.id
}

output "remediation_principal_id" {
  value = azurerm_user_assigned_identity.remediation.principal_id
}

output "remediation_role_bindings" {
  description = "Grants that exist (from created role assignments, not from input). The policy stack checks its needs against this."
  value = [for k, ra in azurerm_role_assignment.remediation : {
    role_definition_id = local.remediation_bindings[k].role_definition_id
    scope              = ra.scope
  }]
}
