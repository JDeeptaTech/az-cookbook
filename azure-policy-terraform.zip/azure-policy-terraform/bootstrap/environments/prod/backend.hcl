resource_group_name  = "rg-tfstate-platform-uks"
storage_account_name = "sttfstateplatformuks"
container_name       = "bootstrap"
key                  = "prod/identity.tfstate"
use_azuread_auth     = true
