ring            = "canary"
subscription_id = "00000000-0000-0000-0000-000000000000" # management subscription hosting the identities
location        = "uksouth"
location_short  = "uks"

definition_root_mg_id        = "/providers/Microsoft.Management/managementGroups/contoso-canary"
policy_state_container_id    = "/subscriptions/00000000-0000-0000-0000-000000000000/resourceGroups/rg-tfstate-platform-uks/providers/Microsoft.Storage/storageAccounts/sttfstateplatformuks/blobServices/default/containers/policy"
bootstrap_state_container_id = "/subscriptions/00000000-0000-0000-0000-000000000000/resourceGroups/rg-tfstate-platform-uks/providers/Microsoft.Storage/storageAccounts/sttfstateplatformuks/blobServices/default/containers/bootstrap"

# Copy both values from the DRAFT service connection in Azure DevOps
# (Project settings > Service connections > New > Azure Resource Manager >
#  App registration or Managed identity (manual) > Workload identity federation).
ado_service_connection_name = "sc-policy-canary"
ado_issuer                  = "https://login.microsoftonline.com/<tenant-id>/v2.0"
ado_subject                 = "<paste the subject identifier exactly as Azure DevOps shows it>"

# Source of truth: `terraform output -json required_role_bindings` in the policy stack.
# The policy plan fails if anything it needs is missing here.
remediation_role_bindings = [
  { # Network Contributor
    role_definition_id = "/providers/Microsoft.Authorization/roleDefinitions/4d97b98b-1d4f-4787-a291-c67834d212e7"
    scope              = "/providers/Microsoft.Management/managementGroups/contoso-canary-landingzones"
  },
  { # Reader
    role_definition_id = "/providers/Microsoft.Authorization/roleDefinitions/acdd72a7-3385-48ef-bd42-f606fba81ae7"
    scope              = "/providers/Microsoft.Management/managementGroups/contoso-canary-landingzones"
  },
  { # Private DNS Zone Contributor
    role_definition_id = "/providers/Microsoft.Authorization/roleDefinitions/b12aa53e-6015-4669-85d0-8515ebb3ae7f"
    scope              = "/providers/Microsoft.Management/managementGroups/contoso-canary-landingzones"
  },
  { # Network Contributor
    role_definition_id = "/providers/Microsoft.Authorization/roleDefinitions/4d97b98b-1d4f-4787-a291-c67834d212e7"
    scope              = "/subscriptions/11111111-1111-1111-1111-111111111111/resourceGroups/rg-dns-canary-uks"
  },
  { # Private DNS Zone Contributor
    role_definition_id = "/providers/Microsoft.Authorization/roleDefinitions/b12aa53e-6015-4669-85d0-8515ebb3ae7f"
    scope              = "/subscriptions/11111111-1111-1111-1111-111111111111/resourceGroups/rg-dns-canary-uks"
  },
  { # Network Contributor
    role_definition_id = "/providers/Microsoft.Authorization/roleDefinitions/4d97b98b-1d4f-4787-a291-c67834d212e7"
    scope              = "/subscriptions/11111111-1111-1111-1111-111111111111/resourceGroups/rg-hub-canary-uks/providers/Microsoft.Network/virtualNetworks/vnet-hub-canary-uks"
  },
]

pipeline_can_grant_remediation_roles = false
