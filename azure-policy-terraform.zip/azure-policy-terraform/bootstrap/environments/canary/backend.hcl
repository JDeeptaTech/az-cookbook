resource_group_name  = "rg-tfstate-platform-uks"
storage_account_name = "sttfstateplatformuks"
container_name       = "bootstrap"
key                  = "canary/identity.tfstate"
use_azuread_auth     = true
