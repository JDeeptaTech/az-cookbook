variable "name" {
  type = string
}

variable "display_name" {
  type = string
}

variable "description" {
  type    = string
  default = null
}

variable "category" {
  type    = string
  default = "Custom"
}

variable "policy_version" {
  type    = string
  default = "1.0.0"
}

variable "management_group_id" {
  type = string
}

variable "parameters" {
  description = "Initiative-level parameter schema (same shape as policy definition parameters)."
  type        = any
  default     = {}
}

variable "references" {
  description = "Member policies. parameter_values use the native shape: { paramName = { value = \"[parameters('x')]\" } }."
  type = list(object({
    policy_definition_id = string
    reference_id         = string
    parameter_values     = any
  }))
}
