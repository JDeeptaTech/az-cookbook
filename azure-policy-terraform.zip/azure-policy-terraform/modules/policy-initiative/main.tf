# Policy set definition (initiative). Assign initiatives, not single definitions:
# one managed identity, one compliance view, one remediation target per concern.

resource "azurerm_policy_set_definition" "this" {
  name                = var.name
  policy_type         = "Custom"
  display_name        = var.display_name
  description         = var.description
  management_group_id = var.management_group_id

  metadata   = jsonencode({ category = var.category, version = var.policy_version, managedBy = "terraform" })
  parameters = jsonencode(var.parameters)

  dynamic "policy_definition_reference" {
    for_each = var.references
    content {
      policy_definition_id = policy_definition_reference.value.policy_definition_id
      reference_id         = policy_definition_reference.value.reference_id
      parameter_values     = jsonencode(policy_definition_reference.value.parameter_values)
    }
  }
}
