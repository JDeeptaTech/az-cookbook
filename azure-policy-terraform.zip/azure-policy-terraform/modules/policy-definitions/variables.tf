variable "management_group_id" {
  description = "Resource ID of the MG that hosts definitions. Must be at or above every scope you assign to (usually the intermediate root MG)."
  type        = string
}

variable "definitions_path" {
  description = "Folder containing policy definition JSON files."
  type        = string
}
