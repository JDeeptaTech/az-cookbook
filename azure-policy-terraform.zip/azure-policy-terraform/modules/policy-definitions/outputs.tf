output "ids" {
  description = "Map of definition name => resource ID."
  value       = { for k, v in azurerm_policy_definition.this : k => v.id }
}

output "role_definition_ids" {
  description = "Map of definition name => roleDefinitionIds required by DINE/Modify effects (empty for audit/deny)."
  value = {
    for k, v in local.definitions :
    k => try(v.policyRule.then.details.roleDefinitionIds, [])
  }
}
