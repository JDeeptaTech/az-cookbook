# Loads every *.json under definitions_path (recursively) and creates one custom
# policy definition per file. JSON files use the native Azure export shape
# ({ "name": ..., "properties": { ... } }) so they round-trip with the portal,
# `az policy definition show`, and the azure-policy GitHub repo.

locals {
  files = fileset(var.definitions_path, "**/*.json")

  definitions = {
    for f in local.files :
    jsondecode(file("${var.definitions_path}/${f}")).name => jsondecode(file("${var.definitions_path}/${f}")).properties
  }
}

resource "azurerm_policy_definition" "this" {
  for_each = local.definitions

  name                = each.key
  policy_type         = "Custom"
  mode                = each.value.mode
  display_name        = each.value.displayName
  description         = try(each.value.description, null)
  management_group_id = var.management_group_id

  metadata    = jsonencode(merge(try(each.value.metadata, {}), { managedBy = "terraform" }))
  parameters  = try(jsonencode(each.value.parameters), null)
  policy_rule = jsonencode(each.value.policyRule)
}
