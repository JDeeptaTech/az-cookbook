# Management-group-scoped assignment with system-assigned identity and the RBAC
# that DINE/Modify policies need, both at the assignment scope and on any extra
# scopes outside it (e.g. the central Private DNS zones RG in the connectivity sub).
#
# Remediation is deliberately NOT a Terraform resource here: remediation tasks are
# one-shot jobs, and azurerm_*_policy_remediation drifts/recreates noisily. The CD
# pipeline triggers remediation after apply instead.

locals {
  needs_identity = length(var.role_definition_ids) > 0

  # role x scope cartesian product for RBAC
  role_bindings = {
    for pair in setproduct(var.role_definition_ids, concat([var.management_group_id], var.additional_role_scopes)) :
    "${basename(pair[0])}|${pair[1]}" => { role = pair[0], scope = pair[1] }
  }
}

resource "azurerm_management_group_policy_assignment" "this" {
  name                 = var.name # <= 24 chars at MG scope
  display_name         = var.display_name
  description          = var.description
  management_group_id  = var.management_group_id
  policy_definition_id = var.policy_definition_id
  not_scopes           = var.not_scopes
  enforce              = var.enforce
  location             = local.needs_identity ? var.location : null
  parameters           = length(var.parameters) > 0 ? jsonencode({ for k, v in var.parameters : k => { value = v } }) : null

  dynamic "identity" {
    for_each = local.needs_identity ? [1] : []
    content {
      type = "SystemAssigned"
    }
  }

  dynamic "non_compliance_message" {
    for_each = var.non_compliance_message == null ? [] : [1]
    content {
      content = var.non_compliance_message
    }
  }

  metadata = jsonencode({ managedBy = "terraform" })

  lifecycle {
    precondition {
      condition     = length(var.name) <= 24
      error_message = "Management group policy assignment names must be <= 24 characters."
    }
  }
}

resource "azurerm_role_assignment" "this" {
  for_each = local.needs_identity ? local.role_bindings : {}

  scope = each.value.scope
  # roleDefinitionIds in policy JSON are tenant-level (/providers/Microsoft.Authorization/roleDefinitions/<guid>);
  # azurerm wants them scoped, so prefix with the target scope.
  role_definition_id               = "${each.value.scope}${each.value.role}"
  principal_id                     = azurerm_management_group_policy_assignment.this.identity[0].principal_id
  principal_type                   = "ServicePrincipal"
  skip_service_principal_aad_check = true
  description                      = "Policy assignment ${var.name} remediation identity"
}
