# Management-group-scoped policy assignment plus the identity DINE/Modify effects
# run as.
#
# Two identity modes:
#   user_assigned_identity_id = null  -> SystemAssigned. The module creates the role
#     assignments, so the PIPELINE identity needs roleAssignments/write on every scope.
#   user_assigned_identity_id = <id>  -> UserAssigned (recommended). Roles are granted
#     once by the privileged bootstrap stack; the module creates NO role assignments and
#     instead fails the plan if a required grant is missing (granted_role_bindings).
#
# Remediation is deliberately NOT a Terraform resource: remediation tasks are one-shot
# jobs. The CD pipeline triggers them after apply.

locals {
  use_uami       = var.user_assigned_identity_id != null
  needs_identity = local.use_uami || length(var.role_definition_ids) > 0 || length(var.extra_role_bindings) > 0

  # Every grant the identity needs: roles x (assignment scope + extra scopes), plus the
  # narrow single-scope bindings. Keyed "<role guid>|<scope>" in lowercase.
  required_bindings = merge(
    {
      for pair in setproduct(var.role_definition_ids, concat([var.management_group_id], var.additional_role_scopes)) :
      lower("${basename(pair[0])}|${pair[1]}") => { role = pair[0], scope = pair[1] }
    },
    {
      for b in var.extra_role_bindings :
      lower("${basename(b.role_definition_id)}|${b.scope}") => { role = b.role_definition_id, scope = b.scope }
    },
  )

  granted_keys     = toset([for b in coalesce(var.granted_role_bindings, []) : lower("${basename(b.role_definition_id)}|${b.scope}")])
  missing_bindings = [for k, v in local.required_bindings : "${basename(v.role)} @ ${v.scope}" if !contains(local.granted_keys, k)]
}

resource "azurerm_management_group_policy_assignment" "this" {
  name                 = var.name # <= 24 chars at MG scope
  display_name         = var.display_name
  description          = var.description
  management_group_id  = var.management_group_id
  policy_definition_id = var.policy_definition_id
  not_scopes           = var.not_scopes
  enforce              = var.enforce
  location             = local.needs_identity ? var.location : null
  parameters           = length(var.parameters) > 0 ? jsonencode({ for k, v in var.parameters : k => { value = v } }) : null

  dynamic "identity" {
    for_each = local.needs_identity ? [1] : []
    content {
      type         = local.use_uami ? "UserAssigned" : "SystemAssigned"
      identity_ids = local.use_uami ? [var.user_assigned_identity_id] : null
    }
  }

  dynamic "non_compliance_message" {
    for_each = var.non_compliance_message == null ? [] : [1]
    content {
      content = var.non_compliance_message
    }
  }

  metadata = jsonencode({ managedBy = "terraform" })

  lifecycle {
    precondition {
      condition     = length(var.name) <= 24
      error_message = "Management group policy assignment names must be <= 24 characters."
    }
    precondition {
      condition     = !local.use_uami || var.granted_role_bindings == null || length(local.missing_bindings) == 0
      error_message = "The remediation identity is missing grants this assignment needs: ${join("; ", local.missing_bindings)}. Add them to the bootstrap stack's remediation_role_bindings and apply it (privileged), then re-run."
    }
  }
}

# SystemAssigned mode only: grant what the policies declare.
resource "azurerm_role_assignment" "this" {
  for_each = local.use_uami || !local.needs_identity ? {} : local.required_bindings

  scope = each.value.scope
  # roleDefinitionIds in policy JSON are tenant-level (/providers/Microsoft.Authorization/roleDefinitions/<guid>);
  # azurerm wants them scoped, so prefix with the target scope.
  role_definition_id               = "${each.value.scope}${each.value.role}"
  principal_id                     = azurerm_management_group_policy_assignment.this.identity[0].principal_id
  principal_type                   = "ServicePrincipal"
  skip_service_principal_aad_check = true
  description                      = "Policy assignment ${var.name} remediation identity"
}

