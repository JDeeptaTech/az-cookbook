variable "name" {
  type = string
}

variable "display_name" {
  type = string
}

variable "description" {
  type    = string
  default = null
}

variable "management_group_id" {
  description = "Resource ID of the MG to assign at."
  type        = string
}

variable "policy_definition_id" {
  description = "Policy definition or policy set definition ID."
  type        = string
}

variable "parameters" {
  description = "Plain map of parameter name => value; wrapped into { value = ... } by the module."
  type        = any
  default     = {}
}

variable "enforce" {
  description = "false = DoNotEnforce (audit-only rollout; DINE won't auto-deploy, Deny won't block). Flip per ring."
  type        = bool
  default     = false
}

variable "not_scopes" {
  type    = list(string)
  default = []
}

variable "location" {
  description = "Region for the assignment's managed identity (required when identity is created)."
  type        = string
  default     = "uksouth"
}

variable "role_definition_ids" {
  description = "Tenant-level role definition IDs from the policies' roleDefinitionIds. Empty => no identity."
  type        = list(string)
  default     = []
}

variable "additional_role_scopes" {
  description = "Extra scopes outside the assignment scope where the identity needs the same roles (e.g. hub DNS RG)."
  type        = list(string)
  default     = []
}

variable "non_compliance_message" {
  type    = string
  default = null
}
