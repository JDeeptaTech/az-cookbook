variable "name" {
  type = string
}

variable "display_name" {
  type = string
}

variable "description" {
  type    = string
  default = null
}

variable "management_group_id" {
  description = "Resource ID of the MG to assign at."
  type        = string
}

variable "policy_definition_id" {
  description = "Policy definition or policy set definition ID."
  type        = string
}

variable "parameters" {
  description = "Plain map of parameter name => value; wrapped into { value = ... } by the module."
  type        = any
  default     = {}
}

variable "enforce" {
  description = "false = DoNotEnforce (audit-only rollout; DINE won't auto-deploy, Deny won't block). Flip per ring."
  type        = bool
  default     = false
}

variable "not_scopes" {
  type    = list(string)
  default = []
}

variable "location" {
  description = "Region for the assignment's managed identity (required when identity is created)."
  type        = string
  default     = "uksouth"
}

variable "role_definition_ids" {
  description = "Tenant-level role definition IDs from the policies' roleDefinitionIds. Empty => no identity."
  type        = list(string)
  default     = []
}

variable "additional_role_scopes" {
  description = "Extra scopes outside the assignment scope where the identity needs the same roles (e.g. hub DNS RG)."
  type        = list(string)
  default     = []
}

variable "extra_role_bindings" {
  description = "Additional single role-at-scope grants for the assignment identity (not crossed with additional_role_scopes)."
  type = list(object({
    role_definition_id = string # tenant-level form: /providers/Microsoft.Authorization/roleDefinitions/<guid>
    scope              = string
  }))
  default = []
}

variable "non_compliance_message" {
  type    = string
  default = null
}

variable "user_assigned_identity_id" {
  description = "Resource ID of a user-assigned managed identity for remediation. Null = SystemAssigned and the module creates the role assignments."
  type        = string
  default     = null
}

variable "granted_role_bindings" {
  description = "UserAssigned mode: grants the bootstrap stack has given the identity. When set, the plan fails if a required grant is missing. Null = skip the check."
  type = list(object({
    role_definition_id = string
    scope              = string
  }))
  default = null
}
