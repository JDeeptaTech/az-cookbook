output "id" {
  value = azurerm_management_group_policy_assignment.this.id
}

output "principal_id" {
  value = try(azurerm_management_group_policy_assignment.this.identity[0].principal_id, null)
}
