output "id" {
  value = azurerm_management_group_policy_assignment.this.id
}

output "principal_id" {
  description = "SystemAssigned mode only; null for UserAssigned (the bootstrap stack outputs that principal)."
  value       = try(azurerm_management_group_policy_assignment.this.identity[0].principal_id, null)
}

output "required_role_bindings" {
  description = "Every role-at-scope grant the remediation identity needs. Paste into the bootstrap stack's remediation_role_bindings."
  value       = [for v in values(local.required_bindings) : { role_definition_id = "/providers/Microsoft.Authorization/roleDefinitions/${lower(basename(v.role))}", scope = v.scope }]
}
