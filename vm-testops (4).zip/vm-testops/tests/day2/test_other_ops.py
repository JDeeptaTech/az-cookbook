"""Day-2: affinity, anti-affinity, migration, lease, lifecycle."""
from __future__ import annotations

import allure
import pytest

from lib.allure_utils import attach_json
from lib.async_ops import TerminalState


@pytest.mark.day2
@pytest.mark.affinity
@allure.feature("Day2 — Affinity")
class TestAffinityOps:

    RULE_NAME = "test-affinity-rule"

    @allure.story("List affinity rules for VM (sync)")
    def test_list(self, provisioned_vm, vm_client, waiter, async_op_tracker):
        handle = async_op_tracker(
            vm_client.submit_op(provisioned_vm["name"], "affinity.list")
        )
        result = waiter.wait(handle)
        assert result.success
        attach_json("affinity-rules", result.final_payload)

    @allure.story("Add VM to an affinity rule")
    def test_add(self, provisioned_vm, vm_client, waiter, async_op_tracker):
        handle = async_op_tracker(
            vm_client.submit_op(
                provisioned_vm["name"], "affinity.add",
                params={"rule_name": self.RULE_NAME},
            )
        )
        result = waiter.wait(handle, expect=TerminalState.SUCCESS)
        assert result.success

    @allure.story("Remove VM from an affinity rule")
    def test_remove(self, provisioned_vm, vm_client, waiter, async_op_tracker):
        handle = async_op_tracker(
            vm_client.submit_op(
                provisioned_vm["name"], "affinity.remove",
                params={"rule_name": self.RULE_NAME},
            )
        )
        result = waiter.wait(handle)
        assert result.success


@pytest.mark.day2
@pytest.mark.anti_affinity
@allure.feature("Day2 — Anti-Affinity")
class TestAntiAffinityOps:

    RULE_NAME = "test-anti-affinity-rule"

    @allure.story("List anti-affinity rules for VM")
    def test_list(self, provisioned_vm, vm_client, waiter, async_op_tracker):
        handle = async_op_tracker(
            vm_client.submit_op(provisioned_vm["name"], "anti_affinity.list")
        )
        result = waiter.wait(handle)
        assert result.success
        attach_json("anti-affinity-rules", result.final_payload)

    @allure.story("Add VM to anti-affinity rule")
    def test_add(self, provisioned_vm, vm_client, waiter, async_op_tracker):
        handle = async_op_tracker(
            vm_client.submit_op(
                provisioned_vm["name"], "anti_affinity.add",
                params={"rule_name": self.RULE_NAME},
            )
        )
        result = waiter.wait(handle)
        assert result.success

    @allure.story("Remove VM from anti-affinity rule")
    def test_remove(self, provisioned_vm, vm_client, waiter, async_op_tracker):
        handle = async_op_tracker(
            vm_client.submit_op(
                provisioned_vm["name"], "anti_affinity.remove",
                params={"rule_name": self.RULE_NAME},
            )
        )
        result = waiter.wait(handle)
        assert result.success


@pytest.mark.day2
@pytest.mark.migration
@pytest.mark.slow
@allure.feature("Day2 — Migration")
class TestMigrationOps:

    @allure.story("Live migrate VM (scheduler-picked target)")
    def test_live_migrate(self, provisioned_vm, vm_client, waiter, async_op_tracker, ocp_validator):
        handle = async_op_tracker(
            vm_client.submit_op(provisioned_vm["name"], "migration.live")
        )
        result = waiter.wait(handle, expect=TerminalState.SUCCESS)
        assert result.success
        ocp_validator.expect_vm_healthy(
            provisioned_vm["name"],
            since_iso=handle.submitted_at.isoformat(),
        )


@pytest.mark.day2
@pytest.mark.lease
@allure.feature("Day2 — Lease")
class TestLeaseOps:

    @allure.story("Get VM lease info (sync)")
    def test_get_lease(self, provisioned_vm, vm_client, waiter, async_op_tracker):
        handle = async_op_tracker(
            vm_client.submit_op(provisioned_vm["name"], "lease.get")
        )
        result = waiter.wait(handle)
        attach_json("lease-info", result.final_payload)
        assert result.success

    @allure.story("Extend VM lease by 30 days")
    def test_extend_lease(self, provisioned_vm, vm_client, waiter, async_op_tracker):
        handle = async_op_tracker(
            vm_client.submit_op(
                provisioned_vm["name"], "lease.extend",
                params={"days": 30},
            )
        )
        result = waiter.wait(handle)
        assert result.success


@pytest.mark.day2
@pytest.mark.lifecycle
@pytest.mark.slow
@allure.feature("Day2 — Lifecycle")
class TestLifecycleOps:
    """
    Lifecycle.demise is destructive — only runs when explicitly selected
    via -m lifecycle to avoid wiping out VMs accidentally during dev runs.
    """

    @allure.story("Decommission VM (destructive)")
    def test_demise(self, provisioned_vm, vm_client, waiter, async_op_tracker):
        handle = async_op_tracker(
            vm_client.submit_op(provisioned_vm["name"], "lifecycle.demise")
        )
        result = waiter.wait(handle, expect=TerminalState.SUCCESS)
        assert result.success
