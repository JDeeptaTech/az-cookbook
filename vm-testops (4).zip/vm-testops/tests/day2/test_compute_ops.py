"""Day-2 compute resize: CPU, memory, or both via POST /compute/resize."""
from __future__ import annotations

import allure
import pytest

from lib.allure_utils import attach_json
from lib.async_ops import TerminalState


@pytest.mark.day2
@pytest.mark.compute
@allure.feature("Day2 — Compute resize")
class TestComputeResize:

    @allure.story("Resize CPU only")
    def test_resize_cpu(self, provisioned_vm, vm_client, waiter, async_op_tracker, ocp_validator):
        handle = async_op_tracker(
            vm_client.submit_op(
                provisioned_vm["name"], "compute.resize", params={"cpu": 4},
            )
        )
        result = waiter.wait(handle, expect=TerminalState.SUCCESS)
        assert result.success
        attach_json("resize-result", result.final_payload)
        ocp_validator.expect_vm_healthy(
            provisioned_vm["name"],
            since_iso=handle.submitted_at.isoformat(),
        )

    @allure.story("Resize memory only")
    def test_resize_memory(self, provisioned_vm, vm_client, waiter, async_op_tracker, ocp_validator):
        handle = async_op_tracker(
            vm_client.submit_op(
                provisioned_vm["name"], "compute.resize", params={"memory_mb": 8192},
            )
        )
        result = waiter.wait(handle)
        assert result.success
        ocp_validator.expect_vm_healthy(
            provisioned_vm["name"],
            since_iso=handle.submitted_at.isoformat(),
        )

    @allure.story("Resize CPU and memory together")
    def test_resize_both(self, provisioned_vm, vm_client, waiter, async_op_tracker, ocp_validator):
        handle = async_op_tracker(
            vm_client.submit_op(
                provisioned_vm["name"], "compute.resize",
                params={"cpu": 8, "memory_mb": 16384},
            )
        )
        result = waiter.wait(handle)
        assert result.success
        ocp_validator.expect_vm_healthy(
            provisioned_vm["name"],
            since_iso=handle.submitted_at.isoformat(),
        )
