"""Day-2 power operations: start, stop, restart."""
from __future__ import annotations

import allure
import pytest

from lib.allure_utils import attach_json
from lib.async_ops import TerminalState


@pytest.mark.day2
@pytest.mark.power
@allure.feature("Day2 — Power")
class TestPowerOps:

    @allure.story("Stop a running VM")
    @allure.severity(allure.severity_level.CRITICAL)
    def test_stop(self, provisioned_vm, vm_client, waiter, async_op_tracker, ocp_validator):
        handle = async_op_tracker(
            vm_client.submit_op(provisioned_vm["name"], "power.stop")
        )
        attach_json("submit", {
            "invocation_id": handle.request_id,
            "correlation_id": handle.correlation_id,
        })
        result = waiter.wait(handle, expect=TerminalState.SUCCESS)
        assert result.success

        ocp_validator.expect_vm_stopped(provisioned_vm["name"])
        ocp_validator.expect_no_warning_events(
            provisioned_vm["name"],
            since_iso=handle.submitted_at.isoformat(),
        )

    @allure.story("Start a stopped VM")
    @allure.severity(allure.severity_level.CRITICAL)
    def test_start(self, provisioned_vm, vm_client, waiter, async_op_tracker, ocp_validator):
        handle = async_op_tracker(
            vm_client.submit_op(provisioned_vm["name"], "power.start")
        )
        result = waiter.wait(handle)
        assert result.success
        ocp_validator.expect_vm_running(provisioned_vm["name"])

    @allure.story("Restart a running VM")
    def test_restart(self, provisioned_vm, vm_client, waiter, async_op_tracker, ocp_validator):
        handle = async_op_tracker(
            vm_client.submit_op(provisioned_vm["name"], "power.restart")
        )
        result = waiter.wait(handle)
        assert result.success
        ocp_validator.expect_vm_healthy(
            provisioned_vm["name"],
            since_iso=handle.submitted_at.isoformat(),
        )

    @allure.story("Force-stop a running VM")
    def test_force_stop(self, provisioned_vm, vm_client, waiter, async_op_tracker, ocp_validator):
        handle = async_op_tracker(
            vm_client.submit_op(provisioned_vm["name"], "power.stop", params={"force": True})
        )
        result = waiter.wait(handle)
        assert result.success
        ocp_validator.expect_vm_stopped(provisioned_vm["name"])
