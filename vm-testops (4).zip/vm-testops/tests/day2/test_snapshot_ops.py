"""Day-2 snapshot operations: precheck, create, revert, delete.

The precheck endpoint is sync — it returns eligibility immediately.
Create/revert/delete are async.
"""
from __future__ import annotations

import allure
import pytest

from lib.allure_utils import attach_json
from lib.async_ops import AsyncOpFailure, TerminalState


@pytest.mark.day2
@pytest.mark.snapshot
@allure.feature("Day2 — Snapshots")
class TestSnapshotOps:

    @allure.story("Precheck snapshot eligibility (sync)")
    def test_precheck(self, provisioned_vm, vm_client, waiter, async_op_tracker):
        handle = async_op_tracker(
            vm_client.submit_op(
                provisioned_vm["name"], "snapshot.precheck",
                params={"name": "precheck-test"},
            )
        )
        result = waiter.wait(handle)
        attach_json("precheck-response", result.final_payload)
        assert result.success
        # Sync ops don't poll; verify that
        assert result.poll_count == 0

    @allure.story("Create snapshot")
    @allure.severity(allure.severity_level.CRITICAL)
    def test_create_snapshot(
        self, provisioned_vm, vm_client, waiter, async_op_tracker, ocp_validator, request,
    ):
        snap_name = f"snap-{provisioned_vm['name']}-baseline"
        handle = async_op_tracker(
            vm_client.submit_op(
                provisioned_vm["name"], "snapshot.create",
                params={"name": snap_name, "description": "framework test"},
            )
        )
        result = waiter.wait(handle, expect=TerminalState.SUCCESS)
        assert result.success
        ocp_validator.expect_snapshot_ready(snap_name)

        request.session.last_snapshot_name = snap_name

    @allure.story("Revert to snapshot")
    def test_revert_snapshot(
        self, provisioned_vm, vm_client, waiter, async_op_tracker, ocp_validator, request,
    ):
        snap_name = getattr(request.session, "last_snapshot_name", None)
        if not snap_name:
            pytest.skip("No snapshot from prior test; run create first")

        handle = async_op_tracker(
            vm_client.submit_op(
                provisioned_vm["name"], "snapshot.revert",
                params={"snapshot_name": snap_name},
            )
        )
        result = waiter.wait(handle)
        assert result.success
        ocp_validator.expect_vm_healthy(
            provisioned_vm["name"],
            since_iso=handle.submitted_at.isoformat(),
        )

    @allure.story("Delete snapshot")
    def test_delete_snapshot(
        self, provisioned_vm, vm_client, waiter, async_op_tracker, ocp_validator, request,
    ):
        snap_name = getattr(request.session, "last_snapshot_name", None)
        if not snap_name:
            pytest.skip("No snapshot to delete")

        handle = async_op_tracker(
            vm_client.submit_op(
                provisioned_vm["name"], "snapshot.delete",
                params={"snapshot_name": snap_name},
            )
        )
        result = waiter.wait(handle)
        assert result.success
        ocp_validator.expect_snapshot_absent(snap_name)

    @allure.story("Revert non-existent snapshot fails cleanly")
    def test_revert_invalid_fails(self, provisioned_vm, vm_client, waiter, async_op_tracker):
        handle = async_op_tracker(
            vm_client.submit_op(
                provisioned_vm["name"], "snapshot.revert",
                params={"snapshot_name": "definitely-does-not-exist"},
            )
        )
        with pytest.raises(AsyncOpFailure) as exc:
            waiter.wait(handle)
        assert exc.value.result.terminal_state == TerminalState.FAILED
