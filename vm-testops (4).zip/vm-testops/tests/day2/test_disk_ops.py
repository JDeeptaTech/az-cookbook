"""Day-2 disk operations: add, detach, delete (matches Swagger surface)."""
from __future__ import annotations

import allure
import pytest

from lib.async_ops import TerminalState


@pytest.mark.day2
@pytest.mark.disk
@allure.feature("Day2 — Disks")
class TestDiskOps:

    DISK_NAME = "test-data-1"

    @allure.story("Add a data disk")
    def test_add_disk(self, provisioned_vm, vm_client, waiter, async_op_tracker, ocp_validator):
        handle = async_op_tracker(
            vm_client.submit_op(
                provisioned_vm["name"], "disk.add",
                params={"name": self.DISK_NAME, "size_gb": 20},
            )
        )
        result = waiter.wait(handle, expect=TerminalState.SUCCESS)
        assert result.success
        ocp_validator.expect_disk_attached(
            provisioned_vm["name"], self.DISK_NAME, size_gb=20,
        )

    @allure.story("Detach a disk (keeps the disk artifact)")
    def test_detach_disk(self, provisioned_vm, vm_client, waiter, async_op_tracker, ocp_validator):
        handle = async_op_tracker(
            vm_client.submit_op(
                provisioned_vm["name"], "disk.detach",
                params={"name": self.DISK_NAME},
            )
        )
        result = waiter.wait(handle)
        assert result.success
        ocp_validator.expect_disk_detached(provisioned_vm["name"], self.DISK_NAME)

    @allure.story("Delete a disk (destructive)")
    def test_delete_disk(self, provisioned_vm, vm_client, waiter, async_op_tracker):
        # Re-add first so we have something to delete (in case detach ran)
        h1 = async_op_tracker(
            vm_client.submit_op(
                provisioned_vm["name"], "disk.add",
                params={"name": "disk-to-delete", "size_gb": 10},
            )
        )
        waiter.wait(h1)

        h2 = async_op_tracker(
            vm_client.submit_op(
                provisioned_vm["name"], "disk.delete",
                params={"name": "disk-to-delete"},
            )
        )
        result = waiter.wait(h2)
        assert result.success
