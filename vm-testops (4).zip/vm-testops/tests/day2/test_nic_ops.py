"""Day-2 NIC operations: attach, detach."""
from __future__ import annotations

import allure
import pytest

from lib.async_ops import TerminalState


@pytest.mark.day2
@pytest.mark.nic
@allure.feature("Day2 — NICs")
class TestNICOps:

    NIC_NAME = "eth1"
    NETWORK = "secondary-net"

    @allure.story("Attach a secondary NIC")
    def test_attach_nic(self, provisioned_vm, vm_client, waiter, async_op_tracker, ocp_validator):
        handle = async_op_tracker(
            vm_client.submit_op(
                provisioned_vm["name"], "nic.attach",
                params={"name": self.NIC_NAME, "network": self.NETWORK},
            )
        )
        result = waiter.wait(handle, expect=TerminalState.SUCCESS)
        assert result.success
        ocp_validator.expect_nic_attached(
            provisioned_vm["name"], self.NIC_NAME, self.NETWORK,
        )

    @allure.story("Detach the secondary NIC")
    def test_detach_nic(self, provisioned_vm, vm_client, waiter, async_op_tracker, ocp_validator):
        handle = async_op_tracker(
            vm_client.submit_op(
                provisioned_vm["name"], "nic.detach",
                params={"name": self.NIC_NAME},
            )
        )
        result = waiter.wait(handle)
        assert result.success
        ocp_validator.expect_nic_detached(provisioned_vm["name"], self.NIC_NAME)
