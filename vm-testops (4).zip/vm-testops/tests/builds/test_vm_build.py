"""Build-phase tests: validate the VM landed correctly via /builds/<type>.

Cross-checks both the API response (build_payload stored in vm record)
and the OpenShift/KubeVirt CRs.
"""
from __future__ import annotations

import allure
import pytest

from lib.allure_utils import attach_json


@pytest.mark.build
@allure.feature("VM Provisioning")
class TestVMBuild:

    @allure.story("VM reaches Running state (API + OCP)")
    @allure.severity(allure.severity_level.BLOCKER)
    def test_vm_running(self, os_spec, provisioned_vm, vm_client, ocp_validator):
        with allure.step(f"[API] Build payload recorded for {os_spec['id']}"):
            attach_json("build-payload", provisioned_vm.get("build_payload", {}))
            assert provisioned_vm["build_type"] == os_spec["build_type"]
            assert provisioned_vm["name"]

        ocp_validator.expect_vm_running(provisioned_vm["name"])

    @allure.story("Build invocation completed without warnings")
    def test_no_provisioning_warnings(self, provisioned_vm, ocp_validator):
        ocp_validator.expect_no_warning_events(
            provisioned_vm["name"],
            ignore_reasons={"SyncFailed", "FailedMount"},
        )

    @allure.story("VM has lease information after build")
    def test_vm_has_lease(self, provisioned_vm, vm_client, waiter, async_op_tracker):
        handle = async_op_tracker(
            vm_client.submit_op(provisioned_vm["name"], "lease.get")
        )
        result = waiter.wait(handle)
        attach_json("lease-after-build", result.final_payload)
        assert result.success, "lease.get failed after build"

    @allure.story("Build type matches the OS family")
    @pytest.mark.smoke
    def test_build_type_correct(self, os_spec, provisioned_vm):
        expected_family = os_spec["family"]
        bt = provisioned_vm["build_type"]
        if expected_family == "linux":
            assert bt in ("smart_linux", "linux"), f"unexpected build_type {bt}"
        else:
            assert bt in ("smart_windows", "windows"), f"unexpected build_type {bt}"
