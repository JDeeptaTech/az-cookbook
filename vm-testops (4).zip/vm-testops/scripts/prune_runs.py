#!/usr/bin/env python3
"""
Prune old numbered run directories from the gh-pages branch.

Keeps the N most recent runs per environment, plus the `latest/`
pointer. Designed to run inside a checkout of gh-pages, then commit
+ push the deletions.

Usage:
  python scripts/prune_runs.py --gh-pages gh-pages-checkout --keep 30

Designed to be idempotent and safe: it only deletes numeric subdirs
under <env>/, never touches `latest/`, root files, or unknown layouts.
"""
from __future__ import annotations

import argparse
import shutil
from pathlib import Path


KNOWN_ENVS = ("dev", "prod")


def prune(gh_pages: Path, env: str, keep: int) -> tuple[int, int]:
    """Return (kept, removed) counts for one environment."""
    env_dir = gh_pages / env
    if not env_dir.is_dir():
        return (0, 0)

    numeric = []
    for entry in env_dir.iterdir():
        if entry.is_dir() and entry.name.isdigit():
            numeric.append(entry)

    # Newest first by run number
    numeric.sort(key=lambda p: int(p.name), reverse=True)

    to_keep = numeric[:keep]
    to_remove = numeric[keep:]

    for path in to_remove:
        print(f"Removing {path}")
        shutil.rmtree(path)

    return (len(to_keep), len(to_remove))


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--gh-pages", type=Path, required=True,
                   help="Path to gh-pages branch checkout")
    p.add_argument("--keep", type=int, default=30,
                   help="Number of most recent runs to keep per environment")
    p.add_argument("--envs", nargs="*", default=list(KNOWN_ENVS))
    args = p.parse_args()

    if not args.gh_pages.is_dir():
        raise SystemExit(f"gh-pages path does not exist: {args.gh_pages}")

    total_removed = 0
    for env in args.envs:
        kept, removed = prune(args.gh_pages, env, args.keep)
        total_removed += removed
        print(f"[{env}] kept {kept}, removed {removed}")

    if total_removed == 0:
        print("Nothing to prune.")


if __name__ == "__main__":
    main()
