#!/usr/bin/env python3
"""
Build a landing page for the GitHub Pages site.

Scans the gh-pages branch for <env>/<run_number>/ directories and emits
an index.html listing recent runs per environment with their status.

We read each run's history/history-trend.json (written by Allure into
every report's history/) to surface pass/fail counts on the index.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Optional


def find_runs(gh_pages: Path, env: str, limit: int = 20) -> list[dict]:
    """Return latest `limit` numbered runs for an environment, newest first."""
    env_dir = gh_pages / env
    if not env_dir.is_dir():
        return []

    runs = []
    for entry in env_dir.iterdir():
        if not entry.is_dir() or entry.name == "latest":
            continue
        if not entry.name.isdigit():
            continue
        runs.append(entry)

    runs.sort(key=lambda p: int(p.name), reverse=True)
    runs = runs[:limit]

    out = []
    for run in runs:
        out.append({
            "number": int(run.name),
            "path": f"{env}/{run.name}/",
            "stats": _read_trend(run),
        })
    return out


def _read_trend(run_dir: Path) -> Optional[dict]:
    """Pull the most recent trend entry from history-trend.json."""
    trend_file = run_dir / "history" / "history-trend.json"
    if not trend_file.exists():
        return None
    try:
        data = json.loads(trend_file.read_text())
        if not data:
            return None
        latest = data[0]
        stats = latest.get("data", {})
        return {
            "total": stats.get("total", 0),
            "passed": stats.get("passed", 0),
            "failed": stats.get("failed", 0),
            "broken": stats.get("broken", 0),
            "skipped": stats.get("skipped", 0),
        }
    except (json.JSONDecodeError, OSError, IndexError):
        return None


def render_runs(env: str, runs: list[dict]) -> str:
    if not runs:
        return f'<p class="empty">No runs published yet for <code>{env}</code>.</p>'

    rows = []
    for run in runs:
        s = run["stats"]
        if s:
            total = s["total"] or 1
            pass_pct = 100 * s["passed"] / total
            status_class = (
                "ok" if s["failed"] == 0 and s["broken"] == 0
                else "warn" if pass_pct >= 80 else "fail"
            )
            stats_html = (
                f'<span class="pct {status_class}">{pass_pct:.0f}%</span>'
                f'<span class="counts">'
                f'<span class="passed">{s["passed"]} passed</span>'
                f'<span class="failed">{s["failed"]} failed</span>'
                f'<span class="broken">{s["broken"]} broken</span>'
                f'<span class="skipped">{s["skipped"]} skipped</span>'
                f"</span>"
            )
        else:
            stats_html = '<span class="pct unknown">—</span>'

        rows.append(
            f'<li><a href="{run["path"]}">Run #{run["number"]}</a>{stats_html}</li>'
        )

    return f"""
    <section>
      <h2>{env} <a class="latest-link" href="{env}/latest/">→ latest</a></h2>
      <ul class="runs">
        {"".join(rows)}
      </ul>
    </section>
    """


def build(gh_pages: Path, repo: str, output: Path) -> None:
    envs = ["dev", "prod"]
    sections = "".join(render_runs(env, find_runs(gh_pages, env)) for env in envs)

    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>VM TestOps — Allure reports</title>
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <style>
    :root {{
      --bg: #0d1117; --fg: #e6edf3; --muted: #8b949e;
      --card: #161b22; --border: #30363d;
      --ok: #3fb950; --warn: #d29922; --fail: #f85149;
      --link: #58a6ff;
    }}
    @media (prefers-color-scheme: light) {{
      :root {{
        --bg: #ffffff; --fg: #1f2328; --muted: #59636e;
        --card: #f6f8fa; --border: #d1d9e0;
        --link: #0969da;
      }}
    }}
    * {{ box-sizing: border-box; }}
    body {{
      margin: 0; padding: 2rem 1rem;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", system-ui, sans-serif;
      background: var(--bg); color: var(--fg);
      max-width: 960px; margin-inline: auto;
    }}
    h1 {{ margin: 0 0 .5rem 0; }}
    .subtitle {{ color: var(--muted); margin-bottom: 2rem; }}
    section {{
      background: var(--card); border: 1px solid var(--border);
      border-radius: 8px; padding: 1.25rem 1.5rem; margin-bottom: 1.25rem;
    }}
    section h2 {{
      margin: 0 0 1rem 0; text-transform: capitalize;
      display: flex; justify-content: space-between; align-items: baseline;
    }}
    .latest-link {{
      font-size: .85rem; font-weight: normal;
      color: var(--link); text-decoration: none;
    }}
    .latest-link:hover {{ text-decoration: underline; }}
    ul.runs {{ list-style: none; padding: 0; margin: 0; }}
    ul.runs li {{
      display: flex; justify-content: space-between; align-items: center;
      padding: .5rem 0;
      border-bottom: 1px solid var(--border);
    }}
    ul.runs li:last-child {{ border-bottom: none; }}
    ul.runs a {{ color: var(--link); text-decoration: none; font-weight: 500; }}
    ul.runs a:hover {{ text-decoration: underline; }}
    .pct {{
      display: inline-block; min-width: 3rem; text-align: right;
      font-variant-numeric: tabular-nums; font-weight: 600; margin-right: 1rem;
    }}
    .pct.ok {{ color: var(--ok); }}
    .pct.warn {{ color: var(--warn); }}
    .pct.fail {{ color: var(--fail); }}
    .pct.unknown {{ color: var(--muted); }}
    .counts {{
      color: var(--muted); font-size: .85rem;
      display: inline-flex; gap: .75rem; font-variant-numeric: tabular-nums;
    }}
    .counts .passed {{ color: var(--ok); }}
    .counts .failed {{ color: var(--fail); }}
    .counts .broken {{ color: var(--warn); }}
    .empty {{ color: var(--muted); font-style: italic; }}
    footer {{
      margin-top: 2rem; padding-top: 1rem;
      border-top: 1px solid var(--border);
      color: var(--muted); font-size: .85rem;
    }}
    footer a {{ color: var(--link); }}
  </style>
</head>
<body>
  <h1>VM TestOps</h1>
  <p class="subtitle">Allure reports for the VM self-service platform.</p>
  {sections}
  <footer>
    Source: <a href="https://github.com/{repo}">{repo}</a> ·
    Reports updated by GitHub Actions
  </footer>
</body>
</html>
"""
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(html)
    print(f"Wrote {output}")


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--gh-pages", type=Path, required=True,
                   help="Path to gh-pages branch checkout")
    p.add_argument("--output", type=Path, required=True,
                   help="Output index.html path")
    p.add_argument("--repo", required=True, help="owner/repo for footer link")
    args = p.parse_args()

    build(args.gh_pages, args.repo, args.output)


if __name__ == "__main__":
    main()
