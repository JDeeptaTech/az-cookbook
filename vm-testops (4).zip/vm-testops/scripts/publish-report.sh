#!/usr/bin/env bash
# Build the Allure report locally with the same history-preservation flow
# the CI uses. Useful for previewing what GH Pages will publish before push.
#
# Usage:
#   ./scripts/publish-report.sh                    # local report only
#   ./scripts/publish-report.sh --push             # build + push to gh-pages
#
# Requires: allure CLI, git, jq (optional, for trimming).

set -euo pipefail

PUSH=false
KEEP_HISTORY="${KEEP_REPORT_HISTORY:-20}"
REMOTE="${GIT_REMOTE:-origin}"
GH_PAGES_BRANCH="gh-pages"
RESULTS_DIR="allure-results"
REPORT_DIR="allure-report"

while [[ $# -gt 0 ]]; do
  case "$1" in
    --push) PUSH=true; shift ;;
    --keep) KEEP_HISTORY="$2"; shift 2 ;;
    --help) sed -n '2,12p' "$0"; exit 0 ;;
    *) echo "Unknown arg: $1"; exit 1 ;;
  esac
done

command -v allure >/dev/null || { echo "allure CLI not found in PATH"; exit 1; }
command -v git    >/dev/null || { echo "git not found"; exit 1; }
[[ -d "$RESULTS_DIR" ]] || { echo "$RESULTS_DIR not found — run pytest first"; exit 1; }

# Carry history forward from the existing gh-pages branch, if any.
WORKTREE=$(mktemp -d)
cleanup() { rm -rf "$WORKTREE"; }
trap cleanup EXIT

if git ls-remote --exit-code --heads "$REMOTE" "$GH_PAGES_BRANCH" >/dev/null 2>&1; then
  echo "→ Fetching existing $GH_PAGES_BRANCH for history continuity"
  git fetch "$REMOTE" "$GH_PAGES_BRANCH" --depth=1 || true
  git worktree add -f "$WORKTREE" "$REMOTE/$GH_PAGES_BRANCH" 2>/dev/null || \
    git worktree add -f "$WORKTREE" "refs/remotes/$REMOTE/$GH_PAGES_BRANCH"
  if [[ -d "$WORKTREE/history" ]]; then
    echo "→ Carrying forward $WORKTREE/history into $RESULTS_DIR/history"
    rm -rf "$RESULTS_DIR/history"
    cp -r "$WORKTREE/history" "$RESULTS_DIR/history"
  else
    echo "→ No prior history found on $GH_PAGES_BRANCH"
  fi
  git worktree remove --force "$WORKTREE" 2>/dev/null || true
else
  echo "→ $GH_PAGES_BRANCH branch doesn't exist yet — first publish"
fi

[[ -f allure_categories.json ]] && cp allure_categories.json "$RESULTS_DIR/categories.json"

echo "→ Generating Allure report"
allure generate "$RESULTS_DIR" --clean -o "$REPORT_DIR"

# Trim history-trend to KEEP_HISTORY entries
if [[ -f "$REPORT_DIR/history/history-trend.json" ]] && command -v python3 >/dev/null; then
  python3 - <<PY
import json, pathlib
p = pathlib.Path("$REPORT_DIR/history/history-trend.json")
data = json.loads(p.read_text())
keep = int("$KEEP_HISTORY")
if len(data) > keep:
    p.write_text(json.dumps(data[:keep], indent=2))
    print(f"→ Trimmed history-trend.json to {keep} entries")
PY
fi

echo "→ Report at $REPORT_DIR/index.html"

if ! $PUSH; then
  echo "→ Done (use --push to deploy to $GH_PAGES_BRANCH)"
  exit 0
fi

# Push to gh-pages branch
TMP_PUBLISH=$(mktemp -d)
trap "rm -rf $WORKTREE $TMP_PUBLISH" EXIT

git worktree add --orphan -B "$GH_PAGES_BRANCH" "$TMP_PUBLISH" 2>/dev/null || \
  git worktree add -B "$GH_PAGES_BRANCH" "$TMP_PUBLISH"

# Wipe the worktree but preserve .git pointer
find "$TMP_PUBLISH" -mindepth 1 -maxdepth 1 -not -name '.git' -exec rm -rf {} +
cp -r "$REPORT_DIR"/. "$TMP_PUBLISH"/
touch "$TMP_PUBLISH/.nojekyll"

pushd "$TMP_PUBLISH" >/dev/null
git add -A
if git diff --cached --quiet; then
  echo "→ No changes to publish"
else
  git -c user.email=ci@local -c user.name="report-publish" \
    commit -m "Allure report: $(date -u +%Y-%m-%dT%H:%M:%SZ)"
  git push "$REMOTE" "$GH_PAGES_BRANCH" --force-with-lease
fi
popd >/dev/null

git worktree remove --force "$TMP_PUBLISH" 2>/dev/null || true
echo "→ Published to $GH_PAGES_BRANCH"
