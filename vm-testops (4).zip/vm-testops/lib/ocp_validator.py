"""
OpenShift-side validators for VM operations.

Each `expect_*` method:
  1. Wraps itself in an Allure step
  2. Reads from the cluster (via OCPClient)
  3. Attaches the raw resource JSON to the Allure report
  4. Asserts on the expected state, with a clear failure message

Validators support `wait_until=` for state that propagates asynchronously
(e.g. VMI phase change lagging behind the API's "stopped" response).
"""
from __future__ import annotations

import time
from datetime import datetime, timezone
from typing import Callable, Optional

import allure

from lib.allure_utils import attach_json, attach_text
from lib.ocp_client import OCPClient, OCPNotFound

DEFAULT_WAIT_TIMEOUT = 60
DEFAULT_WAIT_INTERVAL = 3


class ValidationFailed(AssertionError):
    """OCP state didn't match expectations."""


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _wait_for(
    predicate: Callable[[], tuple[bool, dict]],
    timeout: int,
    interval: float,
    description: str,
) -> dict:
    """
    Poll until predicate returns (True, payload), or raise after timeout.
    predicate returns (matched, latest_payload).
    """
    deadline = time.monotonic() + timeout
    last_payload: dict = {}
    poll_count = 0
    while time.monotonic() < deadline:
        poll_count += 1
        try:
            matched, last_payload = predicate()
        except OCPNotFound as e:
            last_payload = {"not_found": str(e)}
            matched = False
        if matched:
            return last_payload
        time.sleep(interval)
    raise ValidationFailed(
        f"{description}: condition not met after {timeout}s "
        f"({poll_count} polls). Last payload: {last_payload}"
    )


class OCPValidator:
    """Validators that read OCP/KubeVirt state and assert on it."""

    def __init__(self, ocp: OCPClient, enabled: bool = True):
        self.ocp = ocp
        self.enabled = enabled

    def _skip_if_disabled(self, what: str) -> bool:
        if not self.enabled:
            allure.attach(
                f"OCP validation disabled (OCP_VALIDATION_ENABLED=false); "
                f"skipping {what}",
                name="ocp-validation-skipped",
                attachment_type=allure.attachment_type.TEXT,
            )
            return True
        return False

    # ---------- VM lifecycle / power state ----------
    def expect_vm_running(
        self,
        vm_name: str,
        timeout: int = 120,
        interval: float = DEFAULT_WAIT_INTERVAL,
    ) -> None:
        if self._skip_if_disabled(f"expect_vm_running({vm_name})"):
            return
        with allure.step(f"[OCP] VM {vm_name} is Running"):
            def check():
                vm = self.ocp.get_vm(vm_name)
                printable = vm.get("status", {}).get("printableStatus", "")
                ready = vm.get("status", {}).get("ready", False)
                return (printable == "Running" and ready), vm

            vm = _wait_for(check, timeout, interval, f"VM {vm_name} Running")
            attach_json(f"vm-cr-{vm_name}", vm)
            self._validate_vmi_phase(vm_name, expected="Running", timeout=30)

    def expect_vm_stopped(
        self,
        vm_name: str,
        timeout: int = 120,
        interval: float = DEFAULT_WAIT_INTERVAL,
    ) -> None:
        if self._skip_if_disabled(f"expect_vm_stopped({vm_name})"):
            return
        with allure.step(f"[OCP] VM {vm_name} is Stopped"):
            def check():
                vm = self.ocp.get_vm(vm_name)
                printable = vm.get("status", {}).get("printableStatus", "")
                ready = vm.get("status", {}).get("ready", True)
                return (printable in ("Stopped", "Halted") and not ready), vm

            vm = _wait_for(check, timeout, interval, f"VM {vm_name} Stopped")
            attach_json(f"vm-cr-{vm_name}", vm)
            # VMI should be gone when VM is stopped.
            try:
                vmi = self.ocp.get_vmi(vm_name)
                attach_json(f"vmi-cr-{vm_name}-still-present", vmi)
                raise ValidationFailed(
                    f"VMI for {vm_name} still exists after stop"
                )
            except OCPNotFound:
                pass  # expected

    def _validate_vmi_phase(
        self,
        vm_name: str,
        expected: str,
        timeout: int = 60,
    ) -> dict:
        def check():
            vmi = self.ocp.get_vmi(vm_name)
            phase = vmi.get("status", {}).get("phase", "")
            return phase == expected, vmi

        vmi = _wait_for(check, timeout, DEFAULT_WAIT_INTERVAL, f"VMI phase={expected}")
        attach_json(f"vmi-cr-{vm_name}", vmi)
        return vmi

    # ---------- Disk operations ----------
    def expect_disk_attached(
        self,
        vm_name: str,
        disk_name: str,
        size_gb: Optional[int] = None,
        timeout: int = 180,
    ) -> None:
        """Verify a disk is present in VM spec AND backing PVC/DataVolume is Bound."""
        if self._skip_if_disabled(f"expect_disk_attached({vm_name},{disk_name})"):
            return
        with allure.step(f"[OCP] Disk {disk_name} attached to {vm_name}"):
            def check_spec():
                vm = self.ocp.get_vm(vm_name)
                disks = (
                    vm.get("spec", {}).get("template", {})
                    .get("spec", {}).get("domain", {})
                    .get("devices", {}).get("disks", [])
                )
                volumes = (
                    vm.get("spec", {}).get("template", {})
                    .get("spec", {}).get("volumes", [])
                )
                disk_in_spec = any(d.get("name") == disk_name for d in disks)
                vol = next((v for v in volumes if v.get("name") == disk_name), None)
                return (disk_in_spec and vol is not None), {
                    "disks": disks, "volumes": volumes, "matched_volume": vol,
                }

            spec_payload = _wait_for(
                check_spec, timeout, DEFAULT_WAIT_INTERVAL,
                f"disk {disk_name} in VM spec",
            )
            attach_json(f"vm-spec-disks-{vm_name}", spec_payload)

            # Resolve PVC/DataVolume name from volume reference and check binding.
            vol = spec_payload["matched_volume"]
            pvc_name = None
            if "persistentVolumeClaim" in vol:
                pvc_name = vol["persistentVolumeClaim"]["claimName"]
            elif "dataVolume" in vol:
                pvc_name = vol["dataVolume"]["name"]
            if pvc_name:
                self._validate_pvc_bound(pvc_name, size_gb=size_gb, timeout=timeout)

    def expect_disk_detached(self, vm_name: str, disk_name: str, timeout: int = 60) -> None:
        if self._skip_if_disabled(f"expect_disk_detached({vm_name},{disk_name})"):
            return
        with allure.step(f"[OCP] Disk {disk_name} detached from {vm_name}"):
            def check():
                vm = self.ocp.get_vm(vm_name)
                disks = (
                    vm.get("spec", {}).get("template", {})
                    .get("spec", {}).get("domain", {})
                    .get("devices", {}).get("disks", [])
                )
                return (not any(d.get("name") == disk_name for d in disks)), {
                    "disks": disks,
                }
            payload = _wait_for(
                check, timeout, DEFAULT_WAIT_INTERVAL,
                f"disk {disk_name} removed from VM spec",
            )
            attach_json(f"vm-spec-disks-{vm_name}-after-detach", payload)

    def _validate_pvc_bound(
        self,
        pvc_name: str,
        size_gb: Optional[int] = None,
        timeout: int = 180,
    ) -> None:
        with allure.step(f"[OCP] PVC {pvc_name} is Bound"):
            def check():
                pvc = self.ocp.get_pvc(pvc_name)
                phase = (pvc.get("status") or {}).get("phase", "")
                return phase == "Bound", pvc

            pvc = _wait_for(check, timeout, DEFAULT_WAIT_INTERVAL, f"PVC {pvc_name} Bound")
            attach_json(f"pvc-{pvc_name}", pvc)
            if size_gb is not None:
                capacity = (pvc.get("status") or {}).get("capacity", {})
                actual = capacity.get("storage", "")
                expected = f"{size_gb}Gi"
                if actual != expected:
                    raise ValidationFailed(
                        f"PVC {pvc_name} size mismatch: expected {expected}, got {actual}"
                    )

    # ---------- Network operations ----------
    def expect_nic_attached(self, vm_name: str, nic_name: str, network: str, timeout: int = 60) -> None:
        if self._skip_if_disabled(f"expect_nic_attached({vm_name},{nic_name})"):
            return
        with allure.step(f"[OCP] NIC {nic_name} attached to {vm_name} on {network}"):
            def check():
                vm = self.ocp.get_vm(vm_name)
                ifaces = (
                    vm.get("spec", {}).get("template", {})
                    .get("spec", {}).get("domain", {})
                    .get("devices", {}).get("interfaces", [])
                )
                nets = (
                    vm.get("spec", {}).get("template", {})
                    .get("spec", {}).get("networks", [])
                )
                iface = next((i for i in ifaces if i.get("name") == nic_name), None)
                net = next((n for n in nets if n.get("name") == nic_name), None)
                net_match = net and (
                    (net.get("multus") or {}).get("networkName") == network
                    or network in str(net)
                )
                return (iface is not None and bool(net_match)), {
                    "interfaces": ifaces, "networks": nets,
                }
            payload = _wait_for(
                check, timeout, DEFAULT_WAIT_INTERVAL,
                f"NIC {nic_name} attached on {network}",
            )
            attach_json(f"vm-spec-networks-{vm_name}", payload)

    def expect_nic_detached(self, vm_name: str, nic_name: str, timeout: int = 60) -> None:
        if self._skip_if_disabled(f"expect_nic_detached({vm_name},{nic_name})"):
            return
        with allure.step(f"[OCP] NIC {nic_name} detached from {vm_name}"):
            def check():
                vm = self.ocp.get_vm(vm_name)
                ifaces = (
                    vm.get("spec", {}).get("template", {})
                    .get("spec", {}).get("domain", {})
                    .get("devices", {}).get("interfaces", [])
                )
                return (not any(i.get("name") == nic_name for i in ifaces)), {
                    "interfaces": ifaces,
                }
            payload = _wait_for(
                check, timeout, DEFAULT_WAIT_INTERVAL,
                f"NIC {nic_name} removed",
            )
            attach_json(f"vm-spec-networks-{vm_name}-after-detach", payload)

    # ---------- Snapshots ----------
    def expect_snapshot_ready(self, snapshot_name: str, timeout: int = 600) -> None:
        if self._skip_if_disabled(f"expect_snapshot_ready({snapshot_name})"):
            return
        with allure.step(f"[OCP] VirtualMachineSnapshot {snapshot_name} readyToUse"):
            def check():
                snap = self.ocp.get_snapshot(snapshot_name)
                ready = (snap.get("status") or {}).get("readyToUse", False)
                return bool(ready), snap

            snap = _wait_for(check, timeout, 5, f"snapshot {snapshot_name} ready")
            attach_json(f"snapshot-cr-{snapshot_name}", snap)

    def expect_snapshot_absent(self, snapshot_name: str, timeout: int = 60) -> None:
        if self._skip_if_disabled(f"expect_snapshot_absent({snapshot_name})"):
            return
        with allure.step(f"[OCP] VirtualMachineSnapshot {snapshot_name} deleted"):
            def check():
                try:
                    snap = self.ocp.get_snapshot(snapshot_name)
                    return False, snap
                except OCPNotFound:
                    return True, {}
            _wait_for(check, timeout, DEFAULT_WAIT_INTERVAL, f"snapshot {snapshot_name} absent")

    # ---------- Events (warning detection) ----------
    def expect_no_warning_events(
        self,
        vm_name: str,
        since_iso: Optional[str] = None,
        ignore_reasons: Optional[set] = None,
    ) -> None:
        """
        Fail if there are Warning-type events on the VM after `since_iso`.
        Some warnings are noisy (e.g. SyncFailed on transient image pulls);
        pass `ignore_reasons={'SyncFailed'}` to filter them.
        """
        if self._skip_if_disabled(f"expect_no_warning_events({vm_name})"):
            return
        ignore_reasons = ignore_reasons or set()
        with allure.step(f"[OCP] No Warning events on VM {vm_name}"):
            events = self.ocp.get_events("VirtualMachine", vm_name, since_iso=since_iso)
            warnings = [
                e for e in events
                if e.get("type") == "Warning"
                and e.get("reason") not in ignore_reasons
            ]
            attach_json(f"events-{vm_name}", {
                "since": since_iso,
                "total_events": len(events),
                "warnings": warnings,
            })
            if warnings:
                summary = "; ".join(
                    f"{e.get('reason')}: {e.get('message')}" for e in warnings[:5]
                )
                raise ValidationFailed(
                    f"{len(warnings)} warning event(s) on {vm_name}: {summary}"
                )

    # ---------- Composite: full post-op health check ----------
    def expect_vm_healthy(self, vm_name: str, since_iso: Optional[str] = None) -> None:
        """Convenience: VM Running + no warnings since `since_iso`."""
        if self._skip_if_disabled(f"expect_vm_healthy({vm_name})"):
            return
        self.expect_vm_running(vm_name)
        self.expect_no_warning_events(
            vm_name,
            since_iso=since_iso,
            ignore_reasons={"SyncFailed"},  # tune to taste
        )
