"""Helpers for richer Allure reports."""
from __future__ import annotations

import json
import os
import platform
from pathlib import Path
from typing import Any

import allure


def attach_json(name: str, data: Any) -> None:
    allure.attach(
        json.dumps(data, indent=2, default=str),
        name=name,
        attachment_type=allure.attachment_type.JSON,
    )


def attach_text(name: str, text: str) -> None:
    allure.attach(text, name=name, attachment_type=allure.attachment_type.TEXT)


def write_environment(results_dir: str, extra: dict) -> None:
    """Allure reads environment.properties for the report header."""
    Path(results_dir).mkdir(parents=True, exist_ok=True)
    lines = [
        f"python.version={platform.python_version()}",
        f"platform={platform.platform()}",
        f"hostname={platform.node()}",
    ]
    lines += [f"{k}={v}" for k, v in extra.items() if v is not None]
    Path(results_dir, "environment.properties").write_text("\n".join(lines))


def write_executor(results_dir: str) -> None:
    """Optional: Allure 'executor' badge for CI runs."""
    executor = {
        "name": os.environ.get("CI_PIPELINE_NAME", "local"),
        "type": os.environ.get("CI_TYPE", "manual"),
        "url": os.environ.get("CI_PIPELINE_URL", ""),
        "buildOrder": os.environ.get("BUILD_NUMBER", "0"),
        "buildName": os.environ.get("BUILD_TAG", "local"),
        "buildUrl": os.environ.get("BUILD_URL", ""),
        "reportUrl": os.environ.get("REPORT_URL", ""),
        "reportName": "VM TestOps Report",
    }
    Path(results_dir).mkdir(parents=True, exist_ok=True)
    Path(results_dir, "executor.json").write_text(json.dumps(executor, indent=2))
