"""
Thin wrapper around the kubernetes Python client for KubeVirt CRDs.

Auth resolution order:
  1. In-cluster (pod ServiceAccount)
  2. KUBECONFIG env var or ~/.kube/config
  3. OCP_API_URL + OCP_API_TOKEN env vars

Reads are deliberately scoped to the namespace where VMs live
(VM_NAMESPACE env var, defaulting to 'virtualinfrahub-dev').
"""
from __future__ import annotations

import os
from typing import Any, Optional

from kubernetes import client, config
from kubernetes.client.rest import ApiException

KUBEVIRT_GROUP = "kubevirt.io"
KUBEVIRT_VERSION = "v1"
CDI_GROUP = "cdi.kubevirt.io"
CDI_VERSION = "v1beta1"
SNAPSHOT_GROUP = "snapshot.kubevirt.io"
SNAPSHOT_VERSION = "v1beta1"


class OCPNotFound(Exception):
    """Resource does not exist in the cluster."""


def _load_kube_config() -> None:
    """Try in-cluster, kubeconfig file, then explicit env vars in turn."""
    # 1. In-cluster
    try:
        config.load_incluster_config()
        return
    except config.ConfigException:
        pass

    # 2. Kubeconfig file
    kubeconfig = os.environ.get("KUBECONFIG")
    if kubeconfig and os.path.exists(kubeconfig):
        config.load_kube_config(config_file=kubeconfig)
        return
    if os.path.exists(os.path.expanduser("~/.kube/config")):
        config.load_kube_config()
        return

    # 3. Direct API + token
    api_url = os.environ.get("OCP_API_URL")
    token = os.environ.get("OCP_API_TOKEN")
    if api_url and token:
        cfg = client.Configuration()
        cfg.host = api_url
        cfg.api_key = {"authorization": f"Bearer {token}"}
        ca_cert = os.environ.get("OCP_API_CA_CERT")
        if ca_cert:
            cfg.ssl_ca_cert = ca_cert
            cfg.verify_ssl = True
        else:
            cfg.verify_ssl = (
                os.environ.get("OCP_API_INSECURE", "").lower() != "true"
            )
        client.Configuration.set_default(cfg)
        return

    raise RuntimeError(
        "No Kubernetes auth available. Set KUBECONFIG, or "
        "OCP_API_URL + OCP_API_TOKEN, or run inside a cluster."
    )


class OCPClient:
    """Read-only client for KubeVirt and adjacent CRDs."""

    def __init__(self, namespace: Optional[str] = None):
        _load_kube_config()
        self.namespace = namespace or os.environ.get(
            "VM_NAMESPACE", "virtualinfrahub-dev"
        )
        self.custom = client.CustomObjectsApi()
        self.core = client.CoreV1Api()

    # ---------- KubeVirt VirtualMachine ----------
    def get_vm(self, name: str) -> dict:
        try:
            return self.custom.get_namespaced_custom_object(
                group=KUBEVIRT_GROUP,
                version=KUBEVIRT_VERSION,
                namespace=self.namespace,
                plural="virtualmachines",
                name=name,
            )
        except ApiException as e:
            if e.status == 404:
                raise OCPNotFound(f"VM '{name}' not found in {self.namespace}")
            raise

    def get_vmi(self, name: str) -> dict:
        """VirtualMachineInstance (runtime state). 404 if VM is stopped."""
        try:
            return self.custom.get_namespaced_custom_object(
                group=KUBEVIRT_GROUP,
                version=KUBEVIRT_VERSION,
                namespace=self.namespace,
                plural="virtualmachineinstances",
                name=name,
            )
        except ApiException as e:
            if e.status == 404:
                raise OCPNotFound(f"VMI '{name}' not found (VM may be stopped)")
            raise

    def list_vms(self, label_selector: Optional[str] = None) -> list[dict]:
        resp = self.custom.list_namespaced_custom_object(
            group=KUBEVIRT_GROUP,
            version=KUBEVIRT_VERSION,
            namespace=self.namespace,
            plural="virtualmachines",
            label_selector=label_selector or "",
        )
        return resp.get("items", [])

    # ---------- Disks / DataVolumes / PVCs ----------
    def get_datavolume(self, name: str) -> dict:
        try:
            return self.custom.get_namespaced_custom_object(
                group=CDI_GROUP,
                version=CDI_VERSION,
                namespace=self.namespace,
                plural="datavolumes",
                name=name,
            )
        except ApiException as e:
            if e.status == 404:
                raise OCPNotFound(f"DataVolume '{name}' not found")
            raise

    def get_pvc(self, name: str) -> dict:
        try:
            return self.core.read_namespaced_persistent_volume_claim(
                name=name, namespace=self.namespace
            ).to_dict()
        except ApiException as e:
            if e.status == 404:
                raise OCPNotFound(f"PVC '{name}' not found")
            raise

    # ---------- Snapshots ----------
    def get_snapshot(self, name: str) -> dict:
        try:
            return self.custom.get_namespaced_custom_object(
                group=SNAPSHOT_GROUP,
                version=SNAPSHOT_VERSION,
                namespace=self.namespace,
                plural="virtualmachinesnapshots",
                name=name,
            )
        except ApiException as e:
            if e.status == 404:
                raise OCPNotFound(f"VirtualMachineSnapshot '{name}' not found")
            raise

    def list_snapshots(self, vm_name: str) -> list[dict]:
        """All VirtualMachineSnapshot objects for a given VM."""
        resp = self.custom.list_namespaced_custom_object(
            group=SNAPSHOT_GROUP,
            version=SNAPSHOT_VERSION,
            namespace=self.namespace,
            plural="virtualmachinesnapshots",
        )
        items = resp.get("items", [])
        return [
            s for s in items
            if (s.get("spec", {}).get("source", {}).get("name") == vm_name)
        ]

    # ---------- Events ----------
    def get_events(
        self,
        involved_kind: str,
        involved_name: str,
        since_iso: Optional[str] = None,
    ) -> list[dict]:
        """Events for a specific object, optionally filtered by lastTimestamp >= since."""
        field_selector = (
            f"involvedObject.kind={involved_kind},"
            f"involvedObject.name={involved_name}"
        )
        resp = self.core.list_namespaced_event(
            namespace=self.namespace,
            field_selector=field_selector,
        )
        items = [e.to_dict() for e in resp.items]
        if since_iso:
            from datetime import datetime
            since = datetime.fromisoformat(since_iso.replace("Z", "+00:00"))
            filtered = []
            for e in items:
                ts = e.get("last_timestamp") or e.get("event_time")
                if ts is None:
                    continue
                # k8s client returns datetime objects already
                if hasattr(ts, "tzinfo") and ts >= since:
                    filtered.append(e)
            return filtered
        return items
