"""
State store for the build -> day2 handoff.

Build tests write VM identifiers here; day2 tests read them.
File-based so it survives across pytest invocations:
  pytest --phase=build         # writes
  pytest --phase=day2          # reads

Uses cross-process file locking so pytest-xdist workers (separate
processes) don't race on the JSON file. POSIX path uses fcntl;
Windows path falls back to msvcrt.locking.
"""
from __future__ import annotations

import json
import os
import sys
from contextlib import contextmanager
from pathlib import Path
from typing import Optional

STATE_FILE = Path(os.environ.get("VM_STATE_FILE", "vm_state.json"))
LOCK_FILE = STATE_FILE.with_suffix(STATE_FILE.suffix + ".lock")


@contextmanager
def _file_lock():
    """Exclusive cross-process file lock."""
    LOCK_FILE.parent.mkdir(parents=True, exist_ok=True)
    if sys.platform == "win32":
        import msvcrt
        with open(LOCK_FILE, "a+b") as fh:
            try:
                msvcrt.locking(fh.fileno(), msvcrt.LK_LOCK, 1)
                yield
            finally:
                try:
                    fh.seek(0)
                    msvcrt.locking(fh.fileno(), msvcrt.LK_UNLCK, 1)
                except OSError:
                    pass
    else:
        import fcntl
        fd = os.open(str(LOCK_FILE), os.O_CREAT | os.O_RDWR, 0o644)
        try:
            fcntl.flock(fd, fcntl.LOCK_EX)
            yield
        finally:
            try:
                fcntl.flock(fd, fcntl.LOCK_UN)
            finally:
                os.close(fd)


def _load() -> dict:
    if not STATE_FILE.exists():
        return {}
    try:
        return json.loads(STATE_FILE.read_text())
    except json.JSONDecodeError:
        return {}


def _save(data: dict) -> None:
    STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
    tmp = STATE_FILE.with_suffix(STATE_FILE.suffix + ".tmp")
    tmp.write_text(json.dumps(data, indent=2, default=str))
    tmp.replace(STATE_FILE)


def record_vm(os_id: str, vm_info: dict) -> None:
    with _file_lock():
        data = _load()
        data[os_id] = vm_info
        _save(data)


def get_vm(os_id: str) -> Optional[dict]:
    with _file_lock():
        return _load().get(os_id)


def all_vms() -> dict:
    with _file_lock():
        return _load()


def clear() -> None:
    with _file_lock():
        if STATE_FILE.exists():
            STATE_FILE.unlink()
        if LOCK_FILE.exists():
            try:
                LOCK_FILE.unlink()
            except OSError:
                pass
