"""
HTTP client for the cto-pa-hic-vm/api/v3 platform.

Conventions matching the Swagger:
  - vm_name (string) is the path identifier, used as ${vm_name} in templates
  - Async ops return {"invocationId": "..."} (or similar); polled via
    GET /requests/{invocationId}
  - Build endpoints are top-level: /builds/smartlinux, /builds/linux, etc.
  - All routes are registered in config/operations.yaml.

Test code does:
    handle = client.submit_op(vm_name, "snapshot.create", params={"name": "s1"})
    result = client.waiter().wait(handle)
"""
from __future__ import annotations

import os
from datetime import datetime, timezone
from typing import Any, Optional

import httpx
from tenacity import (
    retry,
    retry_if_exception_type,
    stop_after_attempt,
    wait_exponential,
)

from lib.async_ops import AsyncOpWaiter, OpHandle, new_correlation_id
from lib.op_registry import OperationRegistry, OperationSpec, get_registry


def _unwrap(body: Any) -> Any:
    """Unwrap common envelope shapes. Handles {data: {...}} and bare dicts."""
    if isinstance(body, dict) and "data" in body and not any(
        k in body for k in ("invocationId", "status", "state")
    ):
        return body["data"]
    return body


def _extract_invocation_id(body: Any, field_path: str) -> Optional[str]:
    """Pull invocationId from a submit response.

    Looks at field_path first (e.g. 'invocationId' or 'data.invocationId'),
    then common fallbacks. Walks dotted paths.
    """
    def walk(d, path):
        for part in path.split("."):
            if isinstance(d, dict) and part in d:
                d = d[part]
            else:
                return None
        return d

    val = walk(body, field_path)
    if val:
        return str(val)
    # Fallback search at top level and inside .data
    candidates = ["invocationId", "invocation_id", "requestId", "request_id", "id"]
    targets = [body]
    if isinstance(body, dict) and isinstance(body.get("data"), dict):
        targets.append(body["data"])
    for t in targets:
        if not isinstance(t, dict):
            continue
        for k in candidates:
            if t.get(k):
                return str(t[k])
    return None


class VMPlatformClient:
    def __init__(
        self,
        base_url: Optional[str] = None,
        token: Optional[str] = None,
        timeout: float = 60.0,
        verify_ssl: Optional[bool] = None,
        registry: Optional[OperationRegistry] = None,
    ):
        # base_url should include the /cto-pa-hic-vm/api/v3 path prefix,
        # since the Swagger paths are relative to it.
        self.base_url = base_url or os.environ["VM_API_BASE_URL"]
        self.token = token or os.environ["VM_API_TOKEN"]
        if verify_ssl is None:
            verify_ssl = os.environ.get("VM_API_VERIFY_SSL", "true").lower() != "false"
        self.client = httpx.Client(
            base_url=self.base_url,
            headers={
                "Authorization": f"Bearer {self.token}",
                "Accept": "application/json",
            },
            timeout=timeout,
            verify=verify_ssl,
        )
        self.registry = registry or get_registry()

    def close(self) -> None:
        self.client.close()

    # ---------- Low-level dispatch ----------
    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(min=2, max=10),
        retry=retry_if_exception_type(httpx.TransportError),
    )
    def _request(
        self,
        method: str,
        path: str,
        json: Optional[dict] = None,
        params: Optional[dict] = None,
        headers: Optional[dict] = None,
        success_codes: Optional[list[int]] = None,
    ) -> dict:
        r = self.client.request(
            method, path, json=json, params=params, headers=headers,
        )
        if success_codes and r.status_code not in success_codes:
            try:
                r.raise_for_status()
            except httpx.HTTPStatusError:
                raise
            raise httpx.HTTPStatusError(
                f"Unexpected status {r.status_code} (allowed: {success_codes})",
                request=r.request, response=r,
            )
        r.raise_for_status()
        try:
            return r.json()
        except ValueError:
            return {}

    # ---------- Unified submit + wait ----------
    def submit_op(
        self,
        vm_name: Optional[str],
        operation: str,
        params: Optional[dict] = None,
        body: Optional[dict] = None,
        correlation_id: Optional[str] = None,
    ) -> OpHandle:
        """
        Submit any registered operation.

        - vm_name may be None for top-level ops (builds, cluster-level ops)
        - body, if provided, overrides the registry-rendered body entirely
          (useful for build endpoints where the full payload comes from the
          test rather than from substitution)
        """
        corr = correlation_id or new_correlation_id()
        spec, rendered = self.registry.render(
            operation, vm_name=vm_name, params=params or {},
        )
        request_body = body if body is not None else rendered["body"]
        response = self._request(
            rendered["method"],
            rendered["path"],
            json=request_body,
            params=rendered["query"],
            headers={"X-Correlation-Id": corr},
            success_codes=rendered["success_codes"],
        )
        return self._handle_from_response(
            response, spec, operation,
            vm_name=vm_name or "(global)",
            correlation_id=corr,
            params=params,
        )

    def _handle_from_response(
        self,
        body: dict,
        spec: OperationSpec,
        operation: str,
        vm_name: str,
        correlation_id: str,
        params: Optional[dict] = None,
    ) -> OpHandle:
        op_family = operation.split(".", 1)[0] if "." in operation else operation

        if spec.is_async:
            invocation_id = _extract_invocation_id(body, spec.request_id_field)
            if not invocation_id:
                raise RuntimeError(
                    f"{operation} async response missing invocationId "
                    f"(looked for {spec.request_id_field!r}): {body}"
                )
            return OpHandle(
                request_id=invocation_id,
                operation=operation,
                vm_id=vm_name,
                correlation_id=correlation_id,
                submitted_at=datetime.now(timezone.utc),
                metadata={
                    "op_family": op_family,
                    "params": params or {},
                    "mode": "async",
                    "poll_path": spec.poll_path,
                },
            )

        return OpHandle(
            request_id=f"sync-{correlation_id}",
            operation=operation,
            vm_id=vm_name,
            correlation_id=correlation_id,
            submitted_at=datetime.now(timezone.utc),
            metadata={
                "op_family": op_family,
                "params": params or {},
                "mode": "sync",
                "sync_response": _unwrap(body),
            },
        )

    # Back-compat alias for existing tests / fixtures.
    submit_day2 = submit_op

    # ---------- Build VM helpers ----------
    def build_vm(self, build_type: str, payload: dict, correlation_id: Optional[str] = None) -> OpHandle:
        """
        Submit a VM build. `build_type` is one of:
          smart_linux, smart_windows, linux, windows
        Returns the async OpHandle; the caller waits on it.
        """
        op = f"build.{build_type}"
        return self.submit_op(
            vm_name=None,
            operation=op,
            body=payload,
            correlation_id=correlation_id,
        )

    # ---------- VM record lookup ----------
    def get_vm(self, vm_name: str) -> dict:
        _, rendered = self.registry.render("vm.get", vm_name=vm_name)
        body = self._request(
            rendered["method"], rendered["path"],
            success_codes=rendered["success_codes"],
        )
        return _unwrap(body)

    # ---------- Lifecycle ----------
    def demise_vm(self, vm_name: str) -> OpHandle:
        return self.submit_op(vm_name, "lifecycle.demise")

    # ---------- Poll endpoint ----------
    def poll_request(self, invocation_id: str, poll_path: Optional[str] = None) -> dict:
        path = poll_path or f"/requests/{invocation_id}"
        path = path.replace("${invocation_id}", invocation_id)
        r = self.client.get(path)
        r.raise_for_status()
        return _unwrap(r.json())

    def cancel_request(self, invocation_id: str) -> Optional[dict]:
        # Your Swagger doesn't show a cancel endpoint — best-effort only.
        try:
            r = self.client.post(f"/requests/{invocation_id}/cancel")
            r.raise_for_status()
            return _unwrap(r.json())
        except httpx.HTTPError:
            return None

    # ---------- Waiter ----------
    def waiter(self) -> AsyncOpWaiter:
        return AsyncOpWaiter(poll_fn=self._poll_for_waiter)

    def _poll_for_waiter(self, invocation_id: str, handle: Optional[OpHandle] = None) -> dict:
        poll_path = None
        if handle and handle.metadata:
            poll_path = handle.metadata.get("poll_path")
            if poll_path:
                poll_path = poll_path.replace("${invocation_id}", invocation_id)
        return self.poll_request(invocation_id, poll_path=poll_path)
