"""
Central conftest: CLI flags, OS parametrization, build/day2 phase routing,
and shared fixtures.
"""
from __future__ import annotations

import os
from pathlib import Path
from typing import List

import allure
import pytest
import yaml

# Optional .env loading so local runs don't need exported vars
try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

from lib.allure_utils import attach_json, write_environment, write_executor
from lib.async_ops import OpHandle
from lib.state_store import get_vm, record_vm
from lib.vm_api_client import VMPlatformClient

CONFIG_DIR = Path(__file__).parent / "config"
ALLURE_RESULTS_DIR = "allure-results"


# ---------- CLI options ----------
def pytest_addoption(parser):
    g = parser.getgroup("vm-testops")
    g.addoption(
        "--phase",
        action="store",
        default="all",
        choices=["build", "day2", "all"],
        help="Which test phase to run (default: all)",
    )
    g.addoption(
        "--os",
        action="store",
        default="",
        help="Comma-separated OS family filter: linux,windows",
    )
    g.addoption(
        "--os-version",
        action="store",
        default="",
        help="Comma-separated OS id filter: rhel8,win2022",
    )
    g.addoption(
        "--day2-op",
        action="store",
        default="",
        help="Comma-separated day2 op family filter: power,disk,snapshot,network",
    )
    g.addoption(
        "--keep-vms",
        action="store_true",
        default=False,
        help="Don't delete VMs at session end (useful for debugging)",
    )
    g.addoption(
        "--no-ocp-validation",
        action="store_true",
        default=False,
        help="Skip all OCP/KubeVirt side validations (API-only assertions)",
    )
    g.addoption(
        "--vm",
        action="append",
        default=[],
        help=(
            "Run day-2 tests against an existing VM. Format: "
            "name:os_id (repeatable, or comma-separated). "
            "Example: --vm=prod-rhel8-01:rhel8 --vm=win-canary:win2022. "
            "Implies --phase=day2 if not already set. Overrides vm_state.json."
        ),
    )
    g.addoption(
        "--vm-pool",
        action="store",
        default="",
        help=(
            "YAML file listing existing VMs to test. See "
            "config/vm_pool.example.yaml. Used like --vm but for stable test pools."
        ),
    )


def pytest_configure(config):
    """Guardrail: refuse to run xdist with any dist mode other than loadgroup.

    The default 'load' mode would spray tests for the same OS across
    multiple workers, each provisioning its own VM, breaking the
    session-scoped provisioned_vm fixture contract. loadgroup with the
    xdist_group markers we add per-OS is the only safe option.
    """
    numprocesses = getattr(config.option, "numprocesses", None)
    dist = getattr(config.option, "dist", "no")
    if numprocesses and numprocesses not in ("0", 0) and dist != "loadgroup":
        raise pytest.UsageError(
            "Parallel runs require --dist loadgroup. Found --dist={!r}. "
            "Other dist modes split same-OS tests across workers and break "
            "the session-scoped provisioned_vm fixture.".format(dist)
        )

    # If user supplied existing VMs, force day2 phase. Building over an
    # external VM we don't own would be destructive (the cleanup hook
    # would delete it). Also auto-enable --keep-vms so we never delete
    # someone else's VM by accident.
    has_external = bool(
        config.getoption("--vm") or config.getoption("--vm-pool")
    )
    if has_external:
        phase = config.getoption("--phase")
        if phase == "build":
            raise pytest.UsageError(
                "--vm / --vm-pool cannot be combined with --phase=build "
                "(would attempt to provision over external VMs). "
                "Use --phase=day2 explicitly, or omit --phase."
            )
        if phase == "all":
            # all = build + day2; with external VMs only day2 makes sense
            config.option.phase = "day2"
        # Protect against the cleanup hook deleting external VMs.
        config.option.keep_vms = True


# ---------- Config loaders ----------
def _load_os_matrix() -> List[dict]:
    with (CONFIG_DIR / "os_matrix.yaml").open() as f:
        return yaml.safe_load(f)["os_versions"]


def _load_day2_matrix() -> dict:
    with (CONFIG_DIR / "day2_matrix.yaml").open() as f:
        return yaml.safe_load(f)["day2_operations"]


@pytest.fixture(scope="session")
def os_matrix() -> List[dict]:
    return _load_os_matrix()


@pytest.fixture(scope="session")
def day2_matrix() -> dict:
    return _load_day2_matrix()


@pytest.fixture(scope="session")
def vm_client():
    client = VMPlatformClient()
    yield client
    client.close()


@pytest.fixture(scope="session")
def ocp_client():
    """Lazily-constructed OCPClient. Returns None if validation disabled."""
    if os.environ.get("OCP_VALIDATION_ENABLED", "true").lower() != "true":
        return None
    from lib.ocp_client import OCPClient
    try:
        return OCPClient()
    except Exception as e:
        # Don't fail the whole session on auth issues; validators will
        # raise their own clearer errors if they're actually used.
        import warnings
        warnings.warn(f"OCPClient init failed: {e!r}. Validators will skip.")
        return None


@pytest.fixture
def ocp_validator(request, ocp_client):
    """Per-test OCPValidator. Auto-disabled if ocp_client is None."""
    from lib.ocp_validator import OCPValidator
    cli_disabled = request.config.getoption("--no-ocp-validation")
    env_enabled = os.environ.get("OCP_VALIDATION_ENABLED", "true").lower() == "true"
    enabled = ocp_client is not None and env_enabled and not cli_disabled
    return OCPValidator(ocp_client, enabled=enabled)


# ---------- OS filtering + parametrization ----------
def _filter_os(items: List[dict], os_filter: str, version_filter: str) -> List[dict]:
    if os_filter:
        families = {f.strip() for f in os_filter.split(",") if f.strip()}
        items = [i for i in items if i["family"] in families]
    if version_filter:
        versions = {v.strip() for v in version_filter.split(",") if v.strip()}
        items = [i for i in items if i["id"] in versions]
    return items


def pytest_generate_tests(metafunc):
    """Inject the `os_spec` fixture wherever a test asks for it."""
    if "os_spec" in metafunc.fixturenames:
        matrix = _load_os_matrix()
        matrix = _filter_os(
            matrix,
            metafunc.config.getoption("--os"),
            metafunc.config.getoption("--os-version"),
        )
        # If user passed --vm / --vm-pool, restrict to those OSes only.
        # Avoids generating parametrize entries for OSes we can't test.
        external = _ingest_existing_vms(metafunc.config)
        if external:
            matrix = [m for m in matrix if m["id"] in external]
        if not matrix:
            metafunc.parametrize("os_spec", [pytest.param(None, marks=pytest.mark.skip(
                reason="No OS matches filters (--os / --os-version / --vm)"
            ))])
            return
        metafunc.parametrize(
            "os_spec",
            matrix,
            ids=[m["id"] for m in matrix],
            scope="session",
        )


# ---------- Phase + day2-op filtering, dynamic markers ----------
_OS_IDS = {"rhel7", "rhel8", "rhel9", "win2019", "win2022"}
_LINUX_IDS = {"rhel7", "rhel8", "rhel9"}


def pytest_collection_modifyitems(config, items):
    phase = config.getoption("--phase")
    day2_filter = config.getoption("--day2-op")
    day2_ops = {o.strip() for o in day2_filter.split(",") if o.strip()} if day2_filter else None

    skip_build = pytest.mark.skip(reason="--phase=day2 active")
    skip_day2 = pytest.mark.skip(reason="--phase=build active")

    for item in items:
        # Auto-add OS family/version markers based on parametrize id, AND
        # pin each test to an xdist worker group keyed on the OS so all
        # tests for a given OS run serially on the same worker (sharing
        # the session-scoped `provisioned_vm` fixture).
        for os_id in _OS_IDS:
            if f"[{os_id}]" in item.nodeid:
                item.add_marker(getattr(pytest.mark, os_id))
                family = "linux" if os_id in _LINUX_IDS else "windows"
                item.add_marker(getattr(pytest.mark, family))
                item.add_marker(pytest.mark.xdist_group(name=f"os-{os_id}"))
                break

        is_build = "build" in item.keywords
        is_day2 = "day2" in item.keywords

        if phase == "build" and is_day2:
            item.add_marker(skip_day2)
        elif phase == "day2" and is_build:
            item.add_marker(skip_build)

        if day2_ops and is_day2:
            if not (set(item.keywords.keys()) & day2_ops):
                item.add_marker(
                    pytest.mark.skip(reason=f"day2 op filter excludes this: {day2_ops}")
                )


# ---------- Existing-VM ingest (--vm / --vm-pool) ----------
def _parse_vm_cli_args(values: List[str]) -> dict[str, dict]:
    """
    Parse --vm name:os_id arguments into {os_id: {id, name}} dicts.
    Accepts repeated --vm flags and/or comma-separated values.
    """
    result: dict[str, dict] = {}
    for raw in values:
        for item in raw.split(","):
            item = item.strip()
            if not item:
                continue
            if ":" not in item:
                raise pytest.UsageError(
                    f"--vm value {item!r} must be in 'name:os_id' form "
                    f"(example: my-vm:rhel8)"
                )
            name, os_id = item.rsplit(":", 1)
            name = name.strip()
            os_id = os_id.strip()
            if not name or not os_id:
                raise pytest.UsageError(f"--vm value {item!r} has empty name or os_id")
            # We treat name as both id and display name when injected
            # this way. The user can pass `id|name:os_id` if their API
            # needs distinct values, and we'll split on '|' here.
            vm_id = name
            if "|" in name:
                vm_id, name = name.split("|", 1)
            result[os_id] = {"id": vm_id, "name": name, "source": "cli"}
    return result


def _parse_vm_pool_file(path: Path) -> dict[str, dict]:
    """Load YAML pool file: { vms: { os_id: { id, name, ... } } }."""
    if not path.exists():
        raise pytest.UsageError(f"--vm-pool file not found: {path}")
    data = yaml.safe_load(path.read_text()) or {}
    vms = data.get("vms") or {}
    if not isinstance(vms, dict):
        raise pytest.UsageError(
            f"--vm-pool {path}: expected 'vms:' mapping at top level"
        )
    result = {}
    for os_id, vm in vms.items():
        if not isinstance(vm, dict) or "name" not in vm:
            raise pytest.UsageError(
                f"--vm-pool {path}: entry {os_id!r} must be a mapping with at least 'name'"
            )
        # 'id' falls back to 'name' if the API treats names as identifiers
        result[os_id] = {
            "id": vm.get("id", vm["name"]),
            "name": vm["name"],
            "source": "pool",
            **{k: v for k, v in vm.items() if k not in ("id", "name")},
        }
    return result


def _ingest_existing_vms(config) -> dict[str, dict]:
    """Combine --vm and --vm-pool inputs. CLI overrides pool on conflict."""
    pool_arg = config.getoption("--vm-pool")
    vm_args = config.getoption("--vm")

    merged: dict[str, dict] = {}
    if pool_arg:
        merged.update(_parse_vm_pool_file(Path(pool_arg)))
    if vm_args:
        merged.update(_parse_vm_cli_args(vm_args))
    return merged


# ---------- Allure env + executor ----------
def pytest_sessionstart(session):
    # Under xdist, only the controller should write shared metadata files
    # to allure-results/ — workers would race and clobber each other.
    if hasattr(session.config, "workerinput"):
        return

    # If the user passed --vm or --vm-pool, seed the state store now.
    # This makes day-2 tests treat them exactly like build-phase outputs.
    existing = _ingest_existing_vms(session.config)
    if existing:
        for os_id, vm in existing.items():
            record_vm(os_id, vm)

    write_environment(
        ALLURE_RESULTS_DIR,
        {
            "cluster": os.environ.get("OCP_CLUSTER", "unknown"),
            "namespace": os.environ.get("VM_NAMESPACE", "unknown"),
            "api_base_url": os.environ.get("VM_API_BASE_URL", "unknown"),
            "phase": session.config.getoption("--phase"),
            "os_filter": session.config.getoption("--os") or "all",
            "os_version_filter": session.config.getoption("--os-version") or "all",
            "day2_op_filter": session.config.getoption("--day2-op") or "all",
            "external_vms": ",".join(sorted(existing.keys())) or "none",
            "build_tag": os.environ.get("BUILD_TAG", "local"),
        },
    )
    write_executor(ALLURE_RESULTS_DIR)


# ---------- Provisioned VM fixture (the build->day2 contract) ----------
@pytest.fixture(scope="session")
def provisioned_vm(request, os_spec, vm_client):
    """
    Returns a VM record for the given os_spec.

    - phase=build or all: dispatches to the right /builds/<type> endpoint,
      waits for completion, records the VM, then yields it.
    - phase=day2: reads from state store; skips if absent.
    - On teardown (unless --keep-vms or external VM): calls
      lifecycle.demise to decommission.

    The VM record stored carries at least {name, build_type, os_id}.
    `name` is the canonical identifier the rest of the API uses.
    """
    if os_spec is None:
        pytest.skip("No OS spec available")

    phase = request.config.getoption("--phase")
    keep = request.config.getoption("--keep-vms")
    existing = get_vm(os_spec["id"])

    if phase == "day2":
        if not existing:
            pytest.skip(
                f"VM not found in state for {os_spec['id']} -- "
                f"run --phase=build first or pass --vm/--vm-pool"
            )
        yield existing
        return

    if existing and phase == "all":
        # Reuse existing within an 'all' run too
        yield existing
        return

    vm_name = f"test-{os_spec['id']}-{os.environ.get('BUILD_TAG', 'local')}"
    build_type = os_spec["build_type"]
    payload = {
        "name": vm_name,
        "image": os_spec["image"],
        "flavor": os_spec["flavor"],
        "cloud_init": os_spec.get("cloud_init", True),
    }
    with allure.step(f"Provision VM via build.{build_type} ({os_spec['id']})"):
        handle = vm_client.build_vm(build_type, payload)
        attach_json(f"build-submit-{os_spec['id']}", {
            "invocation_id": handle.request_id,
            "correlation_id": handle.correlation_id,
            "build_type": build_type,
        })
        result = vm_client.waiter().wait(handle)
        attach_json(f"build-result-{os_spec['id']}", result.final_payload)

    vm = {
        "name": vm_name,
        "os_id": os_spec["id"],
        "build_type": build_type,
        "invocation_id": handle.request_id,
        "build_payload": result.final_payload,
        # 'id' kept for back-compat with tests expecting vm['id']
        "id": vm_name,
    }
    record_vm(os_spec["id"], vm)
    yield vm

    if not keep and phase != "day2" and vm.get("source") not in ("cli", "pool"):
        try:
            with allure.step(f"Decommission VM ({vm_name})"):
                handle = vm_client.demise_vm(vm_name)
                vm_client.waiter().wait(handle)
        except Exception as e:
            allure.attach(
                f"Demise failed for {vm_name}: {e!r}",
                name="cleanup-error",
                attachment_type=allure.attachment_type.TEXT,
            )


# ---------- Async op helpers ----------
@pytest.fixture
def waiter(vm_client):
    return vm_client.waiter()


@pytest.fixture
def async_op_tracker(vm_client):
    """
    Tracks in-flight handles per test. On teardown, logs any unwaited handle
    and best-effort cancels it so failed tests don't leak AAP jobs.
    """
    handles: List[OpHandle] = []

    def _register(h: OpHandle) -> OpHandle:
        handles.append(h)
        return h

    yield _register

    for h in handles:
        try:
            status = vm_client.poll_request(h.request_id)
            state = (status.get("state") or status.get("status") or "").upper()
            if state in {"PENDING", "RUNNING", "IN_PROGRESS", "QUEUED", "WAITING", "STARTED"}:
                allure.attach(
                    f"Leaked in-flight request: {h.request_id} "
                    f"({h.operation}) still in state={state}. Attempting cancel.",
                    name="leaked-async-op",
                    attachment_type=allure.attachment_type.TEXT,
                )
                vm_client.cancel_request(h.request_id)
        except Exception:
            pass


# ---------- Per-test labels for Allure ----------
@pytest.fixture(autouse=True)
def _allure_labels(request):
    spec = None
    if hasattr(request.node, "funcargs"):
        spec = request.node.funcargs.get("os_spec")
    if spec:
        allure.dynamic.label("os_family", spec["family"])
        allure.dynamic.label("os_version", spec["id"])
        allure.dynamic.label("image", spec["image"])
    yield
