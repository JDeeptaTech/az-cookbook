"""
Post-migration row count verification.

Usage:
    source .env
    python verify.py
"""
import os
import sys

import pyodbc
import psycopg2


TABLES = [
    "countries",
    "customers",
    "products",
    "orders",
    "audit_log",
]

TARGET_SCHEMA = "imported"


def main() -> None:
    mssql = pyodbc.connect(os.environ["SOURCE_MSSQL_ODBC"])
    pg = psycopg2.connect(os.environ["TARGET_PG_DSN"])

    print(f"{'TABLE':<30} {'SOURCE':>10} {'TARGET':>10}  STATUS")
    print("-" * 65)

    all_ok = True
    try:
        with mssql.cursor() as mc, pg.cursor() as pc:
            for t in TABLES:
                mc.execute(f"SELECT COUNT(*) FROM dbo.{t}")
                src = mc.fetchone()[0]
                pc.execute(f'SELECT COUNT(*) FROM {TARGET_SCHEMA}."{t}"')
                tgt = pc.fetchone()[0]
                ok = src == tgt
                all_ok &= ok
                status = "OK" if ok else "MISMATCH"
                print(f"{t:<30} {src:>10} {tgt:>10}  {status}")
    finally:
        mssql.close()
        pg.close()

    sys.exit(0 if all_ok else 1)


if __name__ == "__main__":
    main()
