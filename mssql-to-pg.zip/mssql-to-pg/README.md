# mssql-to-pg

One-shot data migration from SQL Server to PostgreSQL using
[dlt](https://dlthub.com/).

## What's in here

| File             | Purpose                                                      |
|------------------|--------------------------------------------------------------|
| `migrate.py`     | The migration. Full table copy with `write_disposition=replace`. |
| `verify.py`      | Post-migration row count check (source vs target).           |
| `type_audit.py`  | Pre-migration scan for column types that need explicit mapping. |
| `post_load.sql`  | Identity/sequence reset after load.                          |
| `requirements.txt` | Python deps.                                               |
| `.env.example`   | Connection string template. Copy to `.env`.                  |
| `Dockerfile`     | Containerised runner with ODBC Driver 18.                    |

## Run order

```bash
# 1. Set up
cp .env.example .env       # fill in real credentials
source .env

python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt

# 2. Pre-flight type audit
python type_audit.py
# Review any flagged columns; update adapt_columns() in migrate.py if needed.

# 3. Update the TABLES list in migrate.py to match your source.

# 4. Run the migration
python migrate.py

# 5. Verify
python verify.py

# 6. (Optional) Reset Postgres sequences if your source used IDENTITY columns
psql "$TARGET_PG_DSN" -f post_load.sql
```

## Connection string notes

The `SOURCE_MSSQL_DSN` flags exist for specific reasons:

- `driver=ODBC+Driver+18+for+SQL+Server` — current driver (17 is EOL).
- `LongAsMax=yes` — stops `nvarchar(max)` / `varbinary(max)` truncating at 8000 bytes.
- `Encrypt=yes` + `TrustServerCertificate=yes` — pragmatic combo for internal
  servers without proper certs. Drop `TrustServerCertificate` if you have
  valid TLS certs.

## Before you run, check

- **Source is quiesced.** Read-only mode, or stop the writers. Otherwise
  `verify.py` counts will be a moving target.
- **Foreign keys.** `replace` doesn't honour FK order. Either create FKs
  on the target *after* the load, or list `TABLES` in parent-first order
  and drop FKs first.
- **Sequences/identity.** Run `post_load.sql` if the target needs to keep
  auto-incrementing IDs.
- **Type spot-check.** After load, pull one row from each table and eyeball
  dates, money, and `nvarchar(max)` columns. Catches most type issues in
  five minutes.

## Re-running

`replace` is idempotent — if a run dies halfway, just run it again. The
target schema gets wiped and rebuilt each time.

## Docker

```bash
docker build -t mssql-to-pg .
docker run --rm --env-file .env mssql-to-pg
docker run --rm --env-file .env mssql-to-pg python verify.py
```
