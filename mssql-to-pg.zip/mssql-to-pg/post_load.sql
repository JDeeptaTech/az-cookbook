-- Post-load fixups.
-- Run after migrate.py completes successfully.
--
-- If your source tables used IDENTITY columns and you want the new
-- Postgres tables to continue auto-incrementing from the right value,
-- advance the sequences here.
--
-- dlt creates regular columns (not SERIAL) by default. If you want
-- the migrated tables to behave like SERIAL going forward, you'll
-- need to attach a sequence first:
--
--   CREATE SEQUENCE imported.customers_customer_id_seq;
--   ALTER TABLE imported.customers
--     ALTER COLUMN customer_id SET DEFAULT nextval('imported.customers_customer_id_seq');
--   ALTER SEQUENCE imported.customers_customer_id_seq OWNED BY imported.customers.customer_id;

-- Then advance each sequence to max + 1:
SELECT setval(
  pg_get_serial_sequence('imported.customers', 'customer_id'),
  COALESCE((SELECT MAX(customer_id) FROM imported.customers), 1)
);

SELECT setval(
  pg_get_serial_sequence('imported.orders', 'order_id'),
  COALESCE((SELECT MAX(order_id) FROM imported.orders), 1)
);

SELECT setval(
  pg_get_serial_sequence('imported.products', 'product_id'),
  COALESCE((SELECT MAX(product_id) FROM imported.products), 1)
);

SELECT setval(
  pg_get_serial_sequence('imported.audit_log', 'event_id'),
  COALESCE((SELECT MAX(event_id) FROM imported.audit_log), 1)
);
