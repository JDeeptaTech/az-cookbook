"""
One-off type audit — run this BEFORE migrate.py.

Lists every distinct column type across the tables you plan to migrate
so you can spot anything exotic (datetimeoffset, hierarchyid, geography,
xml, sql_variant) that needs an explicit mapping decision.

Usage:
    source .env
    python type_audit.py
"""
import os
import pyodbc

from migrate import TABLES


def main() -> None:
    conn = pyodbc.connect(os.environ["SOURCE_MSSQL_ODBC"])
    placeholders = ",".join("?" for _ in TABLES)

    sql = f"""
        SELECT
            tb.name        AS table_name,
            c.name         AS column_name,
            t.name         AS type_name,
            c.precision,
            c.scale,
            c.max_length,
            c.is_nullable
        FROM sys.columns c
        JOIN sys.types   t  ON c.user_type_id = t.user_type_id
        JOIN sys.tables  tb ON c.object_id    = tb.object_id
        WHERE tb.schema_id = SCHEMA_ID('dbo')
          AND tb.name IN ({placeholders})
        ORDER BY tb.name, c.column_id;
    """

    with conn.cursor() as cur:
        cur.execute(sql, TABLES)
        rows = cur.fetchall()

    print(f"{'TABLE':<25} {'COLUMN':<30} {'TYPE':<20} PREC SCALE NULL")
    print("-" * 95)
    for r in rows:
        print(f"{r.table_name:<25} {r.column_name:<30} {r.type_name:<20} "
              f"{r.precision:>4} {r.scale:>5} {'Y' if r.is_nullable else 'N'}")

    # Flag anything that needs attention
    risky = {"datetimeoffset", "hierarchyid", "geography", "geometry",
             "xml", "sql_variant", "image", "text", "ntext"}
    flagged = [r for r in rows if r.type_name in risky]
    if flagged:
        print()
        print("=" * 95)
        print("REVIEW THESE — they may need explicit handling in adapt_columns():")
        for r in flagged:
            print(f"  {r.table_name}.{r.column_name}  ({r.type_name})")

    conn.close()


if __name__ == "__main__":
    main()
