"""
One-shot data migration from SQL Server to PostgreSQL using dlt.

Usage:
    source .env
    python migrate.py
"""
import os

import dlt
from dlt.sources.sql_database import sql_database
from dlt.sources.credentials import ConnectionStringCredentials
from sqlalchemy import types as sa_types


# Tables to migrate. List them parent-first if you have FKs on the target side.
TABLES = [
    "countries",
    "customers",
    "products",
    "orders",
    "audit_log",
]


def adapt_columns(table) -> None:
    """Fix SQL Server types that don't reflect cleanly into Postgres."""
    for col in table.columns:
        t = str(col.type).upper()
        # datetimeoffset → timestamptz (otherwise comes through as text)
        if t.startswith("DATETIMEOFFSET"):
            col.type = sa_types.DateTime(timezone=True)
        # money / smallmoney → Numeric(19, 4) preserves precision
        elif t in ("MONEY", "SMALLMONEY"):
            col.type = sa_types.Numeric(19, 4)


def main() -> None:
    src = ConnectionStringCredentials(os.environ["SOURCE_MSSQL_DSN"])

    source = sql_database(
        credentials=src,
        schema="dbo",
        table_names=TABLES,
        backend="pyarrow",
        reflection_level="full_with_precision",
        chunk_size=10000,
        table_adapter_callback=adapt_columns,
    )

    pipeline = dlt.pipeline(
        pipeline_name="mssql_to_pg",
        destination="postgres",
        dataset_name="imported",   # target schema in Postgres
        progress="log",
    )

    info = pipeline.run(source, write_disposition="replace")
    print(info)
    print(pipeline.last_trace.last_normalize_info.row_counts)


if __name__ == "__main__":
    main()
