"""Land all three sources into bronze:  python ingestion/pipeline.py
Run daily so connectivity_status_inventory accumulates snapshots."""
import dlt
from sources import (
    connectivity_status_inventory,
    firmware_inventory,
    master_server_inventory,
)


def main() -> None:
    pipeline = dlt.pipeline(
        pipeline_name="firmware_reporting",
        destination="postgres",
        dataset_name="bronze",
        progress="log",
    )
    info = pipeline.run(
        [master_server_inventory(), firmware_inventory(), connectivity_status_inventory()]
    )
    print(info)


if __name__ == "__main__":
    main()
