"""dlt resources landing raw exports into the `bronze` schema.

Table names MUST match what dbt sources expect:
  master_server_inventory · firmware_inventory · connectivity_status_inventory

Design:
- Bronze is RAW: no cleaning/typing/joins. Cleaning is dbt's job.
- Each row gets _ingested_at / _source_file / _file_hash. dlt adds _dlt_load_id / _dlt_id.
  Models derive "latest connectivity snapshot" from _ingested_at (no separate _load_date needed).
- Connectivity APPENDS (point-in-time); master/firmware REPLACE (latest-state extracts).
"""
from __future__ import annotations

import hashlib
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterator

import dlt
import pandas as pd


def _file_hash(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _enrich(rows: list[dict], src_path: str) -> Iterator[dict]:
    fh = _file_hash(src_path)
    fname = Path(src_path).name
    now = datetime.now(timezone.utc)
    for r in rows:
        clean = {(k or "").strip().lower().replace(" ", "_"): v for k, v in r.items()}
        clean["_source_file"] = fname
        clean["_file_hash"] = fh
        clean["_ingested_at"] = now
        yield clean


@dlt.resource(name="master_server_inventory", write_disposition="replace")
def master_server_inventory():
    path = os.environ["SOURCE_MASTER_CSV"]
    df = pd.read_csv(path, dtype=str, keep_default_na=False).rename(columns=str.strip)
    # drop the leading empty/index column present in the export; serverid is the real key
    if df.columns[0] == "" or df.columns[0].lower() == "id":
        df = df.iloc[:, 1:]
    yield from _enrich(df.to_dict("records"), path)


@dlt.resource(name="firmware_inventory", write_disposition="replace")
def firmware_inventory():
    path = os.environ["SOURCE_FIRMWARE_CSV"]
    df = pd.read_csv(path, dtype=str, keep_default_na=False)
    yield from _enrich(df.to_dict("records"), path)


@dlt.resource(name="connectivity_status_inventory", write_disposition="append")
def connectivity_status_inventory():
    """APPEND each daily export so reachability history accumulates."""
    path = os.environ["SOURCE_CONNECTIVITY_XLSX"]
    sheet = os.environ.get("SOURCE_CONNECTIVITY_SHEET", "Unreachables")
    df = pd.read_excel(path, sheet_name=sheet, dtype=str, engine="openpyxl").dropna(how="all")
    yield from _enrich(df.to_dict("records"), path)
