-- Tier-0: which column pair is actually a join key? Highest overlap wins; ~0 = not a key.
-- Run BEFORE trusting cross-project marts. Then set firmware_conn_key var accordingly.
with
 m_sid  as (select distinct lower(trim(serverid))       k from {{ source('bronze','master_server_inventory') }}      where serverid<>''),
 m_host as (select distinct lower(trim(hostname))       k from {{ source('bronze','master_server_inventory') }}      where hostname<>''),
 f_sid  as (select distinct lower(trim(serverid))       k from {{ source('bronze','firmware_inventory') }}            where serverid<>''),
 f_host as (select distinct lower(trim(hostname))       k from {{ source('bronze','firmware_inventory') }}            where hostname<>''),
 f_sh   as (select distinct lower(trim(serverhostname)) k from {{ source('bronze','firmware_inventory') }}            where serverhostname<>''),
 c_host as (select distinct lower(trim(host_name))      k from {{ source('bronze','connectivity_status_inventory') }} where host_name<>'')
            select 'master.serverid = firmware.serverid'       as pair, count(*) matched from m_sid  join f_sid  using(k)
 union all select 'master.hostname = firmware.serverhostname',       count(*)         from m_host join f_sh   using(k)
 union all select 'master.hostname = firmware.hostname',             count(*)         from m_host join f_host using(k)
 union all select 'conn.host_name  = firmware.serverhostname',       count(*)         from c_host join f_sh   using(k)
 union all select 'conn.host_name  = firmware.hostname',             count(*)         from c_host join f_host using(k)
 union all select 'conn.host_name  = firmware.serverid',             count(*)         from c_host join f_sid  using(k)
 union all select 'conn.host_name  = master.hostname',               count(*)         from c_host join m_host using(k)
 union all select 'conn.host_name  = master.serverid',               count(*)         from c_host join m_sid  using(k)
 order by matched desc
