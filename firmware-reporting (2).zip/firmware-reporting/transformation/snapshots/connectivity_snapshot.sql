{% snapshot connectivity_snapshot %}
{{ config(target_schema='silver', unique_key='host_name', strategy='check',
          check_cols=['conn_status','group_assignee','action_owner'],
          invalidate_hard_deletes=True) }}
-- SCD2 over the latest connectivity state: captures when a host flips
-- Reachable<->Not Reachable or changes owner, giving reachability history.
select * from {{ ref('int_connectivity_current') }}
{% endsnapshot %}
