{% macro verify_bridge() %}
{% set q %}
with hop1 as (
  select count(*) filter (where f.{{ var('firmware_master_key') }} is not null) as matched, count(*) as total
  from {{ ref('stg_master') }} m
  left join {{ ref('int_firmware_current') }} f
    on m.{{ var('master_key') }} = f.{{ var('firmware_master_key') }}
),
hop2 as (
  select count(*) filter (where c.host_name is not null) as matched, count(*) as total
  from {{ ref('int_firmware_current') }} f
  left join {{ ref('int_connectivity_current') }} c
    on f.{{ var('firmware_conn_key') }} = c.host_name
)
select 'hop1 master->firmware ({{ var("master_key") }}={{ var("firmware_master_key") }})' as hop,
       matched, total, round(100.0*matched/nullif(total,0),1) pct from hop1
union all
select 'hop2 firmware->connectivity ({{ var("firmware_conn_key") }}=host_name)',
       matched, total, round(100.0*matched/nullif(total,0),1) from hop2
{% endset %}
{% if execute %}
  {% set r = run_query(q) %}
  {% do log('=== BRIDGE MATCH RATES ===', info=True) %}
  {% for row in r.rows %}{% do log(row[0] ~ ': ' ~ row[1] ~ '/' ~ row[2] ~ ' (' ~ row[3] ~ '%)', info=True) %}{% endfor %}
  {% do log('If hop2 is low, switch firmware_conn_key (server_hostname <-> hostname) and re-run.', info=True) %}
{% endif %}
{% endmacro %}
