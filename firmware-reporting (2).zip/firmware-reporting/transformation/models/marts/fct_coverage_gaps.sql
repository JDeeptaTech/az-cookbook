-- "Anything missing from master" + project completeness + orphans.
with x as (select * from {{ ref('int_server_xref') }})
select 'in_firmware_not_in_master'        as gap, count(*) as servers from x
  where in_firmware and not in_master
union all
select 'in_connectivity_not_in_master',         count(*) from x
  where in_connectivity and not in_master
union all
select 'live_master_missing_from_firmware',     count(*) from x
  where in_master and master_lifecycle_state = 'Live' and not in_firmware
union all
select 'live_master_missing_from_connectivity', count(*) from x
  where in_master and master_lifecycle_state = 'Live' and not in_connectivity
