-- Demised (per master) but still tracked by an active project = cleanup target.
select
    coalesce(country_code, 'UNKNOWN') as country_code,
    count(*) filter (where master_lifecycle_state = 'Demised' and in_firmware)     as demised_in_firmware,
    count(*) filter (where master_lifecycle_state = 'Demised' and in_connectivity) as demised_in_connectivity,
    count(*) filter (where master_lifecycle_state = 'Demised'
                          and (in_firmware or in_connectivity))                    as demised_tracked_anywhere
from {{ ref('int_server_xref') }}
where master_lifecycle_state = 'Demised'
group by 1 order by demised_tracked_anywhere desc
