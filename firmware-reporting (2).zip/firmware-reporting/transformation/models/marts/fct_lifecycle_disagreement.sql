-- Same server, different lifecycle state across sources = data-quality signal.
select
    server_key, master_lifecycle_state, fw_lifecycle_state, conn_lifecycle_state
from {{ ref('int_server_xref') }}
where in_master and (in_firmware or in_connectivity)
  and (
       (fw_lifecycle_state   is not null and lower(fw_lifecycle_state)   <> lower(master_lifecycle_state))
    or (conn_lifecycle_state is not null and lower(conn_lifecycle_state) <> lower(master_lifecycle_state))
  )
