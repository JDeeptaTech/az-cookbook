-- Presence matrix: how many in each project and every intersection.
select
    in_master, in_firmware, in_connectivity,
    case
        when in_master and in_firmware and in_connectivity then 'all_three'
        when in_master and in_firmware                     then 'master+firmware'
        when in_firmware and in_connectivity               then 'firmware+connectivity'
        when in_master and in_connectivity                 then 'master+connectivity (transitive)'
        when in_master                                     then 'master_only'
        when in_firmware                                   then 'firmware_only'
        when in_connectivity                               then 'connectivity_only'
    end                                            as segment,
    count(*)                                       as servers
from {{ ref('int_server_xref') }}
group by 1,2,3,4 order by servers desc
