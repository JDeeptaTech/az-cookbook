-- Master inventory by lifecycle state.
select
    coalesce(lifecycle_state, '(blank)') as lifecycle_state,
    count(*)                             as servers,
    round(100.0 * count(*) / sum(count(*)) over (), 1) as pct
from {{ ref('stg_master') }}
group by 1 order by servers desc
