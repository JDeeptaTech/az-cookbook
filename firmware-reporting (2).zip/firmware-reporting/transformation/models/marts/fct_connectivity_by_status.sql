-- Connectivity by status, LATEST snapshot only (int_connectivity_current is deduped).
select
    coalesce(conn_status, '(blank)') as status,
    count(*)                         as hosts,
    round(100.0 * count(*) / sum(count(*)) over (), 1) as pct
from {{ ref('int_connectivity_current') }}
group by 1 order by hosts desc
