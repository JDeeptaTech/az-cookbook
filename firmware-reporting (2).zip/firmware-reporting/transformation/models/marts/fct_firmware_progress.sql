-- Firmware upgrade progress: scope split + lookup completion.
select
    coalesce(m_scope, '(blank)')            as m_scope,
    coalesce(lookup_completed, '(blank)')   as lookup_completed,
    coalesce(upgrade_type, '(blank)')       as upgrade_type,
    count(*)                                as servers
from {{ ref('int_firmware_current') }}
group by 1,2,3 order by servers desc
