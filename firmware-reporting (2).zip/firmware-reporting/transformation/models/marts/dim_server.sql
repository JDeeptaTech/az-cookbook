-- Conformed server dimension. Master = source of truth, projects enrich.
select
    server_key,
    master_lifecycle_state as lifecycle_state,
    country_code, business_line, environment,
    in_master, in_firmware, in_connectivity,
    fw_status, m_scope, upgrade_type,
    conn_status, group_assignee,
    master_hostname, firmware_server_hostname, connectivity_host_name
from {{ ref('int_server_xref') }}
