-- Firmware project by status (+ scope/upgrade breakdowns as extra dims).
select
    coalesce(fw_status, '(blank)')   as status,
    coalesce(m_scope, '(blank)')     as m_scope,
    coalesce(upgrade_type, '(blank)') as upgrade_type,
    count(*)                         as servers
from {{ ref('int_firmware_current') }}
group by 1,2,3 order by servers desc
