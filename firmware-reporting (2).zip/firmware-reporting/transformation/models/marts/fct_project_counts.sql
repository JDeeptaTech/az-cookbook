-- Single-row summary: hosts per project + how many in both (relative to master).
select
    count(*) filter (where in_master)                                    as master_total,
    count(*) filter (where in_firmware)                                  as firmware_total,
    count(*) filter (where in_connectivity)                              as connectivity_total,
    count(*) filter (where in_master and in_firmware)                    as master_and_firmware,
    count(*) filter (where in_master and in_connectivity)                as master_and_connectivity,
    count(*) filter (where in_firmware and in_connectivity)              as in_both_projects,
    count(*) filter (where in_master and in_firmware and in_connectivity) as in_all_three
from {{ ref('int_server_xref') }}
