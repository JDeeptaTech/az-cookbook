-- Ops cut: unreachable hosts by assignee / country / DMZ zone (latest snapshot).
select
    coalesce(group_assignee, '(unassigned)') as group_assignee,
    coalesce(country_code, 'UNKNOWN')        as country_code,
    coalesce(dmz_zone, '(blank)')            as dmz_zone,
    count(*) filter (where conn_status ilike 'Not Reachable%') as not_reachable,
    count(*) filter (where conn_status ilike 'Reachable%')     as reachable,
    count(*)                                                   as total
from {{ ref('int_connectivity_current') }}
group by 1,2,3 order by not_reachable desc
