-- Connectivity project. Point-in-time reachability; dedup to latest happens in intermediate.
with src as (select * from {{ source('bronze', 'connectivity_status_inventory') }})
select
    lower(trim(host_name))                  as host_name,        -- -> firmware bridge key
    nullif(trim(status), '')                as conn_status,      -- Reachable / Not Reachable
    upper(trim(countrycode))                as country_code,
    nullif(trim(lifecyclestate_name), '')   as conn_lifecycle_state,
    nullif(trim(dmz_non_dmz), '')           as dmz_zone,
    nullif(trim(group_assignee), '')        as group_assignee,
    nullif(trim(service_owner_emails), '')  as service_owner_emails,
    nullif(trim(action_on), '')             as action_owner,
    nullif(trim(fixed), '')                 as fixed_flag,
    nullif(trim(date_of_fixed), '')         as date_of_fixed,
    nullif(trim(out_of_scope), '')          as out_of_scope,
    nullif(trim(demise), '')                as conn_demise,
    _ingested_at
from src
where nullif(trim(host_name), '') is not null
