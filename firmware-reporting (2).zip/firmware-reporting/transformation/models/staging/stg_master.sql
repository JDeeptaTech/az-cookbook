-- System of record. serverid is the key; lifecycle_state here is authoritative.
with src as (select * from {{ source('bronze', 'master_server_inventory') }})
select
    lower(trim(serverid))                as server_id,
    lower(trim(hostname))                as hostname,
    upper(trim(country_code))            as country_code,
    nullif(trim(lifecycle_state), '')    as lifecycle_state,
    nullif(trim(business_line), '')      as business_line,
    nullif(trim(hosting_platform), '')   as hosting_platform,
    nullif(trim(environment), '')        as environment,
    _ingested_at
from src
where nullif(trim(serverid), '') is not null
