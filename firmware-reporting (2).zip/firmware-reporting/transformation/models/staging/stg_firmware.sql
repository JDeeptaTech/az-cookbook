-- Firmware upgrade project. Bridge table: server_id -> master, server_hostname/hostname -> connectivity.
with src as (select * from {{ source('bronze', 'firmware_inventory') }})
select
    lower(trim(serverid))                       as server_id,        -- -> master.server_id
    lower(trim(serverhostname))                 as server_hostname,  -- -> connectivity.host_name (candidate)
    lower(trim(hostname))                        as hostname,         -- -> connectivity.host_name (alt candidate)
    nullif(trim(status), '')                     as fw_status,
    nullif(trim(m_scope), '')                    as m_scope,
    nullif(trim(upgrade_type), '')               as upgrade_type,
    nullif(trim(lookup_against_completed), '')   as lookup_completed,
    nullif(trim(in_cm_sheet), '')                as in_cm_sheet,
    nullif(trim(serverlifecyclestate), '')       as fw_lifecycle_state,
    nullif(trim(serverenvironment), '')          as fw_environment,
    nullif(trim(serverbusinessline), '')         as fw_business_line,
    _ingested_at
from src
where nullif(trim(serverid), '') is not null
