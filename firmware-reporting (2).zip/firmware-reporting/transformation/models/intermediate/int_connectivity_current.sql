-- Append-loaded daily; reduce to current state (one row per host).
select distinct on (host_name) *
from {{ ref('stg_connectivity') }}
order by host_name, _ingested_at desc
