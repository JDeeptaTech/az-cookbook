-- Firmware export can repeat a server; keep latest by ingestion time.
select distinct on (server_id) *
from {{ ref('stg_firmware') }}
order by server_id, _ingested_at desc
