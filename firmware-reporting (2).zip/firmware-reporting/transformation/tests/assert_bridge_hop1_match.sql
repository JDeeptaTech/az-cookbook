-- Returns rows (fails) if master->firmware match rate < min_bridge_match_rate var.
with r as (
  select count(*) filter (where f.{{ var('firmware_master_key') }} is not null)::numeric
         / nullif(count(*),0) as pct
  from {{ ref('stg_master') }} m
  left join {{ ref('int_firmware_current') }} f
    on m.{{ var('master_key') }} = f.{{ var('firmware_master_key') }}
)
select pct from r where pct < {{ var('min_bridge_match_rate') }}
