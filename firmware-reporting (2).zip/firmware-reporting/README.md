# firmware-reporting

Medallion reporting stack over three server-inventory sources: **dlt → bronze**, **dbt → silver/gold**, **Grafana** off the gold marts. Validated end-to-end against Postgres.

## Join topology (verify before trusting cross-project numbers)

Firmware is the **bridge** — there is no single shared key:

```
master.serverid ── firmware.serverid          (hop 1)
                   firmware.serverhostname ── connectivity.host_name   (hop 2)
```

`master ↔ connectivity` is **transitive through firmware**. A server absent from firmware
won't register as a master↔connectivity match — surfaced in `fct_coverage_gaps`, not hidden.

Both hop keys are dbt `vars` (`dbt_project.yml`). Hop 2 is the uncertain one: if
`firmware.serverhostname` matches poorly, flip `firmware_conn_key` to `hostname`:

```bash
dbt build --vars '{firmware_conn_key: hostname}'
```

## Run order

```bash
cp .env.example .env                      # set creds + source file paths
docker compose up -d postgres grafana
pip install -r requirements.txt
python ingestion/pipeline.py              # land bronze (run daily for connectivity history)

cd transformation
dbt run-operation verify_bridge           # 1. CHECK MATCH RATES FIRST
dbt build                                 # 2. build silver + gold + run tests
```

Tier-0 key profiling (run once to pick the right `firmware_conn_key`):
compile `analyses/tier0_key_profiling.sql` or paste it into your SQL client.

Grafana: http://localhost:3000 (admin/admin) — dashboard auto-provisioned off `gold`.

## Layout

```
ingestion/            dlt → bronze (master replace, firmware replace, connectivity APPEND)
  sources.py  pipeline.py
transformation/
  models/staging/     silver: stg_master / stg_firmware / stg_connectivity   (1:1 clean+cast)
  models/intermediate/silver: int_firmware_current, int_connectivity_current  (dedup→latest)
                              int_server_xref                                  (FULL OUTER spine)
  models/marts/       gold:   dim_server + 10 fct_* reports
  snapshots/          connectivity SCD2 (reachability over time)
  macros/             verify_bridge, generate_schema_name
  tests/              assert_bridge_hop1_match (fails build if match rate < var)
  analyses/           tier0_key_profiling
grafana/              datasource + dashboard provisioning
docs/                 data-pipeline-design.md (filled-in design spec)
```

## Reports (gold marts)

| Mart | Answers |
|---|---|
| `fct_master_by_state` | Master inventory by lifecycle state |
| `fct_firmware_by_status` | Firmware project by status / scope / upgrade type |
| `fct_connectivity_by_status` | Connectivity by status (latest snapshot) |
| `fct_project_counts` | One-row: totals per project + in-both + all-three |
| `fct_project_overlap` | Full presence matrix (each project + every intersection) |
| `fct_coverage_gaps` | Missing from master; Live master missing from a project |
| `fct_demised_tracked` | Demised servers still tracked by an active project |
| `fct_lifecycle_disagreement` | Same server, different lifecycle across sources |
| `fct_connectivity_ops` | Unreachable by assignee / country / DMZ |
| `fct_firmware_progress` | Upgrade scope split + lookup completion |

## Notes

- Connectivity is loaded `append`; all "current state" marts dedup to latest via `_ingested_at`.
- Master is system-of-record for lifecycle state; project copies are kept only for drift detection.
- Integration uses FULL OUTER joins so orphans survive — they are the coverage report.
