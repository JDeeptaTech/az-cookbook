# Config Diff Tool

> Compare `configurations` table JSONB between two PostgreSQL databases.
> Built with Streamlit — runs in Docker.

---

## What it does

- Connects to two PostgreSQL databases simultaneously
- Lets you select `app_name`, `config_name`, `environment`
- Shows a key-by-key diff with **added / removed / changed / same** status
- Masks Key Vault URIs automatically — shows `🔑 vaultname/…/secretname` only
- Summary cards (changed, added, removed, identical counts)
- Export delta as JSON

---

## Quick start

```bash
# With Docker Compose (includes two seeded test databases)
docker compose up --build

# Open in browser
open http://localhost:8501
```

The compose file starts three containers:
- `config-diff` — Streamlit app on port `8501`
- `postgres-prod` — seeded prod-like data on port `5433`
- `postgres-uat` — seeded UAT-like data on port `5434`

---

## Run locally

```bash
pip install -r requirements.txt

export DB_A_URL=postgres://user:pass@host-a:5432/db
export DB_B_URL=postgres://user:pass@host-b:5432/db

streamlit run app.py
```

---

## Connecting to real databases

Enter the connection URLs in the sidebar. They are masked (`type="password"`)
and never logged. Alternatively, pre-fill via environment variables:

```bash
DB_A_URL=postgres://platform:pass@prod-host:5432/platform
DB_B_URL=postgres://platform:pass@uat-host:5432/platform
```

---

## Use cases

| Scenario | DB A | DB B |
|----------|------|------|
| Prod vs UAT drift check | prod | uat |
| Before / after a config change | prod (before snapshot) | prod (after) |
| Cross-region consistency | region-a | region-b |
| Subscription override audit | subscription-a | subscription-b |

---

## Key Vault URI masking

Any config value containing `vault.azure.net` is automatically masked:

```
https://myvault.vault.azure.net/secrets/db-password  →  🔑 myvault/…/db-password
```

Plaintext secrets are never displayed in the UI.

---

## Stack

| Layer | Choice |
|-------|--------|
| UI | Streamlit 1.35 |
| DB driver | psycopg2 |
| Diff engine | deepdiff |
| Container | Python 3.12 slim |
