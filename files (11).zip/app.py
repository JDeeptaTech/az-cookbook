"""
config-diff-tool — Compare configurations between two PostgreSQL databases.

Connects to two DB instances (e.g. prod vs uat, or two regions),
lets you pick app_name / config_name / environment, and renders a
clean visual diff of the JSONB config values.
"""

import json
import os
from typing import Optional

import psycopg2
import psycopg2.extras
import streamlit as st
from deepdiff import DeepDiff

# ── Page config ───────────────────────────────────────────────────────────────

st.set_page_config(
    page_title="Config Diff",
    page_icon="⚡",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── Styles ────────────────────────────────────────────────────────────────────

st.markdown("""
<style>
    /* Base */
    [data-testid="stAppViewContainer"] { background: #0d1117; }
    [data-testid="stSidebar"]          { background: #161b22; border-right: 1px solid #30363d; }
    [data-testid="stSidebar"] * { color: #e6edf3; }

    /* Typography */
    html, body, [class*="css"] { font-family: 'SF Mono', 'Fira Code', Consolas, monospace; }
    h1, h2, h3 { color: #e6edf3 !important; letter-spacing: -0.02em; }

    /* Page title */
    .page-title {
        font-size: 22px; font-weight: 700; color: #e6edf3;
        display: flex; align-items: center; gap: 10px;
        padding-bottom: 12px; border-bottom: 1px solid #30363d; margin-bottom: 24px;
    }
    .page-title .badge {
        font-size: 11px; font-weight: 600; padding: 2px 8px;
        background: #1f6feb22; color: #58a6ff; border: 1px solid #1f6feb66;
        border-radius: 20px; letter-spacing: .04em;
    }

    /* DB panels */
    .db-header {
        font-size: 11px; font-weight: 700; text-transform: uppercase;
        letter-spacing: .08em; padding: 6px 12px; border-radius: 4px 4px 0 0;
        display: flex; align-items: center; gap: 8px;
    }
    .db-header.left  { background: #1f3a5f; color: #79c0ff; border: 1px solid #1f6feb55; border-bottom: none; }
    .db-header.right { background: #1a3a2e; color: #56d364; border: 1px solid #2ea04355; border-bottom: none; }

    /* Stat cards */
    .stat-row { display: flex; gap: 12px; margin: 20px 0; }
    .stat-card {
        flex: 1; padding: 16px 20px; border-radius: 6px;
        background: #161b22; border: 1px solid #30363d;
    }
    .stat-card .stat-num { font-size: 28px; font-weight: 700; line-height: 1; }
    .stat-card .stat-lbl { font-size: 11px; color: #8b949e; margin-top: 4px; text-transform: uppercase; letter-spacing: .06em; }
    .stat-card.added   { border-color: #2ea04355; }
    .stat-card.removed { border-color: #f8514955; }
    .stat-card.changed { border-color: #e3b34155; }
    .stat-card.same    { border-color: #30363d;   }
    .stat-card.added   .stat-num { color: #56d364; }
    .stat-card.removed .stat-num { color: #f85149; }
    .stat-card.changed .stat-num { color: #e3b341; }
    .stat-card.same    .stat-num { color: #8b949e; }

    /* Diff rows */
    .diff-table { width: 100%; border-collapse: collapse; font-size: 13px; margin-top: 8px; }
    .diff-table th {
        background: #161b22; color: #8b949e; font-size: 10px; font-weight: 700;
        text-transform: uppercase; letter-spacing: .06em;
        padding: 8px 12px; border-bottom: 1px solid #30363d; text-align: left;
    }
    .diff-table td { padding: 8px 12px; border-bottom: 1px solid #21262d; vertical-align: top; }
    .diff-table tr:last-child td { border-bottom: none; }
    .diff-table tr.added   td { background: #1a2b1a; }
    .diff-table tr.removed td { background: #2b1a1a; }
    .diff-table tr.changed td { background: #2b2415; }
    .diff-table tr.same    td { background: #0d1117; }

    .diff-key   { color: #79c0ff; font-weight: 600; font-family: 'SF Mono', monospace; }
    .diff-val   { font-family: 'SF Mono', monospace; word-break: break-all; }
    .val-added  { color: #56d364; }
    .val-removed{ color: #f85149; }
    .val-changed{ color: #e3b341; }
    .val-same   { color: #8b949e; }
    .val-missing{ color: #484f58; font-style: italic; }
    .tag {
        display: inline-block; font-size: 10px; font-weight: 700;
        padding: 1px 6px; border-radius: 3px; margin-right: 6px;
        text-transform: uppercase; letter-spacing: .04em;
    }
    .tag.added   { background: #1a4b2a; color: #56d364; }
    .tag.removed { background: #4b1a1a; color: #f85149; }
    .tag.changed { background: #4b3a10; color: #e3b341; }
    .tag.same    { background: #21262d; color: #8b949e; }

    /* Section headings */
    .section-heading {
        font-size: 12px; font-weight: 700; text-transform: uppercase;
        letter-spacing: .08em; color: #8b949e;
        padding: 16px 0 8px; border-bottom: 1px solid #21262d; margin-bottom: 12px;
    }

    /* Identical banner */
    .identical-banner {
        padding: 20px 24px; border-radius: 6px;
        background: #1a2b1a; border: 1px solid #2ea04355;
        color: #56d364; font-size: 15px; font-weight: 600;
        display: flex; align-items: center; gap: 10px;
    }

    /* No config banner */
    .missing-banner {
        padding: 16px 20px; border-radius: 6px;
        background: #2b1a1a; border: 1px solid #f8514955;
        color: #f85149; font-size: 13px; font-weight: 500;
    }

    /* Sidebar inputs */
    [data-testid="stSelectbox"] > div > div { background: #0d1117 !important; border-color: #30363d !important; }
    [data-testid="stTextInput"] > div > div > input { background: #0d1117 !important; color: #e6edf3 !important; border-color: #30363d !important; }

    /* Metadata row */
    .meta-row { display: flex; gap: 20px; flex-wrap: wrap; margin-bottom: 20px; }
    .meta-item { font-size: 12px; color: #8b949e; }
    .meta-item span { color: #e6edf3; font-weight: 600; }

    /* Buttons */
    [data-testid="stButton"] > button {
        background: #1f6feb; color: white; border: none;
        font-weight: 600; border-radius: 6px; width: 100%;
    }
    [data-testid="stButton"] > button:hover { background: #388bfd; }
    .stButton { margin-top: 8px; }

    div[data-testid="column"] { padding: 0 8px; }
</style>
""", unsafe_allow_html=True)


# ── DB connection ─────────────────────────────────────────────────────────────

def get_connection(url: str):
    """Open a psycopg2 connection. Returns (conn, error_message)."""
    try:
        conn = psycopg2.connect(url, cursor_factory=psycopg2.extras.RealDictCursor)
        return conn, None
    except Exception as e:
        return None, str(e)


@st.cache_data(ttl=30, show_spinner=False)
def fetch_app_names(url: str) -> list[str]:
    conn, err = get_connection(url)
    if err:
        return []
    with conn.cursor() as cur:
        cur.execute(
            "SELECT DISTINCT app_name FROM configurations WHERE is_active=TRUE ORDER BY app_name"
        )
        return [r["app_name"] for r in cur.fetchall()]
    conn.close()


@st.cache_data(ttl=30, show_spinner=False)
def fetch_config_names(url: str, app_name: str) -> list[str]:
    conn, err = get_connection(url)
    if err:
        return []
    with conn.cursor() as cur:
        cur.execute(
            "SELECT DISTINCT config_name FROM configurations "
            "WHERE app_name=%s AND is_active=TRUE ORDER BY config_name",
            (app_name,)
        )
        return [r["config_name"] for r in cur.fetchall()]
    conn.close()


@st.cache_data(ttl=30, show_spinner=False)
def fetch_config(url: str, app_name: str, config_name: str, environment: str) -> Optional[dict]:
    conn, err = get_connection(url)
    if err:
        return None
    with conn.cursor() as cur:
        cur.execute(
            "SELECT config, version, updated_by, updated_at "
            "FROM configurations "
            "WHERE app_name=%s AND config_name=%s AND environment=%s AND is_active=TRUE",
            (app_name, config_name, environment)
        )
        row = cur.fetchone()
    conn.close()
    if not row:
        return None
    return dict(row)


# ── Diff engine ───────────────────────────────────────────────────────────────

def flatten(obj: dict, prefix: str = "") -> dict:
    """Flatten nested dict to dotted paths."""
    out = {}
    for k, v in obj.items():
        key = f"{prefix}.{k}" if prefix else k
        if isinstance(v, dict):
            out.update(flatten(v, key))
        else:
            out[key] = v
    return out


def compute_diff(left: dict, right: dict) -> list[dict]:
    """
    Returns list of rows:
      { key, status, left_val, right_val }
    status: added | removed | changed | same
    """
    lf = flatten(left)
    rf = flatten(right)
    all_keys = sorted(set(lf) | set(rf))
    rows = []
    for k in all_keys:
        lv = lf.get(k)
        rv = rf.get(k)
        if k not in lf:
            status = "added"
        elif k not in rf:
            status = "removed"
        elif lv != rv:
            status = "changed"
        else:
            status = "same"
        rows.append({"key": k, "status": status, "left": lv, "right": rv})
    return rows


def format_val(v) -> str:
    if v is None:
        return "—"
    if isinstance(v, str) and "vault.azure.net" in v:
        # Mask vault URIs — show vault name and secret name only
        parts = v.split("/")
        try:
            vault  = parts[2].split(".")[0]
            secret = parts[parts.index("secrets") + 1]
            return f"🔑 {vault}/…/{secret}"
        except Exception:
            return "🔑 [vault uri]"
    if isinstance(v, (dict, list)):
        return json.dumps(v, indent=2)
    return str(v)


def diff_summary(rows: list[dict]) -> dict:
    counts = {"added": 0, "removed": 0, "changed": 0, "same": 0}
    for r in rows:
        counts[r["status"]] += 1
    return counts


# ── Sidebar ───────────────────────────────────────────────────────────────────

with st.sidebar:
    st.markdown("## ⚙️ Connection")
    st.markdown("---")

    st.markdown("**Database A**")
    db_a_url = st.text_input(
        "URL A", type="password",
        value=os.getenv("DB_A_URL", ""),
        placeholder="postgres://user:pass@host:5432/db",
        key="url_a", label_visibility="collapsed"
    )
    db_a_label = st.text_input("Label A", value="Source", key="label_a")

    st.markdown("---")
    st.markdown("**Database B**")
    db_b_url = st.text_input(
        "URL B", type="password",
        value=os.getenv("DB_B_URL", ""),
        placeholder="postgres://user:pass@host:5432/db",
        key="url_b", label_visibility="collapsed"
    )
    db_b_label = st.text_input("Label B", value="Target", key="label_b")

    st.markdown("---")
    st.markdown("**Filter**")

    ENVIRONMENTS = ["prod", "uat", "test", "dev"]
    environment = st.selectbox("Environment", ENVIRONMENTS)

    # App names — union of both DBs
    apps_a = fetch_app_names(db_a_url) if db_a_url else []
    apps_b = fetch_app_names(db_b_url) if db_b_url else []
    all_apps = sorted(set(apps_a) | set(apps_b))

    if not all_apps:
        st.caption("Connect both databases to load app names.")
        app_name = st.text_input("app_name", placeholder="trading-engine")
    else:
        app_name = st.selectbox("app_name", all_apps)

    # Config names — union of both DBs for selected app
    cnames_a = fetch_config_names(db_a_url, app_name) if db_a_url and app_name else []
    cnames_b = fetch_config_names(db_b_url, app_name) if db_b_url and app_name else []
    all_cnames = sorted(set(cnames_a) | set(cnames_b))

    if not all_cnames:
        config_name = st.text_input("config_name", placeholder="database")
    else:
        config_name = st.selectbox("config_name", all_cnames)

    st.markdown("---")
    compare_btn = st.button("▶  Run Comparison", use_container_width=True)

    st.markdown("---")
    show_identical = st.checkbox("Show identical keys", value=False)
    st.caption("Vault URIs are masked automatically.")


# ── Main ──────────────────────────────────────────────────────────────────────

st.markdown(f"""
<div class="page-title">
    ⚡ Config Diff
    <span class="badge">PLATFORM ENGINEERING</span>
</div>
""", unsafe_allow_html=True)

if not compare_btn and not (db_a_url and db_b_url and app_name and config_name):
    st.markdown("""
    <div style="padding:40px 0; color:#8b949e; font-size:14px;">
        Configure both database connections in the sidebar, select a config, and click
        <strong style="color:#e6edf3">▶ Run Comparison</strong>.
    </div>
    """, unsafe_allow_html=True)
    st.stop()

# ── Fetch ─────────────────────────────────────────────────────────────────────

with st.spinner("Fetching configs…"):
    row_a = fetch_config(db_a_url, app_name, config_name, environment) if db_a_url else None
    row_b = fetch_config(db_b_url, app_name, config_name, environment) if db_b_url else None

# ── Metadata ──────────────────────────────────────────────────────────────────

st.markdown(f"""
<div class="meta-row">
    <div class="meta-item">app_name <span>{app_name}</span></div>
    <div class="meta-item">config_name <span>{config_name}</span></div>
    <div class="meta-item">environment <span>{environment}</span></div>
</div>
""", unsafe_allow_html=True)

# ── Missing config banners ────────────────────────────────────────────────────

if not row_a and not row_b:
    st.markdown(f"""
    <div class="missing-banner">
        ✖ Config <strong>{app_name} / {config_name} / {environment}</strong>
        not found in either database.
    </div>
    """, unsafe_allow_html=True)
    st.stop()

# ── Raw JSON side-by-side ─────────────────────────────────────────────────────

col_l, col_r = st.columns(2)

with col_l:
    st.markdown(f'<div class="db-header left">◀ {db_a_label}</div>', unsafe_allow_html=True)
    if row_a:
        st.json(row_a["config"], expanded=False)
        st.caption(f"v{row_a['version']} · updated by {row_a['updated_by'] or '—'} · {str(row_a['updated_at'])[:19]}")
    else:
        st.markdown(f'<div class="missing-banner">Not found in {db_a_label}</div>', unsafe_allow_html=True)

with col_r:
    st.markdown(f'<div class="db-header right">▶ {db_b_label}</div>', unsafe_allow_html=True)
    if row_b:
        st.json(row_b["config"], expanded=False)
        st.caption(f"v{row_b['version']} · updated by {row_b['updated_by'] or '—'} · {str(row_b['updated_at'])[:19]}")
    else:
        st.markdown(f'<div class="missing-banner">Not found in {db_b_label}</div>', unsafe_allow_html=True)

# ── If one side is missing entirely ──────────────────────────────────────────

if not row_a or not row_b:
    missing_label = db_a_label if not row_a else db_b_label
    present_label = db_b_label if not row_a else db_a_label
    present_config = (row_b if not row_a else row_a)["config"]
    flat = flatten(present_config)

    st.markdown(f'<div class="section-heading">All keys — only in {present_label}</div>', unsafe_allow_html=True)
    status = "added" if not row_a else "removed"
    tag    = "added" if not row_a else "removed"

    rows_html = ""
    for k, v in sorted(flat.items()):
        val = format_val(v)
        rows_html += f"""
        <tr class="{status}">
            <td><span class="diff-key">{k}</span></td>
            <td><span class="tag {tag}">{tag}</span></td>
            <td class="diff-val {'val-missing' if status=='removed' else 'val-added'}">{val}</td>
            <td class="diff-val {'val-missing' if status=='added' else 'val-removed'}">—</td>
        </tr>"""

    st.markdown(f"""
    <table class="diff-table">
        <thead>
            <tr>
                <th>Key</th><th>Status</th>
                <th>{db_a_label}</th><th>{db_b_label}</th>
            </tr>
        </thead>
        <tbody>{rows_html}</tbody>
    </table>
    """, unsafe_allow_html=True)
    st.stop()

# ── Diff ──────────────────────────────────────────────────────────────────────

diff_rows = compute_diff(row_a["config"], row_b["config"])
summary   = diff_summary(diff_rows)
total     = len(diff_rows)

# ── Summary cards ─────────────────────────────────────────────────────────────

st.markdown(f"""
<div class="stat-row">
    <div class="stat-card changed">
        <div class="stat-num">{summary['changed']}</div>
        <div class="stat-lbl">Changed</div>
    </div>
    <div class="stat-card added">
        <div class="stat-num">{summary['added']}</div>
        <div class="stat-lbl">Added in {db_b_label}</div>
    </div>
    <div class="stat-card removed">
        <div class="stat-num">{summary['removed']}</div>
        <div class="stat-lbl">Only in {db_a_label}</div>
    </div>
    <div class="stat-card same">
        <div class="stat-num">{summary['same']}</div>
        <div class="stat-lbl">Identical</div>
    </div>
</div>
""", unsafe_allow_html=True)

# ── Identical short-circuit ───────────────────────────────────────────────────

if summary["changed"] == 0 and summary["added"] == 0 and summary["removed"] == 0:
    st.markdown(f"""
    <div class="identical-banner">
        ✔ Configs are identical across {db_a_label} and {db_b_label}
        — {total} key(s) match exactly.
    </div>
    """, unsafe_allow_html=True)
    if show_identical:
        st.markdown("")
    else:
        st.stop()

# ── Delta table ───────────────────────────────────────────────────────────────

st.markdown('<div class="section-heading">Key-by-key delta</div>', unsafe_allow_html=True)

filtered = [r for r in diff_rows if show_identical or r["status"] != "same"]

rows_html = ""
for r in filtered:
    k      = r["key"]
    status = r["status"]
    lv     = format_val(r["left"])
    rv     = format_val(r["right"])

    lclass = {"added": "val-missing", "removed": "val-removed", "changed": "val-changed", "same": "val-same"}[status]
    rclass = {"added": "val-added",   "removed": "val-missing", "changed": "val-changed", "same": "val-same"}[status]
    ldisplay = "—" if status == "added"   else lv
    rdisplay = "—" if status == "removed" else rv

    rows_html += f"""
    <tr class="{status}">
        <td><span class="diff-key">{k}</span></td>
        <td><span class="tag {status}">{status}</span></td>
        <td class="diff-val {lclass}">{ldisplay}</td>
        <td class="diff-val {rclass}">{rdisplay}</td>
    </tr>"""

st.markdown(f"""
<table class="diff-table">
    <thead>
        <tr>
            <th style="width:30%">Key</th>
            <th style="width:10%">Status</th>
            <th style="width:30%">◀ {db_a_label}</th>
            <th style="width:30%">▶ {db_b_label}</th>
        </tr>
    </thead>
    <tbody>{rows_html}</tbody>
</table>
""", unsafe_allow_html=True)

# ── Export ────────────────────────────────────────────────────────────────────

st.markdown("")
export = {
    "app_name":    app_name,
    "config_name": config_name,
    "environment": environment,
    "source":      db_a_label,
    "target":      db_b_label,
    "summary":     summary,
    "delta": [
        r for r in diff_rows if r["status"] != "same"
    ]
}

st.download_button(
    label     = "⬇  Export delta as JSON",
    data      = json.dumps(export, indent=2, default=str),
    file_name = f"diff_{app_name}_{config_name}_{environment}.json",
    mime      = "application/json",
)
