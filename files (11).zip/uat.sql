-- UAT seed data — intentional differences for demo
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

CREATE TABLE IF NOT EXISTS configurations (
    id              UUID         PRIMARY KEY DEFAULT gen_random_uuid(),
    app_name        VARCHAR(150) NOT NULL,
    config_name     VARCHAR(150) NOT NULL,
    environment     VARCHAR(50)  NOT NULL,
    config          JSONB        NOT NULL DEFAULT '{}',
    version         INTEGER      NOT NULL DEFAULT 1,
    is_active       BOOLEAN      NOT NULL DEFAULT TRUE,
    created_by      VARCHAR(150) NOT NULL,
    updated_by      VARCHAR(150),
    created_at      TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    UNIQUE (app_name, config_name, environment)
);

INSERT INTO configurations (app_name, config_name, environment, config, version, created_by) VALUES
('trading-engine', 'database', 'prod', '{
    "host":            "db-uat.internal.example.com",
    "port":            5432,
    "name":            "trading_uat",
    "max_connections": 20,
    "pool_timeout_ms": 30000,
    "ssl_mode":        "require",
    "password":        "https://myvault-uat.vault.azure.net/secrets/trading-db-password"
}', 1, 'pradeep'),

('trading-engine', 'cache', 'prod', '{
    "host":        "redis-uat.internal.example.com",
    "port":        6379,
    "ttl_seconds": 300,
    "max_retries": 3
}', 1, 'pradeep'),

('trading-engine', 'feature-flags', 'prod', '{
    "new_dashboard":     true,
    "dark_mode":         true,
    "live_price_stream": false,
    "beta_analytics":    true,
    "experimental_ui":   true
}', 1, 'pradeep'),

('platform-vm-provisioner', 'database', 'prod', '{
    "host":            "db-uat.internal.example.com",
    "port":            5432,
    "name":            "provisioner_uat",
    "max_connections": 10,
    "pool_timeout_ms": 5000,
    "password":        "https://myvault-uat.vault.azure.net/secrets/provisioner-db-password"
}', 1, 'pradeep'),

('platform-vm-provisioner', 'limits', 'prod', '{
    "max_vms_per_request": 5,
    "provisioning_timeout_s": 300,
    "retry_attempts": 5,
    "dry_run_mode": true
}', 2, 'pradeep');
