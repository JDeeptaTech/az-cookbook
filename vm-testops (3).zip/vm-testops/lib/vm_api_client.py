"""
HTTP client for the VM self-service platform.

Routes every operation through the registry in config/operations.yaml,
so adding a new endpoint is a YAML change. Handles sync and async ops
uniformly: both return an OpHandle, but sync handles short-circuit
the waiter because they already carry the final result.
"""
from __future__ import annotations

import os
from datetime import datetime, timezone
from typing import Any, Optional

import httpx
from tenacity import (
    retry,
    retry_if_exception_type,
    stop_after_attempt,
    wait_exponential,
)

from lib.async_ops import (
    AsyncOpWaiter,
    OpHandle,
    TerminalState,
    new_correlation_id,
)
from lib.op_registry import OperationRegistry, OperationSpec, get_registry


def _unwrap(body: dict) -> dict:
    """Unwrap common API envelopes ({"data": {...}} → {...})."""
    if isinstance(body, dict) and "data" in body and isinstance(body["data"], dict):
        return body["data"]
    return body


def _extract_request_id(body: dict, field_path: str) -> Optional[str]:
    """Walk dotted field path; fall back to common alternate names."""
    val: Any = body
    for part in field_path.split("."):
        if isinstance(val, dict) and part in val:
            val = val[part]
        else:
            val = None
            break
    if val:
        return str(val)
    # Common fallbacks
    flat = _unwrap(body)
    for k in ("request_id", "id", "job_id", "task_id"):
        if k in flat and flat[k]:
            return str(flat[k])
    return None


class VMPlatformClient:
    def __init__(
        self,
        base_url: Optional[str] = None,
        token: Optional[str] = None,
        timeout: float = 60.0,
        verify_ssl: Optional[bool] = None,
        registry: Optional[OperationRegistry] = None,
    ):
        self.base_url = base_url or os.environ["VM_API_BASE_URL"]
        self.token = token or os.environ["VM_API_TOKEN"]
        if verify_ssl is None:
            verify_ssl = os.environ.get("VM_API_VERIFY_SSL", "true").lower() != "false"
        self.client = httpx.Client(
            base_url=self.base_url,
            headers={
                "Authorization": f"Bearer {self.token}",
                "Accept": "application/json",
            },
            timeout=timeout,
            verify=verify_ssl,
        )
        self.registry = registry or get_registry()

    def close(self) -> None:
        self.client.close()

    # ---------- Low-level dispatch ----------
    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(min=2, max=10),
        retry=retry_if_exception_type(httpx.TransportError),
    )
    def _request(
        self,
        method: str,
        path: str,
        json: Optional[dict] = None,
        params: Optional[dict] = None,
        headers: Optional[dict] = None,
        success_codes: Optional[list[int]] = None,
    ) -> dict:
        r = self.client.request(
            method, path, json=json, params=params, headers=headers,
        )
        if success_codes and r.status_code not in success_codes:
            r.raise_for_status()  # will raise for non-2xx; for 2xx-not-in-list, fall through
            raise httpx.HTTPStatusError(
                f"Unexpected status {r.status_code} (allowed: {success_codes})",
                request=r.request, response=r,
            )
        r.raise_for_status()
        try:
            return r.json()
        except ValueError:
            return {}

    # ---------- Build (special: has its own payload shape) ----------
    def build_vm(self, payload: dict, correlation_id: Optional[str] = None) -> dict:
        """
        VM create is async by default. Returns the final VM record after
        the build job completes. Test code keeps the old signature.
        """
        corr = correlation_id or new_correlation_id()
        spec, rendered = self.registry.render("vm.create")
        body = self._request(
            rendered["method"],
            rendered["path"],
            json=payload,
            headers={"X-Correlation-Id": corr},
            success_codes=rendered["success_codes"],
        )
        if spec.is_async:
            # Async build: get request_id, poll, then fetch the VM record
            handle = self._handle_from_response(
                body, spec, "vm.create", vm_id="(creating)", correlation_id=corr,
            )
            result = self.waiter().wait(handle)
            vm_id = (
                (result.final_payload.get("result") or {}).get("vm_id")
                or _unwrap(result.final_payload).get("id")
            )
            if not vm_id:
                raise RuntimeError(
                    f"build_vm: could not determine vm_id from final payload: "
                    f"{result.final_payload}"
                )
            return self.get_vm(vm_id)
        # Sync build (rare): response already has the VM
        return _unwrap(body)

    def get_vm(self, vm_id: str) -> dict:
        _, rendered = self.registry.render("vm.get", vm_id=vm_id)
        body = self._request(
            rendered["method"], rendered["path"],
            success_codes=rendered["success_codes"],
        )
        return _unwrap(body)

    def delete_vm(self, vm_id: str) -> dict:
        spec, rendered = self.registry.render("vm.delete", vm_id=vm_id)
        body = self._request(
            rendered["method"], rendered["path"],
            success_codes=rendered["success_codes"],
        )
        return _unwrap(body)

    # ---------- Day-2 (registry-driven) ----------
    def submit_day2(
        self,
        vm_id: str,
        operation: str,
        params: Optional[dict] = None,
        correlation_id: Optional[str] = None,
    ) -> OpHandle:
        """
        Submit a day-2 op. Works for both sync and async endpoints:
        - async: returns an OpHandle with a request_id; caller polls via waiter
        - sync:  returns an OpHandle pre-populated with the final response;
                 the waiter recognizes this and short-circuits
        """
        corr = correlation_id or new_correlation_id()
        spec, rendered = self.registry.render(
            operation, vm_id=vm_id, params=params or {},
        )
        body = self._request(
            rendered["method"],
            rendered["path"],
            json=rendered["body"],
            params=rendered["query"],
            headers={"X-Correlation-Id": corr},
            success_codes=rendered["success_codes"],
        )
        return self._handle_from_response(
            body, spec, operation, vm_id=vm_id, correlation_id=corr, params=params,
        )

    def _handle_from_response(
        self,
        body: dict,
        spec: OperationSpec,
        operation: str,
        vm_id: str,
        correlation_id: str,
        params: Optional[dict] = None,
    ) -> OpHandle:
        op_family = operation.split(".", 1)[0] if "." in operation else operation

        if spec.is_async:
            request_id = _extract_request_id(body, spec.request_id_field)
            if not request_id:
                raise RuntimeError(
                    f"{operation} async response missing request_id "
                    f"(looked for {spec.request_id_field!r}): {body}"
                )
            return OpHandle(
                request_id=request_id,
                operation=operation,
                vm_id=vm_id,
                correlation_id=correlation_id,
                submitted_at=datetime.now(timezone.utc),
                metadata={
                    "op_family": op_family,
                    "params": params or {},
                    "mode": "async",
                    "poll_path": spec.poll_path,
                },
            )

        # Sync: wrap the response as a synthetic completed handle.
        # The waiter checks metadata['mode'] == 'sync' and returns immediately
        # with the response payload as the final result.
        return OpHandle(
            request_id=f"sync-{correlation_id}",
            operation=operation,
            vm_id=vm_id,
            correlation_id=correlation_id,
            submitted_at=datetime.now(timezone.utc),
            metadata={
                "op_family": op_family,
                "params": params or {},
                "mode": "sync",
                "sync_response": _unwrap(body),
            },
        )

    def poll_request(self, request_id: str, poll_path: Optional[str] = None) -> dict:
        """Poll an async request. `poll_path` overrides the default endpoint."""
        path = poll_path or f"/api/v1/requests/{request_id}"
        # Allow ${request_id} in the path if it leaked through
        path = path.replace("${request_id}", request_id)
        r = self.client.get(path)
        r.raise_for_status()
        return _unwrap(r.json())

    def cancel_request(self, request_id: str) -> Optional[dict]:
        try:
            r = self.client.post(f"/api/v1/requests/{request_id}/cancel")
            r.raise_for_status()
            return _unwrap(r.json())
        except httpx.HTTPError:
            return None

    def waiter(self) -> AsyncOpWaiter:
        return AsyncOpWaiter(poll_fn=self._poll_for_waiter)

    def _poll_for_waiter(self, request_id: str, handle: Optional[OpHandle] = None) -> dict:
        """
        Poll function used by AsyncOpWaiter. Uses the handle's poll_path
        if provided (so per-op endpoints work), else the default.
        """
        poll_path = None
        if handle and handle.metadata:
            poll_path = handle.metadata.get("poll_path")
            if poll_path:
                poll_path = poll_path.replace("${request_id}", request_id)
        return self.poll_request(request_id, poll_path=poll_path)
