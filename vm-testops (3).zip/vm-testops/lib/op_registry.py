"""
Operation registry: maps op names like 'power.stop' to HTTP endpoint specs.

The registry is data-driven (config/operations.yaml). Adding an endpoint
is a YAML change; the registry handles substitution and the API client
dispatches based on the resolved spec.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

import yaml

CONFIG_PATH = Path(__file__).parent.parent / "config" / "operations.yaml"

# ${vm_id}, ${request_id}, ${params.foo}, ${params.foo|default}
_SUBST_RE = re.compile(r"\$\{([^}]+)\}")


class OperationNotFound(KeyError):
    """Operation name not in registry."""


@dataclass
class OperationSpec:
    name: str
    method: str
    path: str
    body: Optional[dict] = None
    query: Optional[dict] = None
    mode: str = "async"             # 'sync' or 'async'
    poll_path: str = "/api/v1/requests/${request_id}"
    request_id_field: str = "data.request_id"
    success_codes: list[int] = field(default_factory=lambda: [200, 201, 202])

    @property
    def is_async(self) -> bool:
        return self.mode == "async"


def _substitute(template: Any, context: dict) -> Any:
    """
    Recursively substitute ${var} and ${var|default} tokens in strings.
    Walks dicts/lists. Non-string leaves pass through unchanged.

    Important: when a template value is a bare ${x} that resolves to a
    non-string (bool, int, dict), we return the resolved value as-is
    rather than stringifying it. That way:
        body:
          force: ${params.force|false}
    becomes `{"force": False}` not `{"force": "False"}`.
    """
    if isinstance(template, dict):
        return {k: _substitute(v, context) for k, v in template.items()}
    if isinstance(template, list):
        return [_substitute(v, context) for v in template]
    if not isinstance(template, str):
        return template

    # Special-case: if the entire string is one ${...} token, preserve the type.
    full_match = re.fullmatch(r"\$\{([^}]+)\}", template)
    if full_match:
        return _resolve(full_match.group(1), context)

    def repl(m):
        val = _resolve(m.group(1), context)
        return "" if val is None else str(val)

    return _SUBST_RE.sub(repl, template)


def _resolve(expr: str, context: dict) -> Any:
    """Resolve a single ${...} expression, with optional |default.

    Defaults parse as:
        true/false   -> bool
        null/none    -> None
        digits       -> int
        ''           -> empty string (e.g. ${x|} means "blank default")
        anything else -> string literal
    """
    default: Any = None
    if "|" in expr:
        expr, default_str = expr.split("|", 1)
        lit = default_str.lower()
        if lit == "true":
            default = True
        elif lit == "false":
            default = False
        elif lit in ("null", "none"):
            default = None
        elif default_str.lstrip("-").isdigit():
            default = int(default_str)
        else:
            default = default_str  # includes "" for ${x|}

    parts = expr.strip().split(".")
    val: Any = context
    for part in parts:
        if isinstance(val, dict) and part in val:
            val = val[part]
        else:
            return default
    return val


def _strip_nones(d: Any) -> Any:
    """Recursively drop dict entries whose value is None.

    Lets specs like ${params.cpu|null} act as "omit this field if not provided"
    rather than sending an explicit null to the API.
    """
    if isinstance(d, dict):
        return {k: _strip_nones(v) for k, v in d.items() if v is not None}
    if isinstance(d, list):
        return [_strip_nones(v) for v in d]
    return d


class OperationRegistry:
    """Loads operations.yaml and resolves OperationSpec entries."""

    def __init__(self, path: Path = CONFIG_PATH):
        raw = yaml.safe_load(path.read_text())
        self._specs: dict[str, OperationSpec] = {}
        for name, defn in raw.items():
            self._specs[name] = OperationSpec(name=name, **defn)

    def get(self, name: str) -> OperationSpec:
        if name not in self._specs:
            raise OperationNotFound(
                f"Operation {name!r} not in registry. "
                f"Known: {sorted(self._specs.keys())}"
            )
        return self._specs[name]

    def names(self) -> list[str]:
        return sorted(self._specs.keys())

    def render(
        self,
        op_name: str,
        vm_id: Optional[str] = None,
        params: Optional[dict] = None,
        request_id: Optional[str] = None,
    ) -> tuple[OperationSpec, dict]:
        """
        Return (spec, rendered) where rendered is:
            {"method": ..., "path": ..., "body": dict_or_None,
             "query": dict_or_None, "success_codes": [...]}
        """
        spec = self.get(op_name)
        context = {
            "vm_id": vm_id,
            "request_id": request_id,
            "params": params or {},
        }
        rendered_body = _substitute(spec.body, context) if spec.body else None
        rendered_query = _substitute(spec.query, context) if spec.query else None
        rendered = {
            "method": spec.method.upper(),
            "path": _substitute(spec.path, context),
            # Drop None values so optional fields aren't sent as explicit null
            "body": _strip_nones(rendered_body) if rendered_body else None,
            "query": _strip_nones(rendered_query) if rendered_query else None,
            "success_codes": spec.success_codes,
        }
        # If stripping nullified the body entirely (no fields supplied),
        # collapse to None so httpx doesn't send an empty {}.
        if rendered["body"] == {}:
            rendered["body"] = None
        return spec, rendered

    def render_poll(self, op_name: str, request_id: str) -> str:
        spec = self.get(op_name)
        return _substitute(spec.poll_path, {"request_id": request_id})


# Module-level singleton for cheap reuse
_default: Optional[OperationRegistry] = None


def get_registry() -> OperationRegistry:
    global _default
    if _default is None:
        _default = OperationRegistry()
    return _default
