# VM TestOps — pytest + Allure framework

End-to-end test framework for the VM self-service platform. Covers
multi-OS provisioning (Linux + Windows variants) and asynchronous
day-2 operations (power, disk, snapshot, network) with rich Allure reporting.

## Layout

```
.
├── pytest.ini                  # markers, addopts, allure dir
├── conftest.py                 # CLI flags, OS parametrize, build->day2 routing
├── allure_categories.json      # failure bucketing in reports
├── azure-pipelines.yml         # ADO pipeline: build + day2 stages
├── requirements.txt
├── .env.example                # local env template
├── config/
│   ├── os_matrix.yaml          # all OS versions
│   ├── day2_matrix.yaml        # all day-2 ops
│   └── timeouts.yaml           # per-op timeouts + state map
├── lib/
│   ├── async_ops.py            # submit/poll/validate primitives
│   ├── vm_api_client.py        # HTTP client for your FastAPI
│   ├── state_store.py          # build->day2 handoff (vm_state.json)
│   └── allure_utils.py         # report helpers
├── tests/
│   ├── builds/
│   │   └── test_vm_build.py
│   └── day2/
│       ├── test_power_ops.py
│       ├── test_disk_ops.py
│       ├── test_snapshot_ops.py
│       └── test_network_ops.py
└── scripts/run.sh              # common run patterns
```

## Setup

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
# edit .env with your VM_API_BASE_URL and VM_API_TOKEN
```

Install Allure CLI (one-time, for local report viewing):
```bash
# macOS
brew install allure
# Linux
curl -o allure.tgz -L https://github.com/allure-framework/allure2/releases/download/2.27.0/allure-2.27.0.tgz
tar -xzf allure.tgz && export PATH=$PWD/allure-2.27.0/bin:$PATH
```

## Running

### Build + day2 in one shot
```bash
pytest --phase=all
```

### Two-phase (the typical CI pattern)
```bash
pytest --phase=build         # writes vm_state.json
pytest --phase=day2          # reads vm_state.json
```

### OS filtering
```bash
pytest --os=linux                          # all Linux variants
pytest --os-version=rhel8,win2022          # exact versions
pytest --os=windows --phase=build          # build only Windows VMs
```

### Day-2 op filtering
```bash
pytest --phase=day2 --day2-op=snapshot
pytest --phase=day2 --day2-op=power,disk
```

### Day-2 against existing VMs (skip the build phase)

When the VMs already exist — provisioned manually, by another team, or
surviving from a previous run — pass them in directly. The framework
seeds `vm_state.json` from your input, skips the build phase, and
**never** deletes the VM at teardown (external VMs are not ours to delete).

**Inline via `--vm`:**

```bash
# One VM
pytest --phase=day2 --vm=prod-rhel8-canary:rhel8 --day2-op=snapshot

# Multiple VMs (repeatable flag)
pytest --phase=day2 \
  --vm=prod-rhel8-canary:rhel8 \
  --vm=prod-win22-canary:win2022 \
  --day2-op=power

# Or comma-separated
pytest --phase=day2 --vm=rhel8-vm-01:rhel8,win-vm-02:win2022

# If your API requires a distinct id and display name, use id|name:os_id
pytest --phase=day2 --vm=vm-uuid-abc|my-display-name:rhel8
```

**From a YAML pool (`--vm-pool`):**

```bash
pytest --phase=day2 --vm-pool=config/vm_pool.example.yaml --day2-op=snapshot
```

Where the file looks like:

```yaml
vms:
  rhel8:
    id: vm-uuid-rhel8-canary
    name: canary-rhel8-01
  win2022:
    id: vm-uuid-win2022-canary
    name: canary-win2022-01
```

**Important behaviors:**

- `--phase` is auto-set to `day2` when `--vm` / `--vm-pool` is passed.
  Combining with `--phase=build` is a hard error (would destructively
  build over external VMs).
- `--keep-vms` is auto-enabled. External VMs are never deleted at teardown.
- OS parametrization auto-narrows to OSes you supplied a VM for, so
  `pytest --vm=prod-rhel8:rhel8` only generates rhel8 tests — no
  skipped placeholders for other OSes.
- CLI `--vm` overrides matching entries in `--vm-pool` if both are passed.

### Marker-based filtering (works alongside the flags)
```bash
pytest -m "day2 and snapshot and rhel8"
pytest -m "build and windows"
pytest -m smoke
```

### Combine
```bash
pytest --phase=day2 --os=linux --day2-op=power -m "not slow"
```

### Parallel execution

The framework parallelizes **per-OS**: each OS becomes one xdist worker
group, and within a worker, that OS's tests run serially (sharing the
session-scoped `provisioned_vm` fixture). This avoids three races: same-OS
duplicate provisioning, same-VM concurrent day-2 ops, and `vm_state.json`
write conflicts.

```bash
# One worker per OS, auto-sized to CPU count
pytest -n auto --dist loadgroup --phase=all

# Explicit worker count
pytest -n 5 --dist loadgroup --phase=all

# Subset in parallel
pytest -n auto --dist loadgroup --os=linux --phase=day2
```

`--dist loadgroup` is **required** when running with `-n`. The default
`--dist load` would scatter same-OS tests across workers, breaking the
session fixture contract. `conftest.py` enforces this with a
`pytest.UsageError` at startup if the modes don't match.

Expected speedup: serial run time is `Σ(per_OS_time)`; parallel is
`max(per_OS_time)`. For 5 OSes with Windows ~20m and RHEL ~10m, that's
roughly 150m → 30m.

#### When to NOT parallelize

- **API rate limits** — many simultaneous provisioning requests can trip
  per-user caps. Check first-run behaviour.
- **Cluster capacity** — N concurrent Windows builds will spike CPU/IO
  on OCP nodes. Your placement decision engine spreads them, but the
  burst is real.
- **Cleanup stampedes** — combine with `--maxfail=N` so a cascade of
  failures doesn't flood the API with cancel calls.

### Keep VMs after the run (debugging)
```bash
pytest --phase=all --keep-vms
```

### Convenience wrapper
```bash
./scripts/run.sh build --os-version=rhel9
./scripts/run.sh day2 --day2-op=snapshot
./scripts/run.sh serve
```

## OpenShift / KubeVirt validation

Tests assert on **both** the platform API response and the actual OCP
cluster state. After `power.stop` succeeds at the API layer, the
validator checks that the `VirtualMachine` CR shows
`printableStatus: Stopped`, the `VirtualMachineInstance` is gone, and
no Warning events fired on the VM since submission.

### Auth (auto-resolved in this order)

1. **In-cluster ServiceAccount** — when running as a pod
2. **Kubeconfig** — `KUBECONFIG` env or `~/.kube/config`
3. **Bearer token** — `OCP_API_URL` + `OCP_API_TOKEN` (+ optional `OCP_API_CA_CERT`)

### RBAC

Apply the included manifest to set up a read-only ServiceAccount:

```bash
oc apply -f deploy/rbac-validator.yaml -n virtualinfrahub-dev
# Off-cluster: grab the long-lived token
oc get secret vm-testops-validator-token -n virtualinfrahub-dev \
   -o jsonpath='{.data.token}' | base64 -d
```

### Toggling validation

```bash
# Skip OCP validation entirely (e.g. API mock runs)
pytest --no-ocp-validation
# or
OCP_VALIDATION_ENABLED=false pytest
```

When disabled, every `ocp_validator.expect_*()` call becomes a no-op
and emits an Allure attachment noting it was skipped.

### Adding a new validator

Add an `expect_*` method to `lib/ocp_validator.py`:

```python
def expect_cpu_count(self, vm_name, expected, timeout=60):
    if self._skip_if_disabled(f"expect_cpu_count({vm_name})"):
        return
    with allure.step(f"[OCP] VM {vm_name} has {expected} vCPUs"):
        def check():
            vm = self.ocp.get_vm(vm_name)
            cpu = vm["spec"]["template"]["spec"]["domain"]["cpu"]["cores"]
            return cpu == expected, vm
        _wait_for(check, timeout, 3, f"cpu={expected}")
```

Wrapping in `allure.step` + `_wait_for` + `_skip_if_disabled` is the
pattern — three lines of overhead for each new validator.



Append to `config/os_matrix.yaml`:
```yaml
  - id: rhel10
    family: linux
    image: rhel-10.0-x86_64
    flavor: small
    aap_template: vm_build_rhel
    boot_timeout: 600
    cloud_init: true
```
Then register the marker in `pytest.ini` and the `_OS_IDS` / `_LINUX_IDS`
sets in `conftest.py`. That's it — every existing test runs against the
new OS automatically.

## GitHub Pages Allure publishing

Test results are published as a versioned Allure report to GitHub Pages.
History (trend charts, retry counts, flaky test detection) persists
across runs because the workflow restores the previous report's
`history/` folder before generating each new one.

### URLs

```
https://<org>.github.io/<repo>/                  ← landing page
https://<org>.github.io/<repo>/dev/latest/       ← always-current dev report
https://<org>.github.io/<repo>/dev/42/           ← permanent link to run #42
https://<org>.github.io/<repo>/prod/latest/      ← prod equivalents
https://<org>.github.io/<repo>/prod/15/
```

The `latest/` path is a moving pointer — link to it from dashboards.
Numbered paths are permanent and shareable in post-mortems / Jira.

### One-time setup

**1. Configure secrets** (Settings → Secrets and variables → Actions),
one set per environment:

```
VM_API_BASE_URL_dev      VM_API_BASE_URL_prod
VM_API_TOKEN_dev         VM_API_TOKEN_prod
OCP_API_URL_dev          OCP_API_URL_prod
OCP_API_TOKEN_dev        OCP_API_TOKEN_prod
```

The workflow resolves them dynamically via `secrets[format(...)]`
based on the chosen environment input.

**2. Initialize the gh-pages branch** (one-time):

```bash
git checkout --orphan gh-pages
git rm -rf .
echo "VM TestOps reports" > README.md
git add README.md && git commit -m "Initialize gh-pages"
git push origin gh-pages
git checkout main
```

**3. Enable Pages** (Settings → Pages):
- Source: **Deploy from a branch**
- Branch: **gh-pages**, folder: **/ (root)**

**4. Trigger the workflow:** Actions → "VM TestOps" → Run workflow.
Nightly runs against `dev` automatically at 02:00 UTC.

### How history is preserved

Each run does this in the `publish-report` job:

1. Downloads `allure-results-build` + `allure-results-day2`, merges them
2. Checks out the `gh-pages` branch into `gh-pages-checkout/`
3. Copies `gh-pages-checkout/<env>/latest/history/` → `allure-results/history/`
4. Runs `allure generate` (which reads + extends history)
5. Publishes to `<env>/<run_number>/` AND `<env>/latest/`

The `<env>/latest/` overwrite is critical: it's what step 3 reads on
the next run. If you ever break continuity (force-push gh-pages, delete
`latest/`), trend graphs reset but nothing else breaks.

### Triggering manual runs

```bash
gh workflow run "VM TestOps" \
  -f environment=dev \
  -f os_versions=rhel8 \
  -f day2_ops=snapshot
```

### Pruning old reports

`gh-pages` grows ~1-2 MB per report. The `Prune Allure history` workflow
runs Sundays at 05:00 UTC and keeps the most recent 30 runs per
environment (`latest/` is never touched). Manual override:

```bash
gh workflow run "Prune Allure history" -f keep=50
```

### Local preview

`scripts/publish-report.sh` builds the report with the same
history-preservation flow CI uses:

```bash
./scripts/publish-report.sh           # local report only
./scripts/publish-report.sh --push    # build + push to gh-pages
```

## Adding a new day-2 operation

1. **Endpoint** — add to `config/operations.yaml`:
   ```yaml
   disk.snapshot_clone:
     method: POST
     path: /api/v1/disks/snapshot-clone
     body:
       vm_id: ${vm_id}
       source_disk: ${params.source_disk}
       target_name: ${params.target_name}
     mode: async      # or 'sync' if the endpoint returns the final result
   ```
2. **Timeout** — add to `config/timeouts.yaml` under `async_timeouts`:
   ```yaml
   disk.snapshot_clone: 600
   ```
3. **Catalog** — add to `config/day2_matrix.yaml` (used by `--day2-op` filter).
4. **Test** — write the test in `tests/day2/test_<family>_ops.py` using the
   submit-then-wait pattern. No client code changes.

### Endpoint conventions

The registry supports `${vm_id}`, `${request_id}`, and `${params.X}`
substitutions in `path`, `body`, and `query` fields. Defaults work with
`${params.X|default}` syntax (e.g. `${params.force|false}` becomes
`false` when the param isn't passed).

When the entire value of a template field is a single token (like
`force: ${params.force|false}`), the resolved type is preserved —
booleans stay booleans, ints stay ints, dicts stay dicts. String
interpolation only happens when the token is embedded in surrounding
text.

### Sync vs async

- `mode: async` (default) — endpoint returns `request_id`; framework polls.
- `mode: sync` — endpoint returns the final result; framework treats
  the HTTP 2xx response as terminal success and short-circuits the
  waiter. Test code is identical in both cases.

For sync ops the response body can optionally include `status: FAILED`
to signal a failure within a 2xx response — the waiter respects this.

### Custom poll path / request_id field

If an async endpoint uses a non-standard polling URL or response shape:

```yaml
disk.heavy_op:
  method: POST
  path: /api/v1/disks/heavy
  mode: async
  poll_path: /api/v1/disks/jobs/${request_id}/status
  request_id_field: data.job.id    # dotted path into the submit response
```

## How async ops work

Every day-2 op goes through three Allure-visible steps:

1. **Submit** — `submit_day2()` returns an `OpHandle` (with `request_id`
   and `correlation_id`). The handle is attached to Allure as JSON.
2. **Poll** — `waiter.wait(handle)` polls `/api/v1/requests/{id}` with
   exponential backoff (2s → 15s capped) until terminal state, or
   timeout from `config/timeouts.yaml`.
3. **Validate** — your test asserts on `result.success`, fetched VM
   state, or the final payload.

Every poll's state transition is attached to Allure, so when a 14-minute
snapshot fails, you see `PENDING → RUNNING → RUNNING → FAILED` with
timestamps — no need to SSH anywhere.

`correlation_id` is sent as `X-Correlation-Id` and ends up in your
Splunk/APIM logs, so the report pivots to logs with a single search.

## How phase routing works

`conftest.py` reads `--phase` and rewires test collection:

- `--phase=build` skips anything marked `@pytest.mark.day2`.
- `--phase=day2` skips anything marked `@pytest.mark.build` and makes
  the `provisioned_vm` fixture read from `vm_state.json` instead of
  provisioning. If the state is missing, day-2 tests are skipped with
  a clear reason rather than failing noisily.
- `--phase=all` runs both and reuses the same VM for both phases.

`vm_state.json` is the persistent handoff. Override with `VM_STATE_FILE`
env var to keep separate state per pipeline run.

## Report quality

`allure_categories.json` buckets failures into Build / Power / Snapshot /
Disk / Network / Timeout / API-network buckets so the dashboard tells
you *what kind* of failure dominates a run.

Each test gets `os_family` and `os_version` Allure labels, so the
Behaviors view lets you filter "all snapshot failures on Windows 2022"
without writing a query.

## Known gotchas

- **Parallel + same OS**: pytest-xdist with multiple workers all
  targeting the same OS id will race in the build phase. Use
  `--dist loadscope` to keep an OS pinned to one worker, or partition
  by OS at the CI level.
- **State map drift**: if your FastAPI emits a status string not in
  `state_map`, the waiter treats it as in-progress and you'll eventually
  hit a timeout. Check `poll-history-*.json` attachments — unknown
  states show up there. Add to `config/timeouts.yaml` and re-run.
- **Cleanup**: the `provisioned_vm` fixture deletes VMs on session
  teardown unless `--keep-vms` or `--phase=day2`. Day-2-only runs never
  delete, since they don't own the VM.
