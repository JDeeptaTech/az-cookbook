"""Day-2 resize operations: CPU, memory, and both together.

The vm.resize endpoint accepts either or both of cpu/memory_mb; the
registry strips unset fields so the API only receives what was specified.
"""
from __future__ import annotations

import allure
import pytest

from lib.allure_utils import attach_json
from lib.async_ops import TerminalState


@pytest.mark.day2
@pytest.mark.resize
@allure.feature("Day2 — Resize Operations")
class TestResizeOps:

    @allure.story("Resize CPU only")
    @pytest.mark.cpu_only
    def test_resize_cpu(self, provisioned_vm, vm_client, waiter, async_op_tracker, ocp_validator):
        handle = async_op_tracker(
            vm_client.submit_day2(
                provisioned_vm["id"],
                "vm.resize",
                params={"cpu": 4},
            )
        )
        result = waiter.wait(handle, expect=TerminalState.SUCCESS)
        assert result.success

        with allure.step("[API] CPU count reflects new value"):
            vm = vm_client.get_vm(provisioned_vm["id"])
            attach_json("vm-after-resize", vm)
            assert vm.get("cpu") == 4 or vm.get("cpu_cores") == 4, (
                f"CPU not updated: {vm}"
            )

        ocp_validator.expect_vm_healthy(
            provisioned_vm["name"],
            since_iso=handle.submitted_at.isoformat(),
        )

    @allure.story("Resize memory only")
    @pytest.mark.memory_only
    def test_resize_memory(self, provisioned_vm, vm_client, waiter, async_op_tracker, ocp_validator):
        handle = async_op_tracker(
            vm_client.submit_day2(
                provisioned_vm["id"],
                "vm.resize",
                params={"memory_mb": 8192},
            )
        )
        result = waiter.wait(handle)
        assert result.success

        with allure.step("[API] Memory reflects new value"):
            vm = vm_client.get_vm(provisioned_vm["id"])
            mem = vm.get("memory_mb") or vm.get("memory")
            assert mem == 8192, f"Memory not updated: got {mem}"

        ocp_validator.expect_vm_healthy(
            provisioned_vm["name"],
            since_iso=handle.submitted_at.isoformat(),
        )

    @allure.story("Resize CPU and memory together")
    @pytest.mark.cpu_and_memory
    def test_resize_both(self, provisioned_vm, vm_client, waiter, async_op_tracker, ocp_validator):
        handle = async_op_tracker(
            vm_client.submit_day2(
                provisioned_vm["id"],
                "vm.resize",
                params={"cpu": 8, "memory_mb": 16384},
            )
        )
        result = waiter.wait(handle)
        assert result.success

        with allure.step("[API] Both CPU and memory updated"):
            vm = vm_client.get_vm(provisioned_vm["id"])
            attach_json("vm-after-resize-both", vm)
            cpu = vm.get("cpu") or vm.get("cpu_cores")
            mem = vm.get("memory_mb") or vm.get("memory")
            assert cpu == 8, f"CPU not updated: {cpu}"
            assert mem == 16384, f"Memory not updated: {mem}"

        ocp_validator.expect_vm_healthy(
            provisioned_vm["name"],
            since_iso=handle.submitted_at.isoformat(),
        )
