# ocp-dash

OCP version drift analytics: **dlt → DuckDB → Streamlit**, refreshed on a
schedule by APScheduler inside the same container.

```
scheduler (writer)                     streamlit (readers)
  openshift_graph  ─┐                    Home        (health/freshness)
  nexus            ─┼→ raw.* → mart.* →  Drift Report(per-stream drift)
  gitops (clone)   ─┘    (marts.sql)     Ad-hoc SQL  (read-only console)
```

## Run locally

```bash
pip install -e .
cp config.yaml config.local.yaml   # edit endpoints
export OCPDASH_CONFIG=config.local.yaml OCPDASH_DB=./ocp.duckdb
export OCPDASH_NEXUS_TOKEN=...  OCPDASH_GIT_TOKEN=...
python -m ocp_dash.pipeline        # one-off load
streamlit run src/ocp_dash/app/Home.py
```

## Container

```bash
docker build -t ocp-dash .
docker run -p 8501:8501 -v ocpdata:/data \
  -e OCPDASH_NEXUS_TOKEN=... -e OCPDASH_GIT_TOKEN=... ocp-dash
```

## Design decisions (and their trade-offs)

- **DuckDB single-writer** is handled by copy → build → `os.replace()`
  swap. Readers use `read_only=True` connections cache-keyed on file
  mtime. Trade-off: DB is briefly duplicated on disk each run; fine at
  this data volume.
- **No fallback/sample data is ever loaded.** Failed channel fetches land
  in `raw.fetch_errors`; the previous snapshot stays authoritative.
- **Nodes + edges stored**, so `hops_to_latest` in `mart.cluster_drift`
  is real upgrade-graph distance, not semver arithmetic.
- **Single container** (APScheduler + Streamlit) was chosen for
  simplicity. If either process needs independent scaling/restart
  semantics, split into a CronJob (writer) + Deployment (reader) sharing
  a PVC — the swap pattern already supports that; only entrypoint.sh
  changes.
- Nexus load is **incremental** on `last_modified`, merged on component
  id, so hourly runs stay cheap.

## Extending

- Map Nexus components ↔ OCP streams in `marts.sql`
  (`mart.latest_in_nexus`) once your repo naming convention is fixed.
- Operator catalog (your `operators.py`) drops in as a fourth dlt
  resource with `replace` disposition.
- History/trending: add an `append` snapshot resource keyed on run time.
