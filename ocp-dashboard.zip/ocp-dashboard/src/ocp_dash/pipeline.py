"""Run all dlt sources into DuckDB with copy → build → atomic swap.

Why: DuckDB is single-writer. The Streamlit process holds read_only
connections on the live file; writing to a copy and os.replace()-ing it
means readers never see a half-written database. Existing connections keep
the old inode until reopened (the app busts its cache on file mtime).

Copying the live file first (instead of starting empty) preserves history
tables, dlt incremental state, and append-only resources across runs.
"""
from __future__ import annotations

import logging
import os
import shutil
import time
from datetime import datetime, timezone

import dlt
import duckdb

from ocp_dash.config import Config
from ocp_dash.sources.gitops import gitops_source
from ocp_dash.sources.nexus import nexus_source
from ocp_dash.sources.openshift_graph import openshift_graph_source

log = logging.getLogger(__name__)
MARTS_SQL = os.path.join(os.path.dirname(__file__), "marts.sql")


def run(cfg: Config) -> None:
    started = time.monotonic()
    live = cfg.duckdb_path
    build = live.with_suffix(".building.duckdb")
    live.parent.mkdir(parents=True, exist_ok=True)
    if live.exists():
        shutil.copy2(live, build)

    pipeline = dlt.pipeline(
        pipeline_name="ocp_meta",
        destination=dlt.destinations.duckdb(str(build)),
        dataset_name="raw",
    )

    status, error = "ok", None
    try:
        pipeline.run(
            openshift_graph_source(
                cfg.channels, cfg.architecture, cfg.graph_url, cfg.http_timeout
            )
        )
        pipeline.run(
            nexus_source(
                cfg.nexus.base_url,
                cfg.nexus.repositories,
                cfg.nexus.verify_tls,
                cfg.http_timeout,
            )
        )
        pipeline.run(
            gitops_source(
                cfg.gitops.repo_url,
                cfg.gitops.branch,
                cfg.gitops.manifest_glob,
                cfg.gitops.cluster_name_pattern,
            )
        )
    except Exception as exc:  # noqa: BLE001 - recorded, run marked failed
        status, error = "failed", str(exc)
        log.exception("pipeline run failed")

    with duckdb.connect(str(build)) as con:
        with open(MARTS_SQL) as fh:
            con.execute(fh.read())
        con.execute(
            "CREATE TABLE IF NOT EXISTS mart.pipeline_runs ("
            "run_at TIMESTAMP, status VARCHAR, error VARCHAR,"
            "duration_s DOUBLE)"
        )
        con.execute(
            "INSERT INTO mart.pipeline_runs VALUES (?, ?, ?, ?)",
            [
                datetime.now(timezone.utc),
                status,
                error,
                round(time.monotonic() - started, 2),
            ],
        )

    os.replace(build, live)  # atomic on same filesystem
    log.info("run finished status=%s duration=%.1fs", status,
             time.monotonic() - started)


if __name__ == "__main__":
    from ocp_dash.config import load

    logging.basicConfig(level=logging.INFO)
    run(load(os.getenv("OCPDASH_CONFIG", "config.yaml")))
