"""Design system ported from report.py (render_report CSS).

Native Streamlit widgets take colors from .streamlit/config.toml; the
branded components (header band, stat cards, phase badges, pills, tables)
are rendered as our own HTML so we never depend on Streamlit's internal
class names.
"""
from __future__ import annotations

from html import escape

import pandas as pd
import streamlit as st

_CSS = """
<style>
:root {
  color-scheme: light;
  --bg: #ffffff;
  --card: #ffffff;
  --surface-alt: #fff5f6;
  --text: #1c1c1c;
  --muted: #5b5b5b;
  --brand: #db0011;
  --brand-dark: #a8000d;
  --brand-soft: #ffe1e3;
  --line: #e5e5e5;
  --success: #1f7a4d;
  --warning: #a86403;
  --shadow: 0 18px 45px rgba(219, 0, 17, 0.12);
}
html, body, [data-testid="stAppViewContainer"] {
  font-family: "HSBC Universe", "Univers Next", Inter, ui-sans-serif,
    system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
  color: var(--text);
}
.ocp-header {
  padding: 2.2rem min(6vw, 3rem) 1.8rem;
  background: var(--brand);
  color: #ffffff;
  border-bottom: 6px solid #ffffff;
  box-shadow: inset 0 -1px 0 var(--brand-dark);
  position: relative;
  overflow: hidden;
  border-radius: 18px;
  margin-bottom: 1.5rem;
}
.ocp-header::after {
  content: "";
  position: absolute;
  top: -40%;
  right: -8%;
  width: 22rem;
  height: 22rem;
  background: #ffffff;
  opacity: 0.08;
  transform: rotate(35deg);
}
.ocp-header h1 { margin: 0 0 0.5rem; letter-spacing: 0.01em; font-weight: 800; color: #fff; }
.ocp-header p { color: #ffffff; opacity: 0.92; max-width: 64rem; margin: 0; }

.panel {
  background: var(--card);
  border: 1px solid var(--line);
  border-radius: 18px;
  box-shadow: var(--shadow);
  padding: 1.5rem;
  margin-bottom: 1.5rem;
}
.panel h2 { margin-top: 0; }

.stats {
  display: grid;
  grid-template-columns: repeat(5, minmax(0, 1fr));
  gap: 1rem;
  margin-bottom: 1.5rem;
}
.stat {
  padding: 1rem;
  border-radius: 14px;
  background: #ffffff;
  border: 1px solid var(--line);
  border-left: 4px solid var(--brand);
}
.stat strong { display: block; font-size: 1.45rem; color: var(--brand); }
.stat span { color: var(--muted); }

.phase-badge {
  display: inline-flex;
  align-items: center;
  gap: 0.4rem;
  padding: 0.2rem 0.6rem;
  border-radius: 999px;
  font-weight: 800;
  font-size: 0.8rem;
  letter-spacing: 0.02em;
}
.phase-ga  { background: #e6f4ec; color: var(--success); border: 1px solid #b6dcc6; }
.phase-eus { background: #fff7e0; color: var(--warning); border: 1px solid #f0c36b; }
.phase-rc  { background: var(--brand-soft); color: var(--brand-dark); border: 1px solid var(--brand); }

.banner {
  border-radius: 12px; padding: 1rem; margin-bottom: 1rem; font-weight: 700;
  color: var(--brand-dark); background: var(--brand-soft);
  border: 1px solid var(--brand);
}

.ocp-table { width: 100%; border-collapse: collapse; overflow: hidden; }
.ocp-table th, .ocp-table td {
  text-align: left; padding: 0.9rem; border-bottom: 1px solid var(--line);
}
.ocp-table th {
  color: var(--brand); font-size: 0.82rem; text-transform: uppercase;
  letter-spacing: 0.08em; background: #ffffff;
}
.ocp-table tbody tr:hover { background: var(--surface-alt); }
.empty { text-align: center; color: var(--muted); padding: 2rem; }

.pill {
  display: inline-flex; align-items: center; border-radius: 999px;
  background: var(--brand); color: #ffffff; padding: 0.25rem 0.7rem;
  font-weight: 800; font-size: 0.85rem;
}
.pill-ok { background: var(--success); }
.pill-warn { background: var(--warning); }

@media (max-width: 1100px) { .stats { grid-template-columns: repeat(2, minmax(0, 1fr)); } }
@media (max-width: 850px)  { .stats { grid-template-columns: 1fr; } }

footer, .ocp-footer { color: var(--muted); margin-top: 2rem; }
</style>
"""


def page_setup(title: str, subtitle: str = "") -> None:
    st.set_page_config(page_title=title, layout="wide")
    st.markdown(_CSS, unsafe_allow_html=True)
    st.markdown(
        f"""<div class="ocp-header">
              <h1>{escape(title)}</h1>
              <p>{escape(subtitle)}</p>
            </div>""",
        unsafe_allow_html=True,
    )


def stat_row(stats: list[tuple[str, str]]) -> None:
    cells = "".join(
        f'<div class="stat"><strong>{escape(str(v))}</strong>'
        f"<span>{escape(label)}</span></div>"
        for v, label in stats
    )
    st.markdown(f'<div class="stats">{cells}</div>', unsafe_allow_html=True)


def phase_badge(phase: str | None) -> str:
    normalized = (phase or "").lower()
    cls = "phase-ga"
    if "extended" in normalized or "eus" in normalized:
        cls = "phase-eus"
    elif any(k in normalized for k in ("candidate", "preview", "beta", "alpha", "rc")):
        cls = "phase-rc"
    return (
        f'<span class="phase-badge {cls}">'
        f"{escape(phase or 'General Availability')}</span>"
    )


def pill(text: str, kind: str = "") -> str:
    cls = {"ok": " pill-ok", "warn": " pill-warn"}.get(kind, "")
    return f'<span class="pill{cls}">{escape(str(text))}</span>'


def banner(text: str) -> None:
    st.markdown(f'<div class="banner">{escape(text)}</div>', unsafe_allow_html=True)


def panel_table(df: pd.DataFrame, title: str | None = None,
                html_cols: tuple[str, ...] = ()) -> None:
    """Branded table. Values in html_cols are trusted pre-built fragments
    (badges/pills we generated); everything else is escaped."""
    head = "".join(f"<th>{escape(str(c))}</th>" for c in df.columns)
    if len(df):
        rows = "".join(
            "<tr>" + "".join(
                f"<td>{row[c] if c in html_cols else escape(str(row[c]))}</td>"
                for c in df.columns
            ) + "</tr>"
            for _, row in df.iterrows()
        )
    else:
        rows = (f'<tr><td class="empty" colspan="{len(df.columns)}">'
                "No rows match the current filters.</td></tr>")
    title_html = f"<h2>{escape(title)}</h2>" if title else ""
    st.markdown(
        f'<div class="panel">{title_html}'
        f'<table class="ocp-table"><thead><tr>{head}</tr></thead>'
        f"<tbody>{rows}</tbody></table></div>",
        unsafe_allow_html=True,
    )
