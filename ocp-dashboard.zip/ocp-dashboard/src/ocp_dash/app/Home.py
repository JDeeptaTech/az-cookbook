"""Overview page: freshness, run health, headline drift numbers."""
from __future__ import annotations

import os
from pathlib import Path

import duckdb
import streamlit as st

from theme import banner, page_setup, panel_table, stat_row

DB = Path(os.getenv("OCPDASH_DB", "/data/ocp.duckdb"))


@st.cache_resource
def _base_conn(mtime: float) -> duckdb.DuckDBPyConnection:
    # mtime in the cache key -> new connection after each pipeline swap
    return duckdb.connect(str(DB), read_only=True)


def conn() -> duckdb.DuckDBPyConnection:
    if not DB.exists():
        st.warning("Database not populated yet — waiting for first pipeline run.")
        st.stop()
    # .cursor() duplicates the connection: one per Streamlit session thread,
    # since a single DuckDB connection is not safe for concurrent threads.
    return _base_conn(DB.stat().st_mtime).cursor()


page_setup(
    "OCP Version Dashboard",
    "OpenShift release, Nexus availability, and GitOps drift — "
    "refreshed automatically for fast operations review.",
)

c = conn()
runs = c.execute(
    "SELECT run_at, status, duration_s, error FROM mart.pipeline_runs "
    "ORDER BY run_at DESC LIMIT 10"
).df()
drift = c.execute("SELECT * FROM mart.cluster_drift").df()

up_to_date = int(drift["is_current"].fillna(False).sum()) if len(drift) else 0
stat_row(
    [
        (len(drift), "Clusters tracked"),
        (up_to_date, "Up to date"),
        (len(drift) - up_to_date, "Behind latest"),
        (str(runs.iloc[0]["run_at"])[:19] if len(runs) else "never", "Last refresh"),
        (runs.iloc[0]["status"] if len(runs) else "-", "Last run status"),
    ]
)

if len(runs) and runs.iloc[0]["status"] != "ok":
    banner(f"Last pipeline run failed: {runs.iloc[0]['error']}")

panel_table(runs, title="Recent pipeline runs")

errors = c.execute(
    "SELECT channel, error FROM raw.fetch_errors "
    "ORDER BY _dlt_load_id DESC LIMIT 20"
).df()
if len(errors):
    panel_table(errors, title="Upstream fetch errors (per channel)")
