"""Per-stream drift: configured vs upstream vs Nexus availability."""
from __future__ import annotations

import streamlit as st

from Home import conn
from theme import page_setup, panel_table, phase_badge, pill, stat_row

page_setup(
    "Cluster Drift by Stream",
    "What each cluster is configured to run, what upstream publishes, "
    "and what is mirrored in Nexus.",
)

c = conn()
channels = [
    r[0]
    for r in c.execute(
        "SELECT DISTINCT channel FROM mart.cluster_drift ORDER BY 1"
    ).fetchall()
]
col1, col2 = st.columns([3, 1])
selected = col1.multiselect("Channels", channels, default=channels)
only_stale = col2.checkbox("Only behind latest")

df = c.execute(
    """
    SELECT cluster, channel, configured_version, latest_upstream,
           versions_behind, hops_to_latest, is_current, source_path
    FROM mart.cluster_drift
    WHERE channel IN (SELECT unnest(?::VARCHAR[]))
    ORDER BY versions_behind DESC
    """,
    [selected],
).df()
if only_stale:
    df = df[~df["is_current"].fillna(False)]

stat_row(
    [
        (len(df), "Clusters shown"),
        (int(df["is_current"].fillna(False).sum()), "Up to date"),
        (int(df["versions_behind"].fillna(0).max()) if len(df) else 0,
         "Max versions behind"),
        (int(df["hops_to_latest"].dropna().max()) if df["hops_to_latest"].notna().any() else 0,
         "Max upgrade hops"),
        (len(selected), "Channels selected"),
    ]
)

view = df.copy()
view["configured_version"] = [
    pill(v, "ok" if cur else "warn")
    for v, cur in zip(view["configured_version"], view["is_current"].fillna(False))
]
view["latest_upstream"] = [pill(v or "-") for v in view["latest_upstream"]]
view = view.drop(columns=["is_current"])
panel_table(
    view,
    title="Drift",
    html_cols=("configured_version", "latest_upstream"),
)

nexus = c.execute(
    "SELECT repository, name, latest_version, last_modified "
    "FROM mart.latest_in_nexus ORDER BY last_modified DESC"
).df()
nexus["latest_version"] = [pill(v) for v in nexus["latest_version"]]
panel_table(nexus, title="Latest components in Nexus",
            html_cols=("latest_version",))

st.download_button(
    "Export drift as CSV",
    df.to_csv(index=False).encode(),
    file_name="cluster_drift.csv",
    mime="text/csv",
)
