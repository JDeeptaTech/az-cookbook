"""Ad-hoc SQL console. Safety = read_only connection, not string filtering."""
from __future__ import annotations

import streamlit as st

from Home import conn
from theme import page_setup, panel_table

page_setup("Ad-hoc Query", "Read-only SQL over the raw and mart schemas.")

c = conn()

with st.expander("Schema browser", expanded=False):
    tables = c.execute(
        "SELECT table_schema, table_name, "
        "string_agg(column_name, ', ' ORDER BY ordinal_position) AS columns "
        "FROM information_schema.columns "
        "WHERE table_schema IN ('raw','mart') "
        "GROUP BY 1,2 ORDER BY 1,2"
    ).df()
    panel_table(tables)

default_q = "SELECT * FROM mart.cluster_drift ORDER BY versions_behind DESC"
sql = st.text_area("SQL (read-only)", value=default_q, height=160)

if st.button("Run", type="primary"):
    try:
        df = c.execute(sql).df()
        st.caption(f"{len(df)} rows")
        if len(df) > 500:
            st.dataframe(df, use_container_width=True)  # virtualised for big results
        else:
            panel_table(df)
        st.download_button(
            "Download CSV", df.to_csv(index=False).encode(),
            "query_result.csv", "text/csv",
        )
    except Exception as exc:  # noqa: BLE001 - surfaced to user
        st.error(str(exc))
