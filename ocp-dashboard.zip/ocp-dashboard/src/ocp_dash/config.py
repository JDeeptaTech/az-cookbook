"""Configuration: YAML file + env-var overrides (OCPDASH_*)."""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path

import yaml


@dataclass(frozen=True)
class NexusConfig:
    base_url: str
    repositories: tuple[str, ...]
    # token read from env OCPDASH_NEXUS_TOKEN (never in yaml)
    verify_tls: bool = True


@dataclass(frozen=True)
class GitOpsConfig:
    repo_url: str
    branch: str = "main"
    # glob (relative to repo root) for manifests to scan
    manifest_glob: str = "clusters/**/*.y*ml"
    # regex with one capture group extracting cluster name from file path
    cluster_name_pattern: str = r"clusters/([^/]+)/"


@dataclass(frozen=True)
class Config:
    duckdb_path: Path
    channels: tuple[str, ...]
    architecture: str
    graph_url: str
    nexus: NexusConfig
    gitops: GitOpsConfig
    schedule_minutes: int = 60
    http_timeout: int = 20
    workdir: Path = field(default_factory=lambda: Path("/tmp/ocp-dash"))


def load(path: str | os.PathLike = "config.yaml") -> Config:
    raw = yaml.safe_load(Path(path).read_text())
    return Config(
        duckdb_path=Path(os.getenv("OCPDASH_DB", raw["duckdb_path"])),
        channels=tuple(raw["channels"]),
        architecture=raw.get("architecture", "amd64"),
        graph_url=raw.get(
            "graph_url", "https://api.openshift.com/api/upgrades_info/v1/graph"
        ),
        nexus=NexusConfig(
            base_url=raw["nexus"]["base_url"],
            repositories=tuple(raw["nexus"]["repositories"]),
            verify_tls=raw["nexus"].get("verify_tls", True),
        ),
        gitops=GitOpsConfig(
            repo_url=os.getenv("OCPDASH_GITOPS_URL", raw["gitops"]["repo_url"]),
            branch=raw["gitops"].get("branch", "main"),
            manifest_glob=raw["gitops"].get("manifest_glob", "clusters/**/*.y*ml"),
            cluster_name_pattern=raw["gitops"].get(
                "cluster_name_pattern", r"clusters/([^/]+)/"
            ),
        ),
        schedule_minutes=int(
            os.getenv("OCPDASH_SCHEDULE_MINUTES", raw.get("schedule_minutes", 60))
        ),
        http_timeout=raw.get("http_timeout", 20),
    )
