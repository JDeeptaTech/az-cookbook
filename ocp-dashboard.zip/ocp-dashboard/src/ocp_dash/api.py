"""Read-only JSON API over the same DuckDB file.

Concurrency model:
- One base connection per process, read_only=True (never takes the RW lock,
  so it coexists with Streamlit readers and the pipeline's swap writes).
- Reopened when the file mtime changes (pipeline os.replace leaves old
  connections pointing at the deleted inode -> silently stale otherwise).
- Every request gets its own .cursor(): a single DuckDB connection is not
  safe for concurrent threads, and uvicorn serves threads concurrently.

/query safety: the read_only connection makes writes/DDL impossible at the
engine level — no SQL string filtering, which is always bypassable.
"""
from __future__ import annotations

import os
import threading
from pathlib import Path
from typing import Any

import duckdb
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

DB = Path(os.getenv("OCPDASH_DB", "/data/ocp.duckdb"))
MAX_ROWS = 10_000

app = FastAPI(title="ocp-dash API", version="0.1.0")

_lock = threading.Lock()
_base: duckdb.DuckDBPyConnection | None = None
_mtime: float = 0.0


def cursor() -> duckdb.DuckDBPyConnection:
    global _base, _mtime
    if not DB.exists():
        raise HTTPException(503, "database not populated yet")
    m = DB.stat().st_mtime
    with _lock:
        if _base is None or m != _mtime:
            if _base is not None:
                _base.close()
            _base = duckdb.connect(str(DB), read_only=True)
            _mtime = m
        return _base.cursor()


def _rows(cur: duckdb.DuckDBPyConnection) -> list[dict[str, Any]]:
    cols = [d[0] for d in cur.description]
    return [dict(zip(cols, r)) for r in cur.fetchmany(MAX_ROWS)]


@app.get("/health")
def health() -> dict[str, Any]:
    cur = cursor()
    last = cur.execute(
        "SELECT run_at, status FROM mart.pipeline_runs ORDER BY run_at DESC LIMIT 1"
    ).fetchone()
    return {
        "db_mtime": _mtime,
        "last_run_at": str(last[0]) if last else None,
        "last_run_status": last[1] if last else None,
    }


@app.get("/drift")
def drift(channel: str | None = None, stale_only: bool = False) -> list[dict[str, Any]]:
    sql = "SELECT * FROM mart.cluster_drift WHERE 1=1"
    params: list[Any] = []
    if channel:
        sql += " AND channel = ?"
        params.append(channel)
    if stale_only:
        sql += " AND NOT coalesce(is_current, false)"
    sql += " ORDER BY versions_behind DESC"
    return _rows(cursor().execute(sql, params))


@app.get("/clusters/{cluster}")
def cluster(cluster: str) -> dict[str, Any]:
    row = cursor().execute(
        "SELECT * FROM mart.cluster_drift WHERE cluster = ?", [cluster]
    ).df()
    if row.empty:
        raise HTTPException(404, f"unknown cluster {cluster!r}")
    return row.iloc[0].to_dict()


class QueryRequest(BaseModel):
    sql: str = Field(..., min_length=1, max_length=20_000)


@app.post("/query")
def query(req: QueryRequest) -> dict[str, Any]:
    try:
        cur = cursor().execute(req.sql)
    except duckdb.Error as exc:
        # read_only connection: write/DDL attempts land here too
        raise HTTPException(400, str(exc)) from exc
    rows = _rows(cur)
    return {"row_count": len(rows), "truncated": len(rows) == MAX_ROWS, "rows": rows}
