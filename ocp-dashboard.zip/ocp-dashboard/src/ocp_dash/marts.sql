-- Executed against the build DB after every load. Idempotent.
CREATE SCHEMA IF NOT EXISTS mart;

-- semver sort key: pad each numeric segment (rc/pre-release sorts before GA)
CREATE OR REPLACE MACRO mart.vkey(v) AS
  lpad(split_part(split_part(v, '-', 1), '.', 1), 4, '0') ||
  lpad(split_part(split_part(v, '-', 1), '.', 2), 4, '0') ||
  lpad(split_part(split_part(v, '-', 1), '.', 3), 4, '0') ||
  CASE WHEN v LIKE '%-%' THEN '0' || split_part(v, '-', 2) ELSE '1' END;

CREATE OR REPLACE VIEW mart.latest_upstream AS
SELECT channel, max_by(version, mart.vkey(version)) AS latest_version
FROM raw.graph_nodes
GROUP BY channel;

-- naive stream mapping: nexus component name/version carrying the OCP release.
-- Adjust the join predicate to your Nexus layout (e.g. ocp-release images).
CREATE OR REPLACE VIEW mart.latest_in_nexus AS
SELECT name, repository,
       max_by(version, mart.vkey(version)) AS latest_version,
       max(last_modified) AS last_modified
FROM raw.nexus_components
GROUP BY name, repository;

-- shortest upgrade path (hops) from configured version to any newer node
CREATE OR REPLACE VIEW mart.upgrade_hops AS
WITH RECURSIVE walk AS (
    SELECT channel, from_version AS origin, to_version AS reached, 1 AS hops
    FROM raw.graph_edges
    UNION ALL
    SELECT w.channel, w.origin, e.to_version, w.hops + 1
    FROM walk w
    JOIN raw.graph_edges e
      ON e.channel = w.channel AND e.from_version = w.reached
    WHERE w.hops < 8
)
SELECT channel, origin, reached, min(hops) AS hops
FROM walk
GROUP BY 1, 2, 3;

CREATE OR REPLACE VIEW mart.cluster_drift AS
SELECT
    c.cluster,
    c.channel,
    c.desired_version                       AS configured_version,
    lu.latest_version                       AS latest_upstream,
    c.desired_version = lu.latest_version   AS is_current,
    -- versions strictly newer than configured, same channel
    (SELECT count(*) FROM raw.graph_nodes n
      WHERE n.channel = c.channel
        AND mart.vkey(n.version) > mart.vkey(c.desired_version)
    )                                       AS versions_behind,
    -- real upgrade-graph distance to latest (NULL = no path published)
    (SELECT h.hops FROM mart.upgrade_hops h
      WHERE h.channel = c.channel
        AND h.origin  = c.desired_version
        AND h.reached = lu.latest_version
    )                                       AS hops_to_latest,
    c.commit_sha,
    c.source_path
FROM raw.gitops_clusters c
LEFT JOIN mart.latest_upstream lu USING (channel);
