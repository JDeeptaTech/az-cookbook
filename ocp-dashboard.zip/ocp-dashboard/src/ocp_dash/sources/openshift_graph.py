"""OpenShift update-graph source.

Design decisions vs the original OCPMetadataClient:
- Nodes AND edges are persisted. 'How far behind' = shortest path on the
  real graph, not semver distance.
- No fallback/sample data ever enters the warehouse. A failed channel fetch
  is recorded in `fetch_errors`; the previous snapshot stays authoritative.
- Full snapshot per run -> write_disposition='replace'.
"""
from __future__ import annotations

from typing import Any, Iterator

import dlt
import requests


def _fetch_graph(
    session: requests.Session, url: str, channel: str, arch: str, timeout: int
) -> dict[str, Any]:
    resp = session.get(
        url, params={"channel": channel, "arch": arch}, timeout=timeout
    )
    resp.raise_for_status()
    return resp.json()


@dlt.source(name="openshift_graph")
def openshift_graph_source(
    channels: tuple[str, ...],
    arch: str,
    graph_url: str,
    timeout: int = 20,
):
    session = requests.Session()
    # fetch once per channel, shared by both resources
    graphs: dict[str, dict[str, Any]] = {}
    errors: list[dict[str, str]] = []
    for ch in channels:
        try:
            graphs[ch] = _fetch_graph(session, graph_url, ch, arch, timeout)
        except (requests.RequestException, ValueError) as exc:
            errors.append({"channel": ch, "error": str(exc)})

    @dlt.resource(
        write_disposition="replace",
        name="graph_nodes",
        columns={
            "payload": {"data_type": "text"},
            "release_url": {"data_type": "text"},
        },
    )
    def nodes() -> Iterator[dict[str, Any]]:
        for ch, g in graphs.items():
            for idx, node in enumerate(g.get("nodes", [])):
                meta = node.get("metadata") or {}
                yield {
                    "channel": ch,
                    "node_idx": idx,
                    "version": node.get("version"),
                    "payload": node.get("payload"),
                    "release_url": meta.get("url"),
                }

    @dlt.resource(write_disposition="replace", name="graph_edges")
    def edges() -> Iterator[dict[str, Any]]:
        for ch, g in graphs.items():
            versions = [n.get("version") for n in g.get("nodes", [])]
            for frm, to in g.get("edges", []):
                yield {
                    "channel": ch,
                    "from_version": versions[frm],
                    "to_version": versions[to],
                }

    @dlt.resource(write_disposition="append", name="fetch_errors")
    def fetch_errors() -> Iterator[dict[str, str]]:
        yield from errors

    return nodes, edges, fetch_errors
