"""Nexus Repository Manager 3 source.

Paginates /service/rest/v1/components per repository.
Incremental on lastModified (of the newest asset per component) so
scheduled runs only pull new/changed artifacts; merge on component id.

Auth: bearer/token via OCPDASH_NEXUS_TOKEN or user/pass via
OCPDASH_NEXUS_USER / OCPDASH_NEXUS_PASS.
"""
from __future__ import annotations

import os
from typing import Any, Iterator

import dlt
import requests


def _session(verify_tls: bool) -> requests.Session:
    s = requests.Session()
    s.verify = verify_tls
    token = os.getenv("OCPDASH_NEXUS_TOKEN")
    if token:
        s.headers["Authorization"] = f"Bearer {token}"
    else:
        user, pw = os.getenv("OCPDASH_NEXUS_USER"), os.getenv("OCPDASH_NEXUS_PASS")
        if user and pw:
            s.auth = (user, pw)
    return s


def _component_row(repo: str, comp: dict[str, Any]) -> dict[str, Any]:
    assets = comp.get("assets") or []
    last_modified = max(
        (a.get("lastModified") or "" for a in assets), default=None
    )
    sha256 = next(
        (a.get("checksum", {}).get("sha256") for a in assets if a.get("checksum")),
        None,
    )
    return {
        "id": comp["id"],
        "repository": repo,
        "format": comp.get("format"),
        "group": comp.get("group"),
        "name": comp.get("name"),
        "version": comp.get("version"),
        "sha256": sha256,
        "last_modified": last_modified,
        "asset_count": len(assets),
    }


@dlt.source(name="nexus")
def nexus_source(base_url: str, repositories: tuple[str, ...],
                 verify_tls: bool = True, timeout: int = 20):
    session = _session(verify_tls)

    @dlt.resource(
        write_disposition="merge",
        primary_key="id",
        name="nexus_components",
        columns={
            "group": {"data_type": "text"},
            "version": {"data_type": "text"},
            "sha256": {"data_type": "text"},
        },
    )
    def components(
        last_modified=dlt.sources.incremental(
            "last_modified", initial_value="1970-01-01T00:00:00.000+00:00"
        ),
    ) -> Iterator[dict[str, Any]]:
        for repo in repositories:
            token: str | None = None
            while True:
                params: dict[str, str] = {"repository": repo}
                if token:
                    params["continuationToken"] = token
                resp = session.get(
                    f"{base_url.rstrip('/')}/service/rest/v1/components",
                    params=params,
                    timeout=timeout,
                )
                resp.raise_for_status()
                body = resp.json()
                for comp in body.get("items", []):
                    yield _component_row(repo, comp)
                token = body.get("continuationToken")
                if not token:
                    break

    return components
