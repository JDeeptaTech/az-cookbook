"""GitOps source: shallow-clone the repo and parse cluster config.

Extracts from any YAML matching the configured glob:
- kind: ClusterVersion  -> spec.channel, spec.desiredUpdate.version
- Argo CD Application    -> spec.source targetRevision/path (context rows)

Cluster name derives from the file path via a configurable regex, e.g.
clusters/<cluster>/cluster-version.yaml. Snapshot semantics -> 'replace';
dlt's _dlt_load_id keeps per-run lineage if you later want history.

Auth: https token via OCPDASH_GIT_TOKEN (injected into URL) or rely on
mounted SSH agent / netrc.
"""
from __future__ import annotations

import os
import re
import shutil
import subprocess
import tempfile
from pathlib import Path
from typing import Any, Iterator

import dlt
import yaml


def _clone(repo_url: str, branch: str) -> Path:
    token = os.getenv("OCPDASH_GIT_TOKEN")
    url = repo_url
    if token and url.startswith("https://") and "@" not in url:
        url = url.replace("https://", f"https://oauth2:{token}@", 1)
    dest = Path(tempfile.mkdtemp(prefix="gitops-"))
    subprocess.run(
        ["git", "clone", "--depth", "1", "--branch", branch, url, str(dest)],
        check=True,
        capture_output=True,
        text=True,
    )
    return dest


def _head_sha(repo: Path) -> str:
    out = subprocess.run(
        ["git", "-C", str(repo), "rev-parse", "HEAD"],
        check=True, capture_output=True, text=True,
    )
    return out.stdout.strip()


def _docs(path: Path) -> Iterator[dict[str, Any]]:
    try:
        for doc in yaml.safe_load_all(path.read_text()):
            if isinstance(doc, dict):
                yield doc
    except yaml.YAMLError:
        return  # templated/helm files won't parse; skip


@dlt.source(name="gitops")
def gitops_source(repo_url: str, branch: str, manifest_glob: str,
                  cluster_name_pattern: str):
    repo = _clone(repo_url, branch)
    sha = _head_sha(repo)
    name_re = re.compile(cluster_name_pattern)

    @dlt.resource(
        write_disposition="replace",
        name="gitops_clusters",
        columns={
            "channel": {"data_type": "text"},
            "desired_version": {"data_type": "text"},
            "desired_image": {"data_type": "text"},
        },
    )
    def clusters() -> Iterator[dict[str, Any]]:
        try:
            for f in sorted(repo.glob(manifest_glob)):
                rel = str(f.relative_to(repo))
                m = name_re.search(rel)
                cluster = m.group(1) if m else rel
                for doc in _docs(f):
                    if doc.get("kind") == "ClusterVersion":
                        spec = doc.get("spec") or {}
                        desired = spec.get("desiredUpdate") or {}
                        yield {
                            "cluster": cluster,
                            "channel": spec.get("channel"),
                            "desired_version": desired.get("version"),
                            "desired_image": desired.get("image"),
                            "source_path": rel,
                            "commit_sha": sha,
                        }
        finally:
            shutil.rmtree(repo, ignore_errors=True)

    return clusters
