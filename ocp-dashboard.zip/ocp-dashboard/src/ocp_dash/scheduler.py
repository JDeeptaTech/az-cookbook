"""Scheduled runner. One process, one job, no overlap.

max_instances=1 + coalesce=True: if a run overshoots the interval, the
missed trigger collapses into a single catch-up run instead of stacking.
"""
from __future__ import annotations

import logging
import os

from apscheduler.schedulers.blocking import BlockingScheduler

from ocp_dash.config import load
from ocp_dash.pipeline import run

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(name)s %(message)s",
)
log = logging.getLogger("ocp_dash.scheduler")


def main() -> None:
    cfg = load(os.getenv("OCPDASH_CONFIG", "config.yaml"))

    def job() -> None:
        try:
            run(cfg)
        except Exception:  # noqa: BLE001 - keep scheduler alive
            log.exception("scheduled run raised")

    job()  # populate immediately on startup

    sched = BlockingScheduler(timezone="UTC")
    sched.add_job(
        job,
        "interval",
        minutes=cfg.schedule_minutes,
        max_instances=1,
        coalesce=True,
        id="ocp_meta_refresh",
    )
    log.info("scheduler started, interval=%dmin", cfg.schedule_minutes)
    sched.start()


if __name__ == "__main__":
    main()
