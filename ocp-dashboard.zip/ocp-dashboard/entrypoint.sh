#!/usr/bin/env bash
set -euo pipefail

# scheduler (writer) + api (reader) in background; streamlit foreground.
# If any background process dies, kill the container so the orchestrator
# restarts all processes together.
python -m ocp_dash.scheduler &
SCHED_PID=$!
uvicorn ocp_dash.api:app --host 0.0.0.0 --port 8000 &
API_PID=$!
trap 'kill $SCHED_PID $API_PID 2>/dev/null || true' EXIT

( while kill -0 "$SCHED_PID" 2>/dev/null && kill -0 "$API_PID" 2>/dev/null; do
    sleep 10
  done
  echo "background process exited; terminating" >&2
  kill 1 2>/dev/null || kill $$ ) &

exec streamlit run src/ocp_dash/app/Home.py \
    --server.port=8501 --server.address=0.0.0.0 --server.headless=true
