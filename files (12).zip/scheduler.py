"""
scheduler/scheduler.py — LISTEN/NOTIFY event-driven dispatcher.

Unchanged from previous iteration except _run_sync now calls:
    plugin_loader.get_plugin(snapshot["plugin_name"]).run(...)

instead of jobs.execute_ansible_job().
The plugin provides all the execution logic.
"""
from __future__ import annotations

import asyncio
import heapq
import json
import logging
import os
import socket
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta, timezone

import asyncpg
from sqlalchemy import select, update, text
from sqlalchemy.ext.asyncio import async_sessionmaker

from .models import Schedule
from .trigger_calc import compute_next_run

logger = logging.getLogger(__name__)

NOTIFY_CHANNEL     = os.getenv("SCHEDULER_NOTIFY_CHANNEL", "vm_scheduler")
STALE_LOCK_MINUTES = int(os.getenv("SCHEDULER_STALE_LOCK_MIN", "10"))
MAX_OUTPUT_CHARS   = int(os.getenv("SCHEDULER_MAX_OUTPUT",     "4000"))
BOOT_RECOVERY      = os.getenv("SCHEDULER_BOOT_RECOVERY", "true").lower() == "true"

_WORKER_ID = f"{socket.gethostname()}:{os.getpid()}"

_session_factory: async_sessionmaker | None = None
_executor: ThreadPoolExecutor | None = None
_listener_task: asyncio.Task | None = None
_dispatcher_task: asyncio.Task | None = None
_heap: list[tuple[datetime, str]] = []
_heap_event: asyncio.Event


def init_scheduler(session_factory: async_sessionmaker) -> None:
    global _session_factory, _executor, _listener_task, _dispatcher_task, _heap_event
    _session_factory = session_factory
    _heap_event = asyncio.Event()
    _executor = ThreadPoolExecutor(
        max_workers=int(os.getenv("SCHEDULER_THREAD_WORKERS", "5")),
        thread_name_prefix="ansible-job",
    )
    _listener_task   = asyncio.ensure_future(_listener_loop())
    _dispatcher_task = asyncio.ensure_future(_dispatcher_loop())
    logger.info("Scheduler started (LISTEN/NOTIFY) — %s", _WORKER_ID)


async def stop_scheduler() -> None:
    for task in (_listener_task, _dispatcher_task):
        if task and not task.done():
            task.cancel()
            try: await task
            except asyncio.CancelledError: pass
    if _executor:
        _executor.shutdown(wait=False)


def _push(fire_time: datetime, schedule_id: str) -> None:
    heapq.heappush(_heap, (fire_time, schedule_id))
    _heap_event.set()


async def _listener_loop() -> None:
    dsn = os.environ["DATABASE_URL"].replace("+asyncpg", "")
    while True:
        try:
            conn = await asyncpg.connect(dsn)
            try:
                await conn.add_listener(NOTIFY_CHANNEL, _on_notify)
                if BOOT_RECOVERY:
                    await _load_pending()
                while True:
                    await asyncio.sleep(30)
                    await conn.execute("SELECT 1")
            finally:
                await conn.close()
        except asyncio.CancelledError:
            raise
        except Exception:
            logger.exception("Scheduler LISTEN lost — reconnecting in 5s")
            await asyncio.sleep(5)


def _on_notify(_conn, _pid, _channel, payload_str: str) -> None:
    try:
        p = json.loads(payload_str)
        sid, nrat = p.get("id"), p.get("next_run_at")
        if not sid or not nrat:
            return
        ft = datetime.fromisoformat(nrat)
        if ft.tzinfo is None:
            ft = ft.replace(tzinfo=timezone.utc)
        asyncio.get_event_loop().call_soon_threadsafe(_push, ft, sid)
    except Exception:
        logger.exception("Bad scheduler NOTIFY: %s", payload_str)


async def _load_pending() -> None:
    assert _session_factory is not None
    async with _session_factory() as session:
        rows = (await session.execute(
            select(Schedule.id, Schedule.next_run_at)
            .where(Schedule.enabled == True, Schedule.next_run_at != None)
        )).all()
    for r in rows:
        ft = r.next_run_at
        if ft.tzinfo is None:
            ft = ft.replace(tzinfo=timezone.utc)
        _push(ft, str(r.id))
    logger.info("Boot recovery: %d schedule(s) loaded", len(rows))


async def _dispatcher_loop() -> None:
    while True:
        try:
            await _wait_and_dispatch()
        except asyncio.CancelledError:
            raise
        except Exception:
            logger.exception("Dispatcher error — retrying in 5s")
            await asyncio.sleep(5)


async def _wait_and_dispatch() -> None:
    _heap_event.clear()
    if not _heap:
        await _heap_event.wait()
        return

    fire_time, schedule_id = _heap[0]
    delta = (fire_time - datetime.now(timezone.utc)).total_seconds()

    if delta > 0:
        try:
            await asyncio.wait_for(_heap_event.wait(), timeout=delta)
            return   # earlier job arrived
        except asyncio.TimeoutError:
            pass

    heapq.heappop(_heap)
    asyncio.ensure_future(_claim_and_dispatch(schedule_id))


async def _claim_and_dispatch(schedule_id: str) -> None:
    import uuid
    assert _session_factory is not None

    now          = datetime.now(timezone.utc)
    stale_cutoff = now - timedelta(minutes=STALE_LOCK_MINUTES)

    async with _session_factory() as session:
        async with session.begin():
            row = (await session.execute(
                select(Schedule)
                .where(
                    Schedule.id == uuid.UUID(schedule_id),
                    Schedule.enabled == True,
                    Schedule.next_run_at <= now,
                    (Schedule.locked_at == None) | (Schedule.locked_at < stale_cutoff),
                )
                .with_for_update(skip_locked=True)
            )).scalar_one_or_none()

            if row is None:
                return   # claimed by another worker or disabled

            snapshot = {
                "id":          str(row.id),
                "plugin_name": row.plugin_name,
                "extra_vars":  dict(row.extra_vars),
                "trigger_type": row.trigger_type,
                "trigger_args": dict(row.trigger_args),
            }
            await session.execute(
                update(Schedule)
                .where(Schedule.id == row.id)
                .values(locked_at=now, locked_by=_WORKER_ID, last_run_status="running")
            )

    loop = asyncio.get_running_loop()
    fut  = loop.run_in_executor(_executor, _run_sync, snapshot)
    fut.add_done_callback(
        lambda f, s=snapshot: asyncio.ensure_future(_on_done(s, f))
    )


def _run_sync(snapshot: dict) -> tuple[str, str]:
    """Runs in thread — looks up plugin from in-memory registry and calls run()."""
    from .plugin_loader import get_plugin
    try:
        plugin = get_plugin(snapshot["plugin_name"])
        return plugin.run(snapshot["id"], snapshot["extra_vars"])
    except KeyError as exc:
        return "failure", f"Plugin not found in registry: {exc}"
    except Exception as exc:
        import traceback
        return "failure", f"{exc}\n{traceback.format_exc()}"


async def _on_done(snapshot: dict, future: asyncio.Future) -> None:
    import uuid
    assert _session_factory is not None

    status, output = "failure", ""
    try:
        status, output = future.result()
    except Exception as exc:
        import traceback
        output = f"{exc}\n{traceback.format_exc()}"

    now = datetime.now(timezone.utc)

    async with _session_factory() as session:
        async with session.begin():
            row = await session.get(Schedule, uuid.UUID(snapshot["id"]))
            if not row:
                return

            next_run = None
            if row.trigger_type != "date":
                try:
                    next_run = compute_next_run(row.trigger_type, row.trigger_args, after=now)
                except Exception as exc:
                    logger.error("next_run compute error: %s", exc)
            else:
                row.enabled = False

            row.last_run_at     = now
            row.last_run_status = status
            row.last_run_output = output[:MAX_OUTPUT_CHARS]
            row.next_run_at     = next_run
            row.run_count       += 1
            if status == "failure":
                row.failure_count += 1
            row.locked_at = None
            row.locked_by = None

            payload = json.dumps({
                "id":          snapshot["id"],
                "next_run_at": next_run.isoformat() if next_run else None,
            })
            await session.execute(
                text(f"SELECT pg_notify('{NOTIFY_CHANNEL}', :p)"), {"p": payload}
            )

    logger.info("Schedule %s → plugin:%s → %s | next=%s",
                snapshot["id"], snapshot["plugin_name"], status, next_run)


def compute_initial_next_run(trigger_type: str, trigger_args: dict) -> datetime | None:
    return compute_next_run(trigger_type, trigger_args)
