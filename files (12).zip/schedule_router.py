"""scheduler/schedule_router.py"""
from __future__ import annotations
import uuid
from typing import Annotated
from fastapi import APIRouter, Depends, HTTPException, Query, Request, status
from .schemas import ApiResponse, ScheduleCreate, ScheduleListResponse, ScheduleResponse, ScheduleUpdate
from .schedule_service import (
    DuplicateScheduleError, PluginNotFoundError, ScheduleNotFoundError,
    create_schedule, delete_schedule, get_schedule, list_schedules,
    toggle_schedule, update_schedule,
)

router = APIRouter(prefix="/schedules", tags=["Schedules"])

async def get_db(request: Request):
    async with request.app.state.db_session_factory() as session:
        yield session

def current_user(request: Request) -> str:
    return request.headers.get("X-User-Id", "system")

DbDep   = Annotated[object, Depends(get_db)]
UserDep = Annotated[str, Depends(current_user)]

def _ok(data, message=None): return ApiResponse(success=True, data=data, message=message)

@router.get("", response_model=ApiResponse)
async def list_all(db: DbDep, plugin_name: str | None = None, enabled: bool | None = None,
                   mine_only: bool = False, offset: int = Query(0,ge=0), limit: int = Query(50,ge=1,le=200),
                   user: UserDep = None):
    r = await list_schedules(db, plugin_name=plugin_name, created_by=user if mine_only else None,
                             enabled=enabled, offset=offset, limit=limit)
    return _ok(r)

@router.post("", response_model=ApiResponse, status_code=status.HTTP_201_CREATED)
async def create(payload: ScheduleCreate, db: DbDep, user: UserDep):
    try:
        r = await create_schedule(db, payload, created_by=user)
    except PluginNotFoundError as e: raise HTTPException(404, str(e))
    except DuplicateScheduleError as e: raise HTTPException(409, str(e))
    except ValueError as e: raise HTTPException(422, str(e))
    return _ok(r, message="Schedule created")

@router.get("/{schedule_id}", response_model=ApiResponse)
async def get_one(schedule_id: uuid.UUID, db: DbDep):
    try: return _ok(await get_schedule(db, schedule_id))
    except ScheduleNotFoundError: raise HTTPException(404, "Not found")

@router.patch("/{schedule_id}", response_model=ApiResponse)
async def update(schedule_id: uuid.UUID, payload: ScheduleUpdate, db: DbDep, user: UserDep):
    try: r = await update_schedule(db, schedule_id, payload, updated_by=user)
    except ScheduleNotFoundError: raise HTTPException(404, "Not found")
    except PluginNotFoundError as e: raise HTTPException(404, str(e))
    except DuplicateScheduleError as e: raise HTTPException(409, str(e))
    except ValueError as e: raise HTTPException(422, str(e))
    return _ok(r, message="Schedule updated")

@router.delete("/{schedule_id}", response_model=ApiResponse)
async def delete(schedule_id: uuid.UUID, db: DbDep):
    try: await delete_schedule(db, schedule_id)
    except ScheduleNotFoundError: raise HTTPException(404, "Not found")
    return _ok(None, message="Schedule deleted")

@router.post("/{schedule_id}/enable", response_model=ApiResponse)
async def enable(schedule_id: uuid.UUID, db: DbDep, user: UserDep):
    try: r = await toggle_schedule(db, schedule_id, True, user)
    except ScheduleNotFoundError: raise HTTPException(404, "Not found")
    return _ok(r)

@router.post("/{schedule_id}/disable", response_model=ApiResponse)
async def disable(schedule_id: uuid.UUID, db: DbDep, user: UserDep):
    try: r = await toggle_schedule(db, schedule_id, False, user)
    except ScheduleNotFoundError: raise HTTPException(404, "Not found")
    return _ok(r)
