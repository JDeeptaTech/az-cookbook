"""scheduler/trigger_calc.py"""
from __future__ import annotations
from datetime import datetime, timedelta, timezone
from typing import Any
from croniter import croniter


def _utc(dt: datetime) -> datetime:
    return dt.replace(tzinfo=timezone.utc) if dt.tzinfo is None else dt.astimezone(timezone.utc)


def compute_next_run(trigger_type: str, trigger_args: dict, after: datetime | None = None) -> datetime | None:
    base = _utc(after) if after else datetime.now(timezone.utc)
    if trigger_type == "cron":
        expr = f"{trigger_args.get('minute','0')} {trigger_args.get('hour','0')} {trigger_args.get('day','*')} {trigger_args.get('month','*')} {trigger_args.get('day_of_week','*')}"
        return _utc(croniter(expr, base).get_next(datetime))
    elif trigger_type == "interval":
        delta = timedelta(weeks=trigger_args.get("weeks",0), days=trigger_args.get("days",0),
                          hours=trigger_args.get("hours",0), minutes=trigger_args.get("minutes",0),
                          seconds=trigger_args.get("seconds",0))
        if delta.total_seconds() == 0:
            raise ValueError("Interval must have at least one non-zero field")
        return base + delta
    elif trigger_type == "date":
        rd = trigger_args.get("run_date")
        if isinstance(rd, str): rd = datetime.fromisoformat(rd)
        rd = _utc(rd)
        return rd if rd > datetime.now(timezone.utc) else None
    raise ValueError(f"Unknown trigger_type: {trigger_type!r}")


def validate_trigger_args(trigger_type: str, raw: dict) -> dict:
    from .schemas import CronTriggerArgs, IntervalTriggerArgs, DateTriggerArgs
    m = {"cron": CronTriggerArgs, "interval": IntervalTriggerArgs, "date": DateTriggerArgs}
    cls = m.get(trigger_type)
    if not cls:
        raise ValueError(f"Unknown trigger_type: {trigger_type!r}")
    return cls.model_validate(raw).model_dump(exclude_none=True)
