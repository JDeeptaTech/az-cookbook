"""
Example plugins to paste into POST /api/v1/plugins

Each plugin must export:
    METADATA: dict  (name, description required)
    run(schedule_id: str, extra_vars: dict) -> tuple[str, str]

Optional:
    validate_extra_vars(extra_vars: dict) -> list[str]
"""

# =============================================================================
# Plugin 1: Local ansible-playbook subprocess
# =============================================================================

PLUGIN_1 = '''
import json
import subprocess

METADATA = {
    "name":         "nightly-patch",
    "description":  "Run OS patching playbook on target inventory",
    "trigger_type": "cron",
    "trigger_args": {"hour": "2", "minute": "30"},
}


def validate_extra_vars(extra_vars: dict) -> list[str]:
    errors = []
    if "env" not in extra_vars:
        errors.append("'env' is required")
    if extra_vars.get("env") not in ("dev", "test", "prod"):
        errors.append("'env' must be dev, test, or prod")
    return errors


def run(schedule_id: str, extra_vars: dict) -> tuple[str, str]:
    cmd = [
        "ansible-playbook",
        f"/playbooks/{extra_vars.get('playbook', 'patch_vms.yml')}",
        "-i", extra_vars.get("inventory", "localhost,"),
        "--extra-vars", json.dumps({**extra_vars, "schedule_id": schedule_id}),
    ]
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=3600)
    output = (result.stdout + result.stderr).strip()
    return ("success" if result.returncode == 0 else "failure"), output
'''


# =============================================================================
# Plugin 2: AAP job template launch
# =============================================================================

PLUGIN_2 = '''
import json
import os
import urllib.request

METADATA = {
    "name":         "aap-vm-health",
    "description":  "Launch AAP job template for VM health check",
    "trigger_type": "interval",
    "trigger_args": {"hours": 6},
}

_AAP_BASE    = os.environ["AAP_BASE_URL"]
_AAP_TOKEN   = os.environ["AAP_TOKEN"]
_TEMPLATE_ID = int(os.environ.get("AAP_HEALTH_TEMPLATE_ID", "42"))


def validate_extra_vars(extra_vars: dict) -> list[str]:
    if "target_group" not in extra_vars:
        return ["'target_group' is required"]
    return []


def run(schedule_id: str, extra_vars: dict) -> tuple[str, str]:
    body = json.dumps({
        "extra_vars": json.dumps({**extra_vars, "schedule_id": schedule_id})
    }).encode()

    req = urllib.request.Request(
        f"{_AAP_BASE}/api/v2/job_templates/{_TEMPLATE_ID}/launch/",
        data=body,
        headers={
            "Authorization": f"Bearer {_AAP_TOKEN}",
            "Content-Type":  "application/json",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            data = json.loads(resp.read())
        return "success", f"AAP job {data['id']} launched: {_AAP_BASE}{data.get('url','')}"
    except Exception as exc:
        return "failure", str(exc)
'''


# =============================================================================
# Plugin 3: GCP / Azure CLI command
# =============================================================================

PLUGIN_3 = '''
import subprocess
import json

METADATA = {
    "name":         "gcp-snapshot",
    "description":  "Trigger GCP disk snapshots via gcloud CLI",
    "trigger_type": "cron",
    "trigger_args": {"hour": "1", "minute": "0", "day_of_week": "sun"},
}


def validate_extra_vars(extra_vars: dict) -> list[str]:
    errors = []
    for key in ("project", "zone", "disk"):
        if key not in extra_vars:
            errors.append(f"'{key}' is required")
    return errors


def run(schedule_id: str, extra_vars: dict) -> tuple[str, str]:
    project = extra_vars["project"]
    zone    = extra_vars["zone"]
    disk    = extra_vars["disk"]
    snap    = f"{disk}-{schedule_id[:8]}"

    cmd = [
        "gcloud", "compute", "disks", "snapshot", disk,
        f"--project={project}",
        f"--zone={zone}",
        f"--snapshot-names={snap}",
        "--format=json",
    ]
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
    if result.returncode != 0:
        return "failure", result.stderr.strip()
    return "success", f"Snapshot {snap} created"
'''
