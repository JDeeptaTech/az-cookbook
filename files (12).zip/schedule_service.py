"""
scheduler/schedule_service.py — Schedule CRUD.

When creating/updating a schedule:
  - Validates plugin_name exists in DB
  - Falls back to plugin's default trigger if none provided
  - Computes next_run_at
  - NOTIFY 'vm_scheduler' so all workers update their heaps
"""
from __future__ import annotations

import logging
import uuid

from sqlalchemy import func, select, text
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession

from .models import Plugin as PluginModel, Schedule
from .schemas import (
    ScheduleCreate, ScheduleUpdate,
    ScheduleResponse, ScheduleListResponse,
)
from .trigger_calc import compute_next_run, validate_trigger_args
from .notify import notify_schedule_updated, notify_schedule_deleted

logger = logging.getLogger(__name__)

SCHEDULER_CHANNEL = __import__("os").getenv("SCHEDULER_NOTIFY_CHANNEL", "vm_scheduler")


class ScheduleNotFoundError(Exception):
    pass

class DuplicateScheduleError(Exception):
    pass

class PluginNotFoundError(Exception):
    pass


async def create_schedule(
    db: AsyncSession, payload: ScheduleCreate, created_by: str,
) -> ScheduleResponse:
    plugin_row = await _resolve_plugin(db, payload.plugin_name)

    # Use plugin defaults if caller didn't specify a trigger
    trigger_type = payload.trigger_type or plugin_row.trigger_type
    trigger_args = validate_trigger_args(
        trigger_type,
        payload.trigger_args if payload.trigger_args is not None else dict(plugin_row.trigger_args),
    )

    next_run = compute_next_run(trigger_type, trigger_args) if payload.enabled else None

    schedule = Schedule(
        name=payload.name,
        description=payload.description,
        plugin_name=payload.plugin_name,
        trigger_type=trigger_type,
        trigger_args=trigger_args,
        extra_vars=payload.extra_vars,
        enabled=payload.enabled,
        next_run_at=next_run,
        created_by=created_by,
    )
    try:
        async with db.begin():
            db.add(schedule)
            await db.flush()
            await notify_schedule_updated(db, str(schedule.id), next_run)
    except IntegrityError as exc:
        raise DuplicateScheduleError(
            f"Schedule '{payload.name}' already exists for '{created_by}'"
        ) from exc

    await db.refresh(schedule)
    logger.info("Schedule created: %s → plugin:%s", schedule.name, schedule.plugin_name)
    return ScheduleResponse.model_validate(schedule)


async def list_schedules(
    db: AsyncSession,
    plugin_name: str | None = None,
    created_by: str | None = None,
    enabled: bool | None = None,
    offset: int = 0,
    limit: int = 50,
) -> ScheduleListResponse:
    q = select(Schedule)
    if plugin_name:
        q = q.where(Schedule.plugin_name == plugin_name)
    if created_by:
        q = q.where(Schedule.created_by == created_by)
    if enabled is not None:
        q = q.where(Schedule.enabled == enabled)
    total = (await db.execute(select(func.count()).select_from(q.subquery()))).scalar_one()
    rows  = (await db.execute(q.offset(offset).limit(limit).order_by(Schedule.created_at.desc()))).scalars().all()
    return ScheduleListResponse(total=total, items=[ScheduleResponse.model_validate(r) for r in rows])


async def get_schedule(db: AsyncSession, schedule_id: uuid.UUID) -> ScheduleResponse:
    row = await db.get(Schedule, schedule_id)
    if not row:
        raise ScheduleNotFoundError(str(schedule_id))
    return ScheduleResponse.model_validate(row)


async def update_schedule(
    db: AsyncSession, schedule_id: uuid.UUID,
    payload: ScheduleUpdate, updated_by: str,
) -> ScheduleResponse:
    row = await db.get(Schedule, schedule_id)
    if not row:
        raise ScheduleNotFoundError(str(schedule_id))

    if payload.plugin_name and payload.plugin_name != row.plugin_name:
        await _resolve_plugin(db, payload.plugin_name)
        row.plugin_name = payload.plugin_name

    for f in ("name", "description", "extra_vars", "enabled"):
        val = getattr(payload, f)
        if val is not None:
            setattr(row, f, val)

    trigger_changed = payload.trigger_type is not None or payload.trigger_args is not None
    if trigger_changed:
        new_type = payload.trigger_type or row.trigger_type
        new_args = payload.trigger_args if payload.trigger_args is not None else row.trigger_args
        row.trigger_type = new_type
        row.trigger_args = validate_trigger_args(new_type, new_args)

    if trigger_changed or payload.enabled is not None:
        row.next_run_at = (
            compute_next_run(row.trigger_type, row.trigger_args) if row.enabled else None
        )

    row.updated_by = updated_by

    try:
        async with db.begin():
            db.add(row)
            await db.flush()
            await notify_schedule_updated(db, str(row.id), row.next_run_at)
    except IntegrityError as exc:
        raise DuplicateScheduleError(str(exc)) from exc

    await db.refresh(row)
    return ScheduleResponse.model_validate(row)


async def delete_schedule(db: AsyncSession, schedule_id: uuid.UUID) -> None:
    row = await db.get(Schedule, schedule_id)
    if not row:
        raise ScheduleNotFoundError(str(schedule_id))
    async with db.begin():
        await db.delete(row)
        await notify_schedule_deleted(db, str(schedule_id))


async def toggle_schedule(
    db: AsyncSession, schedule_id: uuid.UUID, enable: bool, updated_by: str,
) -> ScheduleResponse:
    return await update_schedule(db, schedule_id, ScheduleUpdate(enabled=enable), updated_by)


async def _resolve_plugin(db: AsyncSession, name: str) -> PluginModel:
    row = (await db.execute(
        select(PluginModel).where(PluginModel.name == name, PluginModel.is_active == True)
    )).scalar_one_or_none()
    if not row:
        raise PluginNotFoundError(f"Active plugin '{name}' not found")
    return row
