"""
scheduler/plugin_service.py — Plugin CRUD business logic.

Every write to platform.plugins issues a pg_notify('vm_plugin_reload', name)
inside the same transaction — all workers reload atomically.
"""
from __future__ import annotations

import asyncio
import logging
import uuid
from datetime import datetime, timezone

from sqlalchemy import func, select, text
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession

from .models import Plugin as PluginModel, PluginTestRun
from .schemas import (
    PluginCreate, PluginUpdate,
    PluginResponse, PluginListResponse,
    PluginTestRunResponse,
)
from .plugin_loader import (
    TestResult, validate_source, run_test,
    PLUGIN_NOTIFY_CHANNEL,
)

logger = logging.getLogger(__name__)

MAX_TEST_OUTPUT = int(__import__("os").getenv("PLUGIN_MAX_OUTPUT", "8000"))


class PluginNotFoundError(Exception):
    pass

class DuplicatePluginError(Exception):
    pass


# ── NOTIFY helper ─────────────────────────────────────────────────────────

async def _notify(session: AsyncSession, plugin_name: str) -> None:
    """Issued inside an open transaction — delivered on commit, discarded on rollback."""
    await session.execute(
        text(f"SELECT pg_notify('{PLUGIN_NOTIFY_CHANNEL}', :name)"),
        {"name": plugin_name},
    )


# ── CRUD ──────────────────────────────────────────────────────────────────

async def create_plugin(
    db: AsyncSession, payload: PluginCreate, created_by: str,
) -> PluginResponse:
    # Validate before touching the DB
    result = validate_source(payload.source_code)
    if result.status == "error":
        raise ValueError(f"Plugin validation failed: {result.error}")

    from .trigger_calc import validate_trigger_args
    trigger_args = validate_trigger_args(payload.trigger_type, payload.trigger_args)

    plugin = PluginModel(
        name=payload.name,
        description=payload.description,
        source_code=payload.source_code,
        trigger_type=payload.trigger_type,
        trigger_args=trigger_args,
        created_by=created_by,
    )
    try:
        async with db.begin():
            db.add(plugin)
            await db.flush()
            await _notify(db, plugin.name)
    except IntegrityError as exc:
        raise DuplicatePluginError(f"Plugin '{payload.name}' already exists") from exc

    await db.refresh(plugin)
    logger.info("Plugin created: %s by %s", plugin.name, created_by)
    return PluginResponse.model_validate(plugin)


async def list_plugins(
    db: AsyncSession,
    is_active: bool | None = None,
    offset: int = 0,
    limit: int = 50,
) -> PluginListResponse:
    q = select(PluginModel)
    if is_active is not None:
        q = q.where(PluginModel.is_active == is_active)
    total = (await db.execute(select(func.count()).select_from(q.subquery()))).scalar_one()
    rows  = (await db.execute(q.offset(offset).limit(limit).order_by(PluginModel.name))).scalars().all()
    return PluginListResponse(total=total, items=[PluginResponse.model_validate(r) for r in rows])


async def get_plugin(db: AsyncSession, name: str) -> PluginResponse:
    row = await _get_or_404(db, name)
    return PluginResponse.model_validate(row)


async def update_plugin(
    db: AsyncSession, name: str, payload: PluginUpdate, updated_by: str,
) -> PluginResponse:
    row = await _get_or_404(db, name)

    if payload.source_code is not None:
        result = validate_source(payload.source_code)
        if result.status == "error":
            raise ValueError(f"Plugin validation failed: {result.error}")
        row.source_code = payload.source_code
        row.version += 1

    if payload.description is not None:
        row.description = payload.description
    if payload.is_active is not None:
        row.is_active = payload.is_active

    if payload.trigger_type is not None or payload.trigger_args is not None:
        from .trigger_calc import validate_trigger_args
        new_type = payload.trigger_type or row.trigger_type
        new_args = payload.trigger_args if payload.trigger_args is not None else row.trigger_args
        row.trigger_type = new_type
        row.trigger_args = validate_trigger_args(new_type, new_args)

    row.updated_by = updated_by

    async with db.begin():
        db.add(row)
        await db.flush()
        await _notify(db, row.name)

    await db.refresh(row)
    logger.info("Plugin updated: %s v%d by %s", row.name, row.version, updated_by)
    return PluginResponse.model_validate(row)


async def delete_plugin(db: AsyncSession, name: str) -> None:
    row = await _get_or_404(db, name)
    async with db.begin():
        await db.delete(row)
        await _notify(db, name)
    logger.info("Plugin deleted: %s", name)


# ── Validate endpoint (no DB write, no test run record) ───────────────────

def validate_plugin_source(source_code: str) -> dict:
    """
    Pure syntax + interface check. Synchronous, safe to call directly.
    Returns {"valid": bool, "error": str|None}
    """
    result = validate_source(source_code)
    return {"valid": result.status == "success", "error": result.error}


# ── Test endpoint (runs code, saves TestRun record) ───────────────────────

async def test_plugin(
    db: AsyncSession,
    source_code: str,
    extra_vars: dict,
    ran_by: str,
    schedule_id: str = "test-run",
    timeout_seconds: int = 30,
    plugin_name: str | None = None,   # if testing an existing plugin
) -> tuple[TestResult, PluginTestRunResponse]:
    """
    Runs the plugin source code in a thread pool (blocking call).
    Saves a plugin_test_runs record regardless of outcome.
    Returns (TestResult, PluginTestRunResponse).
    """
    loop = asyncio.get_running_loop()
    result: TestResult = await loop.run_in_executor(
        None, run_test, source_code, extra_vars, schedule_id, timeout_seconds
    )

    # Resolve plugin_id if a saved plugin was being tested
    plugin_id: uuid.UUID | None = None
    resolved_name = plugin_name or "unsaved"
    if plugin_name:
        row = (await db.execute(
            select(PluginModel.id).where(PluginModel.name == plugin_name)
        )).scalar_one_or_none()
        if row:
            plugin_id = row

    test_run = PluginTestRun(
        plugin_name=resolved_name,
        plugin_id=plugin_id,
        ran_by=ran_by,
        extra_vars=extra_vars,
        status=result.status,
        output=result.output[:MAX_TEST_OUTPUT] if result.output else None,
        error=result.error,
        duration_ms=result.duration_ms,
    )
    db.add(test_run)

    # Update last_test_status on the plugin row (if it exists)
    if plugin_name:
        await db.execute(
            __import__("sqlalchemy").update(PluginModel)
            .where(PluginModel.name == plugin_name)
            .values(
                last_tested_at=datetime.now(timezone.utc),
                last_test_status=result.status,
                last_test_output=(result.output or result.error or "")[:MAX_TEST_OUTPUT],
            )
        )

    await db.commit()
    await db.refresh(test_run)
    logger.info("Plugin test: %s → %s (%dms)", resolved_name, result.status, result.duration_ms or 0)
    return result, PluginTestRunResponse.model_validate(test_run)


async def list_test_runs(
    db: AsyncSession,
    plugin_name: str | None = None,
    offset: int = 0,
    limit: int = 20,
) -> list[PluginTestRunResponse]:
    q = select(PluginTestRun).order_by(PluginTestRun.ran_at.desc())
    if plugin_name:
        q = q.where(PluginTestRun.plugin_name == plugin_name)
    rows = (await db.execute(q.offset(offset).limit(limit))).scalars().all()
    return [PluginTestRunResponse.model_validate(r) for r in rows]


# ── Internal helpers ──────────────────────────────────────────────────────

async def _get_or_404(db: AsyncSession, name: str) -> PluginModel:
    row = (await db.execute(
        select(PluginModel).where(PluginModel.name == name)
    )).scalar_one_or_none()
    if not row:
        raise PluginNotFoundError(name)
    return row
