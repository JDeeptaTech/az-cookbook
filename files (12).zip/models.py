"""
scheduler/models.py — SQLAlchemy 2.x ORM models.

Three tables:
    Plugin          → platform.plugins
    PluginTestRun   → platform.plugin_test_runs
    Schedule        → platform.schedules
"""
from __future__ import annotations

import uuid
from datetime import datetime
from typing import Any

from sqlalchemy import (
    BigInteger, Boolean, CheckConstraint, DateTime,
    ForeignKey, Index, Integer, String, Text, UniqueConstraint, func,
)
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship


class Base(DeclarativeBase):
    pass


# ── Plugin ────────────────────────────────────────────────────────────────

class Plugin(Base):
    __tablename__ = "plugins"
    __table_args__ = (
        CheckConstraint(
            "trigger_type IN ('cron','interval','date')", name="ck_plugin_trigger_type"
        ),
        CheckConstraint(
            "last_test_status IN ('success','failure','error')", name="ck_plugin_test_status"
        ),
        Index("idx_plugins_is_active", "is_active"),
        {"schema": "platform"},
    )

    id:          Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    name:        Mapped[str]       = mapped_column(Text, nullable=False, unique=True)
    description: Mapped[str | None]= mapped_column(Text)
    source_code: Mapped[str]       = mapped_column(Text, nullable=False)

    trigger_type: Mapped[str]            = mapped_column(String(20), nullable=False)
    trigger_args: Mapped[dict[str, Any]] = mapped_column(JSONB, nullable=False, default=dict)

    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)
    version:   Mapped[int]  = mapped_column(Integer, nullable=False, default=1)

    last_tested_at:   Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    last_test_status: Mapped[str | None]      = mapped_column(String(20))
    last_test_output: Mapped[str | None]      = mapped_column(Text)

    created_by: Mapped[str]        = mapped_column(Text, nullable=False)
    updated_by: Mapped[str | None] = mapped_column(Text)
    created_at: Mapped[datetime]   = mapped_column(DateTime(timezone=True), server_default=func.now())
    updated_at: Mapped[datetime]   = mapped_column(DateTime(timezone=True), server_default=func.now())

    test_runs: Mapped[list[PluginTestRun]] = relationship(back_populates="plugin", lazy="noload")
    schedules: Mapped[list[Schedule]]      = relationship(back_populates="plugin", lazy="noload")


# ── PluginTestRun ─────────────────────────────────────────────────────────

class PluginTestRun(Base):
    __tablename__ = "plugin_test_runs"
    __table_args__ = (
        CheckConstraint(
            "status IN ('success','failure','error')", name="ck_test_run_status"
        ),
        Index("idx_test_runs_plugin_id", "plugin_id"),
        Index("idx_test_runs_ran_at",    "ran_at"),
        {"schema": "platform"},
    )

    id:          Mapped[uuid.UUID]  = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    plugin_name: Mapped[str]        = mapped_column(Text, nullable=False)
    plugin_id:   Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True), ForeignKey("platform.plugins.id", ondelete="SET NULL"), nullable=True
    )
    ran_by:      Mapped[str]        = mapped_column(Text, nullable=False)
    extra_vars:  Mapped[dict]       = mapped_column(JSONB, nullable=False, default=dict)
    status:      Mapped[str]        = mapped_column(String(20), nullable=False)
    output:      Mapped[str | None] = mapped_column(Text)
    error:       Mapped[str | None] = mapped_column(Text)
    duration_ms: Mapped[int | None] = mapped_column(Integer)
    ran_at:      Mapped[datetime]   = mapped_column(DateTime(timezone=True), server_default=func.now())

    plugin: Mapped[Plugin | None] = relationship(back_populates="test_runs", lazy="noload")


# ── Schedule ──────────────────────────────────────────────────────────────

class Schedule(Base):
    __tablename__ = "schedules"
    __table_args__ = (
        UniqueConstraint("name", "created_by", name="uq_schedule_name"),
        CheckConstraint(
            "trigger_type IN ('cron','interval','date')", name="ck_schedule_trigger_type"
        ),
        CheckConstraint(
            "last_run_status IN ('success','failure','running')", name="ck_schedule_run_status"
        ),
        Index("idx_schedules_poll", "next_run_at", "enabled", "locked_at",
              postgresql_where="enabled = TRUE"),
        Index("idx_schedules_plugin_name", "plugin_name"),
        Index("idx_schedules_created_by",  "created_by"),
        {"schema": "platform"},
    )

    id:          Mapped[uuid.UUID]  = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    name:        Mapped[str]        = mapped_column(Text, nullable=False)
    description: Mapped[str | None] = mapped_column(Text)

    plugin_name: Mapped[str] = mapped_column(
        Text,
        ForeignKey("platform.plugins.name", onupdate="CASCADE", ondelete="RESTRICT"),
        nullable=False,
    )

    trigger_type: Mapped[str]            = mapped_column(String(20), nullable=False)
    trigger_args: Mapped[dict[str, Any]] = mapped_column(JSONB, nullable=False)
    extra_vars:   Mapped[dict[str, Any]] = mapped_column(JSONB, nullable=False, default=dict)

    enabled: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)

    next_run_at:      Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    last_run_at:      Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    last_run_status:  Mapped[str | None]      = mapped_column(String(20))
    last_run_output:  Mapped[str | None]      = mapped_column(Text)
    run_count:        Mapped[int]             = mapped_column(BigInteger, nullable=False, default=0)
    failure_count:    Mapped[int]             = mapped_column(BigInteger, nullable=False, default=0)

    locked_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    locked_by: Mapped[str | None]      = mapped_column(Text)

    created_by: Mapped[str]        = mapped_column(Text, nullable=False)
    updated_by: Mapped[str | None] = mapped_column(Text)
    created_at: Mapped[datetime]   = mapped_column(DateTime(timezone=True), server_default=func.now())
    updated_at: Mapped[datetime]   = mapped_column(DateTime(timezone=True), server_default=func.now())

    plugin: Mapped[Plugin] = relationship(back_populates="schedules", lazy="noload")
