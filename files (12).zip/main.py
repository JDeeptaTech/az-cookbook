"""
main.py — FastAPI application.

Startup order (per worker):
  1. DB engine + session factory
  2. Plugin loader  — fetch all active plugins from DB, LISTEN 'vm_plugin_reload'
  3. Scheduler      — LISTEN 'vm_scheduler', boot-recover pending schedules
"""
from __future__ import annotations

import logging
import os
from contextlib import asynccontextmanager

from fastapi import FastAPI
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine

from scheduler.plugin_loader import init_plugin_loader, shutdown_plugin_loader
from scheduler.plugin_router  import router as plugin_router
from scheduler.schedule_router import router as schedule_router
from scheduler import scheduler as sched_module
from logging.splunk import configure_worker_logging


@asynccontextmanager
async def lifespan(app: FastAPI):
    # 1. Logging
    configure_worker_logging(level=logging.INFO)
    logger = logging.getLogger(__name__)

    # 2. DB
    engine = create_async_engine(
        os.environ["DATABASE_URL"],
        pool_size=int(os.getenv("DB_POOL_SIZE", "5")),
        max_overflow=int(os.getenv("DB_MAX_OVERFLOW", "10")),
        pool_pre_ping=True,
    )
    session_factory = async_sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)
    app.state.db_session_factory = session_factory

    # 3. Plugin loader — must come before scheduler (scheduler calls plugin_loader.get_plugin)
    await init_plugin_loader(session_factory)
    logger.info("Plugin loader ready")

    # 4. Scheduler
    sched_module.init_scheduler(session_factory)
    logger.info("Scheduler ready")

    yield

    await sched_module.stop_scheduler()
    await shutdown_plugin_loader()
    await engine.dispose()
    logger.info("Shutdown complete")


app = FastAPI(
    title="VM Platform Scheduler",
    version="3.0.0",
    lifespan=lifespan,
)

app.include_router(plugin_router,   prefix="/api/v1")
app.include_router(schedule_router, prefix="/api/v1")


@app.get("/healthz")
async def healthz():
    from scheduler.plugin_loader import list_registry
    return {
        "status": "ok",
        "plugins_loaded": len(list_registry()),
    }
