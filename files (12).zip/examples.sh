#!/usr/bin/env bash
# =============================================================================
# Complete workflow: create plugin → test → save → schedule
# =============================================================================

BASE="http://localhost:8000/api/v1"
HDRS='-H "Content-Type: application/json" -H "X-User-Id: pradeep"'

# ── Plugin source (stored in a shell var for reuse) ───────────────────────
read -r -d '' PLUGIN_SRC << 'PYSRC'
import json
import subprocess

METADATA = {
    "name":        "nightly-patch",
    "description": "OS patching playbook",
    "trigger_type": "cron",
    "trigger_args": {"hour": "2", "minute": "30"},
}

def validate_extra_vars(extra_vars):
    return [] if "env" in extra_vars else ["'env' is required"]

def run(schedule_id, extra_vars):
    cmd = ["ansible-playbook", "/playbooks/patch_vms.yml",
           "--extra-vars", json.dumps(extra_vars)]
    r = subprocess.run(cmd, capture_output=True, text=True, timeout=3600)
    return ("success" if r.returncode == 0 else "failure"), (r.stdout + r.stderr)
PYSRC

# ─────────────────────────────────────────────────────────────────────────────
# STEP 1: Validate (syntax + interface check, no execution, no DB write)
# ─────────────────────────────────────────────────────────────────────────────
echo "=== STEP 1: Validate ==="
curl -s -X POST "$BASE/plugins/validate" \
  -H "Content-Type: application/json" \
  -d "{\"source_code\": $(echo "$PLUGIN_SRC" | python3 -c 'import json,sys; print(json.dumps(sys.stdin.read()))')}" \
  | jq .
# → {"success": true, "data": {"valid": true}, "message": "Plugin is valid"}
# OR
# → {"success": false, "data": {"valid": false, "error": "SyntaxError: ..."}}


# ─────────────────────────────────────────────────────────────────────────────
# STEP 2: Test (run the code, save test run record, still no plugin saved)
# ─────────────────────────────────────────────────────────────────────────────
echo "=== STEP 2: Test (dry-run) ==="
curl -s -X POST "$BASE/plugins/test" \
  -H "Content-Type: application/json" \
  -H "X-User-Id: pradeep" \
  -d "{
    \"source_code\": $(echo "$PLUGIN_SRC" | python3 -c 'import json,sys; print(json.dumps(sys.stdin.read()))'),
    \"extra_vars\": {\"env\": \"dev\", \"inventory\": \"dev-hosts\"},
    \"timeout_seconds\": 30
  }" | jq .
# → {
#     "success": true,
#     "data": {
#       "test_run": {"id": "...", "status": "success", "output": "...", "duration_ms": 1823},
#       "result":   {"status": "success", "output": "PLAY [all] ..."}
#     }
#   }


# ─────────────────────────────────────────────────────────────────────────────
# STEP 3: Save (validates before saving; NOTIFY sent → all workers reload)
# ─────────────────────────────────────────────────────────────────────────────
echo "=== STEP 3: Save plugin ==="
curl -s -X POST "$BASE/plugins" \
  -H "Content-Type: application/json" \
  -H "X-User-Id: pradeep" \
  -d "{
    \"name\":         \"nightly-patch\",
    \"description\":  \"OS patching playbook\",
    \"trigger_type\": \"cron\",
    \"trigger_args\": {\"hour\": \"2\", \"minute\": \"30\"},
    \"source_code\": $(echo "$PLUGIN_SRC" | python3 -c 'import json,sys; print(json.dumps(sys.stdin.read()))')
  }" | jq .
# → {"success": true, "data": {"id": "...", "name": "nightly-patch", "version": 1, ...}}


# ─────────────────────────────────────────────────────────────────────────────
# STEP 4: Test the saved plugin (uses stored source, updates last_test_status)
# ─────────────────────────────────────────────────────────────────────────────
echo "=== STEP 4: Test saved plugin ==="
curl -s -X POST "$BASE/plugins/nightly-patch/test" \
  -H "Content-Type: application/json" \
  -H "X-User-Id: pradeep" \
  -d '{"extra_vars": {"env": "dev"}}' | jq .


# ─────────────────────────────────────────────────────────────────────────────
# STEP 5: Create a schedule that uses the plugin
# ─────────────────────────────────────────────────────────────────────────────
echo "=== STEP 5: Create schedule ==="
curl -s -X POST "$BASE/schedules" \
  -H "Content-Type: application/json" \
  -H "X-User-Id: pradeep" \
  -d '{
    "name":        "dev-nightly-patch",
    "description": "Dev environment nightly patching",
    "plugin_name": "nightly-patch",
    "extra_vars":  {"env": "dev", "inventory": "dev-hosts"},
    "enabled":     true
  }' | jq .
# trigger_type/trigger_args omitted → inherits from plugin defaults


# ─────────────────────────────────────────────────────────────────────────────
# Plugin management
# ─────────────────────────────────────────────────────────────────────────────

# List all plugins
curl -s "$BASE/plugins" | jq .

# List only active plugins
curl -s "$BASE/plugins?is_active=true" | jq .

# Get in-memory registry state (per-worker)
curl -s "$BASE/plugins/registry" | jq .

# View test run history for a plugin
curl -s "$BASE/plugins/nightly-patch/test-runs" | jq .

# Update source code (bumps version, validates, NOTIFY sent)
curl -s -X PUT "$BASE/plugins/nightly-patch" \
  -H "Content-Type: application/json" \
  -H "X-User-Id: pradeep" \
  -d "{\"source_code\": $(echo "$PLUGIN_SRC" | python3 -c 'import json,sys; print(json.dumps(sys.stdin.read()))')}" \
  | jq .

# Deactivate a plugin (existing schedules will fail gracefully)
curl -s -X PUT "$BASE/plugins/nightly-patch" \
  -H "Content-Type: application/json" \
  -H "X-User-Id: pradeep" \
  -d '{"is_active": false}' | jq .

# Delete a plugin (fails if schedules reference it)
curl -s -X DELETE "$BASE/plugins/nightly-patch" | jq .
# → 409 if schedules still reference it


# ─────────────────────────────────────────────────────────────────────────────
# Schedule management (same as before)
# ─────────────────────────────────────────────────────────────────────────────

SCHEDULE_ID="<uuid>"

# Override trigger per-schedule
curl -s -X PATCH "$BASE/schedules/$SCHEDULE_ID" \
  -H "Content-Type: application/json" \
  -H "X-User-Id: pradeep" \
  -d '{"trigger_type": "cron", "trigger_args": {"hour": "4", "minute": "0"}}' | jq .

# List schedules by plugin
curl -s "$BASE/schedules?plugin_name=nightly-patch" | jq .

# Disable / enable
curl -s -X POST "$BASE/schedules/$SCHEDULE_ID/disable" -H "X-User-Id: pradeep" | jq .
curl -s -X POST "$BASE/schedules/$SCHEDULE_ID/enable"  -H "X-User-Id: pradeep" | jq .
