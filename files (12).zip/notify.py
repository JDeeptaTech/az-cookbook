"""scheduler/notify.py — pg_notify helpers (issued inside open transactions)."""
from __future__ import annotations
import json, os
from datetime import datetime
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

NOTIFY_CHANNEL = os.getenv("SCHEDULER_NOTIFY_CHANNEL", "vm_scheduler")

async def notify_schedule_updated(session: AsyncSession, schedule_id: str, next_run_at: datetime | None) -> None:
    payload = json.dumps({"id": schedule_id, "next_run_at": next_run_at.isoformat() if next_run_at else None})
    await session.execute(text(f"SELECT pg_notify('{NOTIFY_CHANNEL}', :p)"), {"p": payload})

async def notify_schedule_deleted(session: AsyncSession, schedule_id: str) -> None:
    await notify_schedule_updated(session, schedule_id, None)
